﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_topsecond_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
		let normal_battery_text_text_img2 = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_hour_cover_pointer_img = ''
        let normal_time_circle_scale = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_system_disconnect_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
		let calendar_btn = ''
		let battery_btn = ''
		let activity_btn = ''
		let btncolor = ''
		let btncontent = ''
		let colornumber = 1
        let totalcolors = 9
		let element_index = 1;
        let element_count = 2;
		
		function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
			{
                 if(colornumber==2) hmUI.showToast({text: 'C Y A N'});
				 if(colornumber==3) hmUI.showToast({text: 'R E D'});
                 if(colornumber==4) hmUI.showToast({text: 'Y E L L O W'});
				 if(colornumber==5) hmUI.showToast({text: 'P U R P L E'});
                 if(colornumber==6) hmUI.showToast({text: 'G R E E N'});
				 if(colornumber==7) hmUI.showToast({text: 'B L U E'});
				 if(colornumber==8) hmUI.showToast({text: 'F U C H S I A'});
				 if(colornumber==9) hmUI.showToast({text: 'C O L O R L E S S'});
            }
            if(colornumber==1) hmUI.showToast({text: 'O R A N G E'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "back" + parseInt(colornumber) + ".png");
        }
		
		function click_btn() {
              element_index++;
              if(element_index > element_count) element_index = 1;

              normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  calendar_btn.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_image_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_battery_text_text_img2.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  activity_btn.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              if (element_index == 1) {
                 hmUI.showToast({text: 'Time & Calendar'});
               };
              if (element_index == 2) {
                 hmUI.showToast({text: 'Activity'});
               };
            };


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'back1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_image_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'panel1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 128,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_battery_text_text_img2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 203,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_text_img2.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 230,
              image_array: ["batt_00.png","batt_01.png","batt_02.png","batt_03.png","batt_04.png","batt_05.png","batt_06.png","batt_07.png","batt_08.png","batt_09.png","batt_10.png","batt_11.png","batt_12.png","batt_13.png","batt_14.png"],
              image_length: 15,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 83,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'numd_15.png',
              unit_tc: 'numd_15.png',
              unit_en: 'numd_15.png',
              imperial_unit_sc: 'numd_16.png',
              imperial_unit_tc: 'numd_16.png',
              imperial_unit_en: 'numd_16.png',
              dot_image: 'numd_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 83,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 203,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 203,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 108,
              y: 112,
              image_array: ["steps_01.png","steps_02.png","steps_03.png","steps_04.png","steps_05.png","steps_06.png","steps_07.png","steps_08.png","steps_09.png","steps_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 94,

              y: 78,
              w: 265,
              h: 28,
              text_size: 20,
              char_space: 1,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 203,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'numd_12.png',
              unit_tc: 'numd_12.png',
              unit_en: 'numd_12.png',
              negative_image: 'numd_11.png',
              invalid_image: 'numd_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 34,
              y: 254,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 153,
              month_startY: 201,
              month_sc_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_tc_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_en_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 203,
              day_sc_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_tc_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_en_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 230,
              week_en: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_tc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_sc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 114,
              hour_array: ["bigd_00.png","bigd_01.png","bigd_02.png","bigd_03.png","bigd_04.png","bigd_05.png","bigd_06.png","bigd_07.png","bigd_08.png","bigd_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 233,
              minute_startY: 114,
              minute_array: ["bigd_00.png","bigd_01.png","bigd_02.png","bigd_03.png","bigd_04.png","bigd_05.png","bigd_06.png","bigd_07.png","bigd_08.png","bigd_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 325,
              second_startY: 115,
              second_array: ["secd_00.png","secd_01.png","secd_02.png","secd_03.png","secd_04.png","secd_05.png","secd_06.png","secd_07.png","secd_08.png","secd_09.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 136,
              src: 'bigd_dots.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 242,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 396,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'numd_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'ana_hour.png',
              hour_centerX: 318,
              hour_centerY: 322,
              hour_posX: 43,
              hour_posY: 43,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'ana_min.png',
              minute_centerX: 318,
              minute_centerY: 322,
              minute_posX: 43,
              minute_posY: 43,
              minute_cover_path: 'ana_top.png',
              minute_cover_x: 277,
              minute_cover_y: 281,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'ana_24.png',
              // center_x: 121,
              // center_y: 323,
              // x: 4,
              // y: 26,
              // start_angle: 0,
              // end_angle: 360,
              // cover_path: 'ana_24_top.png',
              // cover_x: 112,
              // cover_y: 314,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });



            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 121 - 4,
              pos_y: 323 - 26,
              center_x: 121,
              center_y: 323,
              src: 'ana_24.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_pro_hour_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 314,
              src: 'ana_24_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'ana_sec.png',
              // center_x: 204,
              // center_y: 322,
              // x: 9,
              // y: 26,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


          // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          //    x: 0,
          //    y: 0,
           //   w: deviceInfo.width,
           //   h: deviceInfo.height,
           //   pos_x: 204 - 9,
           //   pos_y: 322 - 27,
           //   center_x: 202,
           //   center_y: 322,
            //  src: 'ana_sec.png',
            //  angle: 0,
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            //});

  normal_time_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 202,
              center_y: 322,
              start_angle: 0,
              end_angle: 369,
              radius: 19,
              line_width: 14,
              corner_flag: 0,
              color: 0xFF999999,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

          const time = hmSensor.createSensor(hmSensor.id.TIME);


         time.addEventListener(hmSensor.event.CHANGE, function() {
         //scale_call();
         });

            function second_circle_call() {

                console.log('update scales TIME');
                
                let valueTime = time.second;
                let targetTime = 60;
                let progressTime = valueTime/targetTime;
                if (progressTime > 1) progressTime = 1;
                let progress_cs_normal_time = progressTime;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_time_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_time * 100);

                    if (normal_time_circle_scale) {
                    normal_time_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 204,
                      center_y: 322,
                      start_angle: 0,
                       end_angle: 369,
                      radius: 19,
                      line_width: 14,
                      corner_flag: 0,
                      color: 0xFF999999,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                     level: level,
                

                    });
                  };
                };

            };

function startInterval() {
let intervalId = setInterval(second_circle_call, 1000); // เรียกใช้ฟังก์ชัน scale_call() ทุก 1 วินาที (1000 มิลลิวินาที)
}
startInterval();


            normal_topsecond_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 296,
              src: 'Topsecond.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
          //   normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 107,
              y: 58,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 58,
              src: 'status_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 203,
              font_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 153,
              month_startY: 201,
              month_sc_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_tc_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_en_array: ["monthd_01.png","monthd_02.png","monthd_03.png","monthd_04.png","monthd_05.png","monthd_06.png","monthd_07.png","monthd_08.png","monthd_09.png","monthd_10.png","monthd_11.png","monthd_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 330,
              day_startY: 202,
              day_sc_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_tc_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_en_array: ["numd_00.png","numd_01.png","numd_02.png","numd_03.png","numd_04.png","numd_05.png","numd_06.png","numd_07.png","numd_08.png","numd_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 129,
              hour_startY: 114,
              hour_array: ["bigd_00.png","bigd_01.png","bigd_02.png","bigd_03.png","bigd_04.png","bigd_05.png","bigd_06.png","bigd_07.png","bigd_08.png","bigd_09.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 233,
              minute_startY: 114,
              minute_array: ["bigd_00.png","bigd_01.png","bigd_02.png","bigd_03.png","bigd_04.png","bigd_05.png","bigd_06.png","bigd_07.png","bigd_08.png","bigd_09.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 136,
              src: 'bigd_dots.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'aod_time_am.png',
              am_en_path: 'aod_time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'aod_time_pm.png',
              pm_en_path: 'aod_time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 117,
              y: 93,
              src: 'aod_status_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 284,
              w: 80,
              h: 80,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 284,
              w: 80,
              h: 80,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 373,
              y: 249,
              w: 52,
              h: 52,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 52,
              w: 94,

              h: 28,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 392,
              w: 170,
              h: 38,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 249,
              w: 52,
              h: 52,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 194,
              w: 57,
              h: 38,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 284,
              w: 80,
              h: 80,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 80,
              w: 94,

              h: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,

              y: 80,
              w: 146,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 194,
              w: 57,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 194,
              w: 128,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			
			btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 161,
              y: 9,

              text: '',
              w: 132,
              h: 42,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			btncontent = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 378,
              y: 104,
              text: '',
              w: 38,
              h: 94,

              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_btn();
			   vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			activity_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 156,
			  text: '',
              w: 90,
              h: 24,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'SportScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			activity_btn.setProperty(hmUI.prop.VISIBLE, false);
			
			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 194,
			  text: '',
              w: 222,
              h: 38,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 38,
              y: 104,
			  text: '',
              w: 38,
              h: 94,

              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

            };


            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                //normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}