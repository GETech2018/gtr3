﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                let element_index = 1;
                let element_count = 2;
		
		      function click_Content() {
              element_index++;
              if(element_index > element_count) element_index = 1;
			  
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
	
				  
			  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);


              	  
              if (element_index == 2) {
                 hmUI.showToast({text: 'ЦИФРЫ'});
               };
              if (element_index == 1) {
                 hmUI.showToast({text: 'СТРЕЛКИ'});
               };
        };
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_frame_animation_1 = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 390,
              src: 'Bluetoothe.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 206,
              y: 411,
              src: 'alram_no_data.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 270,
              year_startY: 150,
              year_sc_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              year_tc_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              year_en_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 143,
              month_sc_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              month_tc_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              month_en_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 321,
              font_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BiGm_10.png',
              unit_tc: 'BiGm_10.png',
              unit_en: 'BiGm_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 324,
              font_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display
              
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 154,
              y: 347,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              color: 0xFFA48C71,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 313,
              font_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'BiGm_11.png',
              unit_tc: 'BiGm_11.png',
              unit_en: 'BiGm_11.png',
              negative_image: 'BiGm_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 150,
              font_array: ["BiGm_0.png","BiGm_1.png","BiGm_2.png","BiGm_3.png","BiGm_4.png","BiGm_5.png","BiGm_6.png","BiGm_7.png","BiGm_8.png","BiGm_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 188,
              day_startY: 80,
              day_sc_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              day_tc_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              day_en_array: ["BiGs_0.png","BiGs_1.png","BiGs_2.png","BiGs_3.png","BiGs_4.png","BiGs_5.png","BiGs_6.png","BiGs_7.png","BiGs_8.png","BiGs_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'StRh.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Strm.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'StRs.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 195,
              hour_array: ["BiGd_0.png","BiGd_1.png","BiGd_2.png","BiGd_3.png","BiGd_4.png","BiGd_5.png","BiGd_6.png","BiGd_7.png","BiGd_8.png","BiGd_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 195,
              minute_array: ["BiGd_0.png","BiGd_1.png","BiGd_2.png","BiGd_3.png","BiGd_4.png","BiGd_5.png","BiGd_6.png","BiGd_7.png","BiGd_8.png","BiGd_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display
            
            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 190,
              src: 'BiGd_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Anim",
              anim_fps: 15,
              anim_size: 22,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 46,
              y: 130,
              w: 118,
              h: 53,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 280,
              w: 100,
              h: 70,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 300,
              w: 100,
              h: 73,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 194,
              w: 71,
              h: 72,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 390,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -8,
              y: 194,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_emtry.png',
              normal_src: '0_emtry.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PhoneMusicCtrlScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 364,
              y: 194,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_emtry.png',
              normal_src: '0_emtry.png',
              click_func: (button_widget) => {
                click_Content();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 64,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_emtry.png',
              normal_src: '0_emtry.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}