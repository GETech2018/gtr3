﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_image_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'ZBackground01.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'ZBackground02.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'ZBackground03.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'ZBackground04.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'ZBackground05.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'ZBackground06.png' },
              ],
              count: 6,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 411,
              src: 'IconAlertStrip.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 259,
              y: 418,
              src: 'IconLock2.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 229,
              y: 418,
              src: 'IconAudio2.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 418,
              src: 'IconBT2.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 201,
              y: 418,
              src: 'IconBell2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 353,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 350,
              y: 351,
              src: 'IconO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 283,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              dot_image: 'SymbolDot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 389,
              y: 283,
              src: 'IconRoute.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 176,
              y: 15,
              src: 'Trophy00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 218,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 406,
              y: 216,
              src: 'IconFeet.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [176,176,176,176,176,176,176,176,176,176],
              y: [15,15,15,15,15,15,15,15,15,15],
              image_array: ["Trophy01.png","Trophy02.png","Trophy03.png","Trophy04.png","Trophy05.png","Trophy06.png","Trophy07.png","Trophy08.png","Trophy09.png","Trophy10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 322,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 323,
              src: 'IconHeart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 278,
              image_array: ["GaugeH01.png","GaugeH02.png","GaugeH03.png","GaugeH04.png","GaugeH05.png","GaugeH06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 106,
              font_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 262,
              y: 109,
              src: 'IconBattery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 267,
              y: 63,
              image_array: ["Gauge00.png","Gauge01.png","Gauge02.png","Gauge03.png","Gauge04.png","Gauge05.png","Gauge06.png","Gauge07.png","Gauge08.png","Gauge09.png","Gauge10.png","Gauge11.png","Gauge12.png","Gauge13.png","Gauge14.png","Gauge15.png","Gauge16.png","Gauge17.png","Gauge18.png","Gauge19.png","Gauge20.png","Gauge21.png","Gauge22.png","Gauge23.png","Gauge24.png","Gauge25.png"],
              image_length: 26,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 69,
              year_startY: 100,
              year_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              year_zero: 1,
              year_space: 5,
              year_unit_sc: 'SymbolDash.png',
              year_unit_tc: 'SymbolDash.png',
              year_unit_en: 'SymbolDash.png',
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 100,
              month_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 163,
              day_startY: 64,
              day_sc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_tc_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_en_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 64,
              week_en: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_tc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              week_sc: ["Weekday1.png","Weekday2.png","Weekday3.png","Weekday4.png","Weekday5.png","Weekday6.png","Weekday7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 142,
              hour_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_unit_sc: 'SymbolColon.png',
              hour_unit_tc: 'SymbolColon.png',
              hour_unit_en: 'SymbolColon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 125,
              minute_startY: 142,
              minute_array: ["DigitL0.png","DigitL1.png","DigitL2.png","DigitL3.png","DigitL4.png","DigitL5.png","DigitL6.png","DigitL7.png","DigitL8.png","DigitL9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 161,
              second_startY: 218,
              second_array: ["DigitS0.png","DigitS1.png","DigitS2.png","DigitS3.png","DigitS4.png","DigitS5.png","DigitS6.png","DigitS7.png","DigitS8.png","DigitS9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 15,
              y: 218,
              src: 'Meridian24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 15,
              am_y: 218,
              am_sc_path: 'MeridianAM.png',
              am_en_path: 'MeridianAM.png',
              pm_x: 15,
              pm_y: 218,
              pm_sc_path: 'MeridianPM.png',
              pm_en_path: 'MeridianPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: Disconnected,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnected"});
                  vibro(25);
                }
                if(status) {
                  hmUI.showToast({text: "Connected"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ZFace.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 41,
              y: 136,
              w: 161,
              h: 108,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 62,
              w: 127,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 406,
              w: 130,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 335,
              w: 120,
              h: 52,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 256,
              w: 141,
              h: 141,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 257,
              y: 219,
              w: 164,
              h: 103,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}