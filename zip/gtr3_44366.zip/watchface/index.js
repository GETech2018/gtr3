﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_date_img_date_year = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg147.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 175,
              month_startY: 265,
              month_sc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_tc_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_en_array: ["0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 30,
              hour_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              hour_zero: 1,
              hour_space: -11,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 198,
              minute_startY: 30,
              minute_array: ["CLOCK_0.png","CLOCK_1.png","CLOCK_2.png","CLOCK_3.png","CLOCK_4.png","CLOCK_5.png","CLOCK_6.png","CLOCK_7.png","CLOCK_8.png","CLOCK_9.png"],
              minute_zero: 1,
              minute_space: -11,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 316,
              second_startY: 59,
              second_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              second_zero: 1,
              second_space: -6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 170,
              src: '0500.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 407,
              y: 170,
              src: '0501.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 296,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 75,
              year_startY: 265,
              year_sc_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              year_tc_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              year_en_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              year_zero: 1,
              year_space: -4,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BATTERYLEVEL.png',
              center_x: 136,
              center_y: 198,
              x: 58,
              y: 57,
              start_angle: -180,
              end_angle: 180,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 340,
              font_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 192,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 223,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -7,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 192,
              font_array: ["NUMBERS_SMALL_0.png","NUMBERS_SMALL_1.png","NUMBERS_SMALL_2.png","NUMBERS_SMALL_3.png","NUMBERS_SMALL_4.png","NUMBERS_SMALL_5.png","NUMBERS_SMALL_6.png","NUMBERS_SMALL_7.png","NUMBERS_SMALL_8.png","NUMBERS_SMALL_9.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'ICON_KM.png',
              unit_tc: 'ICON_KM.png',
              unit_en: 'ICON_KM.png',
              dot_image: 'NUMBERS_SMALL_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 320,
              day_startY: 267,
              day_sc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_tc_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_en_array: ["NUMBERS_BIG_0.png","NUMBERS_BIG_1.png","NUMBERS_BIG_2.png","NUMBERS_BIG_3.png","NUMBERS_BIG_4.png","NUMBERS_BIG_5.png","NUMBERS_BIG_6.png","NUMBERS_BIG_7.png","NUMBERS_BIG_8.png","NUMBERS_BIG_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 340,
              image_array: ["WEATHERICON_1.png","WEATHERICON_2.png","WEATHERICON_3.png","WEATHERICON_4.png","WEATHERICON_5.png","WEATHERICON_6.png","WEATHERICON_7.png","WEATHERICON_8.png","WEATHERICON_9.png","WEATHERICON_10.png","WEATHERICON_11.png","WEATHERICON_12.png","WEATHERICON_13.png","WEATHERICON_14.png","WEATHERICON_15.png","WEATHERICON_16.png","WEATHERICON_17.png","WEATHERICON_18.png","WEATHERICON_19.png","WEATHERICON_20.png","WEATHERICON_21.png","WEATHERICON_22.png","WEATHERICON_23.png","WEATHERICON_24.png","WEATHERICON_25.png","WEATHERICON_26.png","WEATHERICON_27.png","WEATHERICON_28.png","WEATHERICON_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 331,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -6,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              invalid_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 236,
              y: 361,
              font_array: ["NUMBERS_MINI_0.png","NUMBERS_MINI_1.png","NUMBERS_MINI_2.png","NUMBERS_MINI_3.png","NUMBERS_MINI_4.png","NUMBERS_MINI_5.png","NUMBERS_MINI_6.png","NUMBERS_MINI_7.png","NUMBERS_MINI_8.png","NUMBERS_MINI_9.png"],
              padding: false,
              h_space: -6,
              negative_image: 'ICON_NEGATIVE_MINI.png',
              invalid_image: 'ICON_NEGATIVE_MINI.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 340,
              font_array: ["NUMBERS_MEDIUM_0.png","NUMBERS_MEDIUM_1.png","NUMBERS_MEDIUM_2.png","NUMBERS_MEDIUM_3.png","NUMBERS_MEDIUM_4.png","NUMBERS_MEDIUM_5.png","NUMBERS_MEDIUM_6.png","NUMBERS_MEDIUM_7.png","NUMBERS_MEDIUM_8.png","NUMBERS_MEDIUM_9.png"],
              padding: false,
              h_space: -7,
              unit_sc: 'ICON_TEMP.png',
              unit_tc: 'ICON_TEMP.png',
              unit_en: 'ICON_TEMP.png',
              negative_image: 'ICON_NEGATIVE.png',
              invalid_image: 'ICON_NEGATIVE.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bgaod2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0103.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 26,
              hour_posY: 136,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0104.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 26,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0105.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 208,
              second_cover_path: 'bg_fill_20.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 52,
              w: 76,
              h: 76,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 33,
              w: 95,
              h: 95,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 393,
              y: 180,
              w: 57,
              h: 95,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 14,
              y: 151,
              w: 66,
              h: 113,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 142,
              y: 336,
              w: 180,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 284,
              w: 95,
              h: 76,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 132,
              w: 189,
              h: 95,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 151,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 265,
              w: 246,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'BUTTON.png',
              normal_src: 'BUTTON.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}