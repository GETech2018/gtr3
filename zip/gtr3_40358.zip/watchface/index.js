﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 279,
              src: 'BLOCKED.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 398,
              src: 'CONNECTED.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 279,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 283,
              font_array: ["N_4_00.png","N_4_01.png","N_4_02.png","N_4_03.png","N_4_04.png","N_4_05.png","N_4_06.png","N_4_07.png","N_4_08.png","N_4_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["BAT_01.png","BAT_02.png","BAT_03.png","BAT_04.png","BAT_05.png","BAT_06.png","BAT_07.png","BAT_08.png","BAT_09.png","BAT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 81,
              font_array: ["N_5_00.png","N_5_01.png","N_5_02.png","N_5_03.png","N_5_04.png","N_5_05.png","N_5_06.png","N_5_07.png","N_5_08.png","N_5_09.png"],
              padding: false,
              h_space: -5,
              negative_image: 'N_5_MINUS.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 137,
              y: 114,
              image_array: ["WTR_00.png","WTR_01.png","WTR_02.png","WTR_03.png","WTR_04.png","WTR_05.png","WTR_06.png","WTR_07.png","WTR_08.png","WTR_09.png","WTR_10.png","WTR_11.png","WTR_12.png","WTR_13.png","WTR_14.png","WTR_15.png","WTR_16.png","WTR_17.png","WTR_18.png","WTR_19.png","WTR_20.png","WTR_21.png","WTR_22.png","WTR_23.png","WTR_24.png","WTR_25.png","WTR_26.png","WTR_27.png","WTR_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 354,
              font_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              padding: true,
              h_space: -3,
              unit_sc: 'N_2_KM.png',
              unit_tc: 'N_2_KM.png',
              unit_en: 'N_2_KM.png',
              dot_image: 'N_2_PNT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 302,
              font_array: ["N_3_00.png","N_3_01.png","N_3_02.png","N_3_03.png","N_3_04.png","N_3_05.png","N_3_06.png","N_3_07.png","N_3_08.png","N_3_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 128,
              y: 152,
              week_en: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_tc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_sc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 277,
              year_startY: 152,
              year_sc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              year_tc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              year_en_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              year_zero: 1,
              year_space: -3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 152,
              month_sc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              month_tc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              month_en_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 152,
              day_sc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              day_tc_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              day_en_array: ["N_2_00.png","N_2_01.png","N_2_02.png","N_2_03.png","N_2_04.png","N_2_05.png","N_2_06.png","N_2_07.png","N_2_08.png","N_2_09.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 192,
              hour_array: ["N_1_00.png","N_1_01.png","N_1_02.png","N_1_03.png","N_1_04.png","N_1_05.png","N_1_06.png","N_1_07.png","N_1_08.png","N_1_09.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 265,
              minute_startY: 192,
              minute_array: ["N_1_00.png","N_1_01.png","N_1_02.png","N_1_03.png","N_1_04.png","N_1_05.png","N_1_06.png","N_1_07.png","N_1_08.png","N_1_09.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 198,
              second_startY: 209,
              second_array: ["N_5_00.png","N_5_01.png","N_5_02.png","N_5_03.png","N_5_04.png","N_5_05.png","N_5_06.png","N_5_07.png","N_5_08.png","N_5_09.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'ARROW.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}