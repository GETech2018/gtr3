﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_pai_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_stress_icon_img = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_pai_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_stress_icon_img = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
    
        function click_zona1() {
          zona1_num = (zona1_num + 1) % (zona1_all + 1);

          if (zona1_num == 0) {
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({
              text: 'Calories'
            });
          };

          if (zona1_num == 1) {
            normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
            hmUI.showToast({
              text: 'Distance'
            });
          };
        }

                // aod changer start

                let btn_aod = ''

                let curAODmode = 0;			// 0 - пусто
                                        // 1 - минимальный
                        // 2 - информативный
        
                let AODmodes = ["no aod", "minimum aod", "maximum aod"];
                let AODmodeCaption;
        
                function toggleAODmode() {
                    curAODmode = (curAODmode + 1) % AODmodes.length;
                    hmFS.SysProSetInt('parkur_aod', curAODmode);
        
                    switch (curAODmode) {
                        case 0:
                            AODmodeCaption = "no aod";
                            break;
                        case 1:
                            AODmodeCaption = "minimum aod";
                            break;
                        case 2:
                            AODmodeCaption = "maximum aod";
                            break;
                        default:
                            AODmodeCaption = "";
                            break;
                    }
        
                    hmUI.showToast({ text: 'AOD: ' + AODmodeCaption });
                }
        
                function makeAOD() {
        
                    let mode = hmFS.SysProGetInt('parkur_aod');
        
                    if (mode == 1) {    // минимальный
        
                      idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 34,
                        hour_startY: 192,
                        hour_array: ["A100_128.png","A100_129.png","A100_130.png","A100_131.png","A100_132.png","A100_133.png","A100_134.png","A100_135.png","A100_136.png","A100_137.png"],
                        hour_zero: 1,
                        hour_space: 0,
                        hour_align: hmUI.align.CENTER_H,
          
                        minute_startX: 256,
                        minute_startY: 192,
                        minute_array: ["A100_128.png","A100_129.png","A100_130.png","A100_131.png","A100_132.png","A100_133.png","A100_134.png","A100_135.png","A100_136.png","A100_137.png"],
                        minute_zero: 1,
                        minute_space: 0,
                        minute_follow: 0,
                        minute_align: hmUI.align.CENTER_H,
          
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
                  
                    }
        
                    if (mode == 2) {			// средний
        
                      idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: '0xFF000000',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        minute_path: 'A100_010_black.png',
                        minute_centerX: 227,
                        minute_centerY: 227,
                        minute_posX: 227,
                        minute_posY: 227,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        second_path: 'A100_012.png',
                        second_centerX: 227,
                        second_centerY: 227,
                        second_posX: 131,
                        second_posY: 131,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        src: 'A100_014.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 124,
                        y: 380,
                        src: 'A100_083.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 193,
                        y: 403,
                        font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
                        padding: false,
                        h_space: -2,
                        align_h: hmUI.align.LEFT,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 0,
                        y: 73,
                        image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
                        image_length: 10,
                        type: hmUI.data_type.BATTERY,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 174,
                        y: 280,
                        image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
                        image_length: 30,
                        type: hmUI.data_type.MOON,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 185,
                        y: 112,
                        font_array: ["A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png"],
                        padding: false,
                        h_space: -2,
                        negative_image: 'A100_067.png',
                        invalid_image: 'A100_067.png',
                        align_h: hmUI.align.CENTER_H,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: 65,
                        y: 73,
                        image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
                        image_length: 29,
                        type: hmUI.data_type.WEATHER_CURRENT,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 133,
                        y: 351,
                        font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
                        padding: false,
                        h_space: -2,
                        dot_image: 'dot_1.png',
                        align_h: hmUI.align.LEFT,
                        type: hmUI.data_type.DISTANCE,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 93,
                        y: 352,
                        src: 'distance.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 54,
                        y: 289,
                        src: 'heart.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 92,
                        y: 288,
                        font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
                        padding: false,
                        h_space: -3,
                        align_h: hmUI.align.LEFT,
                        type: hmUI.data_type.HEART,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 30,
                        y: 174,
                        src: 'A100_026.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 26,
                        y: 203,
                        font_array: ["A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png"],
                        padding: false,
                        h_space: -2,
                        align_h: hmUI.align.CENTER_H,
                        type: hmUI.data_type.STEP,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        day_startX: 187,
                        day_startY: 44,
                        day_sc_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
                        day_tc_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
                        day_en_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
                        day_zero: 1,
                        day_space: -4,
                        day_align: hmUI.align.CENTER_H,
                        day_is_character: false,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                        x: 167,
                        y: 9,
                        week_en: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
                        week_tc: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
                        week_sc: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                        month_startX: 253,
                        month_startY: 8,
                        month_sc_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
                        month_tc_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
                        month_en_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
                        month_is_character: true ,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 136,
                        y: 174,
                        src: 'A100_117.png',
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
          
                      idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
                        hour_startX: 148,
                        hour_startY: 187,
                        hour_array: ["A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
                        hour_zero: 1,
                        hour_space: -5,
                        hour_align: hmUI.align.LEFT,
                        show_level: hmUI.show_level.ONLY_AOD,
                      });
                  }
                }

                function loadSettings() {
                  if (hmFS.SysProGetInt('parkur_aod') === undefined) {
                      curAODmode = 1;
                      hmFS.SysProSetInt('parkur_aod', curAODmode);
                  } else {
                      curAODmode = hmFS.SysProGetInt('parkur_aod');
                  }
              }
              
        // aod changer end \\
        
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        
        /**
         * SMOOTH SECONDS SCRIPTS
         */
         let now;
         let lastTime = 0;
         let animTimer;
         let widgetDelegate;
         const animDuration = 5000;
         const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
     
         function setSec() {
           const screenType = hmSetting.getScreenType();
           if (screenType === hmSetting.screen_type.AOD) {
             return stopSecAnim();
           }
           if (!now) {
             now = hmSensor.createSensor(hmSensor.id.TIME);
           }
           if (widgetDelegate) return;
     
           widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
             resume_call: (function () {
               console.log('ui resume');
     
               if (animTimer) return;
     
               let duration = 0;
               const diffTime = now.utc - lastTime;
               if (diffTime < animDuration) {
                 duration = animDuration - diffTime;
               }
     
               animTimer = timer.createTimer(duration, animDuration, (function (option) {
                 lastTime = now.utc;
                 startSecAnim(now.second * 6);
               }));
             }),
             pause_call: (function () {
               console.log('ui pause');
               stopSecAnim();
             }),
           });
         }
     
         function startSecAnim(sec) {
           const secAnim = {
             anim_rate: 'linear',
             anim_duration: animDuration,
             anim_from: sec,
             anim_to: sec + animDuration * 6 / 1000,
             repeat_count: 1,
             anim_fps: animFps,
             anim_key: "angle",
             anim_status: 1,
           }

           normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
         }
     
         /**
          * onDestroy()
          */
         function stopSecAnim() {
           if (animTimer) {
             timer.stopTimer(animTimer);
             animTimer = undefined;
           }
         }
     
         /** END SMOOTH SECOND SCRIPTS */

        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

        //hands postitions
        //let hourx = 32
        //let houry = 206
        let minutex = 227
        let minutey = 227
        //let secondx = 35
        //let secondy = 226

        // Start color change
        let btncolor = ''
        let colornumber = 0
        let totalcolors = 4

        function click_Color() {
            colornumber=(colornumber+1) % (totalcolors+1);
            click_Vibrate();
            hmUI.showToast({text: "Minute color " + parseInt(colornumber) });

            //call hands function to change to correct hands
            call_change_Hands(colornumber);
        }
		  
        // Give handsnumber. Must exist
        function call_change_Hands(handsnumber) {
           switch (handsnumber) {
               case 1:
                  //hourstring='p_h_01.png';
                  minutestring='A100_010_black.png'; break;
                  //secondstring='p_s_01.png'; break;
               case 2:
                  //hourstring='p_h_02.png';
                  minutestring='A100_010_blue.png'; break;
                  //secondstring='p_s_02.png'; break;
               case 3:
                  //hourstring='cl_4.png';
                  minutestring='A100_010_red.png'; break;
                  //secondstring='cl_6.png'; break;
               case 4:
                  //hourstring='cl_4.png';
                  minutestring='A100_010_green.png'; break;
                  //secondstring='cl_6.png'; break;
               default:
                  //hourstring='cl_1.png';
                  minutestring='A100_010.png'; break;
                  //secondstring='cl_3.png'; break;
             }

             normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
             minute_path: minutestring,
             minute_centerX: 227,
             minute_centerY: 227,
             minute_posX: minutex,
             minute_posY: minutey,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

        }    

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'A100_010.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'A100_012.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 131,
              second_posY: 131,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            // Smooth Seconds
            //normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
            //  x: 0,
            //  y: 0,
            //  w: 454,
            //  h: 454,
            //  pos_x: 454 / 2 - 131,
            //  pos_y: 454 / 2 - 131,
            //  center_x: 227,
            //  center_y: 227,
            //  src: "A100_012.png",
            //  angle: 0,
            //  show_level: hmUI.show_level.ONLY_NORMAL,
            //});
            //setSec();
 
            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_014.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 102,
              y: 42,
              src: 'y1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 132,
              y: 25,
              src: 'y2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 124,
              y: 380,
              src: 'A100_083.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 403,
              font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 73,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 280,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 112,
              font_array: ["A100_057.png","A100_058.png","A100_059.png","A100_060.png","A100_061.png","A100_062.png","A100_063.png","A100_064.png","A100_065.png","A100_066.png"],
              padding: false,
              h_space: -2,
              negative_image: 'A100_067.png',
              invalid_image: 'A100_067.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 73,
              image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 351,
              font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              padding: false,
              h_space: -2,
              dot_image: 'dot_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 93,
              y: 352,
              src: 'distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 351,
              src: 'cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 351,
              font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 289,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 288,
              font_array: ["A100_069.png","A100_070.png","A100_071.png","A100_072.png","A100_073.png","A100_074.png","A100_075.png","A100_076.png","A100_077.png","A100_078.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 30,
              y: 174,
              src: 'A100_026.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 203,
              font_array: ["A100_016.png","A100_017.png","A100_018.png","A100_019.png","A100_020.png","A100_021.png","A100_022.png","A100_023.png","A100_024.png","A100_025.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 44,
              day_sc_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
              day_tc_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
              day_en_array: ["A100_107.png","A100_108.png","A100_109.png","A100_110.png","A100_111.png","A100_112.png","A100_113.png","A100_114.png","A100_115.png","A100_116.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 167,
              y: 9,
              week_en: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
              week_tc: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
              week_sc: ["A100_100.png","A100_101.png","A100_102.png","A100_103.png","A100_104.png","A100_105.png","A100_106.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 8,
              month_sc_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
              month_tc_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
              month_en_array: ["A100_088.png","A100_089.png","A100_090.png","A100_091.png","A100_092.png","A100_093.png","A100_094.png","A100_095.png","A100_096.png","A100_097.png","A100_098.png","A100_099.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 174,
              src: 'A100_117.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 148,
              hour_startY: 187,
              hour_array: ["A100_118.png","A100_119.png","A100_120.png","A100_121.png","A100_122.png","A100_123.png","A100_124.png","A100_125.png","A100_126.png","A100_127.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // смена цвета минут
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 194,
              text: '',
              w: 70,
              h: 66,
              normal_src: 'null.png',
              press_src: 'null.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //конец смены цвета минут
            
      // календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 172,
			  y: 12,
			  text: '',
			  w: 70,
			  h: 80,
			  normal_src: 'null.png',
			  press_src: 'null.png',
			  click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

      btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
        x: 96, //x кнопки
        y: 352, //y кнопки
        text: '',
        w: 100, //ширина кнопки
        h: 50, //высота кнопки
        normal_src: 'null.png',
        press_src: 'mull.png',
        click_func: () => {
          click_zona1();
          vibro(9); //имя вызываемой функции
        },
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
      btn_zona1.setProperty(hmUI.prop.VISIBLE, true);

      normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Нет связи !,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Соединено !,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Нет связи !"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Соединено !"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 184,
              w: 95,
              h: 95,
              src: 'null.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 154,
              y: 282,
              w: 95,
              h: 66,
              src: 'null.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 81,
              w: 95,
              h: 95,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 282,
              w: 95,
              h: 66,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 184,
              w: 95,
              h: 95,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          //buttons start
          btn_aod = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 368,
            y: 198,
            text: '',
            w: 100,
            h: 62,
            normal_src: 'null.png',
            press_src: 'null.png',
            click_func: () => {
                toggleAODmode();
                vibro(25);
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_aod.setProperty(hmUI.prop.VISIBLE, true);
        //buttons end

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
              const currentScreenType = hmSetting.getScreenType();
              switch (currentScreenType) {
                  case hmSetting.screen_type.AOD:
                      makeAOD();
                      break;

                  default:
                      break;
              }

                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
