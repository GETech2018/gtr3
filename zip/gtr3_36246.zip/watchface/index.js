﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_image_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_image_img = ''
        let idle_calorie_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_temperature_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''

// start user_functions.js


        // change style
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 10
        let colorcode = "0xFFFFFF00"
        let point_Batt ="pointer_Y.png"

        function battpointer(){

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: point_Batt,
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
          }

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
                if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
                if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
                if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
                if(elementnumber_1==6) {
                  UpdateElementeSix();
                }
                if(elementnumber_1==7) {
                  UpdateElementeSeven();
                }
                if(elementnumber_1==8) {
                  UpdateElementeEight();
                }
                if(elementnumber_1==9) {
                  UpdateElementeNine();
                }
                if(elementnumber_1==10) {
                  UpdateElementeTen();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Yellow Style'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Blue Style'});
            if(elementnumber_1==3) hmUI.showToast({text: 'Green Style'});
            if(elementnumber_1==4) hmUI.showToast({text: 'Red Style'});
            if(elementnumber_1==5) hmUI.showToast({text: 'White Style'});
            if(elementnumber_1==6) hmUI.showToast({text: 'Yellow Screen Style'});
            if(elementnumber_1==7) hmUI.showToast({text: 'Blue Screen Style'});
            if(elementnumber_1==8) hmUI.showToast({text: 'Green Screen Style'});
            if(elementnumber_1==9) hmUI.showToast({text: 'Red Screen Style'});
            if(elementnumber_1==10) hmUI.showToast({text: 'White Screen Style'});
        }

        //Yellow
        function UpdateElementeOne(){
          colorcode = "0xFFFFFF00"
          point_Batt ="pointer_Y.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_Y_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_Y_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_Y_DIS_KM.png',
              unit_tc: 'Act_Y_DIS_KM.png',
              unit_en: 'Act_Y_DIS_KM.png',
              imperial_unit_sc: 'Act_Y_DIS_Mi.png',
              imperial_unit_tc: 'Act_Y_DIS_Mi.png',
              imperial_unit_en: 'Act_Y_DIS_Mi.png',
              dot_image: 'ACT_Y_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_Y_W2.png',
              unit_tc: 'Act_Y_W2.png',
              unit_en: 'Act_Y_W2.png',
              negative_image: 'Act_Y_W1.png',
              invalid_image: 'Act_Y_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_Y.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_Y.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_Y_Batt_Sy.png',
              unit_tc: 'Act_Y_Batt_Sy.png',
              unit_en: 'Act_Y_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_tc_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_en_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_Y_AM.png',
              am_en_path: 'Clock_Y_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_Y_PM.png',
              pm_en_path: 'Clock_Y_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_Y0.png","Time_Y1.png","Time_Y2.png","Time_Y3.png","Time_Y4.png","Time_Y5.png","Time_Y6.png","Time_Y7.png","Time_Y8.png","Time_Y9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_Y0.png","Time_Y1.png","Time_Y2.png","Time_Y3.png","Time_Y4.png","Time_Y5.png","Time_Y6.png","Time_Y7.png","Time_Y8.png","Time_Y9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_image_img.setProperty(hmUI.prop.SRC, "Top.png");

const result = hmSetting.setScreenOff()

        }

        //Blue
        function UpdateElementeTwo(){
       colorcode = "0xFF00CDE7"
          point_Batt ="pointer_B.png"
       
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_B_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_B_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_B_DIS_KM.png',
              unit_tc: 'Act_B_DIS_KM.png',
              unit_en: 'Act_B_DIS_KM.png',
              imperial_unit_sc: 'Act_B_DIS_Mi.png',
              imperial_unit_tc: 'Act_B_DIS_Mi.png',
              imperial_unit_en: 'Act_B_DIS_Mi.png',
              dot_image: 'ACT_B_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_B_W2.png',
              unit_tc: 'Act_B_W2.png',
              unit_en: 'Act_B_W2.png',
              negative_image: 'Act_B_W1.png',
              invalid_image: 'Act_B_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_B.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_B.png',
              center_x: 109,
              center_Y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_B_Batt_Sy.png',
              unit_tc: 'Act_B_Batt_Sy.png',
              unit_en: 'Act_B_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_tc_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_en_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_B_AM.png',
              am_en_path: 'Clock_B_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_B_PM.png',
              pm_en_path: 'Clock_B_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_B_0.png","Act_B_1.png","Act_B_2.png","Act_B_3.png","Act_B_4.png","Act_B_5.png","Act_B_6.png","Act_B_7.png","Act_B_8.png","Act_B_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_B0.png","Time_B1.png","Time_B2.png","Time_B3.png","Time_B4.png","Time_B5.png","Time_B6.png","Time_B7.png","Time_B8.png","Time_B9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_B0.png","Time_B1.png","Time_B2.png","Time_B3.png","Time_B4.png","Time_B5.png","Time_B6.png","Time_B7.png","Time_B8.png","Time_B9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

normal_image_img.setProperty(hmUI.prop.SRC, "Top.png");


const result = hmSetting.setScreenOff()

        }

       //Green
        function UpdateElementeThree(){
       colorcode = "0xFF00E9A6"
          point_Batt ="pointer_G.png"
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


           normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_G_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_G_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_G_DIS_KM.png',
              unit_tc: 'Act_G_DIS_KM.png',
              unit_en: 'Act_G_DIS_KM.png',
              imperial_unit_sc: 'Act_G_DIS_Mi.png',
              imperial_unit_tc: 'Act_G_DIS_Mi.png',
              imperial_unit_en: 'Act_G_DIS_Mi.png',
              dot_image: 'ACT_G_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_G_W2.png',
              unit_tc: 'Act_G_W2.png',
              unit_en: 'Act_G_W2.png',
              negative_image: 'Act_G_W1.png',
              invalid_image: 'Act_G_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_G.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_G.png',
              center_x: 109,
              center_Y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_G_Batt_Sy.png',
              unit_tc: 'Act_G_Batt_Sy.png',
              unit_en: 'Act_G_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_G0.png","Day_G1.png","Day_G2.png","Day_G3.png","Day_G4.png","Day_G5.png","Day_G6.png","Day_G7.png","Day_G8.png","Day_G9.png"],
              day_tc_array: ["Day_G0.png","Day_G1.png","Day_G2.png","Day_G3.png","Day_G4.png","Day_G5.png","Day_G6.png","Day_G7.png","Day_G8.png","Day_G9.png"],
              day_en_array: ["Day_G0.png","Day_G1.png","Day_G2.png","Day_G3.png","Day_G4.png","Day_G5.png","Day_G6.png","Day_G7.png","Day_G8.png","Day_G9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_G_AM.png',
              am_en_path: 'Clock_G_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_G_PM.png',
              pm_en_path: 'Clock_G_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_G_0.png","Act_G_1.png","Act_G_2.png","Act_G_3.png","Act_G_4.png","Act_G_5.png","Act_G_6.png","Act_G_7.png","Act_G_8.png","Act_G_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_G0.png","Time_G1.png","Time_G2.png","Time_G3.png","Time_G4.png","Time_G5.png","Time_G6.png","Time_G7.png","Time_G8.png","Time_G9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_G0.png","Time_G1.png","Time_G2.png","Time_G3.png","Time_G4.png","Time_G5.png","Time_G6.png","Time_G7.png","Time_G8.png","Time_G9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_image_img.setProperty(hmUI.prop.SRC, "Top.png");

const result = hmSetting.setScreenOff()

}


       //Red
        function UpdateElementeFour(){
       colorcode = "0xFFD70030"
          point_Batt ="pointer_R.png"
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


           normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_R_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_R_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_R_DIS_KM.png',
              unit_tc: 'Act_R_DIS_KM.png',
              unit_en: 'Act_R_DIS_KM.png',
              imperial_unit_sc: 'Act_R_DIS_Mi.png',
              imperial_unit_tc: 'Act_R_DIS_Mi.png',
              imperial_unit_en: 'Act_R_DIS_Mi.png',
              dot_image: 'ACT_R_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_R_W2.png',
              unit_tc: 'Act_R_W2.png',
              unit_en: 'Act_R_W2.png',
              negative_image: 'Act_R_W1.png',
              invalid_image: 'Act_R_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_R.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_R.png',
              center_x: 109,
              center_Y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_R_Batt_Sy.png',
              unit_tc: 'Act_R_Batt_Sy.png',
              unit_en: 'Act_R_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_R0.png","Day_R1.png","Day_R2.png","Day_R3.png","Day_R4.png","Day_R5.png","Day_R6.png","Day_R7.png","Day_R8.png","Day_R9.png"],
              day_tc_array: ["Day_R0.png","Day_R1.png","Day_R2.png","Day_R3.png","Day_R4.png","Day_R5.png","Day_R6.png","Day_R7.png","Day_R8.png","Day_R9.png"],
              day_en_array: ["Day_R0.png","Day_R1.png","Day_R2.png","Day_R3.png","Day_R4.png","Day_R5.png","Day_R6.png","Day_R7.png","Day_R8.png","Day_R9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_R_AM.png',
              am_en_path: 'Clock_R_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_R_PM.png',
              pm_en_path: 'Clock_R_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_R_0.png","Act_R_1.png","Act_R_2.png","Act_R_3.png","Act_R_4.png","Act_R_5.png","Act_R_6.png","Act_R_7.png","Act_R_8.png","Act_R_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_R0.png","Time_R1.png","Time_R2.png","Time_R3.png","Time_R4.png","Time_R5.png","Time_R6.png","Time_R7.png","Time_R8.png","Time_R9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_R0.png","Time_R1.png","Time_R2.png","Time_R3.png","Time_R4.png","Time_R5.png","Time_R6.png","Time_R7.png","Time_R8.png","Time_R9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_image_img.setProperty(hmUI.prop.SRC, "Top.png");


const result = hmSetting.setScreenOff()

}


       //White
        function UpdateElementeFive(){
       colorcode = "0xFFFFFFFF"
          point_Batt ="pointer_W.png"
            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


           normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_W_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_W_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_W_DIS_KM.png',
              unit_tc: 'Act_W_DIS_KM.png',
              unit_en: 'Act_W_DIS_KM.png',
              imperial_unit_sc: 'Act_W_DIS_Mi.png',
              imperial_unit_tc: 'Act_W_DIS_Mi.png',
              imperial_unit_en: 'Act_W_DIS_Mi.png',
              dot_image: 'ACT_W_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_W_W2.png',
              unit_tc: 'Act_W_W2.png',
              unit_en: 'Act_W_W2.png',
              negative_image: 'Act_W_W1.png',
              invalid_image: 'Act_W_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_W.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_W.png',
              center_x: 109,
              center_Y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_W_Batt_Sy.png',
              unit_tc: 'Act_W_Batt_Sy.png',
              unit_en: 'Act_W_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_tc_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_en_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_W_AM.png',
              am_en_path: 'Clock_W_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_W_PM.png',
              pm_en_path: 'Clock_W_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_image_img.setProperty(hmUI.prop.SRC, "Top.png");

const result = hmSetting.setScreenOff()

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //screen Yellow
        function UpdateElementeSix(){
          colorcode = "0xFF000000"
          point_Batt ="pointer_BL.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_BL_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_BL_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_BL_DIS_KM.png',
              unit_tc: 'Act_BL_DIS_KM.png',
              unit_en: 'Act_BL_DIS_KM.png',
              imperial_unit_sc: 'Act_BL_DIS_Mi.png',
              imperial_unit_tc: 'Act_BL_DIS_Mi.png',
              imperial_unit_en: 'Act_BL_DIS_Mi.png',
              dot_image: 'ACT_BL_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_W2.png',
              unit_tc: 'Act_BL_W2.png',
              unit_en: 'Act_BL_W2.png',
              negative_image: 'Act_BL_W1.png',
              invalid_image: 'Act_BL_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 66,
              y: 289,
              week_en: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_tc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_sc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_Batt_Sy.png',
              unit_tc: 'Act_BL_Batt_Sy.png',
              unit_en: 'Act_BL_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_tc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_en_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_Y_AM.png',
              am_en_path: 'Clock_Y_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_Y_PM.png',
              pm_en_path: 'Clock_Y_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_tc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_en_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_image_img.setProperty(hmUI.prop.SRC, "main1.png");
const result = hmSetting.setScreenOff()

        }


        //screen Blue
        function UpdateElementeSeven(){
          colorcode = "0xFF000000"
          point_Batt ="pointer_BL.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_BL_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_BL_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_BL_DIS_KM.png',
              unit_tc: 'Act_BL_DIS_KM.png',
              unit_en: 'Act_BL_DIS_KM.png',
              imperial_unit_sc: 'Act_BL_DIS_Mi.png',
              imperial_unit_tc: 'Act_BL_DIS_Mi.png',
              imperial_unit_en: 'Act_BL_DIS_Mi.png',
              dot_image: 'ACT_BL_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_W2.png',
              unit_tc: 'Act_BL_W2.png',
              unit_en: 'Act_BL_W2.png',
              negative_image: 'Act_BL_W1.png',
              invalid_image: 'Act_BL_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 66,
              y: 289,
              week_en: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_tc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_sc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_Batt_Sy.png',
              unit_tc: 'Act_BL_Batt_Sy.png',
              unit_en: 'Act_BL_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_tc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_en_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_B_AM.png',
              am_en_path: 'Clock_B_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_B_PM.png',
              pm_en_path: 'Clock_B_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_tc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_en_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_image_img.setProperty(hmUI.prop.SRC, "main2.png");
const result = hmSetting.setScreenOff()

        }




        //screen Green
        function UpdateElementeEight(){
          colorcode = "0xFF000000"
          point_Batt ="pointer_BL.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_BL_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_BL_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_BL_DIS_KM.png',
              unit_tc: 'Act_BL_DIS_KM.png',
              unit_en: 'Act_BL_DIS_KM.png',
              imperial_unit_sc: 'Act_BL_DIS_Mi.png',
              imperial_unit_tc: 'Act_BL_DIS_Mi.png',
              imperial_unit_en: 'Act_BL_DIS_Mi.png',
              dot_image: 'ACT_BL_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_W2.png',
              unit_tc: 'Act_BL_W2.png',
              unit_en: 'Act_BL_W2.png',
              negative_image: 'Act_BL_W1.png',
              invalid_image: 'Act_BL_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 66,
              y: 289,
              week_en: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_tc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_sc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_Batt_Sy.png',
              unit_tc: 'Act_BL_Batt_Sy.png',
              unit_en: 'Act_BL_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_tc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_en_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_G_AM.png',
              am_en_path: 'Clock_G_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_G_PM.png',
              pm_en_path: 'Clock_G_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_tc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_en_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_image_img.setProperty(hmUI.prop.SRC, "main3.png");
const result = hmSetting.setScreenOff()

        }


        //screen Red
        function UpdateElementeNine(){
          colorcode = "0xFF000000"
          point_Batt ="pointer_BL.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_BL_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_BL_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_BL_DIS_KM.png',
              unit_tc: 'Act_BL_DIS_KM.png',
              unit_en: 'Act_BL_DIS_KM.png',
              imperial_unit_sc: 'Act_BL_DIS_Mi.png',
              imperial_unit_tc: 'Act_BL_DIS_Mi.png',
              imperial_unit_en: 'Act_BL_DIS_Mi.png',
              dot_image: 'ACT_BL_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_W2.png',
              unit_tc: 'Act_BL_W2.png',
              unit_en: 'Act_BL_W2.png',
              negative_image: 'Act_BL_W1.png',
              invalid_image: 'Act_BL_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 66,
              y: 289,
              week_en: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_tc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_sc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_Batt_Sy.png',
              unit_tc: 'Act_BL_Batt_Sy.png',
              unit_en: 'Act_BL_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_tc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_en_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_R_AM.png',
              am_en_path: 'Clock_R_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_R_PM.png',
              pm_en_path: 'Clock_R_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_tc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_en_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_image_img.setProperty(hmUI.prop.SRC, "main4.png");
const result = hmSetting.setScreenOff()

        }


       //screen White
        function UpdateElementeTen(){
          colorcode = "0xFF000000"
          point_Batt ="pointer_BL.png"

            normal_background_bg.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 174,
              y: 32,
              image_array: ["Weather_icon_BL_01.png","Weather_icon_BL_02.png","Weather_icon_BL_03.png","Weather_icon_BL_04.png","Weather_icon_BL_05.png","Weather_icon_BL_06.png","Weather_icon_BL_07.png","Weather_icon_BL_08.png","Weather_icon_BL_09.png","Weather_icon_BL_10.png","Weather_icon_BL_11.png","Weather_icon_BL_12.png","Weather_icon_BL_13.png","Weather_icon_BL_14.png","Weather_icon_BL_15.png","Weather_icon_BL_16.png","Weather_icon_BL_17.png","Weather_icon_BL_18.png","Weather_icon_BL_19.png","Weather_icon_BL_20.png","Weather_icon_BL_21.png","Weather_icon_BL_22.png","Weather_icon_BL_23.png","Weather_icon_BL_24.png","Weather_icon_BL_25.png","Weather_icon_BL_26.png","Weather_icon_BL_27.png","Weather_icon_BL_28.png","Weather_icon_BL_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 302,
              y: 355,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_system_disconnect_img.setProperty(hmUI.prop.MORE, {
              x: 139,
              y: 395,
              src: 'System_BL_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 402,
              y: 217,
              src: 'System_BL_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 61,
              y: 354,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_BL_DIS_KM.png',
              unit_tc: 'Act_BL_DIS_KM.png',
              unit_en: 'Act_BL_DIS_KM.png',
              imperial_unit_sc: 'Act_BL_DIS_Mi.png',
              imperial_unit_tc: 'Act_BL_DIS_Mi.png',
              imperial_unit_en: 'Act_BL_DIS_Mi.png',
              dot_image: 'ACT_BL_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 222,
              y: 49,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_W2.png',
              unit_tc: 'Act_BL_W2.png',
              unit_en: 'Act_BL_W2.png',
              negative_image: 'Act_BL_W1.png',
              invalid_image: 'Act_BL_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 66,
              y: 289,
              week_en: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_tc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              week_sc: ["WeekB1.png","WeekB2.png","WeekB3.png","WeekB4.png","WeekB5.png","WeekB6.png","WeekB7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 305,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_BL.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 80,
              y: 134,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_BL_Batt_Sy.png',
              unit_tc: 'Act_BL_Batt_Sy.png',
              unit_en: 'Act_BL_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 181,
              y: 126,
              font_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_tc_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_en_array: ["Day_BL0.png","Day_BL1.png","Day_BL2.png","Day_BL3.png","Day_BL4.png","Day_BL5.png","Day_BL6.png","Day_BL7.png","Day_BL8.png","Day_BL9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_W_AM.png',
              am_en_path: 'Clock_W_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_W_PM.png',
              pm_en_path: 'Clock_W_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_BL_0.png","Act_BL_1.png","Act_BL_2.png","Act_BL_3.png","Act_BL_4.png","Act_BL_5.png","Act_BL_6.png","Act_BL_7.png","Act_BL_8.png","Act_BL_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute.setProperty(hmUI.prop.MORE, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour.setProperty(hmUI.prop.MORE, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_BL0.png","Time_BL1.png","Time_BL2.png","Time_BL3.png","Time_BL4.png","Time_BL5.png","Time_BL6.png","Time_BL7.png","Time_BL8.png","Time_BL9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_tc_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_en_array: ["Month_BL_01.png","Month_BL_02.png","Month_BL_03.png","Month_BL_04.png","Month_BL_05.png","Month_BL_06.png","Month_BL_07.png","Month_BL_08.png","Month_BL_09.png","Month_BL_10.png","Month_BL_11.png","Month_BL_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


normal_image_img.setProperty(hmUI.prop.SRC, "main5.png");
const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: colorcode,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 209,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

   //         normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
   //           x: 0,
   //           y: 0,
   //           src: 'Top.png',
   //           show_level: hmUI.show_level.ONLY_NORMAL,
   //         });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 355,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 139,
              y: 395,
              src: 'System_Y_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 402,
              y: 217,
              src: 'System_Y_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 354,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_Y_DIS_KM.png',
              unit_tc: 'Act_Y_DIS_KM.png',
              unit_en: 'Act_Y_DIS_KM.png',
              imperial_unit_sc: 'Act_Y_DIS_Mi.png',
              imperial_unit_tc: 'Act_Y_DIS_Mi.png',
              imperial_unit_en: 'Act_Y_DIS_Mi.png',
              dot_image: 'ACT_Y_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

         normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
             src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
           });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 49,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_Y_W2.png',
              unit_tc: 'Act_Y_W2.png',
              unit_en: 'Act_Y_W2.png',
              negative_image: 'Act_Y_W1.png',
              invalid_image: 'Act_Y_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_Y.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 134,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_Y.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 134,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_Y_Batt_Sy.png',
              unit_tc: 'Act_Y_Batt_Sy.png',
              unit_en: 'Act_Y_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 175,
              // start_y: 161,
              // color: 0xFFFFFF00,
              // lenght: 103,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 126,
              font_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_tc_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_en_array: ["Day_Y0.png","Day_Y1.png","Day_Y2.png","Day_Y3.png","Day_Y4.png","Day_Y5.png","Day_Y6.png","Day_Y7.png","Day_Y8.png","Day_Y9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_Y_AM.png',
              am_en_path: 'Clock_Y_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_Y_PM.png',
              pm_en_path: 'Clock_Y_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_Y_0.png","Act_Y_1.png","Act_Y_2.png","Act_Y_3.png","Act_Y_4.png","Act_Y_5.png","Act_Y_6.png","Act_Y_7.png","Act_Y_8.png","Act_Y_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_Y0.png","Time_Y1.png","Time_Y2.png","Time_Y3.png","Time_Y4.png","Time_Y5.png","Time_Y6.png","Time_Y7.png","Time_Y8.png","Time_Y9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_Y0.png","Time_Y1.png","Time_Y2.png","Time_Y3.png","Time_Y4.png","Time_Y5.png","Time_Y6.png","Time_Y7.png","Time_Y8.png","Time_Y9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 209,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 186,
              month_startY: 403,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 355,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 139,
              y: 395,
              src: 'System_W_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 402,
              y: 217,
              src: 'System_W_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 354,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_W_DIS_KM.png',
              unit_tc: 'Act_W_DIS_KM.png',
              unit_en: 'Act_W_DIS_KM.png',
              imperial_unit_sc: 'Act_W_DIS_Mi.png',
              imperial_unit_tc: 'Act_W_DIS_Mi.png',
              imperial_unit_en: 'Act_W_DIS_Mi.png',
              dot_image: 'ACT_W_DIS_DOT.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 222,
              y: 49,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_W_W2.png',
              unit_tc: 'Act_W_W2.png',
              unit_en: 'Act_W_W2.png',
              negative_image: 'Act_W_W1.png',
              invalid_image: 'Act_W_W1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 32,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_W.png',
              center_x: 345,
              center_y: 106,
              x: 9,
              y: 45,
              start_angle: 252,
              end_angle: 347,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 134,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_W.png',
              center_x: 109,
              center_y: 108,
              x: 9,
              y: 45,
              start_angle: 107,
              end_angle: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 134,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 5,
              unit_sc: 'Act_W_Batt_Sy.png',
              unit_tc: 'Act_W_Batt_Sy.png',
              unit_en: 'Act_W_Batt_Sy.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 175,
              // start_y: 161,
              // color: 0xFFFFFFFF,
              // lenght: 103,
              // line_width: 5,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 126,
              font_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 190,
              day_startY: 335,
              day_sc_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_tc_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_en_array: ["Day_W0.png","Day_W1.png","Day_W2.png","Day_W3.png","Day_W4.png","Day_W5.png","Day_W6.png","Day_W7.png","Day_W8.png","Day_W9.png"],
              day_zero: 1,
              day_space: 7,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 43,
              y: 280,
              week_en: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_tc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              week_sc: ["week1.png","week2.png","week3.png","week4.png","week5.png","week6.png","week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 188,
              am_sc_path: 'Clock_W_AM.png',
              am_en_path: 'Clock_W_AM.png',
              pm_x: 395,
              pm_y: 188,
              pm_sc_path: 'Clock_W_PM.png',
              pm_en_path: 'Clock_W_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 394,
              second_startY: 243,
              second_array: ["Act_W_0.png","Act_W_1.png","Act_W_2.png","Act_W_3.png","Act_W_4.png","Act_W_5.png","Act_W_6.png","Act_W_7.png","Act_W_8.png","Act_W_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 255,
              minute_startY: 187,
              minute_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              minute_zero: 1,
              minute_space: 18,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 187,
              hour_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              hour_zero: 1,
              hour_space: 18,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 202,
              w: 47,
              h: 51,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 116,
              y: 201,
              w: 50,
              h: 51,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 387,
              y: 205,
              w: 58,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 204,
              w: 45,
              h: 44,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 42,
              w: 65,
              h: 43,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 351,
              w: 78,
              h: 54,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 131,
              w: 82,
              h: 30,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 63,
              w: 59,
              h: 55,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 120,
              w: 86,
              h: 32,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 74,
              w: 74,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 336,
              w: 74,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 332,
              w: 74,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 416,
              w: 74,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 175;
                  let start_y_normal_step = 161;
                  let lenght_ls_normal_step = 103;
                  let line_width_ls_normal_step = 5;
                  let color_ls_normal_step = colorcode;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 2,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 175;
                  let start_y_idle_step = 161;
                  let lenght_ls_idle_step = 103;
                  let line_width_ls_idle_step = 5;
                  let color_ls_idle_step = '0xFFFFFFFF';
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    radius: 2,
                    color: color_ls_idle_step,
                  });
                };

            };



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                battpointer(); 
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}