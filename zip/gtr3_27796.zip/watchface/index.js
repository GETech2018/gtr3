﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_linear_scale = ''
        let normal_calorie_linear_scale_mirror = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 69,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 280,
              y: 69,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 69,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 140,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital9_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 106,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital9_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 247,
              y: 147,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 212,
              month_startY: 51,
              month_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 10,
              day_sc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_tc_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_en_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 413,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital9_14.png',
              unit_tc: 'digital9_14.png',
              unit_en: 'digital9_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 373,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 373,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital9_14.png',
              unit_tc: 'digital9_14.png',
              unit_en: 'digital9_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 173,
              y: 373,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 373,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 312,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'digital9_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 312,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 312,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              normal_calorie_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 286,
              // start_y: 123,
              // color: 0xFFFFFF00,
              // lenght: 80,
              // line_width: 10,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 68,
              y: 312,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [10,10,10,10,10,10,10,10],
              y: [180,180,180,180,180,180,180,180],
              image_array: ["dist_01.png","dist_02.png","dist_03.png","dist_04.png","dist_05.png","dist_06.png","dist_07.png","dist_08.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 69,
              font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital9_12.png',
              unit_tc: 'digital9_12.png',
              unit_en: 'digital9_12.png',
              negative_image: 'digital9_13.png',
              invalid_image: 'error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 132,
              y: 18,
              image_array: ["weat_01.png","weat_02.png","weat_03.png","weat_04.png","weat_05.png","weat_06.png","weat_07.png","weat_08.png","weat_09.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 17,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 178,
              hour_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 175,
              minute_startY: 178,
              minute_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 302,
              second_startY: 178,
              second_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 104,
              w: 116,
              h: 63,
              src: 'short.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 345,
              w: 73,
              h: 56,
              src: 'short.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 12,
              w: 114,
              h: 85,
              src: 'short.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 284,
              w: 71,
              h: 55,
              src: 'short.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 285,
              w: 84,
              h: 55,
              src: 'short.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 178,
              hour_array: ["digital8_10.png","digital8_11.png","digital8_12.png","digital8_13.png","digital8_14.png","digital8_15.png","digital8_16.png","digital8_17.png","digital8_18.png","digital8_19.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 175,
              minute_startY: 178,
              minute_array: ["digital8_10.png","digital8_11.png","digital8_12.png","digital8_13.png","digital8_14.png","digital8_15.png","digital8_16.png","digital8_17.png","digital8_18.png","digital8_19.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 302,
              second_startY: 178,
              second_array: ["digital8_10.png","digital8_11.png","digital8_12.png","digital8_13.png","digital8_14.png","digital8_15.png","digital8_16.png","digital8_17.png","digital8_18.png","digital8_19.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 286;
                  let start_y_normal_calorie = 123;
                  let lenght_ls_normal_calorie = 80;
                  let line_width_ls_normal_calorie = 10;
                  let color_ls_normal_calorie = 0xFFFFFF00;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                  
                  // normal_calorie_linear_scale_mirror
                  // initial parameters
                  let start_x_normal_calorie_mirror = 286;
                  let start_y_normal_calorie_mirror = 123;
                  let lenght_ls_normal_calorie_mirror = -80;
                  let line_width_ls_normal_calorie_mirror =10;
                  let color_ls_normal_calorie_mirror = 0xFFFFFF00;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw_mirror = start_x_normal_calorie_mirror;
                  let start_y_normal_calorie_draw_mirror = start_y_normal_calorie_mirror;
                  lenght_ls_normal_calorie_mirror = lenght_ls_normal_calorie_mirror * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw_mirror = lenght_ls_normal_calorie_mirror;
                  let line_width_ls_normal_calorie_draw_mirror = line_width_ls_normal_calorie_mirror;
                  if (lenght_ls_normal_calorie_mirror < 0){
                    lenght_ls_normal_calorie_draw_mirror = -lenght_ls_normal_calorie_mirror;
                    start_x_normal_calorie_draw_mirror = start_x_normal_calorie - lenght_ls_normal_calorie_draw_mirror;
                  };
                  
                  normal_calorie_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw_mirror,
                    y: start_y_normal_calorie_draw_mirror,
                    w: lenght_ls_normal_calorie_draw_mirror,
                    h: line_width_ls_normal_calorie_draw_mirror,
                    color: color_ls_normal_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  