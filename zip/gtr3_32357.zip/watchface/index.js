﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_step_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_pai_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_icon_img = ''
        let idle_stress_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -30,
              y: -65,
              src: 'backPicture82 (1).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 13,
              hour_array: ["2shade_blacwhite_0001.png","2shade_blacwhite_0002.png","2shade_blacwhite_0003.png","2shade_blacwhite_0004.png","2shade_blacwhite_0005.png","2shade_blacwhite_0006.png","2shade_blacwhite_0007.png","2shade_blacwhite_0008.png","2shade_blacwhite_0009.png","2shade_blacwhite_0010.png"],
              hour_zero: 0,
              hour_space: -27,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 90,
              minute_startY: 199,
              minute_array: ["2shade_blacred_0001.png","2shade_blacred_0002.png","2shade_blacred_0003.png","2shade_blacred_0004.png","2shade_blacred_0005.png","2shade_blacred_0006.png","2shade_blacred_0007.png","2shade_blacred_0008.png","2shade_blacred_0009.png","2shade_blacred_0010.png"],
              minute_zero: 1,
              minute_space: -27,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 409,
              src: 'icon_Picture.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 23,
              y: 327,
              src: 'P_date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 77,
              src: 'P_day.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 392,
              y: 194,
              font_array: ["White_small_2shade_blacred_0001.png","White_small_2shade_blacred_0002.png","White_small_2shade_blacred_0003.png","White_small_2shade_blacred_0004.png","White_small_2shade_blacred_0005.png","White_small_2shade_blacred_0006.png","White_small_2shade_blacred_0007.png","White_small_2shade_blacred_0008.png","White_small_2shade_blacred_0009.png","White_small_2shade_blacred_0010.png"],
              padding: false,
              h_space: -30,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 384,
              y: 77,
              src: 'P_calor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 372,
              y: 323,
              src: 'P_power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -6,
              y: 194,
              week_en: ["day_small_2shade_blacred_0001.png","day_small_2shade_blacred_0002.png","day_small_2shade_blacred_0003.png","day_small_2shade_blacred_0004.png","day_small_2shade_blacred_0005.png","day_small_2shade_blacred_0006.png","day_small_2shade_blacred_0007.png"],
              week_tc: ["day_small_2shade_blacred_0001.png","day_small_2shade_blacred_0002.png","day_small_2shade_blacred_0003.png","day_small_2shade_blacred_0004.png","day_small_2shade_blacred_0005.png","day_small_2shade_blacred_0006.png","day_small_2shade_blacred_0007.png"],
              week_sc: ["day_small_2shade_blacred_0001.png","day_small_2shade_blacred_0002.png","day_small_2shade_blacred_0003.png","day_small_2shade_blacred_0004.png","day_small_2shade_blacred_0005.png","day_small_2shade_blacred_0006.png","day_small_2shade_blacred_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -3,
              day_startY: 218,
              day_sc_array: ["red_small_2shade_blacred_0001.png","red_small_2shade_blacred_0002.png","red_small_2shade_blacred_0003.png","red_small_2shade_blacred_0004.png","red_small_2shade_blacred_0005.png","red_small_2shade_blacred_0006.png","red_small_2shade_blacred_0007.png","red_small_2shade_blacred_0008.png","red_small_2shade_blacred_0009.png","red_small_2shade_blacred_0010.png"],
              day_tc_array: ["red_small_2shade_blacred_0001.png","red_small_2shade_blacred_0002.png","red_small_2shade_blacred_0003.png","red_small_2shade_blacred_0004.png","red_small_2shade_blacred_0005.png","red_small_2shade_blacred_0006.png","red_small_2shade_blacred_0007.png","red_small_2shade_blacred_0008.png","red_small_2shade_blacred_0009.png","red_small_2shade_blacred_0010.png"],
              day_en_array: ["red_small_2shade_blacred_0001.png","red_small_2shade_blacred_0002.png","red_small_2shade_blacred_0003.png","red_small_2shade_blacred_0004.png","red_small_2shade_blacred_0005.png","red_small_2shade_blacred_0006.png","red_small_2shade_blacred_0007.png","red_small_2shade_blacred_0008.png","red_small_2shade_blacred_0009.png","red_small_2shade_blacred_0010.png"],
              day_zero: 0,
              day_space: -30,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 405,
              y: 227,
              src: 'icon_line.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 397,
              y: 218,
              font_array: ["red_small_2shade_blacred_0001.png","red_small_2shade_blacred_0002.png","red_small_2shade_blacred_0003.png","red_small_2shade_blacred_0004.png","red_small_2shade_blacred_0005.png","red_small_2shade_blacred_0006.png","red_small_2shade_blacred_0007.png","red_small_2shade_blacred_0008.png","red_small_2shade_blacred_0009.png","red_small_2shade_blacred_0010.png"],
              padding: false,
              h_space: -30,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: 227,
              src: 'icon_line.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'zzblank_icon_AM.png',
              am_en_path: 'zzblank_icon_AM.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'zzblank_icon_PM.png',
              pm_en_path: 'zzblank_icon_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 13,
              hour_array: ["2shade_blacwhite_0001.png","2shade_blacwhite_0002.png","2shade_blacwhite_0003.png","2shade_blacwhite_0004.png","2shade_blacwhite_0005.png","2shade_blacwhite_0006.png","2shade_blacwhite_0007.png","2shade_blacwhite_0008.png","2shade_blacwhite_0009.png","2shade_blacwhite_0010.png"],
              hour_zero: 0,
              hour_space: -27,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 90,
              minute_startY: 199,
              minute_array: ["2shade_blacwhite_0001.png","2shade_blacwhite_0002.png","2shade_blacwhite_0003.png","2shade_blacwhite_0004.png","2shade_blacwhite_0005.png","2shade_blacwhite_0006.png","2shade_blacwhite_0007.png","2shade_blacwhite_0008.png","2shade_blacwhite_0009.png","2shade_blacwhite_0010.png"],
              minute_zero: 1,
              minute_space: -27,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 397,
              y: 218,
              font_array: ["red_small_2shade_blacred_0001.png","red_small_2shade_blacred_0002.png","red_small_2shade_blacred_0003.png","red_small_2shade_blacred_0004.png","red_small_2shade_blacred_0005.png","red_small_2shade_blacred_0006.png","red_small_2shade_blacred_0007.png","red_small_2shade_blacred_0008.png","red_small_2shade_blacred_0009.png","red_small_2shade_blacred_0010.png"],
              padding: false,
              h_space: -30,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: 227,
              src: 'icon_line.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -19,
              y: 2,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 409,
              src: 'icon_Picture.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  