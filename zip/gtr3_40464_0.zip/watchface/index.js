﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_image_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_image_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = ''


      // start user_functions.js
let colorNumber = 1
let totalColors = 6
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    if ( colorNumber == 1) { colorName = "Gold"}
    if ( colorNumber == 2) { colorName = "Yellow"}
    if ( colorNumber == 3) { colorName = "Green "}
    if ( colorNumber == 4) { colorName = "Red"}
    if ( colorNumber == 5) { colorName = "Blue"}
    if ( colorNumber == 6) { colorName = "Gray"}

    hmUI.showToast({text: colorName });




        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colorNumber) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colorNumber) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colorNumber) + ".png");

normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colorNumber) + ".png");
         
    }
/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start background change
        let btn_element_3= ''
        let elementnumber_3= 1
        let total_elemente3 = 2

        function click_elemente3() {
            if(elementnumber_3==total_elemente3) {
            elementnumber_3=1;
                UpdateElemente3One();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente3Two();
                }

            }
            if(elementnumber_3==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_3==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElemente3One(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElemente3Two(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        }

     // hands clock style
        let btncolor2 = ''
        let colornumber2 = 1
        let totalcolors2 = 6
        let namecolor2 = ''

        function click_analog() {

if (elementnumber_3==1) {

            if(colornumber2>=totalcolors2) {
            colornumber2=1;
                }
            else {
                colornumber2=colornumber2+1;
            }

if ( colornumber2 == 1) { namecolor2 = "Hands Clock Gold"}
if ( colornumber2 == 2) { namecolor2 = "Hands Clock Yellow"}
if ( colornumber2 == 3) { namecolor2 = "Hands Clock Green"}
if ( colornumber2 == 4) { namecolor2 = "Hands Clock Red"}
if ( colornumber2 == 5) { namecolor2 = "Hands Clock Blue"}
if ( colornumber2 == 6) { namecolor2 = "Hands Clock Gray"}




hmUI.showToast({text: namecolor2 });

             //hmUI.showToast({text: "color " + parseInt(colornumber2) });
                      

        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber2) + ".png");





        }
}

/////////////////////////////////////////////////////////////////////////////////////////////////


        // Start background change
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Step'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Weather'});
        }

        //Step
        function UpdateElementeOne(){
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        }



        //Weahter
        function UpdateElementeTwo(){
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }




        // Week month

////////  This script based on GTR 3 ///////////
            const deviceInfo = hmSetting.getDeviceInfo();
let xx = deviceInfo.width / 454 * 136
let yy = deviceInfo.height / 454 * 175

let xxd = deviceInfo.width / 454 * 24
let yyd = deviceInfo.height / 454 * 87

let xxw = deviceInfo.width / 454 * 137
let yyw = deviceInfo.height / 454 * 175

let pxxw =deviceInfo.width / 454 * 31
let pyyw =deviceInfo.height / 454 * 78
//////////////////////////////////////////////////
        let btn_element_2 = ''
        let elementnumber_2 = 1
        let total_elemente2 = 2

        function click_elemente2() {
            if(elementnumber_2==total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                elementnumber_2=elementnumber_2+1;
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'Month'});
            if(elementnumber_2==2) hmUI.showToast({text: 'Day Week'});
        }

        //month
        function UpdateElemente2One(){
        normal_image_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer_month.png',
              center_x: xx,
              center_y: yy,
              posX: xxd,
              posY: yyd,
              start_angle: -32,
              end_angle: 329,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: '0_Empty.png',
              center_x: xxw,
              center_y: yyw,
              posX: pxxw,
              posY: pyyw,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Day Week
        function UpdateElemente2Two(){

        normal_image_img.setProperty(hmUI.prop.VISIBLE, true);

            normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: '0_Empty.png',
              center_x: xx,
              center_y: yy,
              posX: xxd,
              posY: yyd,
              start_angle: -32,
              end_angle: 329,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer_Week.png',
              center_x: xxw,
              center_y: yyw,
              posX: pxxw,
              posY: pyyw,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, false);


        }





        // Time / cal_dis
        let btn_element_4= ''
        let elementnumber_4= 1
        let total_elemente4 = 2

        function click_elemente4() {
            if(elementnumber_4==total_elemente4) {
            elementnumber_4=1;
                UpdateElemente4One();
                }
            else {
                elementnumber_4=elementnumber_4+1;
                if(elementnumber_4==2) {
                  UpdateElemente4Two();
                }

            }
            if(elementnumber_4==1) hmUI.showToast({text: 'Time'});
            if(elementnumber_4==2) hmUI.showToast({text: 'Cal_Dis'});
        }

        //Time
        function UpdateElemente4One(){
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);



        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

        //Cal_dist
        function UpdateElemente4Two(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);



        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        }



// end user_functions.js






        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Batt.png',
              center_x: 318,
              center_y: 278,
              x: 10,
              y: 35,
              start_angle: 170,
              end_angle: 67,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 249,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 136,
              center_y: 278,
              x: 11,
              y: 36,
              start_angle: 185,
              end_angle: 290,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 248,
              font_array: ["Act_small_Black0.png","Act_small_Black1.png","Act_small_Black2.png","Act_small_Black3.png","Act_small_Black4.png","Act_small_Black5.png","Act_small_Black6.png","Act_small_Black7.png","Act_small_Black8.png","Act_small_Black9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 161,
              y: 341,
              font_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 163,
              y: 265,
              src: 'icon_cal_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 298,
              font_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 35,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 263,
              y: 357,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 257,
              am_y: 299,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 257,
              pm_y: 299,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 254,
              second_startY: 323,
              second_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 186,
              minute_startY: 339,
              minute_array: ["Time_Black0.png","Time_Black1.png","Time_Black2.png","Time_Black3.png","Time_Black4.png","Time_Black5.png","Time_Black6.png","Time_Black7.png","Time_Black8.png","Time_Black9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 357,
              src: 'System_Alarm2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 287,
              hour_array: ["Time_Black0.png","Time_Black1.png","Time_Black2.png","Time_Black3.png","Time_Black4.png","Time_Black5.png","Time_Black6.png","Time_Black7.png","Time_Black8.png","Time_Black9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 283,
              src: 'side_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 112,
              src: 'icon_Week.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Pointer_Week.png',
              center_x: 136,
              center_y: 175,
              posX: 31,
              posY: 78,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Pointer_month.png',
              center_x: 137,
              center_y: 175,
              posX: 24,
              posY: 87,
              start_angle: -32,
              end_angle: 329,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: -227,
              month_startY: -227,
              month_sc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              month_tc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              month_en_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 109,
              src: 'month_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 161,
              day_sc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_tc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_en_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 278,
              y: 122,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 220,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbo3.png',
              unit_tc: 'Weather_symbo3.png',
              unit_en: 'Weather_symbo3.png',
              negative_image: 'Weather_symbo4.png',
              invalid_image: 'Weather_symbo4.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 220,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbo3.png',
              unit_tc: 'Weather_symbo3.png',
              unit_en: 'Weather_symbo3.png',
              negative_image: 'Weather_symbo4.png',
              invalid_image: 'Weather_symbo4.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 171,
              font_array: ["Act_big0.png","Act_big1.png","Act_big2.png","Act_big3.png","Act_big4.png","Act_big5.png","Act_big6.png","Act_big7.png","Act_big8.png","Act_big9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_symbo1.png',
              unit_tc: 'Weather_symbo1.png',
              unit_en: 'Weather_symbo1.png',
              negative_image: 'Weather_symbo2.png',
              invalid_image: 'Weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 265,
              y: 167,
              src: 'Weather_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 328,
              y: 119,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 215,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 103,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Steps.png',
              center_x: 316,
              center_y: 174,
              x: 16,
              y: 70,
              start_angle: 223,
              end_angle: 495,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Batt.png',
              center_x: 318,
              center_y: 278,
              x: 10,
              y: 35,
              start_angle: 170,
              end_angle: 67,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 249,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Symbo.png',
              unit_tc: 'Batt_Symbo.png',
              unit_en: 'Batt_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_heart.png',
              center_x: 136,
              center_y: 278,
              x: 11,
              y: 36,
              start_angle: 185,
              end_angle: 290,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 248,
              font_array: ["Act_small_Black0.png","Act_small_Black1.png","Act_small_Black2.png","Act_small_Black3.png","Act_small_Black4.png","Act_small_Black5.png","Act_small_Black6.png","Act_small_Black7.png","Act_small_Black8.png","Act_small_Black9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 158,
              y: 35,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 263,
              y: 357,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 257,
              am_y: 299,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 257,
              pm_y: 299,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 254,
              second_startY: 323,
              second_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 186,
              minute_startY: 339,
              minute_array: ["Time_Black0.png","Time_Black1.png","Time_Black2.png","Time_Black3.png","Time_Black4.png","Time_Black5.png","Time_Black6.png","Time_Black7.png","Time_Black8.png","Time_Black9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 263,
              y: 357,
              src: 'System_Alarm2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 186,
              hour_startY: 287,
              hour_array: ["Time_Black0.png","Time_Black1.png","Time_Black2.png","Time_Black3.png","Time_Black4.png","Time_Black5.png","Time_Black6.png","Time_Black7.png","Time_Black8.png","Time_Black9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 283,
              src: 'side_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 72,
              y: 112,
              src: 'icon_Week.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Pointer_Week.png',
              center_x: 136,
              center_y: 175,
              posX: 31,
              posY: 78,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 161,
              day_sc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_tc_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_en_array: ["Act_big_black0.png","Act_big_black1.png","Act_big_black2.png","Act_big_black3.png","Act_big_black4.png","Act_big_black5.png","Act_big_black6.png","Act_big_black7.png","Act_big_black8.png","Act_big_black9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 215,
              font_array: ["ActWhite0.png","ActWhite1.png","ActWhite2.png","ActWhite3.png","ActWhite4.png","ActWhite5.png","ActWhite6.png","ActWhite7.png","ActWhite8.png","ActWhite9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 247,
              y: 103,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_Steps.png',
              center_x: 316,
              center_y: 174,
              x: 16,
              y: 70,
              start_angle: 223,
              end_angle: 495,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H6.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_H6.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M6.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_M6.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S6.png',
              // center_x: 227,
              // center_y: 227,
              // x: 26,
              // y: 228,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 26,
              pos_y: 227 - 228,
              center_x: 227,
              center_y: 227,
              src: 'Hand_S6.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 347,
              w: 39,
              h: 32,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 290,
              w: 39,
              h: 38,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 347,
              w: 38,
              h: 39,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 118,
              w: 96,
              h: 36,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 166,
              w: 57,
              h: 41,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 336,
              w: 81,
              h: 44,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 257,
              w: 41,
              h: 54,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 245,
              w: 61,
              h: 53,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 125,
              w: 45,
              h: 58,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 371,
              y: 264,
              w: 53,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 62,
              w: 73,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 101,
              y: 137,
              w: 71,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 8,
              y: 205,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_elemente3()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 201,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_analog()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 340,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button




            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 391,
              y: 100,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button






            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 23,
              y: 104,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_elemente2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 414,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
 click_elemente4()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



// start user_script_end.js
let cc = 0
if (cc==0){ 
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

/////////////
        normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_month_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: 'Pointer_month.png',
              center_x: xx,
              center_y: yy,
              posX: xxd,
              posY: yyd,
              start_angle: -32,
              end_angle: 329,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.MORE, {
              src: '0_Empty.png',
              center_x: xxw,
              center_y: yyw,
              posX: pxxw,
              posY: pyyw,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, true);


////

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);



        normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

}


// end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}