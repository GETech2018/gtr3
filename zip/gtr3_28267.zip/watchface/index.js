﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 248,
              day_startY: 38,
              day_sc_array: ["039.png","040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png"],
              day_tc_array: ["039.png","040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png"],
              day_en_array: ["039.png","040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 38,
              week_en: ["032.png","033.png","034.png","035.png","036.png","037.png","038.png"],
              week_tc: ["032.png","033.png","034.png","035.png","036.png","037.png","038.png"],
              week_sc: ["032.png","033.png","034.png","035.png","036.png","037.png","038.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 235,
              // end_angle: 123,
              // radius: 227,
              // line_width: 17,
              // color: 0xFF003700,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 383,
              font_array: ["022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png","030.png","031.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 115,
              // end_angle: 3,
              // radius: 227,
              // line_width: 17,
              // color: 0xFF003700,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 300,
              font_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -116,
              // end_angle: -3,
              // radius: 227,
              // line_width: 17,
              // color: 0xFF003700,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 300,
              font_array: ["049.png","050.png","051.png","052.png","053.png","054.png","055.png","056.png","057.png","058.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 130,
              hour_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              hour_zero: 1,
              hour_space: -48,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 216,
              minute_startY: 130,
              minute_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              minute_zero: 1,
              minute_space: -51,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '000.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 125,
              hour_startY: 70,
              hour_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              hour_zero: 1,
              hour_space: -45,
              hour_align: hmUI.align.LEFT,

              minute_startX: 125,
              minute_startY: 190,
              minute_array: ["002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              minute_zero: 1,
              minute_space: -45,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 33;
                  let end_angle_normal_battery = 145;
                  let center_x_normal_battery = 227;
                  let center_y_normal_battery = 227;
                  let radius_normal_battery = 227;
                  let line_width_cs_normal_battery = 17;
                  let color_cs_normal_battery = 0xFF003700;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -87;
                  let end_angle_normal_step = 25;
                  let center_x_normal_step = 227;
                  let center_y_normal_step = 227;
                  let radius_normal_step = 227;
                  let line_width_cs_normal_step = 17;
                  let color_cs_normal_step = 0xFF003700;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -93;
                  let end_angle_normal_calorie = -206;
                  let center_x_normal_calorie = 227;
                  let center_y_normal_calorie = 227;
                  let radius_normal_calorie = 227;
                  let line_width_cs_normal_calorie = 17;
                  let color_cs_normal_calorie = 0xFF003700;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  