﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_main = 1
        let totalcolors_main = 7
        let namecolor_main = ''
        let folder = ''  
        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { 
namecolor_main = "BLUE"
folder = "Blue/"
}
if ( colornumber_main == 2) { 
namecolor_main = "LEMON GREEN"
folder = "LemonGreen/"
}
if ( colornumber_main == 3) { 
namecolor_main = "YELLOW"
folder = "Yellow/"
}
if ( colornumber_main == 4) { 
namecolor_main = "GREEN"
folder = "Green/"
}
if ( colornumber_main == 5) { 
namecolor_main = "ORANGE"
folder = "Orange/"
}
if ( colornumber_main == 6) { 
namecolor_main = "RED"
folder = "Red/"
}
if ( colornumber_main == 7) { 
namecolor_main = "GRAY"
folder = "Gray/"
}


hmUI.showToast({text: namecolor_main });

             normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");
             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber_main) + ".png");
   
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 167,
              second_startY: 304,
              second_array: [folder+"TimeS_0.png",folder+"TimeS_1.png",folder+"TimeS_2.png",folder+"TimeS_3.png",folder+"TimeS_4.png",folder+"TimeS_5.png",folder+"TimeS_6.png",folder+"TimeS_7.png",folder+"TimeS_8.png",folder+"TimeS_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let colornumber_main2 = 1
        let totalcolors_main2 = 7
        let namecolor_main2 = ''
        function click_Color2() {
            if(colornumber_main2>=totalcolors_main2) {
            colornumber_main2=1;
                }
            else {
                colornumber_main2=colornumber_main2+1;
            }

if ( colornumber_main2 == 1) { 
namecolor_main2 = "BLUE"
folder = "Blue/"
}
if ( colornumber_main2 == 2) { 
namecolor_main2 = "LEMON GREEN"
folder = "LemonGreen/"
}
if ( colornumber_main2 == 3) { 
namecolor_main2 = "YELLOW"
folder = "Yellow/"
}
if ( colornumber_main2 == 4) { 
namecolor_main2 = "GREEN"
folder = "Green/"
}
if ( colornumber_main2 == 5) { 
namecolor_main2 = "ORANGE"
folder = "Orange/"
}
if ( colornumber_main2 == 6) { 
namecolor_main2 = "RED"
folder = "Red/"
}
if ( colornumber_main2 == 7) { 
namecolor_main2 = "GRAY"
folder = "Gray/"
}


hmUI.showToast({text: namecolor_main2 });

          //   normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber_main) + ".png");
             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber_main2) + ".png");
   
         normal_digital_clock_img_time_second.setProperty(hmUI.prop.MORE, {
              second_startX: 167,
              second_startY: 304,
              second_array: [folder+"TimeS_0.png",folder+"TimeS_1.png",folder+"TimeS_2.png",folder+"TimeS_3.png",folder+"TimeS_4.png",folder+"TimeS_5.png",folder+"TimeS_6.png",folder+"TimeS_7.png",folder+"TimeS_8.png",folder+"TimeS_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
                           
        }
///////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_humidity_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 85,
              y: 310,
              image_array: ["wind1.png","wind2.png","wind3.png","wind4.png","wind5.png","wind6.png","wind7.png","wind8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 339,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 380,
              week_en: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              week_tc: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              week_sc: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 427,
              month_sc_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_tc_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_en_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 402,
              day_sc_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_tc_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_en_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 276,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Hum_Unit.png',
              unit_tc: 'Hum_Unit.png',
              unit_en: 'Hum_Unit.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 331,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 286,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 239,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 194,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 20,
              y: 140,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 382,
              src: '0246.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 383,
              src: '0247.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 147,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Unit.png',
              unit_tc: 'Batt_Unit.png',
              unit_en: 'Batt_Unit.png',
              invalid_image: 'Step_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 180,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 116,
              font_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'TempHL_error.png',
              invalid_image: 'TempHL_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 86,
              src: '0149.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 116,
              font_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              imperial_unit_sc: 'Temp_Unit.png',
              imperial_unit_tc: 'Temp_Unit.png',
              imperial_unit_en: 'Temp_Unit.png',
              negative_image: 'TempHL_error.png',
              invalid_image: 'TempHL_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 86,
              src: '0150.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 146,
              font_array: ["Temp_0.png","Temp_1.png","Temp_2.png","Temp_3.png","Temp_4.png","Temp_5.png","Temp_6.png","Temp_7.png","Temp_8.png","Temp_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_C.png',
              unit_tc: 'Temp_C.png',
              unit_en: 'Temp_C.png',
              imperial_unit_sc: 'Temp_F.png',
              imperial_unit_tc: 'Temp_F.png',
              imperial_unit_en: 'Temp_F.png',
              negative_image: 'Temp_error.png',
              invalid_image: 'Temp_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 180,
              src: 'Shadow_On_weathericon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 102,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Step_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 157,
              second_startY: 279,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 157,
              minute_startY: 184,
              minute_array: ["TimeH_0.png","TimeH_1.png","TimeH_2.png","TimeH_3.png","TimeH_4.png","TimeH_5.png","TimeH_6.png","TimeH_7.png","TimeH_8.png","TimeH_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 90,
              hour_array: ["TimeH_0.png","TimeH_1.png","TimeH_2.png","TimeH_3.png","TimeH_4.png","TimeH_5.png","TimeH_6.png","TimeH_7.png","TimeH_8.png","TimeH_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 83,
              src: 'Digital_Shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 380,
              week_en: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              week_tc: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              week_sc: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 427,
              month_sc_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_tc_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_en_array: ["0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 402,
              day_sc_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_tc_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_en_array: ["Hum_0.png","Hum_1.png","Hum_2.png","Hum_3.png","Hum_4.png","Hum_5.png","Hum_6.png","Hum_7.png","Hum_8.png","Hum_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 102,
              font_array: ["Step_0.png","Step_1.png","Step_2.png","Step_3.png","Step_4.png","Step_5.png","Step_6.png","Step_7.png","Step_8.png","Step_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Step_0.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 382,
              src: '0246.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 383,
              src: '0247.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 157,
              second_startY: 279,
              second_array: ["TimeS_0.png","TimeS_1.png","TimeS_2.png","TimeS_3.png","TimeS_4.png","TimeS_5.png","TimeS_6.png","TimeS_7.png","TimeS_8.png","TimeS_9.png"],
              second_zero: 1,
              second_space: 6,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 157,
              minute_startY: 184,
              minute_array: ["TimeH_0.png","TimeH_1.png","TimeH_2.png","TimeH_3.png","TimeH_4.png","TimeH_5.png","TimeH_6.png","TimeH_7.png","TimeH_8.png","TimeH_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 157,
              hour_startY: 90,
              hour_array: ["TimeH_0.png","TimeH_1.png","TimeH_2.png","TimeH_3.png","TimeH_4.png","TimeH_5.png","TimeH_6.png","TimeH_7.png","TimeH_8.png","TimeH_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 83,
              src: 'Digital_Shadow.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 184,
              w: 119,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 94,
              w: 95,
              h: 38,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 278,
              w: 104,
              h: 38,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 189,
              w: 95,
              h: 66,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 19,
              y: 136,
              w: 43,
              h: 43,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 128,
              w: 66,
              h: 47,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 137,
              w: 113,
              h: 38,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 189,
              w: 76,
              h: 76,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 284,
              w: 76,
              h: 76,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 376,
              w: 47,
              h: 47,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 19,
              y: 270,
              w: 47,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 378,
              w: 95,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 322,
              w: 95,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 232,
              w: 123,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}