﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_humidity_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_humidity_text_text_img = ''
        let idle_uvi_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_fat_burning_current_text_img = ''
        let idle_stand_current_text_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_low_separator_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
	let rootPath = "images/";
             let screenType = hmSetting.getScreenType()

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

if (screenType != hmSetting.screen_type.AOD) {


	// animate
         let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 203,
                    y: 224,
                    anim_path: rootPath + "anim",

                    anim_prefix: "anim",

                    anim_ext: "png",
                    anim_fps: 10,
                    anim_size: 8,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	 });
           
	}




            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 291,
              src: 'System_BT_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 292,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 368,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 367,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_FONT_BLACK_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 339,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 288,
              image_array: ["Batter_icons_01.png","Batter_icons_02.png","Batter_icons_03.png","Batter_icons_04.png","Batter_icons_05.png","Batter_icons_06.png","Batter_icons_07.png","Batter_icons_08.png","Batter_icons_09.png","Batter_icons_10.png","Batter_icons_11.png","Batter_icons_12.png","Batter_icons_13.png","Batter_icons_14.png","Batter_icons_15.png","Batter_icons_16.png","Batter_icons_17.png","Batter_icons_18.png","Batter_icons_19.png","Batter_icons_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 159,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 159,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 47,
              w: 165,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 101,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_BLACK_14.png',
              unit_tc: 'ACT_Font_BLACK_14.png',
              unit_en: 'ACT_Font_BLACK_14.png',
              negative_image: 'ACT_Font_BLACK_15.png',
              invalid_image: 'ACT_Font_BLACK_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 101,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_BLACK_14.png',
              unit_tc: 'ACT_Font_BLACK_14.png',
              unit_en: 'ACT_Font_BLACK_14.png',
              negative_image: 'ACT_Font_BLACK_15.png',
              invalid_image: 'ACT_Font_BLACK_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ACT_FONT_BLACK_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 20,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_Fonts_12.png',
              unit_tc: 'ACT_Fonts_12.png',
              unit_en: 'ACT_Fonts_12.png',
              negative_image: 'ACT_Fonts_13.png',
              invalid_image: 'ACT_Fonts_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 10,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 258,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 259,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              invalid_image: 'ACT_FONT_BLACK_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 406,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_SMALL_FONT_12.png',
              dot_image: 'ACT_SMALL_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 406,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_SMALL_FONT_12.png',
              dot_image: 'ACT_SMALL_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 373,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 195,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 198,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 198,
              day_sc_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_tc_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_en_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 188,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'ACT_Fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 271,
              y: 188,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 188,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 212,
              image_array: ["Step_icons_01.png","Step_icons_02.png","Step_icons_03.png","Step_icons_04.png","Step_icons_05.png","Step_icons_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 137,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'ACT_Fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 137,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 21,
              am_y: 317,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 21,
              pm_y: 317,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 294,
              hour_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.LEFT,

              minute_startX: 167,
              minute_startY: 294,
              minute_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 263,
              second_startY: 294,
              second_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 47,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 291,
              w: 58,
              h: 66,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 308,
              w: 23,
              h: 45,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 286,
              w: 36,
              h: 31,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 381,
              w: 187,
              h: 70,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 11,
              w: 160,
              h: 112,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 247,
              w: 125,
              h: 37,
              src: '0_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 344,
              y: 249,
              w: 94,
              h: 33,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 166,
              w: 116,
              h: 54,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 21,
              y: 169,
              w: 89,
              h: 48,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 291,
              src: 'System_BT_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 44,
              y: 292,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 368,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 367,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_FONT_BLACK_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 348,
              y: 339,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 288,
              image_array: ["Batter_icons_01.png","Batter_icons_02.png","Batter_icons_03.png","Batter_icons_04.png","Batter_icons_05.png","Batter_icons_06.png","Batter_icons_07.png","Batter_icons_08.png","Batter_icons_09.png","Batter_icons_10.png","Batter_icons_11.png","Batter_icons_12.png","Batter_icons_13.png","Batter_icons_14.png","Batter_icons_15.png","Batter_icons_16.png","Batter_icons_17.png","Batter_icons_18.png","Batter_icons_19.png","Batter_icons_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 159,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 145,
              y: 159,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 47,
              w: 165,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 101,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_BLACK_14.png',
              unit_tc: 'ACT_Font_BLACK_14.png',
              unit_en: 'ACT_Font_BLACK_14.png',
              negative_image: 'ACT_Font_BLACK_15.png',
              invalid_image: 'ACT_Font_BLACK_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 101,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_BLACK_14.png',
              unit_tc: 'ACT_Font_BLACK_14.png',
              unit_en: 'ACT_Font_BLACK_14.png',
              negative_image: 'ACT_Font_BLACK_15.png',
              invalid_image: 'ACT_Font_BLACK_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ACT_FONT_BLACK_01.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 20,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_Fonts_12.png',
              unit_tc: 'ACT_Fonts_12.png',
              unit_en: 'ACT_Fonts_12.png',
              negative_image: 'ACT_Fonts_13.png',
              invalid_image: 'ACT_Fonts_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 165,
              y: 10,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 258,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 259,
              font_array: ["ACT_FONT_BLACK_01.png","ACT_FONT_BLACK_02.png","ACT_FONT_BLACK_03.png","ACT_FONT_BLACK_04.png","ACT_FONT_BLACK_05.png","ACT_FONT_BLACK_06.png","ACT_FONT_BLACK_07.png","ACT_FONT_BLACK_08.png","ACT_FONT_BLACK_09.png","ACT_FONT_BLACK_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_FONT_BLACK_12.png',
              unit_tc: 'ACT_FONT_BLACK_12.png',
              unit_en: 'ACT_FONT_BLACK_12.png',
              invalid_image: 'ACT_FONT_BLACK_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 406,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_SMALL_FONT_12.png',
              dot_image: 'ACT_SMALL_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 406,
              font_array: ["ACT_SMALL_FONT_01.png","ACT_SMALL_FONT_02.png","ACT_SMALL_FONT_03.png","ACT_SMALL_FONT_04.png","ACT_SMALL_FONT_05.png","ACT_SMALL_FONT_06.png","ACT_SMALL_FONT_07.png","ACT_SMALL_FONT_08.png","ACT_SMALL_FONT_09.png","ACT_SMALL_FONT_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_SMALL_FONT_12.png',
              dot_image: 'ACT_SMALL_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 373,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 256,
              month_startY: 195,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 198,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 198,
              day_sc_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_tc_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_en_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              day_zero: 1,
              day_space: 6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 188,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'ACT_Fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 271,
              y: 188,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 188,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 212,
              image_array: ["Step_icons_01.png","Step_icons_02.png","Step_icons_03.png","Step_icons_04.png","Step_icons_05.png","Step_icons_06.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 40,
              y: 137,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'ACT_Fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 137,
              font_array: ["ACT_Fonts_01.png","ACT_Fonts_02.png","ACT_Fonts_03.png","ACT_Fonts_04.png","ACT_Fonts_05.png","ACT_Fonts_06.png","ACT_Fonts_07.png","ACT_Fonts_08.png","ACT_Fonts_09.png","ACT_Fonts_10.png"],
              padding: true,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 21,
              am_y: 317,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 21,
              pm_y: 317,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 294,
              hour_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.LEFT,

              minute_startX: 167,
              minute_startY: 294,
              minute_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 263,
              second_startY: 294,
              second_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              second_zero: 1,
              second_space: 5,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 224,
              src: 'mariorun.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 47,
              second_posY: 227,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  