﻿/*
** Watch_Face_Editor tool
** watchface js version v2.0.1
** Copyright © CashaCX75. All Rights Reserved
** Created by StarRrScreaM [4pda]
*/

try {
  (() => {
    //dynamic modify start


    let normal_background_bg = ''
    let disks_bg_img = ''
    let background_img = ''
    let bat_panel_bg_img = ''
    let normal_heart_rate_pointer_progress_img_pointer = ''
    let normal_heart_rate_pointer_progress_img_pointer_disk = ''
    let normal_heart_rate_text_text_img = ''
    let normal_heart_rate_text_text_img_2 = ''
    let normal_battery_linear_scale = ''
    let normal_battery_pointer_progress_img_pointer = ''
    let normal_battery_pointer_progress_img_pointer_disk = ''
    let normal_battery_text_text_img = ''
    let normal_date_img_date_week_img = ''
    let normal_frame_animation_1 = ''
    let panel_bg_img = ''
    let normal_step_pointer_progress_img_pointer = ''
    let normal_step_current_text_img = ''
    let normal_step_current_text_img_2 = ''
    let normal_step_current_text_img_3 = ''
    let normal_distance_text_text_img = ''
    let normal_calorie_current_text_img = ''
    let normal_digital_clock_img_time = ''
    let normal_date_img_date_month_img = ''
    let normal_date_img_date_day = ''
    let panel_up_mask_img = ''
    let up_red_bezel_img = ''
    let normal_moon_image_progress_img_level = ''
    let normal_weather_image_progress_img_level = ''
    let normal_weather_image_progress_img_level_big = ''
    let normal_weather_image_progress_img_level_text = ''
    let normal_temperature_high_text_img = ''
    let normal_temperature_low_text_img = ''
    let normal_temperature_current_text_img = ''
    let normal_analog_clock_time_pointer_hour = ''
    let normal_analog_clock_time_pointer_minute = ''
    let normal_analog_clock_pro_second_pointer_img = ''
    let normal_timerUpdateSecSmooth = undefined;
    let lastTime = 0;
    let idle_background_bg_img = ''
    let idle_analog_clock_time_pointer_hour = ''
    let idle_analog_clock_time_pointer_minute = ''
    let idle_digital_clock_img_time = ''
    let idle_aod_mask_img = ''
    let timeSensor = ''
    let normal_stopwatch_jumpable_img_click = ''
    let normal_countdown_jumpable_img_click = ''
    let normal_alarm_jumpable_img_click = ''
    let calendar_btn = ''
    let normal_temperature_jumpable_img_click = ''
    let normal_pai_jumpable_img_click = ''
    let normal_heart_jumpable_img_click = ''

    let step_goal = ''
    let step_goal_full_TXT = ''

    let bezel_red_toggle_btn = ''
    let bezel_red_visibility = true;

    let dots = ''
    let dotsVisible = false;
    let halfsec_Timer = null;

    let next_panel_btn = ''
    let prev_panel_btn = ''

    let panel_img = ''
    let panel_state = ''
    let panel_state_txt = ''

    let aod_mode_state = ''

    let hands_toggle_state = ''
    let hands_toggle_btn = ''

    let bg_toggle_btn = ''
    let bg_toggle_state = ''

    let widgetDelegate;

    function loadSettings() {
      if (hmFS.SysProGetInt('kobe3_aod') === undefined) {
        aod_mode_state = 0;
        hmFS.SysProSetInt('kobe3_aod', aod_mode_state);
      }
      else {
        aod_mode_state = hmFS.SysProGetInt('kobe3_aod');
      }

      if (hmFS.SysProGetInt('kobe3_panel') === undefined) {
        panel_state = 0;
        hmFS.SysProSetInt('kobe3_panel', panel_state);
      }
      else {
        panel_state = hmFS.SysProGetInt('kobe3_panel');
      }

      if (hmFS.SysProGetInt('kobe3_hands') === undefined) {
        hands_toggle_state = 0;
        hmFS.SysProSetInt('kobe3_hands', hands_toggle_state);
      }
      else {
        hands_toggle_state = hmFS.SysProGetInt('kobe3_hands');
      }

      if (hmFS.SysProGetInt('kobe3_bg') === undefined) {
        bg_toggle_state = 0;
        hmFS.SysProSetInt('kobe3_bg', bg_toggle_state);
      }
      else {
        bg_toggle_state = hmFS.SysProGetInt('kobe3_bg');
      }
    }

    function showDots() {
      dotsVisible = !dotsVisible;
      dots.setProperty(hmUI.prop.VISIBLE, dotsVisible);
    }

    function setSecondsAnim(on) {
      if (on) {
        if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
        halfsec_Timer = timer.createTimer(0, 500, showDots, {});
      } else {
        if (halfsec_Timer) timer.stopTimer(halfsec_Timer);
        halfsec_Timer = null;
        dots.setProperty(hmUI.prop.VISIBLE, false);
      }
    }

    function click_panel_Switcher() {

      let panel_state_total = 3;

      panel_state = (panel_state + 1) % panel_state_total;

      hmFS.SysProSetInt('kobe3_panel', panel_state);

      apply_panel_switch();
    }

    function click_panel_Switcher_reverse() {

      let panel_state_total = 3;

      if (panel_state == 0) {
        panel_state = panel_state_total - 1;
      } else {
        panel_state = (panel_state - 1) % panel_state_total;
      }

      hmFS.SysProSetInt('kobe3_panel', panel_state);

      apply_panel_switch();
    }

    function apply_panel_switch() {
      switch (panel_state) {

        case 0:
          panel_img = 'panel_1.png';

          //panel 1
          panel_bg_img.setProperty(hmUI.prop.SRC, panel_img);
          bat_panel_bg_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
          dots.setProperty(hmUI.prop.VISIBLE, true);
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
          normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
          setSecondsAnim(true);
          normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
          normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
          normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

          //panel 2
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);

          //panel 3
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level_big.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level_text.setProperty(hmUI.prop.VISIBLE, false);

          break;

        case 1:
          panel_img = 'panel_2.png';

          //panel 1
          panel_bg_img.setProperty(hmUI.prop.SRC, panel_img);
          bat_panel_bg_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
          dots.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
          setSecondsAnim(false);
          normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
          normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
          normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_step_current_text_img_3.setProperty(hmUI.prop.VISIBLE, true);
          normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, true);
          normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
          normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);

          //panel 3
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level_big.setProperty(hmUI.prop.VISIBLE, false);
          normal_weather_image_progress_img_level_text.setProperty(hmUI.prop.VISIBLE, false);

          break;

        case 2:
          panel_img = 'panel_3.png';

          //panel 1
          panel_bg_img.setProperty(hmUI.prop.SRC, panel_img);
          bat_panel_bg_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
          dots.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
          setSecondsAnim(false);
          normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
          normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
          normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

          //panel 2
          normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_step_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
          normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
          normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);

          //panel 3
          normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_weather_image_progress_img_level_big.setProperty(hmUI.prop.VISIBLE, true);
          normal_weather_image_progress_img_level_text.setProperty(hmUI.prop.VISIBLE, true);
          break;

        default:
          break;
      }
    }

    function click_hands_Switcher() {
      let hands_toggle_total = 9;

      hands_toggle_state = (hands_toggle_state + 1) % hands_toggle_total;

      hmFS.SysProSetInt('kobe3_hands', hands_toggle_state);

      apply_hands_Switcher();
    }

    function apply_hands_Switcher() {
      switch (hands_toggle_state) {
        case 0:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_blue.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_blue.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 1:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_red.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_red.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 2:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_white.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_white.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 3:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_blue_2.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_blue_2.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 4:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_red_2.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_red_2.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 5:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_white_2.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_white_2.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 6:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_blue_3.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_blue_3.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 7:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_red_3.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_red_3.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        case 8:
          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: 'hand_hour_white_3.png',
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 28,
            hour_posY: 133,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: 'hand_min_white_3.png',
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 230,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
          break;

        default:
          break;
      }
    }

    function click_bg_Switcher() {
      let bg_toggle_total = 4;
      bg_toggle_state = (bg_toggle_state + 1) % bg_toggle_total;
      hmFS.SysProSetInt('kobe3_bg', bg_toggle_state);
      apply_bg_Swither();
    }

    function apply_bg_Swither() {
      switch (bg_toggle_state) {

        case 0:
          background_img.setProperty(hmUI.prop.SRC, 'background_white.png');
          break;

        case 1:
          background_img.setProperty(hmUI.prop.SRC, 'background_black.png');
          break;

        case 2:
          background_img.setProperty(hmUI.prop.SRC, 'background_gray.png');
          break;

        case 3:
          background_img.setProperty(hmUI.prop.SRC, 'background_red.png');
          break;

        default:
          break;
      }
    }

    //dynamic modify end
    const e = __$$hmAppManager$$__.currentApp;
    const o = e.current
      , { px: i } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, o)),
        e.__globals__)
      , n = Logger.getLogger("watchface6");
    o.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          color: '0xFF000000',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        disks_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 54,
          y: 151,
          src: 'disks_bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_pointer_progress_img_pointer_disk = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'small_circle_half_arrow.png',
          center_x: 345,
          center_y: 200,
          x: 49,
          y: 49,
          start_angle: -90,
          end_angle: 90,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_pointer_progress_img_pointer_disk = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'small_circle_half_arrow.png',
          center_x: 109,
          center_y: 200,
          x: 49,
          y: 49,
          start_angle: -90,
          end_angle: 90,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        background_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'background_white.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bat_panel_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 148,
          y: 304,
          src: 'bat_panel_bg.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'small_arrow.png',
          center_x: 345,
          center_y: 199,
          x: 10,
          y: 36,
          start_angle: -90,
          end_angle: 90,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 327,
          y: 216,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        if (screenType != hmSetting.screen_type.AOD) {
          normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
        };

        // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
        // start_x: 151,
        // start_y: 304,
        // color: 0xFF000000,
        // lenght: 45,
        // line_width: 15,
        // vertical: False,
        // mirror: False,
        // inversion: False,
        // type: hmUI.data_type.BATTERY,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function () {
          scale_call();
        });

        normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'small_arrow.png',
          center_x: 109,
          center_y: 199,
          x: 10,
          y: 36,
          start_angle: -90,
          end_angle: 90,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 91,
          y: 216,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //1 panel
        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 169,
          y: 356,
          week_en: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
          week_tc: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
          week_sc: ["weeks_1.png", "weeks_2.png", "weeks_3.png", "weeks_4.png", "weeks_5.png", "weeks_6.png", "weeks_7.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        panel_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 109,
          y: 257,
          src: 'panel_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const step = hmSensor.createSensor(hmSensor.id.STEP);
        step_goal = step.target;

        step_goal_full_TXT = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 234,
          y: 109,
          w: 29,
          h: 19,
          text_size: 20,
          text: step_goal / 1000,
          color: '0xFFFDFDFD',
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'middle_arrow.png',
          center_x: 227,
          center_y: 109,
          x: 13,
          y: 45,
          start_angle: -115,
          end_angle: 115,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 231,
          y: 322,
          font_array: ["dig28_0.png", "dig28_1.png", "dig28_2.png", "dig28_3.png", "dig28_4.png", "dig28_5.png", "dig28_6.png", "dig28_7.png", "dig28_8.png", "dig28_9.png"],
          padding: false,
          h_space: 1,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img_2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 196,
          y: 136,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 203,
          hour_startY: 276,
          hour_array: ["Dig52_0.png", "Dig52_1.png", "Dig52_2.png", "Dig52_3.png", "Dig52_4.png", "Dig52_5.png", "Dig52_6.png", "Dig52_7.png", "Dig52_8.png", "Dig52_9.png"],
          hour_zero: 1,
          hour_space: 2,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 273,
          minute_startY: 276,
          minute_array: ["Dig52_0.png", "Dig52_1.png", "Dig52_2.png", "Dig52_3.png", "Dig52_4.png", "Dig52_5.png", "Dig52_6.png", "Dig52_7.png", "Dig52_8.png", "Dig52_9.png"],
          minute_zero: 1,
          minute_space: 2,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          second_startX: 164,
          second_startY: 275,
          second_array: ["dig28_0.png", "dig28_1.png", "dig28_2.png", "dig28_3.png", "dig28_4.png", "dig28_5.png", "dig28_6.png", "dig28_7.png", "dig28_8.png", "dig28_9.png"],
          second_zero: 1,
          second_space: 2,
          second_follow: 0,
          second_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        dots = hmUI.createWidget(hmUI.widget.IMG, {
          x: 261,
          y: 275,
          src: 'dots.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        setSecondsAnim(true);

        normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 120,
          month_startY: 325,
          month_sc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_tc_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_en_array: ["mon_1.png", "mon_2.png", "mon_3.png", "mon_4.png", "mon_5.png", "mon_6.png", "mon_7.png", "mon_8.png", "mon_9.png", "mon_10.png", "mon_11.png", "mon_12.png"],
          month_is_character: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 167,
          day_startY: 325,
          day_sc_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          day_tc_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          day_en_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // 2 panel
        normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 243,
          y: 292,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          dot_image: 'dig21_dot.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.DISTANCE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 247,
          y: 269,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img_3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 225,
          y: 318,
          font_array: ["dig28b_0.png", "dig28b_1.png", "dig28b_2.png", "dig28b_3.png", "dig28b_4.png", "dig28b_5.png", "dig28b_6.png", "dig28b_7.png", "dig28b_8.png", "dig28b_9.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img_2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 171,
          y: 318,
          font_array: ["dig28w_0.png", "dig28w_1.png", "dig28w_2.png", "dig28w_3.png", "dig28w_4.png", "dig28w_5.png", "dig28w_6.png", "dig28w_7.png", "dig28w_8.png", "dig28w_9.png"],
          padding: false,
          h_space: -1,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
          x: 111,
          y: 280,
          anim_path: "animation",
          anim_ext: "png",
          anim_prefix: "anim",
          anim_fps: 12,
          anim_size: 12,
          repeat_count: 0,
          anim_repeat: true,
          anim_status: hmUI.anim_status.START,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //3 panel
        normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 195,
          y: 295,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          negative_image: 'dig21_minus.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WEATHER_HIGH,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 195,
          y: 320,
          font_array: ["dig21_0.png", "dig21_1.png", "dig21_2.png", "dig21_3.png", "dig21_4.png", "dig21_5.png", "dig21_6.png", "dig21_7.png", "dig21_8.png", "dig21_9.png"],
          padding: false,
          h_space: 0,
          negative_image: 'dig21_minus.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WEATHER_LOW,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 234,
          y: 296,
          font_array: ["Dig52_0.png", "Dig52_1.png", "Dig52_2.png", "Dig52_3.png", "Dig52_4.png", "Dig52_5.png", "Dig52_6.png", "Dig52_7.png", "Dig52_8.png", "Dig52_9.png"],
          padding: false,
          h_space: 1,
          unit_sc: 'Dig52_degr.png',
          unit_tc: 'Dig52_degr.png',
          unit_en: 'Dig52_degr.png',
          negative_image: 'Dig52_minus.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level_big = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 121,
          y: 282,
          image_array: ["wBig_1.png", "wBig_2.png", "wBig_3.png", "wBig_4.png", "wBig_5.png", "wBig_6.png", "wBig_7.png", "wBig_8.png", "wBig_9.png", "wBig_10.png", "wBig_11.png", "wBig_12.png", "wBig_13.png", "wBig_14.png", "wBig_15.png", "wBig_16.png", "wBig_17.png", "wBig_18.png", "wBig_19.png", "wBig_20.png", "wBig_21.png", "wBig_22.png", "wBig_23.png", "wBig_24.png", "wBig_25.png", "wBig_26.png", "wBig_27.png", "wBig_28.png", "wBig_29.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level_text = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 125,
          y: 275,
          image_array: ["weather_txt_0.png", "weather_txt_1.png", "weather_txt_2.png", "weather_txt_3.png", "weather_txt_4.png", "weather_txt_5.png", "weather_txt_6.png", "weather_txt_7.png", "weather_txt_8.png", "weather_txt_9.png", "weather_txt_10.png", "weather_txt_11.png", "weather_txt_12.png", "weather_txt_13.png", "weather_txt_14.png", "weather_txt_15.png", "weather_txt_16.png", "weather_txt_17.png", "weather_txt_18.png", "weather_txt_19.png", "weather_txt_20.png", "weather_txt_21.png", "weather_txt_22.png", "weather_txt_23.png", "weather_txt_24.png", "weather_txt_25.png", "weather_txt_26.png", "weather_txt_27.png", "weather_txt_28.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        panel_up_mask_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 109,
          y: 257,
          src: 'panel_up_mask.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        up_red_bezel_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 227,
          y: 0,
          src: 'up_red_bezel.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 324,
          y: 89,
          image_array: ["moon_1.png", "moon_2.png", "moon_3.png", "moon_4.png", "moon_5.png", "moon_6.png", "moon_7.png", "moon_8.png", "moon_9.png", "moon_10.png", "moon_11.png", "moon_12.png", "moon_13.png", "moon_14.png", "moon_15.png", "moon_16.png", "moon_17.png", "moon_18.png", "moon_19.png", "moon_20.png", "moon_21.png", "moon_22.png", "moon_23.png", "moon_24.png", "moon_25.png", "moon_26.png", "moon_27.png", "moon_28.png", "moon_29.png", "moon_30.png"],
          image_length: 30,
          type: hmUI.data_type.MOON,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 93,
          y: 92,
          image_array: ["w_01.png", "w_02.png", "w_03.png", "w_04.png", "w_05.png", "w_06.png", "w_07.png", "w_08.png", "w_09.png", "w_10.png", "w_11.png", "w_12.png", "w_13.png", "w_14.png", "w_15.png", "w_16.png", "w_17.png", "w_18.png", "w_19.png", "w_20.png", "w_21.png", "w_22.png", "w_23.png", "w_24.png", "w_25.png", "w_26.png", "w_27.png", "w_28.png", "w_29.png"],
          image_length: 29,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hand_hour_blue.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 28,
          hour_posY: 133,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'hand_min_blue.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 23,
          minute_posY: 230,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'hand_sec.png',
        // center_x: 227,
        // center_y: 227,
        // x: 15,
        // y: 206,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.second,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 15,
          pos_y: 227 - 206,
          center_x: 227,
          center_y: 227,
          src: 'hand_sec.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SRCOND, {
        // type: 2,
        // fps: 6,
        // });

        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: 'background_aod.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hand_hour_aod.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 28,
          hour_posY: 133,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'hand_min_aod.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 23,
          minute_posY: 230,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 204,
          hour_startY: 276,
          hour_array: ["Dig52w_0.png", "Dig52w_1.png", "Dig52w_2.png", "Dig52w_3.png", "Dig52w_4.png", "Dig52w_5.png", "Dig52w_6.png", "Dig52w_7.png", "Dig52w_8.png", "Dig52w_9.png"],
          hour_zero: 1,
          hour_space: 0,
          hour_unit_sc: 'dots_w.png',
          hour_unit_tc: 'dots_w.png',
          hour_unit_en: 'dots_w.png',
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 273,
          minute_startY: 276,
          minute_array: ["Dig52w_0.png", "Dig52w_1.png", "Dig52w_2.png", "Dig52w_3.png", "Dig52w_4.png", "Dig52w_5.png", "Dig52w_6.png", "Dig52w_7.png", "Dig52w_8.png", "Dig52w_9.png"],
          minute_zero: 1,
          minute_space: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_aod_mask_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'aod_mask.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 205,
          y: 267,
          w: 63,
          h: 83,
          src: 'pst.png',
          type: hmUI.data_type.STOP_WATCH,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 273,
          y: 267,
          w: 58,
          h: 83,
          src: 'pst.png',
          type: hmUI.data_type.COUNT_DOWN,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 111,
          y: 267,
          w: 88,
          h: 49,
          src: 'pst.png',
          type: hmUI.data_type.ALARM_CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 80,
          y: 80,
          w: 58,
          h: 58,
          src: 'pst.png',
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 178,
          y: 63,
          text: '',
          w: 97,

          h: 97,

          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            hmApp.startApp({ appid: 1, url: 'activityAppScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 297,
          y: 151,
          w: 97,

          h: 88,
          src: 'pst.png',
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bezel_red_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 178,
          y: 0,
          text: '',
          w: 97,

          h: 49,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            bezel_red_visibility = !bezel_red_visibility;
            up_red_bezel_img.setProperty(hmUI.prop.VISIBLE, bezel_red_visibility);
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 7,
          y: 244,
          text: '',
          w: 78,
          h: 58,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bezel_red_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 178,
          y: 0,
          text: '',
          w: 97,

          h: 49,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            bezel_red_visibility = !bezel_red_visibility;
            up_red_bezel_img.setProperty(hmUI.prop.VISIBLE, bezel_red_visibility);
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        next_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 253,
          y: 370,
          text: '',
          w: 68,
          h: 78,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            click_panel_Switcher();
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        prev_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 136,
          y: 370,
          text: '',
          w: 68,
          h: 78,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            click_panel_Switcher_reverse();
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hands_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 178,
          y: 178,
          text: '',
          w: 97,

          h: 83,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            click_hands_Switcher();
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bg_toggle_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 360,
          y: 244,
          text: '',
          w: 88,
          h: 58,
          normal_src: 'pst.png',
          press_src: 'pst.png',
          click_func: () => {
            click_bg_Switcher();
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let timer_StopVibrate = null;

        function vibro(scene = 25) {
          let stopDelay = 50;
          stopVibro();
          vibrate.scene = scene;
          if (scene < 23 || scene > 25) stopDelay = 1300;
          vibrate.start();
          timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro() {
          vibrate.stop();
          if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }

        function scale_call() {

          console.log('update scales BATTERY');

          let valueBattery = battery.current;
          let targetBattery = 100;
          let progressBattery = valueBattery / targetBattery;
          if (progressBattery > 1) progressBattery = 1;
          let progress_ls_normal_battery = progressBattery;

          if (screenType != hmSetting.screen_type.AOD) {

            // normal_battery_linear_scale
            // initial parameters
            let start_x_normal_battery = 151;
            let start_y_normal_battery = 304;
            let lenght_ls_normal_battery = 45;
            let line_width_ls_normal_battery = 15;
            let color_ls_normal_battery = 0xFF000000;

            // calculated parameters
            let start_x_normal_battery_draw = start_x_normal_battery;
            let start_y_normal_battery_draw = start_y_normal_battery;
            lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
            let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
            let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
            if (lenght_ls_normal_battery < 0) {
              lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
              start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
            };

            normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
              x: start_x_normal_battery_draw,
              y: start_y_normal_battery_draw,
              w: lenght_ls_normal_battery_draw,
              h: line_width_ls_normal_battery_draw,
              color: color_ls_normal_battery,
            });
          };

        };

        function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 25,
                anim_key: 'angle',
                anim_status: 1,
              }
          normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
        }

        loadSettings();
        apply_panel_switch();
        apply_hands_Switcher();
        apply_bg_Swither();

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            scale_call();
            // time_update(true, true);

            if (panel_state == 0) {
              setTimeout(() => {
                dotsVisible = true;
                showDots();
                setSecondsAnim(true);
              }, 1000 - timeSensor.utc % 1000);
            }
            if (panel_state == 1) normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.START);

            let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
            normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSecSmooth) {
                let duration = 0;
                let animDuration = 5000;
                if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                let diffTime = timeSensor.utc - lastTime;
                if (diffTime < animDuration) duration = animDuration - diffTime;
                normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = timeSensor.utc;
                  secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                  startSecAnim(secAngle, animDuration);
                }));  // end timer 
              };  // end timer check
            };  // end screenType

          }),
          pause_call: (function () {
            if (panel_state == 1) normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS, hmUI.anim_status.STOP);
            if (panel_state == 0) setSecondsAnim(false);
            
            if (normal_timerUpdateSecSmooth) {
              timer.stopTimer(normal_timerUpdateSecSmooth);
              normal_timerUpdateSecSmooth = undefined;
            }
          }),
        });

        //dynamic modify end
      },
      onInit() {
        n.log("index page.js on init invoke")
      },
      build() {
        this.init_view(),
          n.log("index page.js on ready invoke")
      },
      onDestroy() {
        n.log("index page.js on destroy invoke")
      }
    })
  }
  )()
} catch (e) {
  console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}
