﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''

        let normal_digital_clock_img_time_minute = ''
        let normal_digital2_clock_img_time_minute = ''
        let normal_digital3_clock_img_time_minute = ''
        let normal_digital4_clock_img_time_minute = ''
        let normal_digital5_clock_img_time_minute = ''
        let normal_digital6_clock_img_time_minute = ''

        let normal_digital_clock_minute_separator_img = ''

        let normal_digital_clock_img_time_hour = ''
        let normal_digital2_clock_img_time_hour = ''
        let normal_digital3_clock_img_time_hour = ''
        let normal_digital4_clock_img_time_hour = ''
        let normal_digital5_clock_img_time_hour = ''
        let normal_digital6_clock_img_time_hour = ''

        let normal_digital_clock_hour_separator_img = ''

        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_sun_current_text_img = ''
        let idle_city_name_text = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 6
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
                if(backgroundnumber==6) {
                  UpdateBackgroundSix();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'White'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Red'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Yellow'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Blue'});
          if(backgroundnumber==5) hmUI.showToast({text: 'Orange'});
          if(backgroundnumber==6) hmUI.showToast({text: 'Mix Color'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //1
        function UpdateBackgroundOne(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //2
        function UpdateBackgroundTwo(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_Red_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //3
        function UpdateBackgroundThree(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_Yellow_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);


        }

/////////////////////////////4 /////////////////////////////////////////////////////////////////////
       function UpdateBackgroundFour(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_Blue_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);


        }

////////////////////////5
       function UpdateBackgroundFive(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_Orange_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////// 6
       function UpdateBackgroundSix(){

        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_Multi_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);


        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 104,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 103,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 88,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 46,
              font_array: ["batt_font_01.png","batt_font_02.png","batt_font_03.png","batt_font_04.png","batt_font_05.png","batt_font_06.png","batt_font_07.png","batt_font_08.png","batt_font_09.png","batt_font_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'SUNRISESUNSET_DOT.png',
              dot_image: 'SUNRISESUNSET_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 6,
              w: 123,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 183,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 183,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 184,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 181,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 233,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_KM.png',
              unit_tc: 'ACT_Font_KM.png',
              unit_en: 'ACT_Font_KM.png',
              imperial_unit_sc: 'ACT_Font_Mi.png',
              imperial_unit_tc: 'ACT_Font_Mi.png',
              imperial_unit_en: 'ACT_Font_Mi.png',
              dot_image: 'Act_Font_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 337,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 285,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 390,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_Font_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 410,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 389,
              src: 'Top_zone.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 5,
              y: 191,
              font_array: ["batt_font_01.png","batt_font_02.png","batt_font_03.png","batt_font_04.png","batt_font_05.png","batt_font_06.png","batt_font_07.png","batt_font_08.png","batt_font_09.png","batt_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 223,
              image_array: ["Batt01.png","Batt02.png","Batt03.png","Batt04.png","Batt05.png","Batt06.png","Batt07.png","Batt08.png","Batt09.png","Batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 239,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 46,
              month_startY: 202,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 125,
              day_startY: 288,
              day_sc_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_tc_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_en_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 21,
              am_y: 137,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 21,
              pm_y: 137,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 348,
              second_startY: 132,
              second_array: ["Time_second_font_01.png","Time_second_font_02.png","Time_second_font_03.png","Time_second_font_04.png","Time_second_font_05.png","Time_second_font_06.png","Time_second_font_07.png","Time_second_font_08.png","Time_second_font_09.png","Time_second_font_10.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

////////////// min 1
            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


////////////// min 2
            normal_digital2_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_Red_font_01.png","Time_Red_font_02.png","Time_Red_font_03.png","Time_Red_font_04.png","Time_Red_font_05.png","Time_Red_font_06.png","Time_Red_font_07.png","Time_Red_font_08.png","Time_Red_font_09.png","Time_Red_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

////////////// min 3
            normal_digital3_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_Yellow_font_01.png","Time_Yellow_font_02.png","Time_Yellow_font_03.png","Time_Yellow_font_04.png","Time_Yellow_font_05.png","Time_Yellow_font_06.png","Time_Yellow_font_07.png","Time_Yellow_font_08.png","Time_Yellow_font_09.png","Time_Yellow_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

////////////// min 4
            normal_digital4_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_Blue_font_01.png","Time_Blue_font_02.png","Time_Blue_font_03.png","Time_Blue_font_04.png","Time_Blue_font_05.png","Time_Blue_font_06.png","Time_Blue_font_07.png","Time_Blue_font_08.png","Time_Blue_font_09.png","Time_Blue_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

////////////// min 5
            normal_digital5_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_Orange_font_01.png","Time_Orange_font_02.png","Time_Orange_font_03.png","Time_Orange_font_04.png","Time_Orange_font_05.png","Time_Orange_font_06.png","Time_Orange_font_07.png","Time_Orange_font_08.png","Time_Orange_font_09.png","Time_Orange_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

////////////// min 6
            normal_digital6_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_Multi_font_01.png","Time_Multi_font_02.png","Time_Multi_font_03.png","Time_Multi_font_04.png","Time_Multi_font_05.png","Time_Multi_font_06.png","Time_Multi_font_07.png","Time_Multi_font_08.png","Time_Multi_font_09.png","Time_Multi_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 96,
              src: 'second_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


/////// hour 1
            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////// hour 2
            normal_digital2_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_Red_font_01.png","Time_Red_font_02.png","Time_Red_font_03.png","Time_Red_font_04.png","Time_Red_font_05.png","Time_Red_font_06.png","Time_Red_font_07.png","Time_Red_font_08.png","Time_Red_font_09.png","Time_Red_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////// hour 3
            normal_digital3_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_Yellow_font_01.png","Time_Yellow_font_02.png","Time_Yellow_font_03.png","Time_Yellow_font_04.png","Time_Yellow_font_05.png","Time_Yellow_font_06.png","Time_Yellow_font_07.png","Time_Yellow_font_08.png","Time_Yellow_font_09.png","Time_Yellow_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////// hour 4
            normal_digital4_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_Blue_font_01.png","Time_Blue_font_02.png","Time_Blue_font_03.png","Time_Blue_font_04.png","Time_Blue_font_05.png","Time_Blue_font_06.png","Time_Blue_font_07.png","Time_Blue_font_08.png","Time_Blue_font_09.png","Time_Blue_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////// hour 5
            normal_digital5_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_Orange_font_01.png","Time_Orange_font_02.png","Time_Orange_font_03.png","Time_Orange_font_04.png","Time_Orange_font_05.png","Time_Orange_font_06.png","Time_Orange_font_07.png","Time_Orange_font_08.png","Time_Orange_font_09.png","Time_Orange_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
/////// hour 6
            normal_digital6_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_Multi_font_01.png","Time_Multi_font_02.png","Time_Multi_font_03.png","Time_Multi_font_04.png","Time_Multi_font_05.png","Time_Multi_font_06.png","Time_Multi_font_07.png","Time_Multi_font_08.png","Time_Multi_font_09.png","Time_Multi_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 50,
              src: 'top_seconds.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 104,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 40,
              y: 103,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 88,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 169,
              y: 46,
              font_array: ["batt_font_01.png","batt_font_02.png","batt_font_03.png","batt_font_04.png","batt_font_05.png","batt_font_06.png","batt_font_07.png","batt_font_08.png","batt_font_09.png","batt_font_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'SUNRISESUNSET_DOT.png',
              dot_image: 'SUNRISESUNSET_DOT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 143,
              y: 6,
              w: 123,
              h: 29,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 183,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 366,
              y: 183,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 130,
              y: 184,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 181,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 233,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Font_KM.png',
              unit_tc: 'ACT_Font_KM.png',
              unit_en: 'ACT_Font_KM.png',
              imperial_unit_sc: 'ACT_Font_Mi.png',
              imperial_unit_tc: 'ACT_Font_Mi.png',
              imperial_unit_en: 'ACT_Font_Mi.png',
              dot_image: 'Act_Font_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 337,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 285,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 390,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'ACT_Font_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 148,
              y: 410,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 389,
              src: 'Top_zone.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 5,
              y: 191,
              font_array: ["batt_font_01.png","batt_font_02.png","batt_font_03.png","batt_font_04.png","batt_font_05.png","batt_font_06.png","batt_font_07.png","batt_font_08.png","batt_font_09.png","batt_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'batt_symbo.png',
              unit_tc: 'batt_symbo.png',
              unit_en: 'batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 35,
              y: 223,
              image_array: ["Batt01.png","Batt02.png","Batt03.png","Batt04.png","Batt05.png","Batt06.png","Batt07.png","Batt08.png","Batt09.png","Batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 81,
              y: 239,
              week_en: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_tc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              week_sc: ["Week01.png","Week02.png","Week03.png","Week04.png","Week05.png","Week06.png","Week07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 46,
              month_startY: 202,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 125,
              day_startY: 288,
              day_sc_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_tc_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_en_array: ["day_font_01.png","day_font_02.png","day_font_03.png","day_font_04.png","day_font_05.png","day_font_06.png","day_font_07.png","day_font_08.png","day_font_09.png","day_font_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 21,
              am_y: 137,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 21,
              pm_y: 137,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 348,
              second_startY: 132,
              second_array: ["Time_second_font_01.png","Time_second_font_02.png","Time_second_font_03.png","Time_second_font_04.png","Time_second_font_05.png","Time_second_font_06.png","Time_second_font_07.png","Time_second_font_08.png","Time_second_font_09.png","Time_second_font_10.png"],
              second_zero: 1,
              second_space: 7,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 96,
              src: 'second_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 71,
              hour_startY: 88,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 50,
              src: 'top_seconds.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 342,
              y: 132,
              w: 93,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 90,
              w: 26,
              h: 75,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 91,
              w: 44,
              h: 46,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 119,
              y: 40,
              w: 140,
              h: 25,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 176,
              w: 113,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 257,
              y: 230,
              w: 159,
              h: 32,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 403,
              w: 107,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 387,
              w: 111,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 108,
              y: 272,
              w: 100,
              h: 100,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 267,
              y: 280,
              w: 153,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1



        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "second_dot.png");

        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital2_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital3_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital4_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital5_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital6_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);






 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 283,
              y: 25,
              text: '',
              w: 37,
              h: 37,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ALL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}