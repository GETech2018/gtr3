﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'tlo_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'tlo_2.png' },
              ],
              count: 2,
              default_id: 1,
              fg: 'fg_i.png',
              tips_bg: 'tt.png',
              tips_x: 153,
              tips_y: 201,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 76,
              y: 58,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 6,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 202,
              y: 351,
              src: 'zn_uBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 351,
              src: 'zn_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 386,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 388,
              src: 'wiatr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 266,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 243,
              src: 'hPa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 239,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'st_C.png',
              unit_tc: 'st_C.png',
              unit_en: 'st_C.png',
              negative_image: 'minus.png',
              invalid_image: 'znak_pusty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 166,
              image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 6,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFCACA,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 294,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'proc.png',
              unit_tc: 'proc.png',
              unit_en: 'proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 320,
              src: 'wilg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 386,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'znak_pusty.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 107,
              y: 387,
              src: 'serce.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 264,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'przecinek.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 77,
              y: 242,
              src: 'km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 417,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'kcal.png',
              unit_tc: 'kcal.png',
              unit_en: 'kcal.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 41,
              y: 297,
              font_array: ["cyf_par2_01.png","cyf_par2_02.png","cyf_par2_03.png","cyf_par2_04.png","cyf_par2_05.png","cyf_par2_06.png","cyf_par2_07.png","cyf_par2_08.png","cyf_par2_09.png","cyf_par2_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 83,
              y: 323,
              src: 'kroki.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 109,
              y: 168,
              week_en: ["DT_1.png","DT_2.png","DT_3.png","DT_4.png","DT_5.png","DT_6.png","DT_7.png"],
              week_tc: ["DT_1.png","DT_2.png","DT_3.png","DT_4.png","DT_5.png","DT_6.png","DT_7.png"],
              week_sc: ["DT_1.png","DT_2.png","DT_3.png","DT_4.png","DT_5.png","DT_6.png","DT_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 293,
              day_startY: 172,
              day_sc_array: ["cyf_d_ak_00.png","cyf_d_ak_01.png","cyf_d_ak_02.png","cyf_d_ak_03.png","cyf_d_ak_04.png","cyf_d_ak_05.png","cyf_d_ak_06.png","cyf_d_ak_07.png","cyf_d_ak_08.png","cyf_d_ak_09.png"],
              day_tc_array: ["cyf_d_ak_00.png","cyf_d_ak_01.png","cyf_d_ak_02.png","cyf_d_ak_03.png","cyf_d_ak_04.png","cyf_d_ak_05.png","cyf_d_ak_06.png","cyf_d_ak_07.png","cyf_d_ak_08.png","cyf_d_ak_09.png"],
              day_en_array: ["cyf_d_ak_00.png","cyf_d_ak_01.png","cyf_d_ak_02.png","cyf_d_ak_03.png","cyf_d_ak_04.png","cyf_d_ak_05.png","cyf_d_ak_06.png","cyf_d_ak_07.png","cyf_d_ak_08.png","cyf_d_ak_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 41,
              font_array: ["cyf_d_ak_00.png","cyf_d_ak_01.png","cyf_d_ak_02.png","cyf_d_ak_03.png","cyf_d_ak_04.png","cyf_d_ak_05.png","cyf_d_ak_06.png","cyf_d_ak_07.png","cyf_d_ak_08.png","cyf_d_ak_09.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 110,
              hour_array: ["cyf_HM_00.png","cyf_HM_01.png","cyf_HM_02.png","cyf_HM_03.png","cyf_HM_04.png","cyf_HM_05.png","cyf_HM_06.png","cyf_HM_07.png","cyf_HM_08.png","cyf_HM_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 285,
              minute_startY: 110,
              minute_array: ["cyf_HM_00.png","cyf_HM_01.png","cyf_HM_02.png","cyf_HM_03.png","cyf_HM_04.png","cyf_HM_05.png","cyf_HM_06.png","cyf_HM_07.png","cyf_HM_08.png","cyf_HM_09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 193,
              second_startY: 285,
              second_array: ["cyf_sec_00.png","cyf_sec_01.png","cyf_sec_02.png","cyf_sec_03.png","cyf_sec_04.png","cyf_sec_05.png","cyf_sec_06.png","cyf_sec_07.png","cyf_sec_08.png","cyf_sec_09.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 183,
              y: 362,
              image_array: ["aku_01.png","aku_02.png","aku_03.png","aku_04.png","aku_05.png","aku_06.png","aku_07.png","aku_08.png","aku_09.png","aku_10.png","aku_11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 96,
              hour_startY: 162,
              hour_array: ["cyf_HM_00.png","cyf_HM_01.png","cyf_HM_02.png","cyf_HM_03.png","cyf_HM_04.png","cyf_HM_05.png","cyf_HM_06.png","cyf_HM_07.png","cyf_HM_08.png","cyf_HM_09.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_unit_sc: 'dwuk_aod.png',
              hour_unit_tc: 'dwuk_aod.png',
              hour_unit_en: 'dwuk_aod.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 162,
              minute_array: ["cyf_HM_00.png","cyf_HM_01.png","cyf_HM_02.png","cyf_HM_03.png","cyf_HM_04.png","cyf_HM_05.png","cyf_HM_06.png","cyf_HM_07.png","cyf_HM_08.png","cyf_HM_09.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 274,
              second_startY: 247,
              second_array: ["cyf_sec_00.png","cyf_sec_01.png","cyf_sec_02.png","cyf_sec_03.png","cyf_sec_04.png","cyf_sec_05.png","cyf_sec_06.png","cyf_sec_07.png","cyf_sec_08.png","cyf_sec_09.png"],
              second_zero: 1,
              second_space: 8,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
