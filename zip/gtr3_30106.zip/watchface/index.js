﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BackGround.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 367,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 367,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 261,
              y: 414,
              src: 'Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 230,
              y: 415,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 197,
              y: 415,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 415,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 91,
              week_en: ["DoW0.png","DoW1.png","DoW2.png","DoW3.png","DoW4.png","DoW5.png","DoW6.png"],
              week_tc: ["DoW0.png","DoW1.png","DoW2.png","DoW3.png","DoW4.png","DoW5.png","DoW6.png"],
              week_sc: ["DoW0.png","DoW1.png","DoW2.png","DoW3.png","DoW4.png","DoW5.png","DoW6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 194,
              year_startY: 91,
              year_sc_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              year_tc_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              year_en_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              year_zero: 1,
              year_space: -3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 122,
              month_startY: 88,
              month_sc_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png"],
              month_tc_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png"],
              month_en_array: ["M00.png","M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 68,
              day_startY: 90,
              day_sc_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              day_tc_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              day_en_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 78,
              y: 40,
              w: 300,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF8000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 16,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'BGrade.png',
              unit_tc: 'BGrade.png',
              unit_en: 'BGrade.png',
              negative_image: 'BNC.png',
              invalid_image: 'BNC.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 182,
              y: 15,
              image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 299,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -3,
              dot_image: 'Bdot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 299,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 429,
              am_y: 230,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 429,
              pm_y: 230,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 130,
              hour_array: ["BHour-0.png","BHour-1.png","BHour-2.png","BHour-3.png","BHour-4.png","BHour-5.png","BHour-6.png","BHour-7.png","BHour-8.png","BHour-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 130,
              minute_array: ["BHour-0.png","BHour-1.png","BHour-2.png","BHour-3.png","BHour-4.png","BHour-5.png","BHour-6.png","BHour-7.png","BHour-8.png","BHour-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 377,
              second_startY: 252,
              second_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 100,
              src: 'BHour-DotDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 143,
              y: -5,
              w: 170,
              h: 87,
              src: 'transparent.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 345,
              w: 142,
              h: 64,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 262,
              w: 299,
              h: 75,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 414,
              font_array: ["B0.png","B1.png","B2.png","B3.png","B4.png","B5.png","B6.png","B7.png","B8.png","B9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 413,
              src: 'BatBlack.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 429,
              am_y: 230,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 429,
              pm_y: 230,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 130,
              hour_array: ["BHour-0.png","BHour-1.png","BHour-2.png","BHour-3.png","BHour-4.png","BHour-5.png","BHour-6.png","BHour-7.png","BHour-8.png","BHour-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 130,
              minute_array: ["BHour-0.png","BHour-1.png","BHour-2.png","BHour-3.png","BHour-4.png","BHour-5.png","BHour-6.png","BHour-7.png","BHour-8.png","BHour-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 100,
              src: 'BHour-DotDot.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  