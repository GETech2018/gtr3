﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 196,
              y: 357,
              image_array: ["luna_1.png","luna_2.png","luna_3.png","luna_4.png","luna_5.png","luna_6.png","luna_7.png","luna_8.png","luna_9.png","luna_10.png","luna_11.png","luna_12.png","luna_13.png","luna_14.png","luna_15.png","luna_16.png","luna_17.png","luna_18.png","luna_19.png","luna_20.png","luna_21.png","luna_22.png","luna_23.png","luna_24.png","luna_25.png","luna_26.png","luna_27.png","luna_28.png","luna_29.png","luna_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 303,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -2,
              invalid_image: 'icon_temp.png',
              dot_image: 'icon_punt.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 355,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -2,
              dot_image: 'icon_punt.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 247,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 92,
              y: 184,
              image_array: ["clima_1.png","clima_2.png","clima_3.png","clima_4.png","clima_5.png","clima_6.png","clima_7.png","clima_8.png","clima_9.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 15,
              y: 187,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'icon_gra.png',
              unit_tc: 'icon_gra.png',
              unit_en: 'icon_gra.png',
              negative_image: 'icon_temp.png',
              invalid_image: 'icon_temp.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 133,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 79,
              font_array: ["numWS_0.png","numWS_1.png","numWS_2.png","numWS_3.png","numWS_4.png","numWS_5.png","numWS_6.png","numWS_7.png","numWS_8.png","numWS_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 291,
              font_array: ["numWB_0.png","numWB_1.png","numWB_2.png","numWB_3.png","numWB_4.png","numWB_5.png","numWB_6.png","numWB_7.png","numWB_8.png","numWB_9.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'icon_porc.png',
              unit_tc: 'icon_porc.png',
              unit_en: 'icon_porc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 336,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 142,
              font_array: ["numWB_0.png","numWB_1.png","numWB_2.png","numWB_3.png","numWB_4.png","numWB_5.png","numWB_6.png","numWB_7.png","numWB_8.png","numWB_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 317,
              y: 63,
              image_array: ["steep_1.png","steep_2.png","steep_3.png","steep_4.png","steep_5.png","steep_6.png","steep_7.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 199,
              y: 74,
              week_en: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_tc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_sc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 199,
              day_startY: 38,
              day_sc_array: ["numBS_0.png","numBS_1.png","numBS_2.png","numBS_3.png","numBS_4.png","numBS_5.png","numBS_6.png","numBS_7.png","numBS_8.png","numBS_9.png"],
              day_tc_array: ["numBS_0.png","numBS_1.png","numBS_2.png","numBS_3.png","numBS_4.png","numBS_5.png","numBS_6.png","numBS_7.png","numBS_8.png","numBS_9.png"],
              day_en_array: ["numBS_0.png","numBS_1.png","numBS_2.png","numBS_3.png","numBS_4.png","numBS_5.png","numBS_6.png","numBS_7.png","numBS_8.png","numBS_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 342,
              hour_startY: 180,
              hour_array: ["numBB_0.png","numBB_1.png","numBB_2.png","numBB_3.png","numBB_4.png","numBB_5.png","numBB_6.png","numBB_7.png","numBB_8.png","numBB_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 342,
              minute_startY: 231,
              minute_array: ["numBB_0.png","numBB_1.png","numBB_2.png","numBB_3.png","numBB_4.png","numBB_5.png","numBB_6.png","numBB_7.png","numBB_8.png","numBB_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'analog_hor.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 100,
              hour_posY: 27,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'analog_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 100,
              minute_posY: 27,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'analog_seg.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 100,
              second_posY: 27,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'analog_hor_aod.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 100,
              hour_posY: 27,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'analog_min_aod.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 100,
              minute_posY: 27,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 197,
              y: 32,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 343,
              y: 115,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 234,
              w: 62,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 22,
              y: 172,
              w: 62,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transparent.png',
              normal_src: 'transparent.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}