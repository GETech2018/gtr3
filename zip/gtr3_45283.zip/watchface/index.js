﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_main = 1;
let totalcolors_main = 8; // Tus 8 colores exactos sin el blanco
let namecolor_main = '';

// Variables de rutas de imágenes optimizadas
let hourstring = 'hand_hour1.png';
let minstring = 'hand_min1.png';
let secstring = 'hand_sec1.png';

function click_main() {
    if (colornumber_main >= totalcolors_main) {
        colornumber_main = 1;
    } else {
        colornumber_main = colornumber_main + 1;
    }

    // Mapeo exacto de tus 8 colores ordenados por separado
    if (colornumber_main == 1) { namecolor_main = "CELESTE"; }
    if (colornumber_main == 2) { namecolor_main = "ROJO"; }
    if (colornumber_main == 3) { namecolor_main = "FUCSIA"; }
    if (colornumber_main == 4) { namecolor_main = "AZUL"; }
    if (colornumber_main == 5) { namecolor_main = "VERDE"; }
    if (colornumber_main == 6) { namecolor_main = "LIMA"; }
    if (colornumber_main == 7) { namecolor_main = "AMARILLO"; }
    if (colornumber_main == 8) { namecolor_main = "NARANJA"; }

    // Generar nombres de archivos dinámicamente según el índice del color
    hourstring = 'hand_hour' + colornumber_main + '.png';
    minstring = 'hand_min' + colornumber_main + '.png';
    secstring = 'hand_sec' + colornumber_main + '.png';
    let bg_string = 'main' + colornumber_main + '.png';

    // 1. Actualizar Manecillas del reloj analógico Normal (Hora, Minuto y Segundo Estándar)
    if (typeof normal_analog_clock_time_pointer_hour !== 'undefined') {
        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
            hour_path: hourstring,
            hour_centerX: 227,
            hour_centerY: 227,
            hour_posX: 27,
            hour_posY: 138,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }

    if (typeof normal_analog_clock_time_pointer_minute !== 'undefined') {
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
            minute_path: minstring,
            minute_centerX: 227,
            minute_centerY: 227,
            minute_posX: 23,
            minute_posY: 184,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }

    if (typeof normal_analog_clock_time_pointer_second !== 'undefined') {
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
            second_path: secstring,
            second_centerX: 227,
            second_centerY: 227,
            second_posX: 21,
            second_posY: 227,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }

    // 2. Actualizar Segundero del modo Continuo (AnalogTimePro - Smooth)
    if (typeof normal_analog_clock_pro_second_pointer_img !== 'undefined') {
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, secstring);
    }

    // 3. CAMBIAR FONDO (Corregido: Se aplican los dos métodos de refresco de Zepp OS para forzar el cambio)
    if (typeof normal_image_img !== 'undefined') {
        normal_image_img.setProperty(hmUI.prop.SRC, bg_string); 
        normal_image_img.setProperty(hmUI.prop.MORE, { src: bg_string });
    }

    // Mostrar aviso en pantalla del color seleccionado
    hmUI.showToast({ text: namecolor_main });
}

// === SECCIÓN DEL SEGUNDERO (Alternar entre Ticking y Smooth) ===
let elementnumber_1 = 1;
let total_elemente = 2; 

function click_seg() {
    if (elementnumber_1 >= total_elemente) {
        elementnumber_1 = 1;
        UpdateElementeOne();
    } else {
        elementnumber_1 = elementnumber_1 + 1;
        if (elementnumber_1 == 2) {
            UpdateElementeTwo();
        }
    }
    
    if (elementnumber_1 == 1) hmUI.showToast({ text: 'Movimiento Analógico' });
    if (elementnumber_1 == 2) hmUI.showToast({ text: 'Movimiento Automático' });
}

function UpdateElementeOne() {
    if (typeof normal_analog_clock_pro_second_pointer_img !== 'undefined') {
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
    }
    if (typeof normal_analog_clock_time_pointer_hour !== 'undefined') {
        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
    }
    if (typeof normal_analog_clock_time_pointer_minute !== 'undefined') {
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
    }
    if (typeof normal_analog_clock_time_pointer_second !== 'undefined') {
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
    }
}

function UpdateElementeTwo() {
    if (typeof normal_analog_clock_pro_second_pointer_img !== 'undefined') {
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
    }
    if (typeof normal_analog_clock_time_pointer_hour !== 'undefined') {
        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
    }
    if (typeof normal_analog_clock_time_pointer_minute !== 'undefined') {
        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
    }
    if (typeof normal_analog_clock_time_pointer_second !== 'undefined') {
        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
    }
}

        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main8.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_min8.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 27,
              hour_posY: 137,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min8.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 23,
              minute_posY: 183,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec8.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec8.png',
              // center_x: 227,
              // center_y: 227,
              // x: 19,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 19,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_sec8.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });




            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 196,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_main()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 385,
              y: 196,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_seg()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let cc = 0
			if (cc ==0 ){
			  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}