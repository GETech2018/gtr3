﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_icon_img = ''
        let idle_pai_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 397,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 397,
              src: 'shade_pwr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 355,
              src: 'shade_pipe1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 355,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 355,
              src: 'shade_hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -74,
              y: -267,
              src: 'Shade_hal1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 355,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 355,
              src: 'shade_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 68,
              minute_startY: 239,
              minute_array: ["cruiser_shade_20min_0001.png","cruiser_shade_20min_0002.png","cruiser_shade_20min_0003.png","cruiser_shade_20min_0004.png","cruiser_shade_20min_0005.png","cruiser_shade_20min_0006.png","cruiser_shade_20min_0007.png","cruiser_shade_20min_0008.png","cruiser_shade_20min_0009.png","cruiser_shade_20min_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'cruiser_shade_20min_0011.png',
              minute_unit_tc: 'cruiser_shade_20min_0011.png',
              minute_unit_en: 'cruiser_shade_20min_0011.png',
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 258,
              second_startY: 239,
              second_array: ["cruiser_shade_20min_0001.png","cruiser_shade_20min_0002.png","cruiser_shade_20min_0003.png","cruiser_shade_20min_0004.png","cruiser_shade_20min_0005.png","cruiser_shade_20min_0006.png","cruiser_shade_20min_0007.png","cruiser_shade_20min_0008.png","cruiser_shade_20min_0009.png","cruiser_shade_20min_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 37,
              hour_array: ["cruiser_shade_32_0001.png","cruiser_shade_32_0002.png","cruiser_shade_32_0003.png","cruiser_shade_32_0004.png","cruiser_shade_32_0005.png","cruiser_shade_32_0006.png","cruiser_shade_32_0007.png","cruiser_shade_32_0008.png","cruiser_shade_32_0009.png","cruiser_shade_32_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -28,
              y: 33,
              src: 'Line_shadow _3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 73,
              month_sc_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_tc_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_en_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 73,
              day_sc_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_tc_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_en_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 73,
              week_en: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              week_tc: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              week_sc: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 73,
              font_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'shade_celc.png',
              unit_tc: 'shade_celc.png',
              unit_en: 'shade_celc.png',
              negative_image: 'shade_dash.png',
              invalid_image: 'shade_dash.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 72,
              src: 'shade_pipe.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 10,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -45,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 397,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 136,
              y: 397,
              src: 'shade_pwr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 238,
              y: 355,
              src: 'shade_pipe1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 355,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 252,
              y: 355,
              src: 'shade_hr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -74,
              y: -267,
              src: 'Shade_hal1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 156,
              y: 355,
              font_array: ["stats_black_cruiser_shade_8min_0001.png","stats_black_cruiser_shade_8min_0002.png","stats_black_cruiser_shade_8min_0003.png","stats_black_cruiser_shade_8min_0004.png","stats_black_cruiser_shade_8min_0005.png","stats_black_cruiser_shade_8min_0006.png","stats_black_cruiser_shade_8min_0007.png","stats_black_cruiser_shade_8min_0008.png","stats_black_cruiser_shade_8min_0009.png","stats_black_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 355,
              src: 'shade_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 68,
              minute_startY: 239,
              minute_array: ["cruiser_shade_20min_0001.png","cruiser_shade_20min_0002.png","cruiser_shade_20min_0003.png","cruiser_shade_20min_0004.png","cruiser_shade_20min_0005.png","cruiser_shade_20min_0006.png","cruiser_shade_20min_0007.png","cruiser_shade_20min_0008.png","cruiser_shade_20min_0009.png","cruiser_shade_20min_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'cruiser_shade_20min_0011.png',
              minute_unit_tc: 'cruiser_shade_20min_0011.png',
              minute_unit_en: 'cruiser_shade_20min_0011.png',
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 258,
              second_startY: 239,
              second_array: ["cruiser_shade_20min_0001.png","cruiser_shade_20min_0002.png","cruiser_shade_20min_0003.png","cruiser_shade_20min_0004.png","cruiser_shade_20min_0005.png","cruiser_shade_20min_0006.png","cruiser_shade_20min_0007.png","cruiser_shade_20min_0008.png","cruiser_shade_20min_0009.png","cruiser_shade_20min_0010.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 93,
              hour_startY: 37,
              hour_array: ["cruiser_shade_32_0001.png","cruiser_shade_32_0002.png","cruiser_shade_32_0003.png","cruiser_shade_32_0004.png","cruiser_shade_32_0005.png","cruiser_shade_32_0006.png","cruiser_shade_32_0007.png","cruiser_shade_32_0008.png","cruiser_shade_32_0009.png","cruiser_shade_32_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -28,
              y: 33,
              src: 'Line_shadow _3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 73,
              month_sc_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_tc_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_en_array: ["months_white_cruiser_shade_8min_0001.png","months_white_cruiser_shade_8min_0002.png","months_white_cruiser_shade_8min_0003.png","months_white_cruiser_shade_8min_0004.png","months_white_cruiser_shade_8min_0005.png","months_white_cruiser_shade_8min_0006.png","months_white_cruiser_shade_8min_0007.png","months_white_cruiser_shade_8min_0008.png","months_white_cruiser_shade_8min_0009.png","months_white_cruiser_shade_8min_0010.png","months_white_cruiser_shade_8min_0011.png","months_white_cruiser_shade_8min_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 73,
              day_sc_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_tc_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_en_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 171,
              y: 73,
              week_en: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              week_tc: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              week_sc: ["day_white_cruiser_shade_8min_0001.png","day_white_cruiser_shade_8min_0002.png","day_white_cruiser_shade_8min_0003.png","day_white_cruiser_shade_8min_0004.png","day_white_cruiser_shade_8min_0005.png","day_white_cruiser_shade_8min_0006.png","day_white_cruiser_shade_8min_0007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 73,
              font_array: ["stats_white_cruiser_shade_8min_0001.png","stats_white_cruiser_shade_8min_0002.png","stats_white_cruiser_shade_8min_0003.png","stats_white_cruiser_shade_8min_0004.png","stats_white_cruiser_shade_8min_0005.png","stats_white_cruiser_shade_8min_0006.png","stats_white_cruiser_shade_8min_0007.png","stats_white_cruiser_shade_8min_0008.png","stats_white_cruiser_shade_8min_0009.png","stats_white_cruiser_shade_8min_0010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'shade_celc.png',
              unit_tc: 'shade_celc.png',
              unit_en: 'shade_celc.png',
              negative_image: 'shade_dash.png',
              invalid_image: 'shade_dash.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 72,
              src: 'shade_pipe.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 10,
              image_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -45,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -28,
              y: -8,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}