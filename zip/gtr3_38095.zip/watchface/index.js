﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'WATCH_BACKGROUND.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 315,
              y: 340,
              src: 'LOCK.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 340,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 393,
              src: 'BLUETOOTH.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 139,
              y: 393,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 97,
              y: 43,
              week_en: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              week_tc: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              week_sc: ["DAY_01.png","DAY_02.png","DAY_03.png","DAY_04.png","DAY_05.png","DAY_06.png","DAY_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 197,
              day_startY: 78,
              day_sc_array: ["D_00.png","D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png","D_08.png","D_09.png"],
              day_tc_array: ["D_00.png","D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png","D_08.png","D_09.png"],
              day_en_array: ["D_00.png","D_01.png","D_02.png","D_03.png","D_04.png","D_05.png","D_06.png","D_07.png","D_08.png","D_09.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 115,
              month_sc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_tc_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_en_array: ["MONTH_01.png","MONTH_02.png","MONTH_03.png","MONTH_04.png","MONTH_05.png","MONTH_06.png","MONTH_07.png","MONTH_08.png","MONTH_09.png","MONTH_10.png","MONTH_11.png","MONTH_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 338,
              font_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 338,
              font_array: ["N_00.png","N_01.png","N_02.png","N_03.png","N_04.png","N_05.png","N_06.png","N_07.png","N_08.png","N_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 346,
              font_array: ["T_00.png","T_01.png","T_02.png","T_03.png","T_04.png","T_05.png","T_06.png","T_07.png","T_08.png","T_09.png"],
              padding: false,
              h_space: 1,
              negative_image: 'T_MINUS.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 280,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 280,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 25,
              y: 144,
              image_array: ["BAT_01.png","BAT_02.png","BAT_03.png","BAT_04.png","BAT_05.png","BAT_06.png","BAT_07.png","BAT_08.png","BAT_09.png","BAT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 158,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 1,
              dot_image: 'NN_POINT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 158,
              font_array: ["NN_00.png","NN_01.png","NN_02.png","NN_03.png","NN_04.png","NN_05.png","NN_06.png","NN_07.png","NN_08.png","NN_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 354,
              y: 144,
              image_array: ["STP_01.png","STP_02.png","STP_03.png","STP_04.png","STP_05.png","STP_06.png","STP_07.png","STP_08.png","STP_09.png","STP_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 126,
              hour_startY: 201,
              hour_array: ["TIME_00.png","TIME_01.png","TIME_02.png","TIME_03.png","TIME_04.png","TIME_05.png","TIME_06.png","TIME_07.png","TIME_08.png","TIME_09.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 201,
              minute_array: ["TIME_00.png","TIME_01.png","TIME_02.png","TIME_03.png","TIME_04.png","TIME_05.png","TIME_06.png","TIME_07.png","TIME_08.png","TIME_09.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'HS.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'PERIMETR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}