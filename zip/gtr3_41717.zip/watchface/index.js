﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 410,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0071.png',
              unit_tc: '0071.png',
              unit_en: '0071.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 47,
              hour_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              hour_zero: 1,
              hour_space: -36,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 313,
              minute_startY: 101,
              minute_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 188,
              second_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 214,
              am_y: 11,
              am_sc_path: '0004.png',
              am_en_path: '0004.png',
              pm_x: 214,
              pm_y: 11,
              pm_sc_path: '0005.png',
              pm_en_path: '0005.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 353,
              font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 294,
              week_en: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              week_tc: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              week_sc: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 239,
              month_sc_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_tc_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_en_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 13,
              day_startY: 240,
              day_sc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_tc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_en_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 196,
              y: 410,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0071.png',
              unit_tc: '0071.png',
              unit_en: '0071.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 47,
              hour_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              hour_zero: 1,
              hour_space: -36,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 313,
              minute_startY: 101,
              minute_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 340,
              second_startY: 188,
              second_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 214,
              am_y: 11,
              am_sc_path: '0004.png',
              am_en_path: '0004.png',
              pm_x: 214,
              pm_y: 11,
              pm_sc_path: '0005.png',
              pm_en_path: '0005.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 353,
              font_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 95,
              y: 294,
              week_en: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              week_tc: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              week_sc: ["dd_1.png","dd_2.png","dd_3.png","dd_4.png","dd_5.png","dd_6.png","dd_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 218,
              month_startY: 239,
              month_sc_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_tc_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_en_array: ["mm_1.png","mm_2.png","mm_3.png","mm_4.png","mm_5.png","mm_6.png","mm_7.png","mm_8.png","mm_9.png","mm_10.png","mm_11.png","mm_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 13,
              day_startY: 240,
              day_sc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_tc_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_en_array: ["0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 341,
              w: 181,
              h: 51,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 287,
              w: 261,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 316,
              y: 104,
              w: 89,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}