﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let editableZone_1_battery_circle_scale = null;
        let editableZone_1_step_circle_scale = null;
        let editableZone_1_calorie_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_pai_circle_scale = null;
        let editableZone_1_stand_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_battery_circle_scale = null;
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editableZone_2_heart_rate_circle_scale = null;
        let editableZone_2_pai_circle_scale = null;
        let editableZone_2_stand_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_battery_circle_scale = null;
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editableZone_3_pai_circle_scale = null;
        let editGroup_3  = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 67,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -5,
              dot_image: 'dig_sm_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 38,
              src: 'icon_19.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 11,
              hour_startY: 0,
              hour_array: ["H2_0.png","H2_1.png","H2_2.png","H2_3.png","H2_4.png","H2_5.png","H2_6.png","H2_7.png","H2_8.png","H2_9.png"],
              hour_zero: 1,
              hour_space: -42,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 207,
              minute_array: ["H1_0.png","H1_1.png","H1_2.png","H1_3.png","H1_4.png","H1_5.png","H1_6.png","H1_7.png","H1_8.png","H1_9.png"],
              minute_zero: 1,
              minute_space: -42,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 266,
              second_startY: 371,
              second_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              second_zero: 0,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 293,
              y: 306,
              image_array: ["Weat_1.png","Weat_2.png","Weat_3.png","Weat_4.png","Weat_5.png","Weat_6.png","Weat_7.png","Weat_8.png","Weat_9.png","Weat_10.png","Weat_11.png","Weat_12.png","Weat_13.png","Weat_14.png","Weat_15.png","Weat_16.png","Weat_17.png","Weat_18.png","Weat_19.png","Weat_20.png","Weat_21.png","Weat_22.png","Weat_23.png","Weat_24.png","Weat_25.png","Weat_26.png","Weat_27.png","Weat_28.png","Weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 197,
              src: 'icon_18.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 0,
              y: 224,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 276,
              y: 163,
              week_en: ["W-01.png","W-02.png","W-03.png","W-04.png","W-05.png","W-06.png","W-07.png"],
              week_tc: ["W-01.png","W-02.png","W-03.png","W-04.png","W-05.png","W-06.png","W-07.png"],
              week_sc: ["W-01.png","W-02.png","W-03.png","W-04.png","W-05.png","W-06.png","W-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 266,
              day_startY: 194,
              day_sc_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_tc_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_en_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_zero: 0,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 280,
              month_startY: 252,
              month_sc_array: ["M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png","M-10.png","M-11.png","M-12.png"],
              month_tc_array: ["M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png","M-10.png","M-11.png","M-12.png"],
              month_en_array: ["M-01.png","M-02.png","M-03.png","M-04.png","M-05.png","M-06.png","M-07.png","M-08.png","M-09.png","M-10.png","M-11.png","M-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 154,
              src: 'status_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 274,
              src: 'status_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Editable_Elements');

            let screenType = hmSetting.getScreenType();            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 358,
              y: 173,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY_preview .png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(1)_FAT_BURNING.png'},
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '00003.png',
              tips_x: -261,
              tips_y: 35,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 398,
                  y: 176,
                  src: 'icon_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 407,
                  center_y: 227,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 376,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 401,
                  y: 178,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 407,
                  center_y: 227,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 370,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 398,
                  y: 173,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 407,
                  center_y: 227,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 376,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 394,
                  y: 181,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 407,
                  center_y: 227,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 395,
                  y: 173,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 407,
                    center_y: 227,
                    start_angle: 40,
                    end_angle: 320,
                    radius: 40,
                    line_width: 8,
                    corner_flag: 0,
                    color: 0xFF04B5BB,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 371,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 401,
                  y: 173,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 407,
                    center_y: 227,
                    start_angle: 40,
                    end_angle: 320,
                    radius: 40,
                    line_width: 8,
                    corner_flag: 0,
                    color: 0xFF04B5BB,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                stand.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 362,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 396,
                  y: 173,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 384,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 396,
              y: 173,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 391,
                  y: 171,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 390,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 399,
                  y: 175,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 376,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 394,
                  y: 173,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 374,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 398,
                  y: 173,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 206,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 228,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 398,
                  y: 173,
                  src: 'icon_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 390,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 331,
              y: 76,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY_preview .png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(1)_FAT_BURNING.png'},
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '00003.png',
              tips_x: -234,
              tips_y: 36,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 366,
                  y: 76,
                  src: 'icon_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 130,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 371,
                  y: 77,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 130,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 368,
                  y: 77,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 130,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 77,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 130,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 79,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 376,
                    center_y: 130,
                    start_angle: 40,
                    end_angle: 320,
                    radius: 40,
                    line_width: 8,
                    corner_flag: 0,
                    color: 0xFF04B5BB,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 340,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 370,
                  y: 79,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_2_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 376,
                    center_y: 130,
                    start_angle: 40,
                    end_angle: 320,
                    radius: 40,
                    line_width: 8,
                    corner_flag: 0,
                    color: 0xFF04B5BB,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 77,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 77,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 117,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 80,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 117,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 78,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 345,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 76,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 120,
                  font_array: ["dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png","dig_sm_10.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 76,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 109,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 132,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 76,
                  src: 'icon_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 331,
              y: 271,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY_preview.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: hmUI.edit_type.FAT_BURN, preview: 'ez(1)_FAT_BURNING.png'},
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '00003.png',
              tips_x: -234,
              tips_y: 35,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 273,
                  src: 'icon_18.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 324,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 370,
                  y: 273,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 324,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 337,
                  y: 316,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 273,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 324,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 274,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                  center_x: 376,
                  center_y: 324,
                  start_angle: 40,
                  end_angle: 320,
                  radius: 40,
                  line_width: 8,
                  corner_flag: 0,
                  color: 0xFF04B5BB,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 275,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 37,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // line_cap: Rounded,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                    center_x: 376,
                    center_y: 324,
                    start_angle: 37,
                    end_angle: 320,
                    radius: 40,
                    line_width: 8,
                    corner_flag: 0,
                    color: 0xFF04B5BB,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -5,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 370,
                  y: 274,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 366,
                  y: 272,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.FAT_BURN:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 274,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 366,
                  y: 275,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 357,
                  y: 313,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 369,
                  y: 275,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 274,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 274,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 342,
                  y: 304,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 326,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 274,
                  src: 'icon_3.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 360,
                  y: 313,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            function scale_call() {
              console.log('scale_call()');

                console.log('update editable circle_scale BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_editableZone_1_battery = progressBattery;

                if (editableZone_1_battery_circle_scale) {

                  // editableZone_1_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_battery * 100);
                  if (editableZone_1_battery_circle_scale) {
                    editableZone_1_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_step * 100);
                  if (editableZone_1_step_circle_scale) {
                    editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_1_calorie = progressCalories;

                if (editableZone_1_calorie_circle_scale) {

                  // editableZone_1_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_calorie * 100);
                  if (editableZone_1_calorie_circle_scale) {
                    editableZone_1_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_heart_rate * 100);
                  if (editableZone_1_heart_rate_circle_scale) {
                    editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_1_pai = progressPAI;

                if (editableZone_1_pai_circle_scale) {

                  // editableZone_1_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_pai * 100);
                  if (editableZone_1_pai_circle_scale) {
                    editableZone_1_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_editableZone_1_stand = progressStand;

                if (editableZone_1_stand_circle_scale) {

                  // editableZone_1_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_1_stand * 100);
                  if (editableZone_1_stand_circle_scale) {
                    editableZone_1_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 407,
                      center_y: 227,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_2_battery = progressBattery;

                if (editableZone_2_battery_circle_scale) {

                  // editableZone_2_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_battery * 100);
                  if (editableZone_2_battery_circle_scale) {
                    editableZone_2_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_step * 100);
                  if (editableZone_2_step_circle_scale) {
                    editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_2_calorie = progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_calorie * 100);
                  if (editableZone_2_calorie_circle_scale) {
                    editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_heart_rate * 100);
                  if (editableZone_2_heart_rate_circle_scale) {
                    editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_2_pai = progressPAI;

                if (editableZone_2_pai_circle_scale) {

                  // editableZone_2_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_pai * 100);
                  if (editableZone_2_pai_circle_scale) {
                    editableZone_2_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STAND');
                let progress_cs_editableZone_2_stand = progressStand;

                if (editableZone_2_stand_circle_scale) {

                  // editableZone_2_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_2_stand * 100);
                  if (editableZone_2_stand_circle_scale) {
                    editableZone_2_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 130,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale BATTERY');
                let progress_cs_editableZone_3_battery = progressBattery;

                if (editableZone_3_battery_circle_scale) {

                  // editableZone_3_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_battery * 100);
                  if (editableZone_3_battery_circle_scale) {
                    editableZone_3_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 324,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_step * 100);
                  if (editableZone_3_step_circle_scale) {
                    editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 324,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_calorie * 100);
                  if (editableZone_3_calorie_circle_scale) {
                    editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 324,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_heart_rate * 100);
                  if (editableZone_3_heart_rate_circle_scale) {
                    editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 324,
                      start_angle: 40,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_3_pai = progressPAI;

                if (editableZone_3_pai_circle_scale) {

                  // editableZone_3_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_editableZone_3_pai * 100);
                  if (editableZone_3_pai_circle_scale) {
                    editableZone_3_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 376,
                      center_y: 324,
                      start_angle: 37,
                      end_angle: 320,
                      radius: 40,
                      line_width: 8,
                      corner_flag: 0,
                      color: 0xFF04B5BB,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}