
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_stand_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_heart_rate_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
		let dateText = null;
        //dynamic modify end
    
       let nongli = null;

    let zodiacs = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
    let Gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
    let Zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
    let weekday = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']

    let now = null
    let countDownTimer = null
    //用于计算农历年月日的数据
    let GY = 0
    let GM = 0
    let GD = 0

    let year = 0
    let month = 0
    let date = 0
    let hours = 0
    let minutes = 0
    let seconds = 0

    const calendar = {
      gregorianYear: null,          //公历年
      gregorianMonth: null,         //公历月
      gregorianDay: null,           //公历日
      weekday: null,                //星期
      hours: null,
      minutes: null,
      seconds: null,

      lunarYear: null,              //农历年
      lunarMonth: null,             //农历月
      lunarDay: null,               //农历日

      lunarYearCn: '',              //农历天干地支纪年
      lunarMonthCn: '',             //农历中文月
      lunarDayCn: '',               //农历中文日
      zodiacYear: '',               //农历生肖年

      solarTerm: '',                //节气
      gregorianFestival: '',        //公历节日
      lunarFestival: ''             //农历节日
    }

    let lunarInfo = [
      0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
      0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
      0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
      0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
      0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
      0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573, 0x052d0, 0x0a9a8, 0x0e950, 0x06aa0,
      0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
      0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6,
      0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
      0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0,
      0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
      0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
      0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
      0x05aa0, 0x076a3, 0x096d0, 0x04bd7, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
      0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0]

    /**
             * 阳历节日
             */
    let festival = {
      '1-1': { title: '元旦' },
      '2-2': { title: '世界湿地日' },
      '2-14': { title: '情人节' },
      '3-5': { title: '雷锋日' },
      '3-8': { title: '妇女节' },
      '3-12': { title: '植树节' },
      '3-15': { title: '消权日' },
      '4-1': { title: '愚人节' },
      '4-22': { title: '地球日' },
      '5-1': { title: '劳动节' },
      '5-4': { title: '青年节' },
      '5-12': { title: '护士节' },
      '6-1': { title: '国际儿童节' },
      '7-1': { title: '建党节' },
      '8-1': { title: '建军节' },
      '8-19': { title: '中国医师节' },
      '9-10': { title: '教师节' },
      '9-30': { title: '烈士纪念日' },
      '10-1': { title: '国庆节' },
      '10-31': { title: '万圣前夜' },
      '11-1': { title: '万圣节' },
      '12-13': { title: '国家公祭日' },
      '12-20': { title: '澳门回归' },
      '12-24': { title: '平安夜' },
      '12-25': { title: '圣诞节' }
    }

    /**
    * 农历节日
    */
    let lfestival = {
      //'12-30': { title: '除夕' },
      '1-1': { title: '春节' },
      '1-15': { title: '元宵节' },
      '2-2': { title: '龙抬头' },
      '5-5': { title: '端午节' },
      '7-7': { title: '七夕节' },
      '7-15': { title: '中元节' },
      '8-15': { title: '中秋节' },
      '9-9': { title: '重阳节' },
      '12-8': { title: '腊八节' },
      '12-23': { title: '北方小年' },
      '12-24': { title: '南方小年' },
      '2-19': { title: '观音诞' },
      '6-19': { title: '观音诞' },
      '9-19': { title: '观音诞' }
    }

    //母亲节和父亲节、感恩节
    function getMotherOrFatherDay(year, month, day) {
      if (month != 5 && month != 6 && month != 11) return null;
      if ((month == 5 && (day < 8 || day > 14)) || (month == 6 && (day < 15 || day > 21)) || (month == 11 && (day < 22 || day > 28))) return null;
      var d = new Date(year, month - 1, 1, 1, 1, 1, 0)
      var weekDate = (d.getDay() == 0 ? 7 : d.getDay()) - 1;

      switch (month) {
        case 5:
          weekDate = 7 - weekDate;
          if (day == 7 + weekDate) {
            return "母亲节";
          }
          break;
        case 6:
          weekDate = 7 - weekDate;
          if (day == 14 + weekDate) {
            return "父亲节";
          }
          break;
        case 11:
          weekDate = weekDate >= 4 ? (11 - weekDate) : (4 - weekDate)
          if (day == 21 + weekDate) {
            return "感恩节"
          }
          break;
      }
      return null;
    }

    //==== 传入 offset 传回干支, 0=甲子
    function cyclical(num) {
      return (Gan[num % 10] + Zhi[num % 12])
    }

    //==== 传回农历 year年的总天数
    function lYearDays(year) {
      let i, sum = 348
      for (i = 0x8000; i > 0x8; i >>= 1) {
        sum += (lunarInfo[year - 1900] & i) ? 1 : 0
      }
      return (sum + leapDays(year))
    }

    //==== 传回农历 year年闰月的天数
    function leapDays(year) {
      if (leapMonth(year)) {
        return ((lunarInfo[year - 1900] & 0x10000) ? 30 : 29)
      }
      else {
        return 0
      }
    }

    //==== 传回农历 year年闰哪个月 1-12 , 没闰传回 0
    function leapMonth(year) {
      return (lunarInfo[year - 1900] & 0xf)
    }

    //==== 传回农历 year年month月的总天数
    function monthDays(year, month) {
      return ((lunarInfo[year - 1900] & (0x10000 >> month)) ? 30 : 29)
    }

    //==== 算出农历, 传入日期对象, 传回农历日期对象
    //     该对象属性有 农历年year 农历月month 农历日day 是否闰年isLeap yearCyl dayCyl monCyl
    function Lunar(objDate) {
      let i, temp = 0
      let baseDate = new Date(1900, 0, 31)
      let offset = Math.floor((objDate - baseDate) / 86400000)

      let dayCyl = offset + 40
      let monCyl = 14

      for (i = 1900; i < 2050 && offset > 0; i++) {
        temp = lYearDays(i)
        offset -= temp
        monCyl += 12
      }
      if (offset < 0) {
        offset += temp;
        i--;
        monCyl -= 12
      }
      //农历年
      let year = i
      let yearCyl = i - 1864

      let leap = leapMonth(i) //闰哪个月
      let isLeap = false  //是否闰年

      for (i = 1; i < 13 && offset > 0; i++) {
        //闰月
        if (leap > 0 && i === (leap + 1) && isLeap === false) {
          --i; isLeap = true; temp = leapDays(year);
        }
        else {
          temp = monthDays(year, i);
        }

        //解除闰月
        if (isLeap === true && i === (leap + 1)) {
          isLeap = false
        }

        offset -= temp
        if (isLeap === false) {
          monCyl++
        }
      }

      if (offset === 0 && leap > 0 && i === leap + 1)
        if (isLeap) {
          isLeap = false
        }
        else {
          isLeap = true
          --i
          --monCyl
        }

      if (offset < 0) {
        offset += temp
        --i
        --monCyl
      }
      //农历月
      let month = i
      //农历日
      let day = offset + 1
      let dateStr = '' + month + "-" + day
      let holidayTemp = lfestival[dateStr]
      let holiday = holidayTemp ? holidayTemp.title : null
      if (holiday == null && month == 12 && ((temp == 29 && day == 29) || (temp == 30 && day == 30))) {
        holiday = '除夕';
      }

      return {
        year: year,
        month: month,
        day: day,
        isLeap: isLeap,
        leap: leap,
        yearCyl: yearCyl,
        dayCyl: dayCyl,
        monCyl: monCyl,
        holiday: holiday
      }
    }

    //==== 中文日期 m为传入月份，d为传入日期
    function cDay(m, d) {
      let nStrMonth = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊']
      let nStr1 = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
      let nStr2 = ['初', '十', '廿', '卅', '']
      //农历中文月
      let lunarMonthCn
      //农历中文日
      let lunarDayCn

      lunarMonthCn = nStrMonth[m - 1]

      lunarMonthCn += '月'

      switch (d) {
        case 10: lunarDayCn = '初十'; break;
        case 20: lunarDayCn = '二十'; break;
        case 30: lunarDayCn = '三十'; break;
        default: lunarDayCn = nStr2[Math.floor(d / 10)] + nStr1[d % 10]
      }
      return {
        lunarMonthCn: lunarMonthCn,
        lunarDayCn: lunarDayCn
      }
    }

    //节气
    function getSolarTerm() {
      let sTermInfo = [
        0, 21208, 42467, 63836, 85337, 107014,
        128867, 150921, 173149, 195551, 218072, 240693,
        263343, 285989, 308563, 331033, 353350, 375494,
        397447, 419210, 440795, 462224, 483532, 504758
      ]
      let solarTerm = [
        '小寒', '大寒', '立春', '雨水', '惊蛰', '春分',
        '清明', '谷雨', '立夏', '小满', '芒种', '夏至',
        '小暑', '大暑', '立秋', '处暑', '白露', '秋分',
        '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'
      ]

      let solarTerms = ''
      let tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2 + 1] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      let tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2 + 1]
      tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2]

      return solarTerms
    }
        now = hmSensor.    createSensor(hmSensor.id.TIME);

        function add0(v) {
          if (v < 10) return "0" + v;
          else return v;
        }

        function updateCalendar() {
          if (now == null) {
            now = hmSensor.createSensor(hmSensor.id.TIME)
          }
          //用于计算农历年月日的数据
          GY = now.year
          GM = now.month - 1
          GD = now.day

          year = now.year
          month = now.month - 1 + 1
          date = now.day
          hours = now.hour
          minutes = now.minute
          seconds = now.second
		  
		  if (year != calendar.gregorianYear || month != calendar.gregorianMonth || date != calendar.gregorianDay) {
          let dateStr = '' + month + "-" + date
          let holidayTemp = festival[dateStr]
          let holiday = holidayTemp ? holidayTemp.title : null
          calendar.gregorianFestival = holiday
          if (calendar.gregorianFestival == '' || calendar.gregorianFestival == null) {
            calendar.gregorianFestival = getMotherOrFatherDay(year, month, date)
          }
          // month = month.toString().padStart(2, '0')
          // date = date.toString().padStart(2, '0')
          // hours = hours.toString().padStart(2, '0')
          // minutes = minutes.toString().padStart(2, '0')
          // seconds = seconds.toString().padStart(2, '0')
          //公历年月日、星期、时分秒
          calendar.gregorianYear = year
          calendar.gregorianMonth = month
          calendar.gregorianDay = date
          calendar.weekday = weekday[now.week - 1]
          calendar.hours = hours
          calendar.minutes = minutes
          calendar.seconds = seconds

          //去掉时分秒的日期
          let sDObj = new Date(GY, GM, GD);
          let lDObj = new Lunar(sDObj);

          //农历年月日、生肖年,数字
          calendar.lunarYear = lDObj.year
          calendar.lunarMonth = lDObj.month
          calendar.lunarDay = lDObj.day
          calendar.zodiacYear = zodiacs[(GY - 4) % 12]

          //农历中文年月日
          calendar.lunarYearCn = cyclical(GY - 1900 + 36)
          calendar.lunarMonthCn = cDay(lDObj.month, lDObj.day).lunarMonthCn
          calendar.lunarDayCn = cDay(lDObj.month, lDObj.day).lunarDayCn
          calendar.lunarFestival = lDObj.holiday

          //节气
          calendar.solarTerm = getSolarTerm()
		  if (dateText != null) {
                dateText.setProperty(hmUI.prop.TEXT, " " + add0(now.month) + "月" + add0(now.day) + "日 " + calendar.weekday);
            }
			
          if (nongli != null) {
            var str = "" + calendar.lunarMonthCn + "" + calendar.lunarDayCn + "";
            if (calendar.solarTerm != '') {//节气
              str = "" + calendar.solarTerm;
            }
            if (calendar.lunarFestival != null) {//农历节日
              str = " " + calendar.lunarFestival;
            }
            if (calendar.gregorianFestival != null) {//公历节日纪念日
              str = " " + calendar.gregorianFestival;
            }

            nongli.setProperty(hmUI.prop.TEXT, str);
          }
		   
        }
		}
        //dynamic modify end

        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
//农历数值 
     nongli = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 265,
          y: 110,
          w: 200,//文本容器宽度,文本会居中显示
          h: 30,//文本容器高度
          color: 0xFFFFFFFF,
          text_size: 18,
          text: "",
          align_h: hmUI.align.LEFT,
	      align_v: hmUI.align.TOP,
	show_level: hmUI.show_level.  ONLY_NORMAL
				}), 
		
        updateCalendar();

        //创建一个监听器，每次表盘显示时更新
        var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {//表盘显示
            console.log('ui resume');
            updateCalendar()

          }),
          pause_call: (function () {
            console.log('ui pause');
          }),

        });
            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 108,
              y: 85,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              invalid_image: '13.png',
              dot_image: '14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 264,
              y: 85,
              font_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              padding: false,
              h_space: 0,
              invalid_image: '25.png',
              dot_image: '26.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 240,
              y: 330,
              week_en: ["213.png","214.png","215.png","216.png","217.png","218.png","219.png"],
              week_tc: ["213.png","214.png","215.png","216.png","217.png","218.png","219.png"],
              week_sc: ["213.png","214.png","215.png","216.png","217.png","218.png","219.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 145,
              font_array: ["105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 85,
              font_array: ["27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png"],
              padding: false,
              h_space: 0,
              invalid_image: '37.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 145,
              font_array: ["38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png"],
              padding: false,
              h_space: 0,
              negative_image: '49.png',
              invalid_image: '48.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 121,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              padding: false,
              h_space: 0,
              negative_image: '61.png',
              invalid_image: '60.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 121,
              font_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              padding: false,
              h_space: 0,
              negative_image: '63.png',
              invalid_image: '62.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 120,
              image_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 169,
              font_array: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png"],
              padding: false,
              h_space: 0,
              invalid_image: '75.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 170,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              invalid_image: '116.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 341,
              y: 116,
              image_array: ["117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 50,
              y: 248,
              font_array: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png"],
              padding: false,
              h_space: 2,
              invalid_image: '157.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 307,
              font_array: ["158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png"],
              padding: false,
              h_space: 0,
              invalid_image: '168.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '169.png',
              center_x: 101,
              center_y: 315,
              x: 9,
              y: 36,
              start_angle: -130,
              end_angle: 132,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 145,
              y: 279,
              image_array: ["170.png","171.png","172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png","181.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 235,
              hour_startY: 253,
              hour_array: ["182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png","190.png","191.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 309,
              minute_startY: 253,
              minute_array: ["182.png","183.png","184.png","185.png","186.png","187.png","188.png","189.png","190.png","191.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 372,
              second_startY: 269,
              second_array: ["192.png","193.png","194.png","195.png","196.png","197.png","198.png","199.png","200.png","201.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 253,
              src: '212.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 34,
              y: 203,
              image_array: ["202.png","203.png","204.png","205.png","206.png","207.png","208.png","209.png","210.png","211.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 359,
              day_startY: 301,
              day_sc_array: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png"],
              day_tc_array: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png"],
              day_en_array: ["240.png","241.png","242.png","243.png","244.png","245.png","246.png","247.png","248.png","249.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 314,
              month_startY: 301,
              month_sc_array: ["230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              month_tc_array: ["230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              month_en_array: ["230.png","231.png","232.png","233.png","234.png","235.png","236.png","237.png","238.png","239.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 241,
              year_startY: 301,
              year_sc_array: ["220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              year_tc_array: ["220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              year_en_array: ["220.png","221.png","222.png","223.png","224.png","225.png","226.png","227.png","228.png","229.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 367,
              font_array: ["250.png","251.png","252.png","253.png","254.png","255.png","256.png","257.png","258.png","259.png"],
              padding: false,
              h_space: 2,
              invalid_image: '260.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 367,
              font_array: ["261.png","262.png","263.png","264.png","265.png","266.png","267.png","268.png","269.png","270.png"],
              padding: false,
              h_space: 0,
              invalid_image: '271.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 389,
              font_array: ["272.png","273.png","274.png","275.png","276.png","277.png","278.png","279.png","280.png","281.png"],
              padding: false,
              h_space: 0,
              invalid_image: '282.png',
              dot_image: '283.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 367,
              font_array: ["284.png","285.png","286.png","287.png","288.png","289.png","290.png","291.png","292.png","293.png"],
              padding: false,
              h_space: 2,
              invalid_image: '294.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 34,
              src: '295.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });





            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '298.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 36,
              y: 267,
              image_array: ["310.png","311.png","312.png","313.png","314.png","315.png","316.png","317.png","318.png","319.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 74,
              hour_startY: 135,
              hour_array: ["299.png","300.png","301.png","302.png","303.png","304.png","305.png","306.png","307.png","308.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 242,
              minute_startY: 135,
              minute_array: ["299.png","300.png","301.png","302.png","303.png","304.png","305.png","306.png","307.png","308.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 41,
              y: 87,
              src: '309.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });



// SMOOTH SECONDS Definition
            let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 19;
            let second_posY = 227;
            let second_path = "297.png";
            // ----------------------------
            let lastTime = 0;
            let animTimer;
            const animDuration = 5000;
            const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
            const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection

            // Smooth Seconds
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: second_centerX - second_posX,
              pos_y: second_centerY - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
              }
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
            }

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {  // when the screen turns on, create a timer to update the animation
                console.log('ui resume');

                const screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.WATCHFACE) return;  // if not the main screen of the dial, then do nothing
                if (animTimer) return;  // if the timer is already running, then do nothing

                let duration = 0;
                const diffTime = now.utc - lastTime;
                if (diffTime < animDuration) {
                  duration = animDuration - diffTime;  // we calculate the timer start delay, depending on the time of its last start (so that there is no overlap of two animations)
                }

                console.log('createTimer');
                animTimer = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = now.utc;
                  let sec = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);  // we calculate the angle of the second hand depending on the seconds and milliseconds.
                  startSecAnim(sec);
                }));
              }),
              pause_call: (function () {  // when the screen turns off, delete the timer
                console.log('ui pause');
                if (animTimer) {
                  timer.stopTimer(animTimer);
                  animTimer = undefined;
                }
              }),
            });
            // SMOOTH SECONDS Definition End
 //START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 121,
              w: 80,
              h: 80,
              src: 'blank.png', // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
		hmApp.startApp({ appid: 1, url: 'CompassScreen', native: true })
            });
//END Calendar Shortcut
                   },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  