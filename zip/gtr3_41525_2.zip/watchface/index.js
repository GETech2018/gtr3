﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// Definición de estilos disponibles
const STYLES = {
    1: {
        name: 'BLACK STYLE',
        image: 'main1.png'
    },
    2: {
        name: 'BLUE STYLE',
        image: 'main2.png'
    }
};

class StyleSwitcher {
    constructor() {
        this.currentStyle = 1;
        this.totalStyles = Object.keys(STYLES).length;
    }

    /**
     * Cambia al siguiente estilo disponible
     * @returns {void}
     */
    switchStyle() {
        // Calcula el siguiente estilo usando operador módulo
        this.currentStyle = (this.currentStyle % this.totalStyles) + 1;

        const style = STYLES[this.currentStyle];

        // Actualiza la UI
        this.updateUI(style);
    }

    /**
     * Actualiza la interfaz de usuario con el nuevo estilo
     * @param {Object} style - Objeto con la información del estilo
     * @returns {void}
     */
    updateUI(style) {
        // Muestra el nombre del estilo
        hmUI.showToast({
            text: style.name
        });

        // Actualiza la imagen
        normal_image_img.setProperty(
            hmUI.prop.SRC,
            style.image
        );
    }
}

// Instancia del switcher
const styleSwitcher = new StyleSwitcher();

// Función que se llama en el evento click
function click_Color() {
    styleSwitcher.switchStyle();
}


// let colornumber_main = 1
// let totalcolors_main = 2
// let namecolor_main = ''

// function click_Color() {
//     if (colornumber_main >= totalcolors_main) {
//         colornumber_main = 1;
//     } else {
//         colornumber_main = colornumber_main + 1;
//     }

//     if (colornumber_main == 1) {
//         namecolor_main = "BLACK STYLE"
//     }

//     if (colornumber_main == 2) {
//         namecolor_main = "BLUE STYLE"
//     }

//     hmUI.showToast({ text: namecolor_main });
//     normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
// }

// let elementnumber_3 = 1
// let total_elemente3 = 2

// function click_Hands() {
//     if (elementnumber_3 == total_elemente3) {
//         elementnumber_3 = 1;
//         UpdateElemente3One();
//     }
//     else {
//         elementnumber_3 = elementnumber_3 + 1;
//         if (elementnumber_3 == 2) {
//             UpdateElemente3Two();
//         }

//     }
//     if (elementnumber_3 == 1) hmUI.showToast({ text: 'HYBRID WATCH' });
//     if (elementnumber_3 == 2) hmUI.showToast({ text: 'DIGITAL ONLY' });
// }

// function UpdateElemente3One() {
//     normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
//     normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
//     normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

// }

// function UpdateElemente3Two() {
//     normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
//     normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
//     normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
//     normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

// }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'seg_01.png',
              // center_x: 227,
              // center_y: 227,
              // x: 25,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 25,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'seg_01.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hor_01.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 27,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_01.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 199,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}