﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
		let element_index = 1; 
        let element_count = 4; 

		function click_CONTENT() {
              element_index++;
              if(element_index > element_count) element_index = 1;

              normal_stand_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_1.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_2.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_3.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_4.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  Button_5.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_6.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_7.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  Button_8.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  Button_9.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_10.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_11.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  Button_12.setProperty(hmUI.prop.VISIBLE, element_index == 4);

               if (element_index == 1) {
                 hmUI.showToast({text: 'DIGITAL TIME'});
               };
               if (element_index == 2) {
                 hmUI.showToast({text: 'ACTIVITY'});
               };
               if (element_index == 3) {
                 hmUI.showToast({text: 'WEATHER'});
               };
			   if (element_index == 4) {
                 hmUI.showToast({text: 'SUN & MOON'});
               };
        };
		
		let color1number_main = 1
        let totalcolor1s_main = 9
        let namecolor1_main = ''
		let minstring = 'hand_min1.png'
		let hourstring = 'hand_hour1.png'
		
		function click_COLOR() {
            if(color1number_main>=totalcolor1s_main) {
            color1number_main=1;
                }
            else {
                color1number_main=color1number_main+1;
            }
			if ( color1number_main == 1) { namecolor1_main = "COLOR 1/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 2) { namecolor1_main = "COLOR 2/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 3) { namecolor1_main = "COLOR 3/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 4) { namecolor1_main = "COLOR 4/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 5) { namecolor1_main = "COLOR 5/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 6) { namecolor1_main = "COLOR 6/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 7) { namecolor1_main = "COLOR 7/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 8) { namecolor1_main = "COLOR 8/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			if ( color1number_main == 9) { namecolor1_main = "COLOR 9/9"
				minstring = "hand_min" + parseInt(color1number_main) + ".png"
				hourstring = "hand_hour" + parseInt(color1number_main) + ".png"
			}
			
			if ( color1number_main <= 9) { 
			
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minstring,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			}

			hmUI.showToast({text: namecolor1_main });
			normal_stand_icon_img.setProperty(hmUI.prop.SRC, "hand_top" + parseInt(color1number_main) + ".png");
            normal_stress_icon_img.setProperty(hmUI.prop.SRC, "color" + parseInt(color1number_main) + ".png");
        }
		
		let elementnumber_1 = 1
        let total_elemente = 3

        function click_HANDS() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'BOTH SECOND'});
            if(elementnumber_1==2) hmUI.showToast({text: 'SECOND CIRCLE'});
			if(elementnumber_1==3) hmUI.showToast({text: 'SECOND HAND'});
        }

        function UpdateElementeOne(){
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElementeTwo(){
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		function UpdateElementeThree(){
				normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_stress_icon_img = ''
        let normal_image_img = ''
        let normal_spo2_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 14;
        let normal_battery_TextCircle_img_height = 20;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 14;
        let normal_heart_rate_TextCircle_img_height = 20;
        let normal_sun_icon_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stand_icon_img = ''
        let idle_background_bg = ''
        let idle_battery_text_text_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let Button_17 = ''
        let Button_18 = ''
        let Button_19 = ''
        let Button_20 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'circle.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: -360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'circle.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (-360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'no_circle.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 158,
              // end_angle: 101,
              // radius: 220,
              // line_width: 19,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 101,
              end_angle: 158,
              radius: 211,
              line_width: 19,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 213,
              // angle: -194,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_battery_TextCircle_img_width / 2,
                pos_y: 227 + 203,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 203,
              // end_angle: 259,
              // radius: 220,
              // line_width: 19,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 259,
              end_angle: 203,
              radius: 211,
              line_width: 19,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'progr_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              // radius: 213,
              // angle: -165,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'small_00.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'small_01.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'small_02.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'small_03.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'small_04.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'small_05.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'small_06.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'small_07.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'small_08.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'small_09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 227 + 203,
                src: 'small_00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_moon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 119,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'day_13.png',
              dot_image: 'day_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 302,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'day_13.png',
              dot_image: 'day_15.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 168,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 151,
              y: 378,
              w: 151,
              h: 28,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 217,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_10.png',
              unit_tc: 'small_10.png',
              unit_en: 'small_10.png',
              negative_image: 'small_11.png',
              invalid_image: 'small_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 217,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_10.png',
              unit_tc: 'small_10.png',
              unit_en: 'small_10.png',
              negative_image: 'small_11.png',
              invalid_image: 'small_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 118,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'day_11.png',
              unit_tc: 'day_11.png',
              unit_en: 'day_11.png',
              negative_image: 'day_12.png',
              invalid_image: 'day_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["weathern_01.png","weathern_02.png","weathern_03.png","weathern_04.png","weathern_05.png","weathern_06.png","weathern_07.png","weathern_08.png","weathern_09.png","weathern_10.png","weathern_11.png","weathern_12.png","weathern_13.png","weathern_14.png","weathern_15.png","weathern_16.png","weathern_17.png","weathern_18.png","weathern_19.png","weathern_20.png","weathern_21.png","weathern_22.png","weathern_23.png","weathern_24.png","weathern_25.png","weathern_26.png","weathern_27.png","weathern_28.png","weathern_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 135,
              y: 351,
              week_en: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_tc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              week_sc: ["wd_1.png","wd_2.png","wd_3.png","wd_4.png","wd_5.png","wd_6.png","wd_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_activity.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 382,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_kcal.png',
              unit_tc: 'small_kcal.png',
              unit_en: 'small_kcal.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 312,
              font_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'day_km.png',
              unit_tc: 'day_km.png',
              unit_en: 'day_km.png',
              imperial_unit_sc: 'day_mil.png',
              imperial_unit_tc: 'day_mil.png',
              imperial_unit_en: 'day_mil.png',
              dot_image: 'day_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 183,
              font_array: ["step_00.png","step_01.png","step_02.png","step_03.png","step_04.png","step_05.png","step_06.png","step_07.png","step_08.png","step_09.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 383,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 135,
              month_startY: 351,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -82,
              y: -258,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 297,
              second_startY: 318,
              second_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 234,
              minute_startY: 294,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 161,
              hour_startY: 294,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 426,
              font_array: ["small_00.png","small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'small_13.png',
              unit_tc: 'small_13.png',
              unit_en: 'small_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'sym_time.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 2,
              y: -1,
              src: 'st_bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'st_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 234,
              minute_startY: 294,
              minute_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 161,
              hour_startY: 294,
              hour_array: ["big_00.png","big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour9.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min9.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              minute_cover_path: 'hand_top9.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 293,
              w: 57,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 161,
              y: 293,
              w: 57,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 118,
              y: 295,
              w: 38,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 350,
              w: 170,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 199,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_HANDS();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 189,
              w: 265,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 355,
              w: 156,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 298,
              w: 156,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 113,
              w: 156,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 194,
              w: 66,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 113,
              w: 156,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 147,
              y: 298,
              w: 156,
              h: 46,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 227,
              y: 416,
              w: 85,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 416,
              w: 85,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 0,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 199,
              y: 57,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_17 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 132,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_18 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 397,
              y: 132,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_19 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 340,
              y: 57,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_CONTENT();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_20 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 57,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                				click_COLOR();
				vibro(25);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js
			let cc = 0
			if (cc ==0 ){
			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_6.setProperty(hmUI.prop.VISIBLE, false);
			  Button_7.setProperty(hmUI.prop.VISIBLE, false);
			  Button_8.setProperty(hmUI.prop.VISIBLE, false);

              normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_city_name_text.setProperty(hmUI.prop.VISIBLE, false);
			  normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_9.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			  Button_10.setProperty(hmUI.prop.VISIBLE, false);
			  Button_11.setProperty(hmUI.prop.VISIBLE, false);
			  Button_12.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_spo2_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -14;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 213));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 15;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 213));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 101,
                      end_angle: 158,
                      radius: 211,
                      line_width: 19,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 259,
                      end_angle: 203,
                      radius: 211,
                      line_width: 19,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
                let secAngle = 0 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}