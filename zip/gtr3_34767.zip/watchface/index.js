﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'GlowBase.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 266,
              font_array: ["wf30-0.png","wf30-1.png","wf30-2.png","wf30-3.png","wf30-4.png","wf30-5.png","wf30-6.png","wf30-7.png","wf30-8.png","wf30-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 306,
              y: 267,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 164,
              month_sc_array: ["m23-00.png","m23-01.png","m23-02.png","m23-03.png","m23-04.png","m23-05.png","m23-06.png","m23-07.png","m23-08.png","m23-09.png","m23-10.png","m23-11.png"],
              month_tc_array: ["m23-00.png","m23-01.png","m23-02.png","m23-03.png","m23-04.png","m23-05.png","m23-06.png","m23-07.png","m23-08.png","m23-09.png","m23-10.png","m23-11.png"],
              month_en_array: ["m23-00.png","m23-01.png","m23-02.png","m23-03.png","m23-04.png","m23-05.png","m23-06.png","m23-07.png","m23-08.png","m23-09.png","m23-10.png","m23-11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 296,
              day_startY: 164,
              day_sc_array: ["wf23-0.png","wf23-1.png","wf23-2.png","wf23-3.png","wf23-4.png","wf23-5.png","wf23-6.png","wf23-7.png","wf23-8.png","wf23-9.png"],
              day_tc_array: ["wf23-0.png","wf23-1.png","wf23-2.png","wf23-3.png","wf23-4.png","wf23-5.png","wf23-6.png","wf23-7.png","wf23-8.png","wf23-9.png"],
              day_en_array: ["wf23-0.png","wf23-1.png","wf23-2.png","wf23-3.png","wf23-4.png","wf23-5.png","wf23-6.png","wf23-7.png","wf23-8.png","wf23-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 117,
              y: 164,
              week_en: ["dof23-0.png","dof23-1.png","dof23-2.png","dof23-3.png","dof23-4.png","dof23-5.png","dof23-6.png"],
              week_tc: ["dof23-0.png","dof23-1.png","dof23-2.png","dof23-3.png","dof23-4.png","dof23-5.png","dof23-6.png"],
              week_sc: ["dof23-0.png","dof23-1.png","dof23-2.png","dof23-3.png","dof23-4.png","dof23-5.png","dof23-6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 266,
              font_array: ["wf30-0.png","wf30-1.png","wf30-2.png","wf30-3.png","wf30-4.png","wf30-5.png","wf30-6.png","wf30-7.png","wf30-8.png","wf30-9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'wf30-percent.png',
              unit_tc: 'wf30-percent.png',
              unit_en: 'wf30-percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 310,
              font_array: ["wf30-0.png","wf30-1.png","wf30-2.png","wf30-3.png","wf30-4.png","wf30-5.png","wf30-6.png","wf30-7.png","wf30-8.png","wf30-9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 308,
              src: 'walk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 119,
              font_array: ["BF30-0.png","BF30-1.png","BF30-2.png","BF30-3.png","BF30-4.png","BF30-5.png","BF30-6.png","BF30-7.png","BF30-8.png","BF30-9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'BF30-Grade.png',
              unit_tc: 'BF30-Grade.png',
              unit_en: 'BF30-Grade.png',
              negative_image: 'BF30-Minus.png',
              invalid_image: 'BF30-MinusMinus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 177,
              y: 113,
              image_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Manilla31.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 37,
              hour_posY: 218,
              hour_cover_path: 'Numbers.png',
              hour_cover_x: 0,
              hour_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Manilla32.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 175,
              minute_cover_path: 'Numbers.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Manilla33.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 189,
              second_cover_path: 'Numbers.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 302,
              am_y: 229,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 302,
              pm_y: 229,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 200,
              hour_array: ["bf68-0.png","bf68-1.png","bf68-2.png","bf68-3.png","bf68-4.png","bf68-5.png","bf68-6.png","bf68-7.png","bf68-8.png","bf68-9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 228,
              minute_startY: 200,
              minute_array: ["bf68-0.png","bf68-1.png","bf68-2.png","bf68-3.png","bf68-4.png","bf68-5.png","bf68-6.png","bf68-7.png","bf68-8.png","bf68-9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 201,
              second_array: ["pf30-0.png","pf30-1.png","pf30-2.png","pf30-3.png","pf30-4.png","pf30-5.png","pf30-6.png","pf30-7.png","pf30-8.png","pf30-9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 197,
              src: 'bf68-DOTdot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 302,
              am_y: 229,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 302,
              pm_y: 229,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 130,
              hour_startY: 200,
              hour_array: ["bf68-0.png","bf68-1.png","bf68-2.png","bf68-3.png","bf68-4.png","bf68-5.png","bf68-6.png","bf68-7.png","bf68-8.png","bf68-9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 228,
              minute_startY: 200,
              minute_array: ["bf68-0.png","bf68-1.png","bf68-2.png","bf68-3.png","bf68-4.png","bf68-5.png","bf68-6.png","bf68-7.png","bf68-8.png","bf68-9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 314,
              second_startY: 201,
              second_array: ["pf30-0.png","pf30-1.png","pf30-2.png","pf30-3.png","pf30-4.png","pf30-5.png","pf30-6.png","pf30-7.png","pf30-8.png","pf30-9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 197,
              src: 'bf68-DOTdot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 156,
              y: 110,
              w: 149,
              h: 43,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 303,
              w: 130,
              h: 38,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}