﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_TextRotate = new Array(5);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 14;
        let normal_battery_TextRotate = new Array(5);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 14;
        let normal_battery_TextRotate_unit = null;
        let normal_battery_TextRotate_unit_width = 14;
        let normal_battery_TextRotate_error_img_width = 14;
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_TextRotate = new Array(5);
        let idle_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextRotate_img_width = 14;
        let idle_battery_TextRotate = new Array(5);
        let idle_battery_TextRotate_ASCIIARRAY = new Array(10);
        let idle_battery_TextRotate_img_width = 14;
        let idle_battery_TextRotate_unit = null;
        let idle_battery_TextRotate_unit_width = 14;
        let idle_battery_TextRotate_error_img_width = 14;
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calorie
        function UpdateBackgroundTwo(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundThree(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 6
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "Color1"}
if ( colornumber == 2) { namecolor = "Color2"}
if ( colornumber == 3) { namecolor = "Color3"}
if ( colornumber == 4) { namecolor = "Color4"}
if ( colornumber == 5) { namecolor = "Color5"}
if ( colornumber == 6) { namecolor = "Color6"}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top_image.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 258,
              y: 390,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 392,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 208,
              y: 54,
              w: 110,
              h: 25,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 33,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Weather_Symbo_1.png',
              unit_tc: 'Weather_Symbo_1.png',
              unit_en: 'Weather_Symbo_1.png',
              negative_image: 'Weather_Symbo_2.png',
              invalid_image: 'Weather_Symbo_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 34,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 198,
              am_y: 391,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 198,
              pm_y: 391,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 81,
              hour_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 172,
              minute_startY: 226,
              minute_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 390,
              y: 139,
              week_en: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              week_tc: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              week_sc: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 418,
              day_startY: 209,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 100,
              // y: 130,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -41,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 100,
                center_y: 130,
                pos_x: 100,
                pos_y: 130,
                angle: -41,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 306,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 39,
              // unit_en: 'Act_Symob_Batt.png',
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 109,
                center_y: 306,
                pos_x: 109,
                pos_y: 306,
                angle: 39,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 109,
              center_y: 306,
              pos_x: 109,
              pos_y: 306,
              angle: 39,
              src: 'Act_Symob_Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 197,
              src: 'icon_distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 218,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 197,
              src: 'icon_calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 218,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 197,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 218,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 47,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'color6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Top_image.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 258,
              y: 390,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 392,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 208,
              y: 54,
              w: 110,
              h: 25,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 33,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Weather_Symbo_1.png',
              unit_tc: 'Weather_Symbo_1.png',
              unit_en: 'Weather_Symbo_1.png',
              negative_image: 'Weather_Symbo_2.png',
              invalid_image: 'Weather_Symbo_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 34,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 198,
              am_y: 391,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 198,
              pm_y: 391,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 172,
              hour_startY: 81,
              hour_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 172,
              minute_startY: 226,
              minute_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 390,
              y: 139,
              week_en: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              week_tc: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              week_sc: ["WeekDay1.png","WeekDay2.png","WeekDay3.png","WeekDay4.png","WeekDay5.png","WeekDay6.png","WeekDay7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 418,
              day_startY: 209,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 100,
              // y: 130,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -41,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            idle_heart_rate_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 100,
                center_y: 130,
                pos_x: 100,
                pos_y: 130,
                angle: -41,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 109,
              // y: 306,
              // font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 39,
              // unit_en: 'Act_Symob_Batt.png',
              // invalid_image: 'Act_Font_0.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_TextRotate_ASCIIARRAY[0] = 'Act_Font_0.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[1] = 'Act_Font_1.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[2] = 'Act_Font_2.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[3] = 'Act_Font_3.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[4] = 'Act_Font_4.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[5] = 'Act_Font_5.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[6] = 'Act_Font_6.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[7] = 'Act_Font_7.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[8] = 'Act_Font_8.png';  // set of images with numbers
            idle_battery_TextRotate_ASCIIARRAY[9] = 'Act_Font_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 109,
                center_y: 306,
                pos_x: 109,
                pos_y: 306,
                angle: 39,
                src: 'Act_Font_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_battery_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 109,
              center_y: 306,
              pos_x: 109,
              pos_y: 306,
              angle: 39,
              src: 'Act_Symob_Batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 4,
              y: 197,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 218,
              font_array: ["Act_Font_0.png","Act_Font_1.png","Act_Font_2.png","Act_Font_3.png","Act_Font_4.png","Act_Font_5.png","Act_Font_6.png","Act_Font_7.png","Act_Font_8.png","Act_Font_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 265,
              w: 71,
              h: 68,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 117,
              w: 73,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 381,
              w: 48,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 33,
              w: 48,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 23,
              w: 72,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 210,
              w: 76,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 154,
              w: 34,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 100,
              w: 67,
              h: 67,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 398,
              y: 184,
              w: 100,
              h: 100,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 209,
              w: 77,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            function text_update() {

              console.log('update text rotate HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 4 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 100 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  normal_battery_TextRotate_posOffset = normal_battery_TextRotate_posOffset + 2 * (normal_battery_rotate_string.length - 1);
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 109 + img_offset);
                  normal_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 109 - normal_battery_TextRotate_error_img_width / 2);
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  normal_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate HEART');
              let idle_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_rotate_string.length > 0 && idle_heart_rate_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_img_width * idle_heart_rate_rotate_string.length;
                  idle_heart_rate_TextRotate_posOffset = idle_heart_rate_TextRotate_posOffset + 4 * (idle_heart_rate_rotate_string.length - 1);
                  img_offset -= idle_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 100 + img_offset);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_heart_rate_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate BATTERY');
              let idle_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && idle_battery_rotate_string.length > 0 && idle_battery_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_battery_TextRotate_posOffset = idle_battery_TextRotate_img_width * idle_battery_rotate_string.length;
                  idle_battery_TextRotate_posOffset = idle_battery_TextRotate_posOffset + 2 * (idle_battery_rotate_string.length - 1);
                  img_offset -= idle_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 109 + img_offset);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.SRC, idle_battery_TextRotate_ASCIIARRAY[charCode]);
                      idle_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_battery_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.POS_X, 109 + img_offset);
                  idle_battery_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.POS_X, 109 - idle_battery_TextRotate_error_img_width / 2);
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_0.png');
                  idle_battery_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                text_update();
              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x:3,
              y: 205,
              text: '',
              w: 54,
              h: 45,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ALL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 150,
              y: 377,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end
//////////////////////////////////////////////////////////////////////////////////////////////////  




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}