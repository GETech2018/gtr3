﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_pai_weekly_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 329,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 193,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Action_font_11.png',
              unit_tc: 'Action_font_11.png',
              unit_en: 'Action_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 207,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 145,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_14.png',
              unit_tc: 'Action_font_14.png',
              unit_en: 'Action_font_14.png',
              negative_image: 'Action_font_13.png',
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 266,
              y: 142,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 416,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 240,
              y: 424,
              src: 'System_Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 402,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 320,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 215,
              y: 365,
              week_en: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              week_tc: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              week_sc: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -149,
              day_startY: 322,
              day_sc_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_tc_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_en_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_zero: 1,
              day_space: -19,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 288,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 283,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 285,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 241,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 192,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 143,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_15.png',
              unit_tc: 'Action_font_15.png',
              unit_en: 'Action_font_15.png',
              dot_image: 'Action_font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 241,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_11.png',
              unit_tc: 'Action_font_11.png',
              unit_en: 'Action_font_11.png',
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 76,
              am_y: 94,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 76,
              pm_y: 94,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -148,
              hour_startY: 38,
              hour_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_align: hmUI.align.LEFT,

              minute_startX: -19,
              minute_startY: 42,
              minute_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 54,
              second_startY: 5,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: -18,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 56,
              src: 'Dot_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 48,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 12,
              w: 85,
              h: 47,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 212,
              y: 65,
              w: 38,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 393,
              w: 53,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 324,
              w: 46,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 143,
              w: 155,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 281,
              w: 162,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 237,
              y: 233,
              w: 191,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 226,
              y: 278,
              w: 199,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 182,
              w: 181,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 329,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 193,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Action_font_11.png',
              unit_tc: 'Action_font_11.png',
              unit_en: 'Action_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 353,
              y: 207,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 313,
              y: 145,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_14.png',
              unit_tc: 'Action_font_14.png',
              unit_en: 'Action_font_14.png',
              negative_image: 'Action_font_13.png',
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 266,
              y: 142,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 268,
              y: 416,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 240,
              y: 424,
              src: 'System_Bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 402,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 320,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 215,
              y: 365,
              week_en: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              week_tc: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              week_sc: ["weekday_iconst_01.png","weekday_iconst_02.png","weekday_iconst_03.png","weekday_iconst_04.png","weekday_iconst_05.png","weekday_iconst_06.png","weekday_iconst_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -149,
              day_startY: 322,
              day_sc_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_tc_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_en_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              day_zero: 1,
              day_space: -19,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 288,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 283,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 285,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 241,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 192,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 143,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_15.png',
              unit_tc: 'Action_font_15.png',
              unit_en: 'Action_font_15.png',
              dot_image: 'Action_font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 241,
              font_array: ["Action_font_01.png","Action_font_02.png","Action_font_03.png","Action_font_04.png","Action_font_05.png","Action_font_06.png","Action_font_07.png","Action_font_08.png","Action_font_09.png","Action_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Action_font_11.png',
              unit_tc: 'Action_font_11.png',
              unit_en: 'Action_font_11.png',
              invalid_image: 'Action_font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 76,
              am_y: 94,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 76,
              pm_y: 94,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -148,
              hour_startY: 38,
              hour_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_align: hmUI.align.LEFT,

              minute_startX: -19,
              minute_startY: 42,
              minute_array: ["Time_MH_01.png","Time_MH_02.png","Time_MH_03.png","Time_MH_04.png","Time_MH_05.png","Time_MH_06.png","Time_MH_07.png","Time_MH_08.png","Time_MH_09.png","Time_MH_10.png"],
              minute_zero: 1,
              minute_space: -18,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 54,
              second_startY: 5,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: -18,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 56,
              src: 'Dot_time.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 48,
              second_posY: 227,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  