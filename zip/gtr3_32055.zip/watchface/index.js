﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -152,
              y: -147,
              src: 'purp_back.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 68,
              month_startY: 320,
              month_sc_array: ["month_digi_small_0001.png","month_digi_small_0002.png","month_digi_small_0003.png","month_digi_small_0004.png","month_digi_small_0005.png","month_digi_small_0006.png","month_digi_small_0007.png","month_digi_small_0008.png","month_digi_small_0009.png","month_digi_small_0010.png","month_digi_small_0011.png","month_digi_small_0012.png"],
              month_tc_array: ["month_digi_small_0001.png","month_digi_small_0002.png","month_digi_small_0003.png","month_digi_small_0004.png","month_digi_small_0005.png","month_digi_small_0006.png","month_digi_small_0007.png","month_digi_small_0008.png","month_digi_small_0009.png","month_digi_small_0010.png","month_digi_small_0011.png","month_digi_small_0012.png"],
              month_en_array: ["month_digi_small_0001.png","month_digi_small_0002.png","month_digi_small_0003.png","month_digi_small_0004.png","month_digi_small_0005.png","month_digi_small_0006.png","month_digi_small_0007.png","month_digi_small_0008.png","month_digi_small_0009.png","month_digi_small_0010.png","month_digi_small_0011.png","month_digi_small_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 69,
              day_startY: 300,
              day_sc_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              day_tc_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              day_en_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              day_zero: 0,
              day_space: -23,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 97,
              y: 300,
              week_en: ["day_digi_small_0001.png","day_digi_small_0002.png","day_digi_small_0003.png","day_digi_small_0004.png","day_digi_small_0005.png","day_digi_small_0006.png","day_digi_small_0007.png"],
              week_tc: ["day_digi_small_0001.png","day_digi_small_0002.png","day_digi_small_0003.png","day_digi_small_0004.png","day_digi_small_0005.png","day_digi_small_0006.png","day_digi_small_0007.png"],
              week_sc: ["day_digi_small_0001.png","day_digi_small_0002.png","day_digi_small_0003.png","day_digi_small_0004.png","day_digi_small_0005.png","day_digi_small_0006.png","day_digi_small_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 130,
              font_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              padding: false,
              h_space: -23,
              unit_sc: 'icon_location_unit.png',
              unit_tc: 'icon_location_unit.png',
              unit_en: 'icon_location_unit.png',
              dot_image: 'icon_location_dotunit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 133,
              src: 'icon_location.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 68,
              y: 81,
              src: 'icon_calo_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 77,
              font_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              padding: false,
              h_space: -23,
              unit_sc: 'icon_calo_unit.png',
              unit_tc: 'icon_calo_unit.png',
              unit_en: 'icon_calo_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 106,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 105,
              font_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              padding: false,
              h_space: -21,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 72,
              src: 'circle.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 107,
              // start_angle: 360,
              // end_angle: 0,
              // radius: 35,
              // line_width: 3,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 102,
              font_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              padding: false,
              h_space: -24,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 310,
              y: 77,
              src: 'icon_heart_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 413,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 316,
              src: 'circle.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 324,
              // center_y: 350,
              // start_angle: 360,
              // end_angle: 0,
              // radius: 35,
              // line_width: 3,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 346,
              font_array: ["rect_digi_small_0001.png","rect_digi_small_0002.png","rect_digi_small_0003.png","rect_digi_small_0004.png","rect_digi_small_0005.png","rect_digi_small_0006.png","rect_digi_small_0007.png","rect_digi_small_0008.png","rect_digi_small_0009.png","rect_digi_small_0010.png"],
              padding: false,
              h_space: -24,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 325,
              src: 'icon_batt_grey.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 4,
              am_y: 265,
              am_sc_path: 'gsans_am (2).png',
              am_en_path: 'gsans_am (2).png',
              pm_x: 4,
              pm_y: 265,
              pm_sc_path: 'gsans_pm (2).png',
              pm_en_path: 'gsans_pm (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 31,
              hour_startY: 107,
              hour_array: ["digi_grepe_purple_0001.png","digi_grepe_purple_0002.png","digi_grepe_purple_0003.png","digi_grepe_purple_0004.png","digi_grepe_purple_0005.png","digi_grepe_purple_0006.png","digi_grepe_purple_0007.png","digi_grepe_purple_0008.png","digi_grepe_purple_0009.png","digi_grepe_purple_0010.png"],
              hour_zero: 1,
              hour_space: -37,
              hour_align: hmUI.align.LEFT,

              minute_startX: 132,
              minute_startY: 50,
              minute_array: ["digi_grepe_white_0001.png","digi_grepe_white_0002.png","digi_grepe_white_0003.png","digi_grepe_white_0004.png","digi_grepe_white_0005.png","digi_grepe_white_0006.png","digi_grepe_white_0007.png","digi_grepe_white_0008.png","digi_grepe_white_0009.png","digi_grepe_white_0010.png"],
              minute_zero: 1,
              minute_space: -186,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 311,
              second_startY: 232,
              second_array: ["digi_grey_sec0001.png","digi_grey_sec0002.png","digi_grey_sec0003.png","digi_grey_sec0004.png","digi_grey_sec0005.png","digi_grey_sec0006.png","digi_grey_sec0007.png","digi_grey_sec0008.png","digi_grey_sec0009.png","digi_grey_sec0010.png"],
              second_zero: 1,
              second_space: -85,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 192,
              y: 2,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF090400',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 414,
              src: 'icon_bluetooth_lightgrey.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 301,
              font_array: ["small5_size_googlesan_grey_0001.png","small5_size_googlesan_grey_0002.png","small5_size_googlesan_grey_0003.png","small5_size_googlesan_grey_0004.png","small5_size_googlesan_grey_0005.png","small5_size_googlesan_grey_0006.png","small5_size_googlesan_grey_0007.png","small5_size_googlesan_grey_0008.png","small5_size_googlesan_grey_0009.png","small5_size_googlesan_grey_0010.png"],
              padding: false,
              h_space: -33,
              unit_sc: 'icon_pecnet_lightgrey.png',
              unit_tc: 'icon_pecnet_lightgrey.png',
              unit_en: 'icon_pecnet_lightgrey.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 336,
              y: 310,
              src: 'icon_batt_grey.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 108,
              hour_array: ["grape_digi_aob_0001.png","grape_digi_aob_0002.png","grape_digi_aob_0003.png","grape_digi_aob_0004.png","grape_digi_aob_0005.png","grape_digi_aob_0006.png","grape_digi_aob_0007.png","grape_digi_aob_0008.png","grape_digi_aob_0009.png","grape_digi_aob_0010.png"],
              hour_zero: 1,
              hour_space: -35,
              hour_align: hmUI.align.LEFT,

              minute_startX: 202,
              minute_startY: 108,
              minute_array: ["grape_digi_aob_0001.png","grape_digi_aob_0002.png","grape_digi_aob_0003.png","grape_digi_aob_0004.png","grape_digi_aob_0005.png","grape_digi_aob_0006.png","grape_digi_aob_0007.png","grape_digi_aob_0008.png","grape_digi_aob_0009.png","grape_digi_aob_0010.png"],
              minute_zero: 1,
              minute_space: -35,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 123,
              src: 'digi_column.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 190,
              am_sc_path: 'digi_grey_am0001.png',
              am_en_path: 'digi_grey_am0001.png',
              pm_x: 330,
              pm_y: 190,
              pm_sc_path: 'digi_grey_pm0002.png',
              pm_en_path: 'digi_grey_pm0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -41,
              y: -5,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = 270;
                  let end_angle_normal_heart_rate = -90;
                  let center_x_normal_heart_rate = 324;
                  let center_y_normal_heart_rate = 107;
                  let radius_normal_heart_rate = 35;
                  let line_width_cs_normal_heart_rate = 3;
                  let color_cs_normal_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 270;
                  let end_angle_normal_battery = -90;
                  let center_x_normal_battery = 324;
                  let center_y_normal_battery = 350;
                  let radius_normal_battery = 35;
                  let line_width_cs_normal_battery = 3;
                  let color_cs_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  