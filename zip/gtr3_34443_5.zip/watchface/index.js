﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_stand_icon_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_text_text_img = ''
        let idle_stand_icon_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'Preview1.png', path: 'Main_0.png' },
                { id: 2, preview: 'Preview2.png', path: 'Main_1.png' },
                { id: 3, preview: 'Preview3.png', path: 'Main_2.png' },
                { id: 4, preview: 'Preview4.png', path: 'Main_3.png' },
                { id: 5, preview: 'Preview5.png', path: 'Main_4.png' },
                { id: 6, preview: 'Preview6.png', path: 'Main_5.png' },
                { id: 7, preview: 'Preview7.png', path: 'Main_6.png' },
                { id: 8, preview: 'Preview8.png', path: 'Main_7.png' },
                { id: 9, preview: 'Preview9.png', path: 'Main_8.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 96,
              month_sc_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_tc_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_en_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 129,
              week_en: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              week_tc: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              week_sc: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 113,
              day_startY: 98,
              day_sc_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_tc_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_en_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 331,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 332,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: -9,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 176,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 239,
              minute_startY: 177,
              minute_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 333,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'prozent.png',
              unit_tc: 'prozent.png',
              unit_en: 'prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'MAIN.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 202,
              month_startY: 96,
              month_sc_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_tc_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_en_array: ["Mon0_1.png","Mon0_2.png","Mon0_3.png","Mon0_4.png","Mon0_5.png","Mon0_6.png","Mon0_7.png","Mon0_8.png","Mon0_9.png","Mon0_10.png","Mon0_11.png","Mon0_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 129,
              week_en: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              week_tc: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              week_sc: ["Day1_1.png","Day1_2.png","Day1_3.png","Day1_4.png","Day1_5.png","Day1_6.png","Day1_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 113,
              day_startY: 98,
              day_sc_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_tc_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_en_array: ["c_0.png","c_1.png","c_2.png","c_3.png","c_4.png","c_5.png","c_6.png","c_7.png","c_8.png","c_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 331,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 332,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 176,
              hour_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png","b6.png","b7.png","b8.png","b9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 239,
              minute_startY: 177,
              minute_array: ["a0.png","a1.png","a2.png","a3.png","a4.png","a5.png","a6.png","a7.png","a8.png","a9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 333,
              font_array: ["Little0_0.png","Little0_1.png","Little0_2.png","Little0_3.png","Little0_4.png","Little0_5.png","Little0_6.png","Little0_7.png","Little0_8.png","Little0_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'prozent.png',
              unit_tc: 'prozent.png',
              unit_en: 'prozent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}