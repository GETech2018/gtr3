﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_minute2 = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_hour2 = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_minute2 = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_hour2 = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

var hour_array1=["Time_H2_0.png","Time_H2_1.png","Time_H2_2.png","Time_H2_3.png","Time_H2_4.png","Time_H2_5.png","Time_H2_6.png","Time_H2_7.png","Time_H2_8.png","Time_H2_9.png"];

var hour_array2=["Time_H1_0.png","Time_H1_1.png","Time_H1_2.png","Time_H1_3.png","Time_H1_4.png","Time_H1_5.png","Time_H1_6.png","Time_H1_7.png","Time_H1_8.png","Time_H1_9.png"];

/////////////////////////


        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 5
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { 
namecolor = "B&W";
hour_array1.splice(0, 1, "Time_H2_0.png");
hour_array1.splice(1, 1, "Time_H2_1.png");
hour_array1.splice(2, 1, "Time_H2_2.png");
hour_array1.splice(3, 1, "Time_H2_3.png");
hour_array1.splice(4, 1, "Time_H2_4.png");
hour_array1.splice(5, 1, "Time_H2_5.png");
hour_array1.splice(6, 1, "Time_H2_6.png");
hour_array1.splice(7, 1, "Time_H2_7.png");
hour_array1.splice(8, 1, "Time_H2_8.png");
hour_array1.splice(9, 1, "Time_H2_9.png");

hour_array2.splice(0, 1, "Time_H1_0.png");
hour_array2.splice(1, 1, "Time_H1_1.png");
hour_array2.splice(2, 1, "Time_H1_2.png");
hour_array2.splice(3, 1, "Time_H1_3.png");
hour_array2.splice(4, 1, "Time_H1_4.png");
hour_array2.splice(5, 1, "Time_H1_5.png");
hour_array2.splice(6, 1, "Time_H1_6.png");
hour_array2.splice(7, 1, "Time_H1_7.png");
hour_array2.splice(8, 1, "Time_H1_8.png");
hour_array2.splice(9, 1, "Time_H1_9.png");

}
if ( colornumber == 2){ 
namecolor = "Green";
hour_array1.splice(0, 1, "TimeG_H2_0.png");
hour_array1.splice(1, 1, "TimeG_H2_1.png");
hour_array1.splice(2, 1, "TimeG_H2_2.png");
hour_array1.splice(3, 1, "TimeG_H2_3.png");
hour_array1.splice(4, 1, "TimeG_H2_4.png");
hour_array1.splice(5, 1, "TimeG_H2_5.png");
hour_array1.splice(6, 1, "TimeG_H2_6.png");
hour_array1.splice(7, 1, "TimeG_H2_7.png");
hour_array1.splice(8, 1, "TimeG_H2_8.png");
hour_array1.splice(9, 1, "TimeG_H2_9.png");

hour_array2.splice(0, 1, "TimeG_H1_0.png");
hour_array2.splice(1, 1, "TimeG_H1_1.png");
hour_array2.splice(2, 1, "TimeG_H1_2.png");
hour_array2.splice(3, 1, "TimeG_H1_3.png");
hour_array2.splice(4, 1, "TimeG_H1_4.png");
hour_array2.splice(5, 1, "TimeG_H1_5.png");
hour_array2.splice(6, 1, "TimeG_H1_6.png");
hour_array2.splice(7, 1, "TimeG_H1_7.png");
hour_array2.splice(8, 1, "TimeG_H1_8.png");
hour_array2.splice(9, 1, "TimeG_H1_9.png");

}


if ( colornumber == 3){ 
namecolor = "Rust";
hour_array1.splice(0, 1, "TimeO_H2_0.png");
hour_array1.splice(1, 1, "TimeO_H2_1.png");
hour_array1.splice(2, 1, "TimeO_H2_2.png");
hour_array1.splice(3, 1, "TimeO_H2_3.png");
hour_array1.splice(4, 1, "TimeO_H2_4.png");
hour_array1.splice(5, 1, "TimeO_H2_5.png");
hour_array1.splice(6, 1, "TimeO_H2_6.png");
hour_array1.splice(7, 1, "TimeO_H2_7.png");
hour_array1.splice(8, 1, "TimeO_H2_8.png");
hour_array1.splice(9, 1, "TimeO_H2_9.png");

hour_array2.splice(0, 1, "TimeO_H1_0.png");
hour_array2.splice(1, 1, "TimeO_H1_1.png");
hour_array2.splice(2, 1, "TimeO_H1_2.png");
hour_array2.splice(3, 1, "TimeO_H1_3.png");
hour_array2.splice(4, 1, "TimeO_H1_4.png");
hour_array2.splice(5, 1, "TimeO_H1_5.png");
hour_array2.splice(6, 1, "TimeO_H1_6.png");
hour_array2.splice(7, 1, "TimeO_H1_7.png");
hour_array2.splice(8, 1, "TimeO_H1_8.png");
hour_array2.splice(9, 1, "TimeO_H1_9.png");

}



if ( colornumber == 4){ 
namecolor = "Yellow";
hour_array1.splice(0, 1, "TimeY_H2_0.png");
hour_array1.splice(1, 1, "TimeY_H2_1.png");
hour_array1.splice(2, 1, "TimeY_H2_2.png");
hour_array1.splice(3, 1, "TimeY_H2_3.png");
hour_array1.splice(4, 1, "TimeY_H2_4.png");
hour_array1.splice(5, 1, "TimeY_H2_5.png");
hour_array1.splice(6, 1, "TimeY_H2_6.png");
hour_array1.splice(7, 1, "TimeY_H2_7.png");
hour_array1.splice(8, 1, "TimeY_H2_8.png");
hour_array1.splice(9, 1, "TimeY_H2_9.png");

hour_array2.splice(0, 1, "TimeY_H1_0.png");
hour_array2.splice(1, 1, "TimeY_H1_1.png");
hour_array2.splice(2, 1, "TimeY_H1_2.png");
hour_array2.splice(3, 1, "TimeY_H1_3.png");
hour_array2.splice(4, 1, "TimeY_H1_4.png");
hour_array2.splice(5, 1, "TimeY_H1_5.png");
hour_array2.splice(6, 1, "TimeY_H1_6.png");
hour_array2.splice(7, 1, "TimeY_H1_7.png");
hour_array2.splice(8, 1, "TimeY_H1_8.png");
hour_array2.splice(9, 1, "TimeY_H1_9.png");

}

if ( colornumber == 5){ 
namecolor = "Sky Blue";
hour_array1.splice(0, 1, "TimeB_H2_0.png");
hour_array1.splice(1, 1, "TimeB_H2_1.png");
hour_array1.splice(2, 1, "TimeB_H2_2.png");
hour_array1.splice(3, 1, "TimeB_H2_3.png");
hour_array1.splice(4, 1, "TimeB_H2_4.png");
hour_array1.splice(5, 1, "TimeB_H2_5.png");
hour_array1.splice(6, 1, "TimeB_H2_6.png");
hour_array1.splice(7, 1, "TimeB_H2_7.png");
hour_array1.splice(8, 1, "TimeB_H2_8.png");
hour_array1.splice(9, 1, "TimeB_H2_9.png");

hour_array2.splice(0, 1, "TimeB_H1_0.png");
hour_array2.splice(1, 1, "TimeB_H1_1.png");
hour_array2.splice(2, 1, "TimeB_H1_2.png");
hour_array2.splice(3, 1, "TimeB_H1_3.png");
hour_array2.splice(4, 1, "TimeB_H1_4.png");
hour_array2.splice(5, 1, "TimeB_H1_5.png");
hour_array2.splice(6, 1, "TimeB_H1_6.png");
hour_array2.splice(7, 1, "TimeB_H1_7.png");
hour_array2.splice(8, 1, "TimeB_H1_8.png");
hour_array2.splice(9, 1, "TimeB_H1_9.png");

}




hmUI.showToast({text: namecolor });

                           
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 275,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 268,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 273,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 63,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 28,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 297,
              y: 410,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 9,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 380,
              font_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'DAY_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 337,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 362,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 303,
              font_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'BATTERY_Symbo.png',
              unit_tc: 'BATTERY_Symbo.png',
              unit_en: 'BATTERY_Symbo.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 289,
              y: 214,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 386,
              day_startY: 237,
              day_sc_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_tc_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_en_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 293,
              month_startY: 232,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 173,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 412,
              pm_y: 173,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 285,
              minute_startY: 99,
              minute_array: ["Time_M2_0.png","Time_M2_1.png","Time_M2_2.png","Time_M2_3.png","Time_M2_4.png","Time_M2_5.png","Time_M2_6.png","Time_M2_7.png","Time_M2_8.png","Time_M2_9.png"],
              minute_zero: 1,
              minute_space: 99,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -92,
              minute_startY: 99,
              minute_array: ["Time_M1_0.png","Time_M1_1.png","Time_M1_2.png","Time_M1_3.png","Time_M1_4.png","Time_M1_5.png","Time_M1_6.png","Time_M1_7.png","Time_M1_8.png","Time_M1_9.png"],
              minute_zero: 1,
              minute_space: 348,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -3,
              hour_startY: 94,
              hour_array: hour_array1,
              hour_zero: 1,
              hour_space: 268,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_digital_clock_img_time_hour2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -228,
              hour_startY: 94,
              hour_array: hour_array2,
              hour_zero: 1,
              hour_space: 93,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 408,
              second_startY: 189,
              second_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 6,
              src: 'TopH1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 275,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 268,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 273,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 63,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 290,
              y: 28,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 380,
              font_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'DAY_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 297,
              y: 410,
              src: 'anim_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 337,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 362,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 303,
              font_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'BATTERY_Symbo.png',
              unit_tc: 'BATTERY_Symbo.png',
              unit_en: 'BATTERY_Symbo.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 289,
              y: 214,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 386,
              day_startY: 237,
              day_sc_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_tc_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_en_array: ["DAY_0.png","DAY_1.png","DAY_2.png","DAY_3.png","DAY_4.png","DAY_5.png","DAY_6.png","DAY_7.png","DAY_8.png","DAY_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 293,
              month_startY: 232,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 173,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 412,
              pm_y: 173,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 285,
              minute_startY: 99,
              minute_array: ["Time_M2_0.png","Time_M2_1.png","Time_M2_2.png","Time_M2_3.png","Time_M2_4.png","Time_M2_5.png","Time_M2_6.png","Time_M2_7.png","Time_M2_8.png","Time_M2_9.png"],
              minute_zero: 1,
              minute_space: 99,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

           idle_digital_clock_img_time_minute2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -92,
              minute_startY: 99,
              minute_array: ["Time_M1_0.png","Time_M1_1.png","Time_M1_2.png","Time_M1_3.png","Time_M1_4.png","Time_M1_5.png","Time_M1_6.png","Time_M1_7.png","Time_M1_8.png","Time_M1_9.png"],
              minute_zero: 1,
              minute_space: 348,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -3,
              hour_startY: 94,
              hour_array: ["Time_H2_0.png","Time_H2_1.png","Time_H2_2.png","Time_H2_3.png","Time_H2_4.png","Time_H2_5.png","Time_H2_6.png","Time_H2_7.png","Time_H2_8.png","Time_H2_9.png"],
              hour_zero: 1,
              hour_space: 268,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

     idle_digital_clock_img_time_hour2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -228,
              hour_startY: 94,
              hour_array: ["Time_H1_0.png","Time_H1_1.png","Time_H1_2.png","Time_H1_3.png","Time_H1_4.png","Time_H1_5.png","Time_H1_6.png","Time_H1_7.png","Time_H1_8.png","Time_H1_9.png"],
              hour_zero: 1,
              hour_space: 93,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 408,
              second_startY: 189,
              second_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 6,
              src: 'TopH1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 187,
              w: 100,
              h: 100,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 125,
              w: 54,
              h: 64,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 319,
              y: 267,
              w: 55,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 2,
              w: 91,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 60,
              w: 86,
              h: 27,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 409,
              w: 100,
              h: 100,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 291,
              y: 375,
              w: 83,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 215,
              w: 150,
              h: 50,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 290,
              y: 333,
              w: 115,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 36,
              text: '',
              w: 81,
              h: 45,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}