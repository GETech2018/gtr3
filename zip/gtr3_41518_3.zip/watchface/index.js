﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start

    // Start						  
    let colornumber_main = 1
    let totalcolors_main = 6
    let namecolor_main = ''

    function bgp() {
      if (colornumber_main >= totalcolors_main) {
        colornumber_main = 1;
      }
      else {
        colornumber_main = colornumber_main + 1;
      }

      if (colornumber_main == 1) {
        namecolor_main = "1"
      }
      if (colornumber_main == 2) {
        namecolor_main = "2"
      }
      if (colornumber_main == 3) {
        namecolor_main = "3"
      }
      if (colornumber_main == 4) {
        namecolor_main = "4"
      }
      if (colornumber_main == 5) {
        namecolor_main = "5"
      }
      if (colornumber_main == 6) {
        namecolor_main = "6"
      }

      //hmUI.showToast({text: namecolor_main });
      normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "seg_" + parseInt(colornumber_main) + ".png");
      normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(colornumber_main) + ".png");
    }

    let elementnumber_1 = 1
    let total_elements = 2

    function hands() {
      if (elementnumber_1 == total_elements) {
        elementnumber_1 = 1;
        UpdateElementOne();
      }
      else {
        elementnumber_1 = elementnumber_1 + 1;
        if (elementnumber_1 == 2) {
          UpdateElementTwo();
        }


      }
    }
    // End

    // Start
    let elementdate_1 = 1
    let total_elemente = 6

    function click_cahe() {
      if (elementdate_1 == total_elemente) {
        elementdate_1 = 1;
        UpdateElementeOne();
      }
      else {
        elementdate_1 = elementdate_1 + 1;
        if (elementdate_1 == 2) {
          UpdateElementeTwo();
        }
        if (elementdate_1 == 3) {
          UpdateElementeThree();
        }
        if (elementdate_1 == 4) {
          UpdateElementeFour();
        }
        if (elementdate_1 == 5) {
          UpdateElementeFive();
        }
        if (elementdate_1 == 6) {
          UpdateElementeSix();
        }
      }
      // if(elementdate_1==1) hmUI.showToast({text: '1'});
      // if(elementdate_1==2) hmUI.showToast({text: '2'});
      // if(elementdate_1==3) hmUI.showToast({text: '3'});
      // if(elementdate_1==4) hmUI.showToast({text: '4'});
    }

    //red
    function UpdateElementeOne() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);
    }

    //orange
    function UpdateElementeTwo() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);
    }

    //gray
    function UpdateElementeThree() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);
    }

    //orange		 
    function UpdateElementeFour() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);
    }

    //blue     
    function UpdateElementeFive() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, true);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, true);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);
    }

    //verde		 
    function UpdateElementeSix() {
      normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, true);

      normal_calorie_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, true);

      normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, true);

      normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);
      normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, true);
    }

    // end 
    let normal_background_bg_img = ''
    let normal_calorie_current_text_img
    let normal_calorie_current_text_img_2
    let normal_calorie_current_text_img_3
    let normal_calorie_current_text_img_4
    let normal_calorie_current_text_img_5
    let normal_calorie_current_text_img_6
    let normal_calorie_image_progress_img_level = ''
    let normal_calorie_image_progress_img_level_2 = ''
    let normal_calorie_image_progress_img_level_3 = ''
    let normal_calorie_image_progress_img_level_4 = ''
    let normal_calorie_image_progress_img_level_5 = ''
    let normal_calorie_image_progress_img_level_6 = ''
    let normal_heart_rate_text_text_img = ''
    let normal_heart_rate_text_text_img_2 = ''
    let normal_heart_rate_text_text_img_3 = ''
    let normal_heart_rate_text_text_img_4 = ''
    let normal_heart_rate_text_text_img_5 = ''
    let normal_heart_rate_text_text_img_6 = ''
    let normal_heart_rate_image_progress_img_level = ''
    let normal_heart_rate_image_progress_img_level_2 = ''
    let normal_heart_rate_image_progress_img_level_3 = ''
    let normal_heart_rate_image_progress_img_level_4 = ''
    let normal_heart_rate_image_progress_img_level_5 = ''
    let normal_heart_rate_image_progress_img_level_6 = ''
    let normal_date_img_date_year = ''
    let normal_date_img_date_day = ''
    let normal_date_img_date_month_img = ''
    let normal_date_img_date_week_img = ''
    let normal_step_current_text_img = ''
    let normal_step_image_progress_img_level = ''
    let normal_battery_text_text_img = ''
    let normal_battery_image_progress_img_level = ''
    let normal_digital_clock_img_time = ''
    let normal_digital_clock_hour_separator_img = ''
    let normal_digital_clock_img_time_AmPm = ''
    let normal_system_dnd_img = ''
    let normal_system_clock_img = ''
    let normal_analog_clock_pro_hour_pointer_img = ''
    let normal_analog_clock_pro_minute_pointer_img = ''
    let normal_analog_clock_pro_minute_cover_pointer_img = ''
    let normal_analog_clock_pro_second_pointer_img = ''
    let normal_timerUpdateSec = undefined;
    let normal_analog_clock_pro_second_cover_pointer_img = ''
    let idle_digital_clock_img_time = ''
    let idle_digital_clock_hour_separator_img = ''
    let normal_calorie_jumpable_img_click = ''
    let Button_1 = ''
    let Button_2 = ''
    let Button_3 = ''
    let Button_4 = ''
    let Button_5 = ''
    let Button_6 = ''
    let Button_7 = ''
    let Button_8 = ''
    let timeSensor = ''


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start


        console.log('Watch_Face.ScreenNormal');
        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          src: 'bg_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        //---------


        hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 84,
          y: 370,
          image_array: [
            'tr_1.png',
            'tr_2.png',
            'tr_3.png'
          ],
          image_length: 3,
          type: hmUI.data_type.TRAINING_LOAD,
          show_level: hmUI.show_level.ONLY_NORMAL
        });


        //---------


        normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["01_nr_1.png", "01_nr_2.png", "01_nr_3.png", "01_nr_4.png", "01_nr_5.png", "01_nr_6.png", "01_nr_7.png", "01_nr_8.png", "01_nr_9.png", "01_nr_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_current_text_img_2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["02_ndo_1.png", "02_ndo_2.png", "02_ndo_3.png", "02_ndo_4.png", "02_ndo_5.png", "02_ndo_6.png", "02_ndo_7.png", "02_ndo_8.png", "02_ndo_9.png", "02_ndo_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_current_text_img_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img_3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["03_ng_1.png", "03_ng_2.png", "03_ng_3.png", "03_ng_4.png", "03_ng_5.png", "03_ng_6.png", "03_ng_7.png", "03_ng_8.png", "03_ng_9.png", "03_ng_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_current_text_img_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img_4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["04_no_1.png", "04_no_2.png", "04_no_3.png", "04_no_4.png", "04_no_5.png", "04_no_6.png", "04_no_7.png", "04_no_8.png", "04_no_9.png", "04_no_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_current_text_img_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img_5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["05_nb_1.png", "05_nb_2.png", "05_nb_3.png", "05_nb_4.png", "05_nb_5.png", "05_nb_6.png", "05_nb_7.png", "05_nb_8.png", "05_nb_9.png", "05_nb_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_current_text_img_5.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_current_text_img_6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 325,
          y: 205,
          font_array: ["06_nv_1.png", "06_nv_2.png", "06_nv_3.png", "06_nv_4.png", "06_nv_5.png", "06_nv_6.png", "06_nv_7.png", "06_nv_8.png", "06_nv_9.png", "06_nv_10.png"],
          padding: false,
          h_space: -4,
          angle: 0,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_current_text_img_6.setProperty(hmUI.prop.VISIBLE, false);

        //---------

        normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["01_prr_1.png", "01_prr_2.png", "01_prr_3.png", "01_prr_4.png", "01_prr_5.png", "01_prr_6.png", "01_prr_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_image_progress_img_level_2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["02_pbodr_1.png", "02_pbodr_2.png", "02_pbodr_3.png", "02_pbodr_4.png", "02_pbodr_5.png", "02_pbodr_6.png", "02_pbodr_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_image_progress_img_level_3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["03_pgr_1.png", "03_pgr_2.png", "03_pgr_3.png", "03_pgr_4.png", "03_pgr_5.png", "03_pgr_6.png", "03_pgr_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_image_progress_img_level_4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["04_pbor_1.png", "04_pbor_2.png", "04_pbor_3.png", "04_pbor_4.png", "04_pbor_5.png", "04_pbor_6.png", "04_pbor_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_image_progress_img_level_5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["05_pbr_1.png", "05_pbr_2.png", "05_pbr_3.png", "05_pbr_4.png", "05_pbr_5.png", "05_pbr_6.png", "05_pbr_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);

        normal_calorie_image_progress_img_level_6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 397,
          y: 126,
          image_array: ["06_pvr_1.png", "06_pvr_2.png", "06_pvr_3.png", "06_pvr_4.png", "06_pvr_5.png", "06_pvr_6.png", "06_pvr_7.png"],
          image_length: 7,
          type: hmUI.data_type.CAL,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_calorie_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

        //----------

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["01_nr_1.png", "01_nr_2.png", "01_nr_3.png", "01_nr_4.png", "01_nr_5.png", "01_nr_6.png", "01_nr_7.png", "01_nr_8.png", "01_nr_9.png", "01_nr_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img_2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["02_ndo_1.png", "02_ndo_2.png", "02_ndo_3.png", "02_ndo_4.png", "02_ndo_5.png", "02_ndo_6.png", "02_ndo_7.png", "02_ndo_8.png", "02_ndo_9.png", "02_ndo_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_text_img_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_text_text_img_3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["03_ng_1.png", "03_ng_2.png", "03_ng_3.png", "03_ng_4.png", "03_ng_5.png", "03_ng_6.png", "03_ng_7.png", "03_ng_8.png", "03_ng_9.png", "03_ng_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_text_img_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_text_text_img_4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["04_no_1.png", "04_no_2.png", "04_no_3.png", "04_no_4.png", "04_no_5.png", "04_no_6.png", "04_no_7.png", "04_no_8.png", "04_no_9.png", "04_no_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_text_img_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_text_text_img_5 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["05_nb_1.png", "05_nb_2.png", "05_nb_3.png", "05_nb_4.png", "05_nb_5.png", "05_nb_6.png", "05_nb_7.png", "05_nb_8.png", "05_nb_9.png", "05_nb_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_text_img_5.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_text_text_img_6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 40,
          y: 205,
          font_array: ["06_nv_1.png", "06_nv_2.png", "06_nv_3.png", "06_nv_4.png", "06_nv_5.png", "06_nv_6.png", "06_nv_7.png", "06_nv_8.png", "06_nv_9.png", "06_nv_10.png"],
          padding: false,
          h_space: -1,
          angle: 0,
          invalid_image: 'error11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_text_text_img_6.setProperty(hmUI.prop.VISIBLE, false);


        ////
        normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["01_prl_1.png", "01_prl_2.png", "01_prl_3.png", "01_prl_4.png", "01_prl_5.png", "01_prl_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_image_progress_img_level_2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["02_pbodl_1.png", "02_pbodl_2.png", "02_pbodl_3.png", "02_pbodl_4.png", "02_pbodl_5.png", "02_pbodl_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_image_progress_img_level_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_image_progress_img_level_3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["03_pgl_1.png", "03_pgl_2.png", "03_pgl_3.png", "03_pgl_4.png", "03_pgl_5.png", "03_pgl_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_image_progress_img_level_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_image_progress_img_level_4 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["04_pbol_1.png", "04_pbol_2.png", "04_pbol_3.png", "04_pbol_4.png", "04_pbol_5.png", "04_pbol_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_image_progress_img_level_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_image_progress_img_level_5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["05_pbl_1.png", "05_pbl_2.png", "05_pbl_3.png", "05_pbl_4.png", "05_pbl_5.png", "05_pbl_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_image_progress_img_level_5.setProperty(hmUI.prop.VISIBLE, false);

        normal_heart_rate_image_progress_img_level_6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 19,
          y: 125,
          image_array: ["06_prv_1.png", "06_prv_2.png", "06_prv_3.png", "06_prv_4.png", "06_prv_5.png", "06_prv_6.png"],
          image_length: 6,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_heart_rate_image_progress_img_level_6.setProperty(hmUI.prop.VISIBLE, false);

        //---------


        normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          year_startX: 266,
          year_startY: 96,
          year_sc_array: ["b_num_0.png", "b_num_1.png", "b_num_2.png", "b_num_3.png", "b_num_4.png", "b_num_5.png", "b_num_6.png", "b_num_7.png", "b_num_8.png", "b_num_9.png"],
          year_tc_array: ["b_num_0.png", "b_num_1.png", "b_num_2.png", "b_num_3.png", "b_num_4.png", "b_num_5.png", "b_num_6.png", "b_num_7.png", "b_num_8.png", "b_num_9.png"],
          year_en_array: ["b_num_0.png", "b_num_1.png", "b_num_2.png", "b_num_3.png", "b_num_4.png", "b_num_5.png", "b_num_6.png", "b_num_7.png", "b_num_8.png", "b_num_9.png"],
          year_zero: 1,
          year_space: 0,
          year_align: hmUI.align.LEFT,
          year_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 200,
          day_startY: 82,
          day_sc_array: ["T_0.png", "T_1.png", "T_2.png", "T_3.png", "T_4.png", "T_5.png", "T_6.png", "T_7.png", "T_8.png", "T_9.png"],
          day_tc_array: ["T_0.png", "T_1.png", "T_2.png", "T_3.png", "T_4.png", "T_5.png", "T_6.png", "T_7.png", "T_8.png", "T_9.png"],
          day_en_array: ["T_0.png", "T_1.png", "T_2.png", "T_3.png", "T_4.png", "T_5.png", "T_6.png", "T_7.png", "T_8.png", "T_9.png"],
          day_zero: 1,
          day_space: 0,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 133,
          month_startY: 96,
          month_sc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
          month_tc_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
          month_en_array: ["month_1.png", "month_2.png", "month_3.png", "month_4.png", "month_5.png", "month_6.png", "month_7.png", "month_8.png", "month_9.png", "month_10.png", "month_11.png", "month_12.png"],
          month_is_character: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 76,
          y: 1,
          week_en: ["w_01.png", "w_02.png", "w_03.png", "w_04.png", "w_05.png", "w_06.png", "w_07.png"],
          week_tc: ["w_01.png", "w_02.png", "w_03.png", "w_04.png", "w_05.png", "w_06.png", "w_07.png"],
          week_sc: ["w_01.png", "w_02.png", "w_03.png", "w_04.png", "w_05.png", "w_06.png", "w_07.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 273,
          y: 264,
          font_array: ["sb_1.png", "sb_2.png", "sb_3.png", "sb_4.png", "sb_5.png", "sb_6.png", "sb_7.png", "sb_8.png", "sb_9.png", "sb_10.png"],
          padding: false,
          h_space: 0,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 132,
          y: 284,
          image_array: ["pb_1.png", "pb_2.png", "pb_3.png", "pb_4.png", "pb_5.png", "pb_6.png", "pb_7.png", "pb_8.png", "pb_9.png", "pb_10.png", "pb_11.png", "pb_12.png", "pb_13.png", "pb_14.png"],
          image_length: 14,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 282,
          y: 175,
          font_array: ["sb_1.png", "sb_2.png", "sb_3.png", "sb_4.png", "sb_5.png", "sb_6.png", "sb_7.png", "sb_8.png", "sb_9.png", "sb_10.png"],
          padding: false,
          h_space: 0,
          unit_sc: 'sb_11.png',
          unit_tc: 'sb_11.png',
          unit_en: 'sb_11.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: 132,
          y: 159,
          image_array: ["bt_1.png", "bt_2.png", "bt_3.png", "bt_4.png", "bt_5.png", "bt_6.png", "bt_7.png", "bt_8.png", "bt_9.png", "bt_10.png", "bt_11.png", "bt_12.png", "bt_13.png", "bt_14.png"],
          image_length: 14,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 158,
          hour_startY: 334,
          hour_array: ["hb_1.png", "hb_2.png", "hb_3.png", "hb_4.png", "hb_5.png", "hb_6.png", "hb_7.png", "hb_8.png", "hb_9.png", "hb_10.png"],
          hour_zero: 1,
          hour_space: 0,
          hour_angle: 0,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 240,
          minute_startY: 334,
          minute_array: ["hb_1.png", "hb_2.png", "hb_3.png", "hb_4.png", "hb_5.png", "hb_6.png", "hb_7.png", "hb_8.png", "hb_9.png", "hb_10.png"],
          minute_zero: 1,
          minute_space: 0,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 224,
          y: 336,
          src: 'hb_11.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          am_x: 212,
          am_y: 385,
          am_sc_path: 'am.png',
          am_en_path: 'am.png',
          pm_x: 212,
          pm_y: 385,
          pm_sc_path: 'pm.png',
          pm_en_path: 'pm.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 322,
          y: 341,
          src: 'wurao.png',
          type: hmUI.system_status.DISTURB,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 109,
          y: 342,
          src: 'naozhong.png',
          type: hmUI.system_status.CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const deviceInfo = hmSetting.getDeviceInfo();
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.MINUTEEND, function () {
          let updateHour = timeSensor.minute == 0;

          time_update(updateHour, true);
        });

        // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'min.png',
        // center_x: 227,
        // center_y: 227,
        // x: 56,
        // y: 187,
        // start_angle: 0,
        // end_angle: 360,
        // type: hmUI.data_type.hour,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 56,
          pos_y: 227 - 187,
          center_x: 227,
          center_y: 227,
          src: 'min.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'hr.png',
        // center_x: 227,
        // center_y: 227,
        // x: 56,
        // y: 231,
        // start_angle: 0,
        // end_angle: 360,
        // cover_path: 's1.png',
        // cover_x: 171,
        // cover_y: 171,
        // type: hmUI.data_type.minute,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 56,
          pos_y: 227 - 231,
          center_x: 227,
          center_y: 227,
          src: 'hr.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_pro_minute_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 171,
          y: 171,
          src: 's1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
        // src: 'seg_1.png',
        // center_x: 227,
        // center_y: 227,
        // x: 19,
        // y: 226,
        // start_angle: 0,
        // end_angle: 360,
        // cover_path: 's2.png',
        // cover_x: 204,
        // cover_y: 203,
        // type: hmUI.data_type.second,
        // show_level: hmUI.show_level.ONLY_NORMAL,
        // });


        normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: deviceInfo.width,
          h: deviceInfo.height,
          pos_x: 227 - 19,
          pos_y: 227 - 226,
          center_x: 227,
          center_y: 227,
          src: 'seg_1.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        normal_analog_clock_pro_second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 204,
          y: 203,
          src: 's2.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        console.log('Watch_Face.ScreenAOD');

        idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 158,
          hour_startY: 334,
          hour_array: ["AODhb_1.png", "AODhb_2.png", "AODhb_3.png", "AODhb_4.png", "AODhb_5.png", "AODhb_6.png", "AODhb_7.png", "AODhb_8.png", "AODhb_9.png", "AODhb_10.png"],
          hour_zero: 1,
          hour_space: 0,
          hour_angle: 0,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 240,
          minute_startY: 334,
          minute_array: ["AODhb_1.png", "AODhb_2.png", "AODhb_3.png", "AODhb_4.png", "AODhb_5.png", "AODhb_6.png", "AODhb_7.png", "AODhb_8.png", "AODhb_9.png", "AODhb_10.png"],
          minute_zero: 1,
          minute_space: 0,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 224,
          y: 336,
          src: 'AODhb_11.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });
        console.log('Watch_Face.Shortcuts');

        console.log('Watch_Face.Buttont');

        // vibrate function
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let timer_StopVibrate = null;

        function vibro(scene = 25) {
          let stopDelay = 50;
          stopVibro();
          vibrate.stop();
          vibrate.scene = scene;
          if (scene < 23 || scene > 25) stopDelay = 1300;
          vibrate.start();
          if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
        }

        function stopVibro() {
          vibrate.stop();
          if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
        }
        // end vibrate function

        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 102,
          y: 54,
          w: 250,
          h: 73,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 192,
          y: 137,
          w: 70,
          h: 52,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'Settings_batteryManagerScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 15,
          y: 174,
          w: 88,
          h: 108,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'heart_app_Screen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 192,
          y: 266,
          w: 70,
          h: 51,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'activityAppScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 84,
          y: 333,
          w: 59,
          h: 49,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'AlarmInfoScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 317,
          y: 333,
          w: 59,
          h: 49,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'Settings_dndScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 84,
          y: 389,
          w: 292,
          h: 57,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'SportStatusScreen', native: true });
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 194,
          y: 193,
          w: 65,
          h: 68,
          text: '',
          color: 0xFFFF8C00,
          text_size: 24,
          press_src: 'null.png',
          normal_src: 'null.png',
          click_func: (button_widget) => {
            bgp();
            click_cahe();
            vibro(25);
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        //start of ignored block
        function time_update(updateHour = false, updateMinute = false) {
          console.log('time_update()');
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          if (updateHour) {
            let normal_hour = hour;
            let normal_fullAngle_hour = 360;
            if (normal_hour > 11) normal_hour -= 12;
            let normal_angle_hour = 0 + normal_fullAngle_hour * normal_hour / 12 + (normal_fullAngle_hour / 12) * minute / 60;
            if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
          };

          if (updateMinute) {
            let normal_fullAngle_minute = 360;
            let normal_angle_minute = 0 + normal_fullAngle_minute * minute / 60;
            if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
          };

          let normal_fullAngle_second = 360;
          let normal_angle_second = 0 + normal_fullAngle_second * second / 60;
          if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

        };

        //end of ignored block
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            time_update(true, true);
            if (screenType == hmSetting.screen_type.WATCHFACE) {
              if (!normal_timerUpdateSec) {
                let animDelay = timeSensor.utc % 1000;
                let animRepeat = 1000;
                normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                  time_update(false, false);
                }));  // end timer 
              };  // end timer check
            };  // end screenType


          }),
          pause_call: (function () {
            console.log('pause_call()');
            if (normal_timerUpdateSec) {
              timer.stopTimer(normal_timerUpdateSec);
              normal_timerUpdateSec = undefined;
            }

          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}