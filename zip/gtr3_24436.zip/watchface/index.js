﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
	let rootPath = "images/";
             let screenType = hmSetting.getScreenType()

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
if (screenType != hmSetting.screen_type.AOD) {


	// animate
         let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 215,
                    y: 314,
                    anim_path: rootPath + "anim",

                    anim_prefix: "anim",

                    anim_ext: "png",
                    anim_fps: 14,
                    anim_size: 8,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	 });
           
	}


            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 89,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 125,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 45,
              w: 150,
              h: 25,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 20,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_fonts_15.png',
              unit_tc: 'ACT_fonts_15.png',
              unit_en: 'ACT_fonts_15.png',
              negative_image: 'ACT_fonts_14.png',
              invalid_image: 'ACT_fonts_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 9,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 332,
              y: 122,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 418,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_fonts_12.png',
              unit_tc: 'ACT_fonts_12.png',
              unit_en: 'ACT_fonts_12.png',
              dot_image: 'ACT_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 237,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_fonts_13.png',
              unit_tc: 'ACT_fonts_13.png',
              unit_en: 'ACT_fonts_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 292,
              y: 266,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 361,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 304,
              image_array: ["Step_icons_01.png","Step_icons_02.png","Step_icons_03.png","Step_icons_04.png","Step_icons_05.png","Step_icons_06.png","Step_icons_07.png","Step_icons_08.png","Step_icons_09.png","Step_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 239,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 232,
              y: 268,
              image_array: ["Cal_icons_01.png","Cal_icons_02.png","Cal_icons_03.png","Cal_icons_04.png","Cal_icons_05.png","Cal_icons_06.png","Cal_icons_07.png","Cal_icons_08.png","Cal_icons_09.png","Cal_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 244,
              font_array: ["HEART_fonts_01.png","HEART_fonts_02.png","HEART_fonts_03.png","HEART_fonts_04.png","HEART_fonts_05.png","HEART_fonts_06.png","HEART_fonts_07.png","HEART_fonts_08.png","HEART_fonts_09.png","HEART_fonts_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'HEART_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 58,
              y: 249,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 187,
              year_startY: 120,
              year_sc_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_tc_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_en_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 118,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 92,
              week_en: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              week_tc: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              week_sc: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 110,
              day_sc_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_tc_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_en_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 73,
              am_y: 154,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 73,
              pm_y: 154,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 166,
              hour_array: ["Time_HM_fonts_01.png","Time_HM_fonts_02.png","Time_HM_fonts_03.png","Time_HM_fonts_04.png","Time_HM_fonts_05.png","Time_HM_fonts_06.png","Time_HM_fonts_07.png","Time_HM_fonts_08.png","Time_HM_fonts_09.png","Time_HM_fonts_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 166,
              minute_array: ["Time_HM_fonts_01.png","Time_HM_fonts_02.png","Time_HM_fonts_03.png","Time_HM_fonts_04.png","Time_HM_fonts_05.png","Time_HM_fonts_06.png","Time_HM_fonts_07.png","Time_HM_fonts_08.png","Time_HM_fonts_09.png","Time_HM_fonts_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 336,
              second_startY: 179,
              second_array: ["Time_Seconds_fonts_01.png","Time_Seconds_fonts_02.png","Time_Seconds_fonts_03.png","Time_Seconds_fonts_04.png","Time_Seconds_fonts_05.png","Time_Seconds_fonts_06.png","Time_Seconds_fonts_07.png","Time_Seconds_fonts_08.png","Time_Seconds_fonts_09.png","Time_Seconds_fonts_10.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 44,
              w: 69,
              h: 86,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 50,
              w: 74,
              h: 82,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 116,
              w: 47,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 328,
              y: 118,
              w: 49,
              h: 47,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 8,
              w: 100,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 238,
              y: 231,
              w: 100,
              h: 47,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 235,
              w: 38,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 153,
              y: 236,
              w: 71,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 352,
              w: 97,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 110,
              y: 89,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 99,
              y: 125,
              src: 'System_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 152,
              y: 45,
              w: 150,
              h: 25,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 20,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_fonts_15.png',
              unit_tc: 'ACT_fonts_15.png',
              unit_en: 'ACT_fonts_15.png',
              negative_image: 'ACT_fonts_14.png',
              invalid_image: 'ACT_fonts_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 9,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 332,
              y: 122,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 418,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_fonts_12.png',
              unit_tc: 'ACT_fonts_12.png',
              unit_en: 'ACT_fonts_12.png',
              dot_image: 'ACT_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 237,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'ACT_fonts_13.png',
              unit_tc: 'ACT_fonts_13.png',
              unit_en: 'ACT_fonts_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 292,
              y: 266,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 361,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 304,
              image_array: ["Step_icons_01.png","Step_icons_02.png","Step_icons_03.png","Step_icons_04.png","Step_icons_05.png","Step_icons_06.png","Step_icons_07.png","Step_icons_08.png","Step_icons_09.png","Step_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 239,
              font_array: ["ACT_fonts_01.png","ACT_fonts_02.png","ACT_fonts_03.png","ACT_fonts_04.png","ACT_fonts_05.png","ACT_fonts_06.png","ACT_fonts_07.png","ACT_fonts_08.png","ACT_fonts_09.png","ACT_fonts_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 232,
              y: 268,
              image_array: ["Cal_icons_01.png","Cal_icons_02.png","Cal_icons_03.png","Cal_icons_04.png","Cal_icons_05.png","Cal_icons_06.png","Cal_icons_07.png","Cal_icons_08.png","Cal_icons_09.png","Cal_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 244,
              font_array: ["HEART_fonts_01.png","HEART_fonts_02.png","HEART_fonts_03.png","HEART_fonts_04.png","HEART_fonts_05.png","HEART_fonts_06.png","HEART_fonts_07.png","HEART_fonts_08.png","HEART_fonts_09.png","HEART_fonts_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'HEART_fonts_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 58,
              y: 249,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 187,
              year_startY: 120,
              year_sc_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_tc_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_en_array: ["YEAR_fonts_01.png","YEAR_fonts_02.png","YEAR_fonts_03.png","YEAR_fonts_04.png","YEAR_fonts_05.png","YEAR_fonts_06.png","YEAR_fonts_07.png","YEAR_fonts_08.png","YEAR_fonts_09.png","YEAR_fonts_10.png"],
              year_zero: 1,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 225,
              month_startY: 118,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 92,
              week_en: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              week_tc: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              week_sc: ["DAYWEEK_01.png","DAYWEEK_02.png","DAYWEEK_03.png","DAYWEEK_04.png","DAYWEEK_05.png","DAYWEEK_06.png","DAYWEEK_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 110,
              day_sc_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_tc_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_en_array: ["DAY_fonts_01.png","DAY_fonts_02.png","DAY_fonts_03.png","DAY_fonts_04.png","DAY_fonts_05.png","DAY_fonts_06.png","DAY_fonts_07.png","DAY_fonts_08.png","DAY_fonts_09.png","DAY_fonts_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 73,
              am_y: 154,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 73,
              pm_y: 154,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 166,
              hour_array: ["Time_HM_fonts_01.png","Time_HM_fonts_02.png","Time_HM_fonts_03.png","Time_HM_fonts_04.png","Time_HM_fonts_05.png","Time_HM_fonts_06.png","Time_HM_fonts_07.png","Time_HM_fonts_08.png","Time_HM_fonts_09.png","Time_HM_fonts_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 166,
              minute_array: ["Time_HM_fonts_01.png","Time_HM_fonts_02.png","Time_HM_fonts_03.png","Time_HM_fonts_04.png","Time_HM_fonts_05.png","Time_HM_fonts_06.png","Time_HM_fonts_07.png","Time_HM_fonts_08.png","Time_HM_fonts_09.png","Time_HM_fonts_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 336,
              second_startY: 179,
              second_array: ["Time_Seconds_fonts_01.png","Time_Seconds_fonts_02.png","Time_Seconds_fonts_03.png","Time_Seconds_fonts_04.png","Time_Seconds_fonts_05.png","Time_Seconds_fonts_06.png","Time_Seconds_fonts_07.png","Time_Seconds_fonts_08.png","Time_Seconds_fonts_09.png","Time_Seconds_fonts_10.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 314,
              src: 'RunIcon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  