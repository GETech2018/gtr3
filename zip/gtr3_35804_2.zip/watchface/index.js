﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let timer_anim_rotate_1_mirror = false;
        let normal_rotate_animation_param_1_mirror = null;
        let normal_rotate_animation_count_1 = 0;
        let normal_image_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_linear_scale = ''
        let idle_step_linear_scale_pointer_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 455,
              h: 455,
              pos_x: 52,
              pos_y: 52,
              center_x: 227,
              center_y: 227,
              angle: 360,
              src: 'animation/seconds.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 60000,
              anim_from: 360,
              anim_to: 0,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_rotate_animation_param_1_mirror = {
              anim_rate: 'linear',
              anim_duration: 60000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_1_mirror() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1_mirror);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();

            }; // end animation_mirror callback function

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 360,
              // end_angle: 0,
              // pos_x: 175,
              // pos_y: 175,
              // center_x: 227,
              // center_y: 227,
              // src: 'seconds.png',
              // anim_fps: 15,
              // anim_duration: 60000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'option.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 212,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 113,
              center_y: 185,
              x: 9,
              y: 37,
              start_angle: -114,
              end_angle: 0,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 222,
              font_array: ["font_black_0.png","font_black_1.png","font_black_2.png","font_black_3.png","font_black_4.png","font_black_5.png","font_black_6.png","font_black_7.png","font_black_8.png","font_black_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 269,
              image_array: ["img_hr_1.png","img_hr_2.png","img_hr_3.png","img_hr_4.png","img_hr_5.png","img_hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 334,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 108,
              // start_y: 282,
              // color: 0xFF141414,
              // pointer: 'pointer_0.png',
              // lenght: 95,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 42,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 204,
              center_y: 115,
              posX: 9,
              posY: 59,
              start_angle: 2,
              end_angle: 352,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 117,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 89,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 269,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 313,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 12,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 212,
              second_cover_path: 'pointer_3.png',
              second_cover_x: 207,
              second_cover_y: 207,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'option.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 258,
              y: 212,
              image_array: ["img_bat_1.png","img_bat_2.png","img_bat_3.png","img_bat_4.png","img_bat_5.png","img_bat_6.png","img_bat_7.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 113,
              center_y: 185,
              x: 9,
              y: 37,
              start_angle: -114,
              end_angle: 0,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 222,
              font_array: ["font_black_0.png","font_black_1.png","font_black_2.png","font_black_3.png","font_black_4.png","font_black_5.png","font_black_6.png","font_black_7.png","font_black_8.png","font_black_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 77,
              y: 269,
              image_array: ["img_hr_1.png","img_hr_2.png","img_hr_3.png","img_hr_4.png","img_hr_5.png","img_hr_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 334,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'dot.png',
              unit_tc: 'dot.png',
              unit_en: 'dot.png',
              imperial_unit_sc: 'dot.png',
              imperial_unit_tc: 'dot.png',
              imperial_unit_en: 'dot.png',
              dot_image: 'pointer_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 108,
              // start_y: 282,
              // color: 0xFF141414,
              // pointer: 'pointer_0.png',
              // lenght: 95,
              // line_width: 0,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 306,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 42,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 204,
              center_y: 115,
              posX: 9,
              posY: 59,
              start_angle: 2,
              end_angle: 352,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 117,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 186,
              day_startY: 89,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 269,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 313,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 12,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 212,
              second_cover_path: 'pointer_3.png',
              second_cover_x: 207,
              second_cover_y: 207,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 253,
              w: 113,
              h: 113,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 216,
              w: 140,
              h: 29,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 97,
              y: 271,
              w: 115,
              h: 115,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 108;
                  let start_y_normal_step = 282;
                  let lenght_ls_normal_step = 95;
                  let line_width_ls_normal_step = 0;
                  let color_ls_normal_step = 0xFF141414;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 12;
                  let pointer_offset_y_ls_normal_step = 12;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step + lenght_ls_normal_step - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_y_ls_normal_step,
                    src: 'pointer_0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 108;
                  let start_y_idle_step = 282;
                  let lenght_ls_idle_step = 95;
                  let line_width_ls_idle_step = 0;
                  let color_ls_idle_step = 0xFF141414;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = lenght_ls_idle_step;
                  let line_width_ls_idle_step_draw = line_width_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    lenght_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_x_idle_step_draw = start_x_idle_step - lenght_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    color: color_ls_idle_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_step = 12;
                  let pointer_offset_y_ls_idle_step = 12;
                  idle_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step + lenght_ls_idle_step - pointer_offset_x_ls_idle_step,
                    y: start_y_idle_step_draw + line_width_ls_idle_step / 2 - pointer_offset_y_ls_idle_step,
                    src: 'pointer_0.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 60000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1*2) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    if(timer_anim_rotate_1_mirror) {
                      anim_rotate_1_mirror()
                    } else {
                      anim_rotate_1_complete_call()
                    };
                    timer_anim_rotate_1_mirror = !timer_anim_rotate_1_mirror;
                  })); // end timer create
                };

              }),
              pause_call: (function () {
                stop_anim_rotate_1();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}