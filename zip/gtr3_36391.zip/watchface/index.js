﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_image_img = ''
        let normal_rotate_animation_img_1 = '';
        let normal_rotate_animation_param_1 = null;
        let normal_rotate_animation_lastTime_1 = 0;
        let timer_anim_rotate_1;
        let normal_rotate_animation_count_1 = 0;
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_image_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_spo2_text_text_img = ''
        let idle_spo2_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = ''

      // start user_functions.js
let colorNumber = 1
let totalColors = 7
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    if ( colorNumber == 1) { colorName = "Copper"}
    if ( colorNumber == 2) { colorName = "Lemon Green"}
    if ( colorNumber == 3) { colorName = "Red Rost "}
    if ( colorNumber == 4) { colorName = "Yelllow"}
    if ( colorNumber == 5) { colorName = "Green"}
    if ( colorNumber == 6) { colorName = "Blue"}
    if ( colorNumber == 7) { colorName = "Gray"}

    hmUI.showToast({text: colorName });




    normal_image_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colorNumber) + ".png");
         
    }
/////////////////////////////////////////////////////////////////////////////////////////////////

        // Start background change
        let btn_element_3= ''
        let elementnumber_3= 1
        let total_elemente3 = 2

        function click_elemente3() {
            if(elementnumber_3==total_elemente3) {
            elementnumber_3=1;
                UpdateElemente3One();
                }
            else {
                elementnumber_3=elementnumber_3+1;
                if(elementnumber_3==2) {
                  UpdateElemente3Two();
                }

            }
            if(elementnumber_3==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_3==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElemente3One(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElemente3Two(){
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);

        }

     // hands clock style
        let btncolor2 = ''
        let colornumber2 = 1
        let totalcolors2 = 11
        let namecolor2 = ''

        function click_analog() {

if (elementnumber_3==1) {

            if(colornumber2>=totalcolors2) {
            colornumber2=1;
                }
            else {
                colornumber2=colornumber2+1;
            }

if ( colornumber2 == 1) { namecolor2 = "Analog Type 1"}
if ( colornumber2 == 2) { namecolor2 = "Analog Type 2"}
if ( colornumber2 == 3) { namecolor2 = "Analog Type 3"}
if ( colornumber2 == 4) { namecolor2 = "Analog Type 4"}
if ( colornumber2 == 5) { namecolor2 = "Analog Type 5"}
if ( colornumber2 == 6) { namecolor2 = "Analog Type 6"}
if ( colornumber2 == 7) { namecolor2 = "Analog Type 7"}
if ( colornumber2 == 8) { namecolor2 = "Analog Type 8"}
if ( colornumber2 == 9) { namecolor2 = "Analog Type 9"}
if ( colornumber2 == 10) { namecolor2 = "Analog Type 10"}
if ( colornumber2 == 11) { namecolor2 = "Analog Type 11"}



hmUI.showToast({text: namecolor2 });

             //hmUI.showToast({text: "color " + parseInt(colornumber2) });
                      

        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber2) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber2) + ".png");





        }
}

/////////////////////////////////////////////////////////////////////////////////////////////////

// end user_functions.js

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PulseCircle.png',
              center_x: 227,
              center_y: 341,
              x: 70,
              y: 70,
              start_angle: -90,
              end_angle: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 302,
              src: 'Toppulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 338,
              font_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 345,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 341,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekcricel.png',
              center_x: 226,
              center_y: 117,
              posX: 68,
              posY: 68,
              start_angle: 403,
              end_angle: 89,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 455,
              h: 455,
              pos_x: 73,
              pos_y: 193,
              center_x: 108,
              center_y: 228,
              angle: 0,
              src: 'animation/gear_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_1 = {
              anim_rate: 'linear',
              anim_duration: 10000,
              anim_from: 0,
              anim_to: 360,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            function anim_rotate_1_complete_call() {
              normal_rotate_animation_img_1.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_1);
              normal_rotate_animation_lastTime_1 = now.utc;
              normal_rotate_animation_count_1 = normal_rotate_animation_count_1 - 1;
              if(normal_rotate_animation_count_1 < -1) normal_rotate_animation_count_1 = - 1;
              if(normal_rotate_animation_count_1 == 0) stop_anim_rotate_1();
            }; // end animation callback function
            
            function stop_anim_rotate_1() {
              if (timer_anim_rotate_1) {
                timer.stopTimer(timer_anim_rotate_1);
                timer_anim_rotate_1 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_1 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 0,
              // end_angle: 360,
              // pos_x: 35,
              // pos_y: 35,
              // center_x: 108,
              // center_y: 228,
              // src: 'gear_0.png',
              // anim_fps: 15,
              // anim_duration: 10000,
              // repeat_count: 0,
              // anim_two_sides: False,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BattCircle.png',
              center_x: 108,
              center_y: 229,
              x: 72,
              y: 72,
              start_angle: 0,
              end_angle: 293,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 86,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 384,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 121,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 313,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 314,
              src: 'o2_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 260,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 349,
              year_startY: 260,
              year_sc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_tc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_en_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 260,
              day_sc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_tc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_en_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 226,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Cal_unit.png',
              unit_tc: 'Cal_unit.png',
              unit_en: 'Cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 200,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 164,
              font_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 50,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 82,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 83,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 331,
              minute_startY: 108,
              minute_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 279,
              hour_startY: 108,
              hour_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 107,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 34,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 34,
              pos_y: 227 - 221,
              center_x: 227,
              center_y: 227,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 34,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 34,
              pos_y: 227 - 221,
              center_x: 227,
              center_y: 227,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 34,
              // y: 221,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 34,
              pos_y: 227 - 221,
              center_x: 227,
              center_y: 227,
              src: 'Hand_S1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PulseCircle.png',
              center_x: 227,
              center_y: 341,
              x: 70,
              y: 70,
              start_angle: -90,
              end_angle: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 302,
              src: 'Toppulse.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 338,
              font_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 279,
              y: 345,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 341,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'weekcricel.png',
              center_x: 226,
              center_y: 117,
              posX: 68,
              posY: 68,
              start_angle: 403,
              end_angle: 89,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'BattCircle.png',
              center_x: 108,
              center_y: 229,
              x: 72,
              y: 72,
              start_angle: 0,
              end_angle: 293,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 86,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 384,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 375,
              y: 121,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 313,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 283,
              y: 314,
              src: 'o2_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 260,
              month_sc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_tc_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_en_array: ["Month01.png","Month02.png","Month03.png","Month04.png","Month05.png","Month06.png","Month07.png","Month08.png","Month09.png","Month10.png","Month11.png","Month12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 349,
              year_startY: 260,
              year_sc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_tc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_en_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 260,
              day_sc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_tc_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_en_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 226,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Cal_unit.png',
              unit_tc: 'Cal_unit.png',
              unit_en: 'Cal_unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 200,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'dis_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 164,
              font_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 50,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 82,
              font_array: ["Act_Small_W0.png","Act_Small_W1.png","Act_Small_W2.png","Act_Small_W3.png","Act_Small_W4.png","Act_Small_W5.png","Act_Small_W6.png","Act_Small_W7.png","Act_Small_W8.png","Act_Small_W9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 282,
              y: 83,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 331,
              minute_startY: 108,
              minute_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 279,
              hour_startY: 108,
              hour_array: ["Time_W0.png","Time_W1.png","Time_W2.png","Time_W3.png","Time_W4.png","Time_W5.png","Time_W6.png","Time_W7.png","Time_W8.png","Time_W9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 321,
              y: 107,
              src: 'TimeDot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_S12.png',
              // center_x: 227,
              // center_y: 227,
              // x: 46,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 46,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'Hand_S12.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 106,
              w: 36,
              h: 30,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 108,
              w: 32,
              h: 28,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 376,
              y: 106,
              w: 56,
              h: 37,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 301,
              y: 23,
              w: 54,
              h: 48,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 75,
              w: 98,
              h: 28,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 271,
              y: 223,
              w: 113,
              h: 21,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 310,
              w: 82,
              h: 45,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 317,
              w: 58,
              h: 59,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 161,
              w: 133,
              h: 30,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 196,
              w: 130,
              h: 22,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 205,
              w: 55,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 270,
              y: 257,
              w: 134,
              h: 27,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 77,
              y: 324,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
       /// change color main
            click_color()   
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 206,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
       /// change analog
            click_analog()   
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 195,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
       /// analog on off
            click_elemente3()  
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                let nawAnimationTime = now.utc;;
                let timer_anim_rotate_1_mirror = ''
                let delay_anim_rotate_1 = 0;
                let repeat_anim_rotate_1 = 10000;
                delay_anim_rotate_1 = repeat_anim_rotate_1 - (nawAnimationTime - normal_rotate_animation_lastTime_1);
                if(delay_anim_rotate_1 < 0) delay_anim_rotate_1 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_1) > repeat_anim_rotate_1) {
                  normal_rotate_animation_count_1 = 0;
                  timer_anim_rotate_1_mirror = false;
                };

                if (!timer_anim_rotate_1) {
                  timer_anim_rotate_1 = timer.createTimer(delay_anim_rotate_1, repeat_anim_rotate_1, (function (option) {
                    anim_rotate_1_complete_call()
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_1();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}