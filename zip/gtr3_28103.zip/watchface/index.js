﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''

        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

        //hands postitions
        let hourx = 24
        let houry = 214
        let minutex = 24
        let minutey = 214
        let secondx = 24
        let secondy = 214

        // Start color change
        let btncolor = ''
        let colornumber = 0
        let totalcolors = 5

        function click_Color() {
            colornumber=(colornumber+1) % (totalcolors+1);
            click_Vibrate();
            hmUI.showToast({text: "Handscolor " + parseInt(colornumber) });

            //call hands function to change to correct hands
            call_change_Hands(colornumber);
        }

        // Give handsnumber. Must exist
        function call_change_Hands(handsnumber) {
           switch (handsnumber) {
               case 1:
                  hourstring='hour1.png';
                  minutestring='minute1.png';
                  secondstring='sec1.png'; break;
               case 2:
                  hourstring='hour2.png';
                  minutestring='minute2.png';
                  secondstring='sec2.png'; break;
               case 3:
                  hourstring='hour3.png';
                  minutestring='minute3.png';
                  secondstring='sec3.png'; break;
               case 4:
                  hourstring='hour4.png';
                  minutestring='minute4.png';
                  secondstring='sec4.png'; break;
               case 5:
                  hourstring='hour5.png';
                  minutestring='minute5.png';
                  secondstring='sec5.png'; break;
               default:
                  hourstring='hour0.png';
                  minutestring='minute0.png';
                  secondstring='sec0.png'; break;
             }

             normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
             hour_path: hourstring,
             hour_centerX: 227,
             hour_centerY: 227,
             hour_posX: hourx,
             hour_posY: houry,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

             normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
             minute_path: minutestring,
             minute_centerX: 227,
             minute_centerY: 227,
             minute_posX: minutex,
             minute_posY: minutey,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });

             normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
             second_path: secondstring,
             second_centerX: 227,
             second_centerY: 227,
             second_posX: secondx,
             second_posY: secondy,
             second_cover_path: 'timetop.png',
             second_cover_x: 177,
             second_cover_y: 177,
             show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }

        // Start bachground change
        let btnbackground = ''
        let backgroundnumber = 0
        let totalbackgrounds = 1
        let backchange = false

        function click_Background() {
            backgroundnumber=(backgroundnumber+1) % (totalbackgrounds+1);
            click_Vibrate();

            normal_background_bg_img.setProperty(hmUI.prop.SRC, "background" + parseInt(backgroundnumber) + ".png");
            bezelbackground.setProperty(hmUI.prop.SRC, "tach" + parseInt(backgroundnumber) + ".png");

            if (backgroundnumber==0) {
            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 120,
              y: 246,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'celcius_black.png',
              unit_tc: 'celcius_black.png',
              unit_en: 'celcius_black.png',
              negative_image: 'minus_black.png',
              invalid_image: 'dbminus_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 127,
              y: 168,
              image_array: ["weather0_0.png","weather0_1.png","weather0_2.png","weather0_3.png","weather0_4.png","weather0_5.png","weather0_6.png","weather0_7.png","weather0_8.png","weather0_9.png","weather0_10.png","weather0_11.png","weather0_12.png","weather0_13.png","weather0_14.png","weather0_15.png","weather0_16.png","weather0_17.png","weather0_18.png","weather0_19.png","weather0_20.png","weather0_21.png","weather0_22.png","weather0_23.png","weather0_24.png","weather0_25.png","weather0_26.png","weather0_27.png","weather0_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 268,
              y: 190,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 229,
              y: 280,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.MORE, {
              x: 191,
              y: 275,
              src: 'hart_black.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 263,
              y: 246,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              week_en: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_tc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_sc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            bezel='tach0.png';
            } else {
            normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 120,
              y: 246,
              font_array: ["dig1_0.png","dig1_1.png","dig1_2.png","dig1_3.png","dig1_4.png","dig1_5.png","dig1_6.png","dig1_7.png","dig1_8.png","dig1_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'celcius_white.png',
              unit_tc: 'celcius_white.png',
              unit_en: 'celcius_white.png',
              negative_image: 'minus_white.png',
              invalid_image: 'dbminus_white.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 127,
              y: 168,
              image_array: ["weather1_0.png","weather1_1.png","weather1_2.png","weather1_3.png","weather1_4.png","weather1_5.png","weather1_6.png","weather1_7.png","weather1_8.png","weather1_9.png","weather1_10.png","weather1_11.png","weather1_12.png","weather1_13.png","weather1_14.png","weather1_15.png","weather1_16.png","weather1_17.png","weather1_18.png","weather1_19.png","weather1_20.png","weather1_21.png","weather1_22.png","weather1_23.png","weather1_24.png","weather1_25.png","weather1_26.png","weather1_27.png","weather1_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 268,
              y: 190,
              font_array: ["dig1_0.png","dig1_1.png","dig1_2.png","dig1_3.png","dig1_4.png","dig1_5.png","dig1_6.png","dig1_7.png","dig1_8.png","dig1_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 229,
              y: 280,
              font_array: ["dig1_0.png","dig1_1.png","dig1_2.png","dig1_3.png","dig1_4.png","dig1_5.png","dig1_6.png","dig1_7.png","dig1_8.png","dig1_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.MORE, {
              x: 191,
              y: 275,
              src: 'hart_white.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 263,
              y: 246,
              font_array: ["dig1_0.png","dig1_1.png","dig1_2.png","dig1_3.png","dig1_4.png","dig1_5.png","dig1_6.png","dig1_7.png","dig1_8.png","dig1_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 3,
              week_en: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png"],
              week_tc: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png"],
              week_sc: ["day1_0.png","day1_1.png","day1_2.png","day1_3.png","day1_4.png","day1_5.png","day1_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            bezel='tach1.png';
            }

            showbackgroundonscreen();
            backchange=true;
            const result = hmSetting.setScreenOff();
        }

        function showbackgroundonscreen() {
              hmUI.showToast({text: "Background " + parseInt(backgroundnumber) });
        }

        let bezelbackground = ''
        let bezel = 'tach0.png'
        let nAngle = 0

        function click_Back() {
            click_Vibrate();
            nAngle-=10;
            if(nAngle<=-360) nAngle=0;
            bezelbackground.setProperty(hmUI.prop.MORE, {
                  center_x: 227,
                  center_y: 227,
                  pos_x: 0,
                  pos_y: 0,
                  x:0,
                  y:0,
                  w:454,
                  h:454,
                  src: bezel,
                  angle:nAngle,
                  show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

         function click_Front() {
            click_Vibrate();
            nAngle+=10;
            if(nAngle>=360) nAngle=0;
            bezelbackground.setProperty(hmUI.prop.MORE, {
                  center_x: 227,
                  center_y: 227,
                  pos_x: 0,
                  pos_y: 0,
                  x:0,
                  y:0,
                  w:454,
                  h:454,
                  src: bezel,
                  angle:nAngle,
                  show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			bezelbackground = hmUI.createWidget(hmUI.widget.IMG, {
			  center_x: 227,
			  center_y: 227,
			  pos_x: 0,
			  pos_y: 0,
			  x:0,
			  y:0,
			  w:454,
			  h:454,
			  src: bezel,
			  angle:0,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 91,
              y: 335,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 331,
              y: 334,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 321,
              src: 'bat_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 173,
              // start_y: 324,
              // color: 0xFFA6A6A6,
              // lenght: 25,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 321,
              font_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'procent.png',
              unit_tc: 'procent.png',
              unit_en: 'procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 246,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'celcius_black.png',
              unit_tc: 'celcius_black.png',
              unit_en: 'celcius_black.png',
              negative_image: 'minus_black.png',
              invalid_image: 'dbminus_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 168,
              image_array: ["weather0_0.png","weather0_1.png","weather0_2.png","weather0_3.png","weather0_4.png","weather0_5.png","weather0_6.png","weather0_7.png","weather0_8.png","weather0_9.png","weather0_10.png","weather0_11.png","weather0_12.png","weather0_13.png","weather0_14.png","weather0_15.png","weather0_16.png","weather0_17.png","weather0_18.png","weather0_19.png","weather0_20.png","weather0_21.png","weather0_22.png","weather0_23.png","weather0_24.png","weather0_25.png","weather0_26.png","weather0_27.png","weather0_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 190,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              dot_image: 'dot_black.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 280,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 275,
              src: 'hart_black.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 246,
              font_array: ["dig0_0.png","dig0_1.png","dig0_2.png","dig0_3.png","dig0_4.png","dig0_5.png","dig0_6.png","dig0_7.png","dig0_8.png","dig0_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 133,
              day_sc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_tc_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_en_array: ["num0_0.png","num0_1.png","num0_2.png","num0_3.png","num0_4.png","num0_5.png","num0_6.png","num0_7.png","num0_8.png","num0_9.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_tc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              week_sc: ["day0_0.png","day0_1.png","day0_2.png","day0_3.png","day0_4.png","day0_5.png","day0_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 210,
              am_y: 385,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 210,
              pm_y: 385,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 151,
              hour_startY: 357,
              hour_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 236,
              minute_startY: 357,
              minute_array: ["num1_0.png","num1_1.png","num1_2.png","num1_3.png","num1_4.png","num1_5.png","num1_6.png","num1_7.png","num1_8.png","num1_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 24,
              hour_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 24,
              second_posY: 214,
              second_cover_path: 'timetop.png',
              second_cover_x: 177,
              second_cover_y: 177,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 323,
              w: 57,
              h: 57,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 189,
              w: 66,
              h: 76,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 273,
              w: 95,
              h: 57,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 189,
              w: 66,
              h: 76,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 120,
              year_startY: 230,
              year_sc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              year_tc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              year_en_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              year_zero: 1,
              year_space: -3,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 90,
              month_startY: 230,
              month_sc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              month_tc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              month_en_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              month_zero: 1,
              month_space: -3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 230,
              src: 'num3_10.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 59,
              day_startY: 230,
              day_sc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              day_tc_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              day_en_array: ["num3_0.png","num3_1.png","num3_2.png","num3_3.png","num3_4.png","num3_5.png","num3_6.png","num3_7.png","num3_8.png","num3_9.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 84,
              y: 230,
              src: 'num3_10.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 40,
              y: 206,
              week_en: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png"],
              week_tc: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png"],
              week_sc: ["day2_0.png","day2_1.png","day2_2.png","day2_3.png","day2_4.png","day2_5.png","day2_6.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_aod.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 23,
              hour_posY: 147,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute_aod.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 23,
              minute_posY: 215,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 300,
              hour_startY: 208,
              hour_array: ["num2_0.png","num2_1.png","num2_2.png","num2_3.png","num2_4.png","num2_5.png","num2_6.png","num2_7.png","num2_8.png","num2_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 356,
              minute_startY: 208,
              minute_array: ["num2_0.png","num2_1.png","num2_2.png","num2_3.png","num2_4.png","num2_5.png","num2_6.png","num2_7.png","num2_8.png","num2_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 208,
              src: 'num2_10.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 173;
                  let start_y_normal_battery = 324;
                  let lenght_ls_normal_battery = 25;
                  let line_width_ls_normal_battery = 10;
                  let color_ls_normal_battery = 0xFFA6A6A6;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                if (backchange) {
                        showbackgroundonscreen();
                        backchange=false;
                }
              }),
            });

            // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 196,
              text: '',
              w: 70,
              h: 63,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

            // Change background shortcut start
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 15,
              text: '',
              w: 87,
              h: 79,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

            // Change option shortcut start
            btnback = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 188,
              text: '',
              w: 87,
              h: 79,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Back();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnback.setProperty(hmUI.prop.VISIBLE, true);
            // Change option shortcut end

            // Change secondhand shortcut start
            btnsec = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 367,
              y: 188,
              text: '',
              w: 87,
              h: 79,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Front();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnfront.setProperty(hmUI.prop.VISIBLE, true);
            // Change secondhand shortcut end

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestroy() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
          },
          onDestory() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  