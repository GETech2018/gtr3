/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_animation6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_week_imageset12 = '';
		let timeInterval;
		let normal_date_low_imageset13 = '';
		let normal_date_low_imageset13_array = ['0052.png','0053.png','0054.png','0055.png','0056.png','0057.png','0058.png','0059.png','0060.png','0061.png'];
		let normal_date_high_imageset14 = '';
		let normal_date_high_imageset14_array = ['0062.png','0063.png','0064.png','0065.png'];
		let normal_second_rotary16 = '';
		let normal_hour_rotary17 = '';
		let normal_minute_rotary18 = '';
		let normal_img20 = '';
		let idle_hour_rotary23 = '';
		let idle_minute_rotary24 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 155,
					y: 77,
					w: 141,
					h: 89,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 262,
					y: 204,
					w: 109,
					h: 44,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -94,
					y: -95,
					w: 642,
					h: 642,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 153,
					w: 113,
					h: 113,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_animation6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						x: 83,
						y: 148,
						anim_path: '',
						anim_prefix: '1710066907283',
						anim_ext: 'png',
						anim_fps: 20,
						anim_size: 33,
						anim_repeat: false,
						repeat_count: 0,
						anim_status: hmUI.anim_status.START,
						display_on_restart: true,
						enable: false,
					});
				};

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 98,
					y: 163,
					w: 99,
					h: 99,
					src: '0041.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 89,
					y: 154,
					w: 117,
					h: 117,
					src: '0042.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 184,
					y: 181,
					w: 84,
					h: 84,
					src: '0043.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 195,
					y: 194,
					w: 62,
					h: 62,
					src: '0044.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset12 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 278,
					y: 215,
					week_en: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					week_tc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					week_sc: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_low_imageset13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 345,
					y: 214,
					w: 345,
					h: 214,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_high_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 333,
					y: 214,
					w: 333,
					h: 214,
					src: '0065.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_rotary16 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0066.png',
					second_centerX: 227,
					second_centerY: 343,
					second_posX: 10,
					second_posY: 68,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary17 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0067.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 20,
					hour_posY: 149,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary18 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0068.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 21,
					minute_posY: 189,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 210,
					w: 30,
					h: 30,
					src: '0069.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_rotary23 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0070.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 9,
					hour_posY: 124,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary24 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0071.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 9,
					minute_posY: 210,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_date_low_imageset13.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset13_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					normal_date_high_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset14_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}