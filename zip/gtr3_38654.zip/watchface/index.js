/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_hour_imagecombo9 = '';
		let normal_minute_imagecombo10 = '';
		let normal_second_imagecombo11 = '';
		let normal_clickable_image13 = '';
		let normal_clickable_image13_current = 0;
		let normal_clickable_image13_array = ['0029.png','0030.png','0031.png','0032.png','0033.png','0034.png','0035.png','0036.png','0037.png','0038.png','0039.png'];
		let normal_date_imagecombo15 = '';
		let normal_hour_rotary16 = '';
		let normal_minute_rotary17 = '';
		let normal_second_rotary18 = '';
		let idle_img22 = '';
		let idle_hour_rotary23 = '';
		let idle_minute_rotary24 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 109,
					y: 36,
					w: 242,
					h: 136,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 301,
					w: 243,
					h: 71,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: 2,
					w: 454,
					h: 452,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 275,
					y: 156,
					w: 140,
					h: 140,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 157,
					w: 140,
					h: 140,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 189,
					y: 311,
					w: 12,
					h: 54,
					src: '0008.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 113,
					hour_startY: 303,
					hour_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 205,
					minute_startY: 303,
					minute_array: ["0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 282,
					second_startY: 318,
					second_array: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_clickable_image13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 78,
					y: 196,
					w: 67,
					h: 64,
					src: '0029.png',
					enable: true,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_clickable_image13.addEventListener(hmUI.event.CLICK_DOWN, function() {
					let tcur = ((normal_clickable_image13_current+1) > (normal_clickable_image13_array.length-1) ? 0 : normal_clickable_image13_current + 1);
					normal_clickable_image13.setProperty(hmUI.prop.SRC, normal_clickable_image13_array[tcur]);
					normal_clickable_image13_current = tcur;
				});

				normal_date_imagecombo15 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 317,
					day_startY: 200,
					day_sc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_tc_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_en_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary16 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0050.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 24,
					hour_posY: 147,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary17 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0051.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 24,
					minute_posY: 208,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary18 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0052.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 20,
					second_posY: 213,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0053.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary23 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0054.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 9,
					hour_posY: 124,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary24 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0055.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 9,
					minute_posY: 210,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}