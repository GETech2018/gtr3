try {
  (() => {

    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

/*
* huamiOS bundle tool v1.0.17
* Copyright © Huami. All Rights Reserved
*/
    'use strict';

    /*params声明*/

    let strRootPath = "images/";
    let nX = 0;
    let nY = 0;
    let arrEnWeek = [];
    let arrTcWeek = [];
    let arrScWeek = [];
    let arrSec = [];
    let arrDate = [];
    let arrData = [];
    let arrTime = [];
    let arrAodTime = [];
    let arrEnMonth = [];
    let arrScMonth = [];
    let arrTcMonth = [];
    let arrHeart = [];
    let arrWeather = [];
    let arrStep = [];
    let arrSun = [];
    let arrBat = [];
    let strPath = '';
    let arrEnHeart = []
    let arrTcHeart = []
    let arrScHeart = []
    let arrEnDis = []
    let arrTcDis = []
    let arrScDis = []
    let arrEnBat = []
    let arrTcBat = []
    let arrScBat = []
    let arrEnPre = []
    let arrTcPre = []
    let arrScPre = []
    let arrEnTem = []
    let arrTcTem = []
    let arrScTem = []
    let arrEnAlt = []
    let arrTcAlt = []
    let arrScAlt = []
    let arrBatLevel = []
    let arrTemFont = []
    let languge = hmSetting.getLanguage();
    console.log("当前的语言是languge",languge);
    switch (languge) {
      case 2:
        strPath = strRootPath + "edit/preview/en/";
        strDataPath = strRootPath + "edit_data/en/";
        break;
      case 0:
        strPath = strRootPath + "edit/preview/sc/";
        strDataPath = strRootPath + "edit_data/sc/";
        break;
      case 1:
        strPath = strRootPath + "edit/preview/tc/";
        strDataPath = strRootPath + "edit_data/tc/";
        break;
      default:
        strPath = strRootPath + "edit/preview/en/";
        strDataPath = strRootPath + "edit_data/en/";
        break;
    };

    let objTime = {
      hour_zero:1, //是否补零
      hour_startX:31,
      hour_startY:127,
      hour_array:arrTime,
      hour_unit_sc: strRootPath+"time/hour/dot.png",
      hour_unit_tc: strRootPath+"time/hour/dot.png",
      hour_unit_en: strRootPath+"time/hour/dot.png",
      hour_align:hmUI.align.LEFT,
      minute_zero:1, //是否补零
      minute_startX:211,
      minute_startY:127,
      minute_array:arrTime,
      second_align:hmUI.align.LEFT,
      second_zero:1, //是否补零
      second_startX:354,
      second_startY:127,
      second_array:arrSec,
      second_align:hmUI.align.LEFT,
      am_x:370,
      am_y:197,
      am_sc_path: strRootPath+"time/am_sc"+".png",
      am_en_path: strRootPath+"time/am_en"+".png",
      pm_x:370,
      pm_y:197,
      pm_sc_path: strRootPath+"time/pm_sc"+".png",
      pm_en_path: strRootPath+"time/pm_en"+".png",
      show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
    }

    let objAodTime ={
      hour_zero:1, //是否补零
      hour_startX:31,
      hour_startY:127,
      hour_array:arrAodTime,
      hour_unit_sc: strRootPath+"aod_time/dot.png",
      hour_unit_tc: strRootPath+"aod_time/dot.png",
      hour_unit_en: strRootPath+"aod_time/dot.png",
      hour_align:hmUI.align.LEFT,
      minute_zero:1, //是否补零
      minute_startX:211,
      minute_startY:127,
      minute_array:arrAodTime,
      am_x:370,
      am_y:197,
      am_sc_path: strRootPath+"aod_time/am_sc"+".png",
      am_en_path: strRootPath+"aod_time/am_en"+".png",
      pm_x:370,
      pm_y:197,
      pm_sc_path: strRootPath+"aod_time/pm_sc"+".png",
      pm_en_path: strRootPath+"aod_time/pm_en"+".png",
      show_level: hmUI.show_level.ONLY_AOD
    }

    let objWeek = {
      x: 159,
      y: 59,
      week_en: arrEnWeek,
      week_sc: arrScWeek,
      week_tc: arrTcWeek,
      show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
    };
    let objClock = {
      x:206,
      y:7,
      type:hmUI.system_status.CLOCK,
      src: strRootPath+"icon/clock_o"+".png",
      show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
    }
    let objHeartLine = {
      x:38,
      y:278,
      w:454,
      h:60,
      line_width:4,
      line_color:0xFF6452,
      color_from:0x7fFF6452,
      color_to:0x7fFF6452,
      type:hmUI.data_type.HEART,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objPreLine = {
      x:38,
      y:278,
      w:454,
      h:60,
      line_width:4,
      line_color:0x0097E3,
      color_from:0x7f0097E3,
      color_to:0x7f0097E3,
      type:hmUI.data_type.BARO,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objTemLine = {
      x:38,
      y:278,
      w:454,
      h:60,
      line_width:4,
      line_color:0x0097E3,
      color_from:0x7f0097E3,
      color_to:0x7f0097E3,
      type:hmUI.data_type.WEATHER,
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let objArtLine = {
      x:38,
      y:278,
      w:454,
      h:60,
      line_width:4,
      line_color:0x00AC6D,
      color_from:0x7f00AC6D,
      color_to:0x7f00AC6D,
      type:hmUI.data_type.ALTITUDE,
      show_level: hmUI.show_level.ONLY_NORMAL
    }

    let objDate = {
      month_startX: 159,
      month_startY: 83,
      month_align: hmUI.align.LEFT,
      month_space: 0,
      month_zero: 1,
      month_follow: 0,
      month_en_array: arrEnMonth,
      month_sc_array: arrScMonth,
      month_tc_array: arrTcMonth,
      month_is_character:true,
      day_startX: 90,
      day_startY: 59,
      day_align: hmUI.align.LEFT,
      day_space: 0,
      day_zero: 1,
      day_follow: 0,
      day_en_array: arrDate,
      day_sc_array: arrDate,
      day_tc_array: arrDate,
      show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
    };
    let objMask = {
      x: 0,
      y: 0,
      w: 454,
      h: 454,
      src: strRootPath+"edit/mask/mask2.png",
      show_level:hmUI.show_level.ONLY_EDIT,
    };
    let objMaskN = {
      x:0,
      y:230,
      src:strRootPath+"bg/mask_bg_null.png",
      show_level: hmUI.show_level.ONLY_NORMAL
    }
    let edit_list_Line = {
      title_font_size :34 ,
      title_align_h: hmUI.align.CENTER_H ,
      list_item_vspace: 8,
      list_tips_text_font_size: 32,
      list_tips_text_align_h : hmUI.align.LEFT,
    };
    let objEditLine = {
      edit_id: 101,
      x: 0,
      y: 230,
      w: 454,
      h: 130,
      select_image:strRootPath + "edit/select/select.png",
      un_select_image:strRootPath + "edit/select/select_null.png",
      default_type:hmUI.edit_type.HEART,
      optional_types: [
        { type: hmUI.edit_type.HEART, preview: strPath + "heart.png" },
        { type: hmUI.edit_type.ALTIMETER, preview: strPath + "pre.png" },
        { type: hmUI.edit_type.TEMPERATURE, preview: strPath + "tem.png",},
        { type: hmUI.edit_type.ALTITUDE, preview: strPath + "art.png" },
      ],
      count:4,
      tips_BG:strRootPath+"edit/mask/tips.png",
      tips_x:150,
      tips_y:-220,
      tips_width:148,
      tips_margin:0,
      select_list: edit_list_Line,
    };

    /*遍历数组*/
    for(i = 0; i < 29; i++){
      if( i < 8 && i > 0 ){
        arrEnWeek.push(strRootPath+"week/en/"+i+".png")
        arrScWeek.push(strRootPath+"week/sc/"+i+".png")
        arrTcWeek.push(strRootPath+"week/tc/"+i+".png")
        arrEnHeart.push(strRootPath+"edit/type_name/heart/en/"+i+".png")
        arrTcHeart.push(strRootPath+"edit/type_name/heart/tc/"+i+".png")
        arrScHeart.push(strRootPath+"edit/type_name/heart/sc/"+i+".png")
        arrEnDis.push(strRootPath+"edit/type_name/distance/en/"+i+".png")
        arrTcDis.push(strRootPath+"edit/type_name/distance/tc/"+i+".png")
        arrScDis.push(strRootPath+"edit/type_name/distance/sc/"+i+".png")
        arrEnBat.push(strRootPath+"edit/type_name/power/en/"+i+".png")
        arrTcBat.push(strRootPath+"edit/type_name/power/tc/"+i+".png")
        arrScBat.push(strRootPath+"edit/type_name/power/sc/"+i+".png")
        arrEnPre.push(strRootPath+"edit/type_name/pre/en/"+i+".png")
        arrTcPre.push(strRootPath+"edit/type_name/pre/tc/"+i+".png")
        arrScPre.push(strRootPath+"edit/type_name/pre/sc/"+i+".png")
        arrEnTem.push(strRootPath+"edit/type_name/tem/en/"+i+".png")
        arrTcTem.push(strRootPath+"edit/type_name/tem/tc/"+i+".png")
        arrScTem.push(strRootPath+"edit/type_name/tem/sc/"+i+".png")
        arrEnAlt.push(strRootPath+"edit/type_name/alt/en/"+i+".png")
        arrTcAlt.push(strRootPath+"edit/type_name/alt/tc/"+i+".png")
        arrScAlt.push(strRootPath+"edit/type_name/alt/sc/"+i+".png")
      }
      if(i < 10){
        arrDate.push(strRootPath+"date/"+i+".png")
        arrTime.push(strRootPath+"time/hour/"+i+".png")
        arrAodTime.push(strRootPath+"aod_time/"+i+".png")
        arrSec.push(strRootPath+"time/sec/"+i+".png")
        arrStep.push(strRootPath+"data/step_font/"+i+".png")
        arrData.push(strRootPath+"data/heart_font/"+i+".png")
        arrSun.push(strRootPath+"data/sun/"+i+".png")
        arrBat.push(strRootPath+"data/dis/"+i+".png")
        arrTemFont.push(strRootPath+"data/tem_font/section/"+i+".png")
      }
      if(i < 11 && i > 0 ){
        arrBatLevel.push(strRootPath+"data/power/level/"+i+".png")
      }
      if(i < 13 && i > 0){
        arrEnMonth.push(strRootPath+"month/en/"+i+".png")
        arrScMonth.push(strRootPath+"month/sc/"+i+".png")
        arrTcMonth.push(strRootPath+"month/tc/"+i+".png")
      }
      arrWeather.push(strRootPath+"weather/"+i+".png")
    };

    // const logger = DeviceRuntimeCore.HmLogger.getLogger("xiping");
    __$$module$$__.module = DeviceRuntimeCore.WatchFace({

      /* 获取数值--电量/湿度/步数/卡路里/天气温度/PAI/心率 */
      getFont(options) {
        let objConfig = {
          x: 0,
          y: 0,
          w: 0,
          type: "",
          font_array: arrData,
          h_space: 0,
          align_h: hmUI.align.LEFT,
          unit_sc: "",
          unit_tc: "",
          unit_en: "",
          invalid_image: "",
          dot_image:"",
          padding: !1,
          negative_image: "",
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        }
        for (let key in options) {
          if (key in objConfig) {
            objConfig[key] = options[key]
          }
        }
        for (let key in objConfig) {
          if (!objConfig[key]) {
            delete objConfig[key]
          }
        }
        let text = hmUI.createWidget(hmUI.widget.TEXT_IMG, objConfig)
      },
      /* 获取进度--电量/湿度/步数/卡路里 */
      getLevel(options) {
        let { x, y, arr, type } = options
        let progress = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
          x: x,
          y: y,
          image_array: arr,
          image_length: arr.length, //长度
          type: type,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        })
      },
      /* 获取图标 */
      getIcon(options){
        let { x, y, src  } = options
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
        })
        return icon;
      },
      getIcons(options){
        let { x, y, src  } = options
        let icon = hmUI.createWidget(hmUI.widget.IMG, {
          x: x,
          y: y,
          src: src,
          show_level:hmUI.show_level.ONLY_EDIT
        })
        return icon;
      },

      /* week event */
      getWeek(options){
        let { x, y, en, sc, tc} = options
        let name =  hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: x,
          y: y,
          week_en: en,
          week_sc: sc,
          week_tc: tc,
          show_level: hmUI.show_level.ONLY_NORMAL|hmUI.show_level.ONLY_EDIT
         })
      },

      /* click event */
      changeClick(options){
        let { x, y, w, h, type} = options
        let click = hmUI.createWidget(hmUI.widget.IMG_CLICK,{
          x: x,
          y: y,
          w: w,
          h: h,
          type: type,
        })
      },
      /* 根据编辑的状态选择数据 */
      getEditData(options){

        let { type } = options;
        switch (type) {
          case hmUI.edit_type.HEART:
            /* Heart */
            this.getIcon({x:26,y:236,src:strRootPath+"icon/heart.png"});
            this.getFont({ x: 159, y:244, type: hmUI.data_type.HEART,invalid_image: strRootPath+"data/heart_font/null.png"});
            this.getWeek({ x: 56, y: 240, en:arrEnHeart, sc:arrScHeart, tc:arrTcHeart});
            /* 心率折线图 */
            let widget_H = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, objHeartLine);
            this.getIcon({x:0,y:230,src:strRootPath+"bg/mask.png"});
            this.changeClick({x:30, y:236, w:180, h:30, type: hmUI.data_type.HEART});
            this.changeClick({x:0, y:270, w:454, h:71, type: hmUI.data_type.HEART});
            break;
          case hmUI.edit_type.ALTIMETER:
             /* 气压 */
             this.getIcon({x:26, y:236, src:strRootPath+"icon/pre.png"});
             this.getFont({ x: 159, y:244, type: hmUI.data_type.ALTIMETER,invalid_image: strRootPath+"data/heart_font/null.png"});
             this.getWeek({ x: 56, y: 240, en:arrEnPre, sc:arrScPre, tc:arrTcPre});
             /* 气压折线图 */
             let widget_pre = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, objPreLine);
             this.getIcon({x:0,y:230,src:strRootPath+"bg/mask.png"});
             this.changeClick({x:30, y:236, w:180, h:30, type: hmUI.data_type.ALTIMETER});
             this.changeClick({x:0, y:270, w:454, h:71, type: hmUI.data_type.ALTIMETER});

            break;
          case hmUI.edit_type.TEMPERATURE:
             /* 温度 */
             this.getIcon({x:26,y:236,src:strRootPath+"icon/tem.png"});
             this.getFont({ x: 159, y:244, type: hmUI.data_type.WEATHER_CURRENT,
             unit_sc: strRootPath+"data/heart_font/du.png",
             unit_tc: strRootPath+"data/heart_font/du.png",
             unit_en: strRootPath+"data/heart_font/du.png",
             negative_image:strRootPath+"data/tem_font/section/dot.png",invalid_image: strRootPath+"data/heart_font/null.png"});
             this.getWeek({ x: 56, y: 240, en:arrEnTem, sc:arrScTem, tc:arrTcTem});
             /* 温度折线图 */
             let widget_tem = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, objTemLine);
             this.getIcon({x:0,y:230,src:strRootPath+"bg/mask.png"});
             this.changeClick({x:30, y:236, w:180, h:30, type: hmUI.data_type.WEATHER})
             this.changeClick({x:0, y:270, w:454, h:71, type: hmUI.data_type.WEATHER})

            break;
          case hmUI.edit_type.ALTITUDE:
              /* 海拔 */
              this.getIcon({x:26,y:236,src:strRootPath+"icon/art.png"});
              this.getFont({ x: 159, y:244, type: hmUI.data_type.ALTITUDE,invalid_image: strRootPath+"data/heart_font/null.png"});
              this.getWeek({ x: 56, y: 240, en:arrEnAlt, sc:arrScAlt, tc:arrTcAlt});
              /* 海拔折线图 */
              let widget_art_ = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, objArtLine);
              this.getIcon({x:0,y:230,src:strRootPath+"bg/mask.png"});
              this.changeClick({x:30, y:236, w:180, h:30, type: hmUI.data_type.ALTITUDE})
              this.changeClick({x:0, y:270, w:454, h:71, type: hmUI.data_type.ALTITUDE})

            break;

          default:
            break;
        }
      },
      init_view() {
        let that = this;

        /* normal bg */
        this.getIcon({x:0,y:0,src:strRootPath+"bg/bg.png"})

        /* time */
        let timeText = hmUI.createWidget(hmUI.widget.IMG_TIME, objTime);

        /*time edit*/
        this.getIcons({x:31,y:127,src:strRootPath+"time/hour/1.png" })
        this.getIcons({x:31+70,y:127,src:strRootPath+"time/hour/0.png" })
        this.getIcons({x:31+140,y:127,src:strRootPath+"time/hour/dot.png" })
        this.getIcons({x:211,y:127,src:strRootPath+"time/hour/0.png" })
        this.getIcons({x:211+70,y:127,src:strRootPath+"time/hour/9.png" })
        this.getIcons({x:354,y:127,src:strRootPath+"time/sec/3.png" })
        this.getIcons({x:354+30,y:127,src:strRootPath+"time/sec/4.png" })
        /* time aod */
        let AodTime = hmUI.createWidget(hmUI.widget.IMG_TIME, objAodTime);

        /* date */
        let timeDate = hmUI.createWidget(hmUI.widget.IMG_DATE, objDate);

        /* week */
        let timeWeek = hmUI.createWidget(hmUI.widget.IMG_WEEK, objWeek);
        this.getWeek({ x: 159, y: 59, en:arrEnWeek, sc:arrScWeek, tc:arrTcWeek});

        /* weather icon */
        this.getLevel({x:288,y:32,arr:arrWeather,type:hmUI.data_type.WEATHER})

        this.getFont({ x: 270, y:85, w:50, align_h: hmUI.align.CENTER_H, font_array:arrTemFont, type: hmUI.data_type.WEATHER_LOW,
          unit_sc: strRootPath+"data/tem_font/section/du.png",
          unit_tc: strRootPath+"data/tem_font/section/du.png",
          unit_en: strRootPath+"data/tem_font/section/du.png",
          negative_image:strRootPath+"data/tem_font/section/dot.png",
          invalid_image: strRootPath+"data/tem_font/section/null.png"});

        this.getIcon({ x:311, y:85,src: strRootPath + "data/tem_font/section/dot_1.png"})

        this.getFont({ x: 324, y:85,font_array:arrTemFont, type: hmUI.data_type.WEATHER_HIGH,
          unit_sc: strRootPath+"data/tem_font/section/du.png",
          unit_tc: strRootPath+"data/tem_font/section/du.png",
          unit_en: strRootPath+"data/tem_font/section/du.png",
          negative_image:strRootPath+"data/tem_font/section/dot.png",
          invalid_image: strRootPath+"data/tem_font/section/null.png"});

        /* clock status */
        let status = hmUI.createWidget(hmUI.widget.IMG_STATUS,objClock);

        /* step */
        this.getFont({ x: 124, y:362, font_array:arrStep, type: hmUI.data_type.STEP});

        /* sun */
        this.getFont({ x: 288, y:244, font_array:arrSun, type: hmUI.data_type.SUN_RISE,
          dot_image: strRootPath+"data/sun/mao.png",
          invalid_image: strRootPath+"data/sun/null.png"});
        this.getFont({ x: 383, y:244, font_array:arrSun, type: hmUI.data_type.SUN_SET,
          dot_image: strRootPath+"data/sun/mao.png",
          invalid_image: strRootPath+"data/sun/null.png"
        });

        /* Distance */
        this.getFont({ x: 289, y:360, font_array:arrBat, type: hmUI.data_type.DISTANCE,
          unit_sc: strRootPath+"data/dis/unit.png",
          unit_tc: strRootPath+"data/dis/unit.png",
          unit_en: strRootPath+"data/dis/unit.png",
          dot_image: strRootPath+"data/dis/dot.png",
          invalid_image: strRootPath+"data/dis/null.png"});
        this.getWeek({ x: 206, y: 359, en:arrEnDis, sc:arrScDis, tc:arrTcDis});

        /* bat */
        this.getFont({ x: 235, y:412, font_array:arrBat, type: hmUI.data_type.BATTERY,
          unit_sc: strRootPath+"data/dis/b.png",
          unit_tc: strRootPath+"data/dis/b.png",
          unit_en: strRootPath+"data/dis/b.png",});
        this.getWeek({ x: 172, y: 412, en:arrEnBat, sc:arrScBat, tc:arrTcBat});

         /* step level*/
         this.getLevel({x:92,y:388,arr:arrBatLevel,type:hmUI.data_type.STEP});

        /* grid bg */
        // this.getIcon({x:0,y:230,src:strRootPath+"bg/mask_bg_null.png"});
        let mask_bn = hmUI.createWidget(hmUI.widget.IMG,objMaskN);

        /* 可编辑组件 */
        editLine  = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP,objEditLine);
        let editType = editLine.getProperty(hmUI.prop.CURRENT_TYPE);
        this.getEditData({ type:editType, });

        /* jump */
        this.changeClick({x:206, y:7, w:42, h:42, type: hmUI.data_type.ALARM_CLOCK})
        this.changeClick({x:286, y:33, w:70, h:70, type: hmUI.data_type.WEATHER_CURRENT})
        this.changeClick({x:253, y:236, w:180, h:30, type: hmUI.data_type.SUN_CURRENT})
        this.changeClick({x:95, y:352, w:100, h:35, type: hmUI.data_type.STEP})
        this.changeClick({x:100, y:388, w:250, h:20, type: hmUI.data_type.STEP})
        this.changeClick({x:205, y:352, w:190, h:35, type: hmUI.data_type.DISTANCE})

        /* 可编辑模式 */
        /* 100%mask 编辑背景 */
        let maskCover = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, objMask);

      },

      onInit() {
        console.log('index page.js on init invoke')
        this.init_view();
      },

      onReady() {
        console.log('index page.js on ready invoke')
      },

      onShow() {
        console.log('index page.js on show invoke')
      },

      onHide() {
        console.log('index page.js on hide invoke')
      },

      onDestory() {
        console.log('index page.js on destory invoke')
      },
    });
    /*
    * end js
    */
  })()
} catch (e) {
  console.log(e)
}
