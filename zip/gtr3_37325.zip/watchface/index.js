﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_minute_TextCircle = new Array(2);
        let normal_minute_TextCircle_ASCIIARRAY = new Array(10);
        let normal_minute_TextCircle_img_width = 17;
        let normal_minute_TextCircle_img_height = 14;
        let normal_timerTextUpdate = undefined;
        let normal_hour_TextCircle = new Array(2);
        let normal_hour_TextCircle_ASCIIARRAY = new Array(10);
        let normal_hour_TextCircle_img_width = 17;
        let normal_hour_TextCircle_img_height = 14;
        let normal_hour_TextCircle_unit = null;
        let normal_hour_TextCircle_unit_width = 17;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_calorie_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_minute_TextCircle = new Array(2);
        let idle_minute_TextCircle_ASCIIARRAY = new Array(10);
        let idle_minute_TextCircle_img_width = 17;
        let idle_minute_TextCircle_img_height = 14;
        let idle_timerTextUpdate = undefined;
        let idle_hour_TextCircle = new Array(2);
        let idle_hour_TextCircle_ASCIIARRAY = new Array(10);
        let idle_hour_TextCircle_img_width = 17;
        let idle_hour_TextCircle_img_height = 14;
        let idle_hour_TextCircle_unit = null;
        let idle_hour_TextCircle_unit_width = 17;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''

// start user_functions.js

        // Start background change
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElementeOne(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElementeTwo(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }


/////////////////////////////////////////////////////////////////////
// Start background change
        let elementnumber_5 = 1
        let total_elemente5 = 11
         function click_elemente5() {
            if(elementnumber_5 >=total_elemente5) {
           elementnumber_5=1;
            }
else { 
elementnumber_5 =elementnumber_5 +1;
}


            const deviceInfo = hmSetting.getDeviceInfo();

if (elementnumber_5 <= total_elemente5 && elementnumber_1 == 1){

        let HH = "Hand_H" + parseInt(elementnumber_5) + ".png"
        let MM = "Hand_M" + parseInt(elementnumber_5) + ".png"
        let SS =  "Hand_S" + parseInt(elementnumber_5) + ".png"



            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: HH,
              hour_centerX: deviceInfo.width / 454 * 227,
              hour_centerY: deviceInfo.height / 454 * 227,
              hour_posX: deviceInfo.width / 454 * 34,
              hour_posY: deviceInfo.height / 454 * 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: MM,
              minute_centerX: deviceInfo.width / 454 * 227,
              minute_centerY: deviceInfo.height / 454 * 227,
              minute_posX: deviceInfo.width / 454  * 34,
              minute_posY: deviceInfo.height / 454 * 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: SS,
              second_centerX: deviceInfo.width / 454 * 227,
              second_centerY: deviceInfo.height / 454 * 227,
              second_posX: deviceInfo.width / 454  * 34,
              second_posY: deviceInfo.height / 454 * 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 hmUI.showToast({text: 'Analog Style '+ elementnumber_5});

}
}

// end user_functions.js

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 72,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 102,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0103.png',
              unit_tc: '0103.png',
              unit_en: '0103.png',
              negative_image: '0104.png',
              invalid_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 78,
              image_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 157,
              y: 124,
              src: '0088.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 123,
              src: '0090.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 179,
              src: '0089.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0020.png',
              center_x: 227,
              center_y: 227,
              posX: 16,
              posY: 89,
              start_angle: 194,
              end_angle: 104,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 359,
              month_startY: 262,
              month_sc_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_tc_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_en_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 291,
              day_startY: 322,
              day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_zero: 1,
              day_space: -8,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 292,
              src: '0092.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0021.png',
              center_x: 174,
              center_y: 307,
              x: 10,
              y: 63,
              start_angle: 262,
              end_angle: 175,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 79,
              y: 320,
              image_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0022.png',
              center_x: 115,
              center_y: 224,
              x: 10,
              y: 48,
              start_angle: 253,
              end_angle: 470,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 245,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0013.png',
              center_x: 312,
              center_y: 140,
              x: 10,
              y: 63,
              start_angle: 270,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 84,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0021.png',
              center_x: 312,
              center_y: 140,
              x: 10,
              y: 63,
              start_angle: 271,
              end_angle: 451,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              // radius: 49,
              // angle: 131,
              // char_space_angle: 7,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextCircle_ASCIIARRAY[0] = '0063.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[1] = '0064.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[2] = '0065.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[3] = '0066.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[4] = '0067.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[5] = '0068.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[6] = '0069.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[7] = '0070.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[8] = '0071.png';  // set of images with numbers
            normal_minute_TextCircle_ASCIIARRAY[9] = '0072.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_minute_TextCircle_img_width / 2,
                pos_y: 227 + 35,
                src: '0063.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              // radius: 49,
              // angle: 209,
              // char_space_angle: 7,
              // unit: 'Time_dot.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextCircle_ASCIIARRAY[0] = '0063.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[1] = '0064.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[2] = '0065.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[3] = '0066.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[4] = '0067.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[5] = '0068.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[6] = '0069.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[7] = '0070.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[8] = '0071.png';  // set of images with numbers
            normal_hour_TextCircle_ASCIIARRAY[9] = '0072.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_hour_TextCircle_img_width / 2,
                pos_y: 227 + 35,
                src: '0063.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_hour_TextCircle_unit_width / 2,
              pos_y: 227 + 35,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 221,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 72,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 102,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0103.png',
              unit_tc: '0103.png',
              unit_en: '0103.png',
              negative_image: '0104.png',
              invalid_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 121,
              y: 78,
              image_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 157,
              y: 124,
              src: '0088.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 123,
              src: '0090.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 179,
              src: '0089.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0020.png',
              center_x: 227,
              center_y: 227,
              posX: 16,
              posY: 89,
              start_angle: 194,
              end_angle: 104,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 359,
              month_startY: 262,
              month_sc_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_tc_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_en_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 291,
              day_startY: 322,
              day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_zero: 1,
              day_space: -8,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 292,
              src: '0092.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0021.png',
              center_x: 174,
              center_y: 307,
              x: 10,
              y: 63,
              start_angle: 262,
              end_angle: 175,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 79,
              y: 320,
              image_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0022.png',
              center_x: 115,
              center_y: 224,
              x: 10,
              y: 48,
              start_angle: 253,
              end_angle: 470,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 245,
              font_array: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0013.png',
              center_x: 312,
              center_y: 140,
              x: 10,
              y: 63,
              start_angle: 270,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 84,
              font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0021.png',
              center_x: 312,
              center_y: 140,
              x: 10,
              y: 63,
              start_angle: 271,
              end_angle: 451,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_minute_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              // radius: 49,
              // angle: 131,
              // char_space_angle: 7,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextCircle_ASCIIARRAY[0] = '0063.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[1] = '0064.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[2] = '0065.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[3] = '0066.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[4] = '0067.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[5] = '0068.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[6] = '0069.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[7] = '0070.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[8] = '0071.png';  // set of images with numbers
            idle_minute_TextCircle_ASCIIARRAY[9] = '0072.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_minute_TextCircle_img_width / 2,
                pos_y: 227 + 35,
                src: '0063.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_hour_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              // radius: 49,
              // angle: 209,
              // char_space_angle: 7,
              // unit: 'Time_dot.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextCircle_ASCIIARRAY[0] = '0063.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[1] = '0064.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[2] = '0065.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[3] = '0066.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[4] = '0067.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[5] = '0068.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[6] = '0069.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[7] = '0070.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[8] = '0071.png';  // set of images with numbers
            idle_hour_TextCircle_ASCIIARRAY[9] = '0072.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_hour_TextCircle_img_width / 2,
                pos_y: 227 + 35,
                src: '0063.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_hour_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - idle_hour_TextCircle_unit_width / 2,
              pos_y: 227 + 35,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H5.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M5.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S5.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 221,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 196,
              w: 48,
              h: 64,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 393,
              y: 205,
              w: 46,
              h: 39,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 153,
              w: 38,
              h: 42,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 64,
              w: 49,
              h: 35,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 72,
              w: 48,
              h: 38,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 146,
              w: 66,
              h: 53,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 82,
              w: 62,
              h: 49,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 81,
              w: 66,
              h: 48,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 239,
              w: 89,
              h: 37,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 134,
              y: 320,
              w: 50,
              h: 41,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 258,
              y: 342,
              w: 76,
              h: 74,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 208,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
click_elemente5() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 399,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
click_elemente() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button




            function text_update() {
              console.log('text_update()');

              console.log('update text circle minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_circle_string = parseInt(valueMinute).toString();
              normal_minute_circle_string = normal_minute_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 311;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_circle_string.length > 0 && normal_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_minute_TextCircle_img_angle = 0;
                  let normal_minute_TextCircle_dot_img_angle = 0;
                  normal_minute_TextCircle_img_angle = toDegree(Math.atan2(normal_minute_TextCircle_img_width/2, 49));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_minute_TextCircle_img_width / 2);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.SRC, normal_minute_TextCircle_ASCIIARRAY[charCode]);
                      normal_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_minute_TextCircle_img_angle + 7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_circle_string = parseInt(valueHour).toString();
              normal_hour_circle_string = normal_hour_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 389;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_circle_string.length > 0 && normal_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_hour_TextCircle_img_angle = 0;
                  let normal_hour_TextCircle_dot_img_angle = 0;
                  let normal_hour_TextCircle_unit_angle = 0;
                  normal_hour_TextCircle_img_angle = toDegree(Math.atan2(normal_hour_TextCircle_img_width/2, 49));
                  normal_hour_TextCircle_unit_angle = toDegree(Math.atan2(normal_hour_TextCircle_unit_width/2, 49));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_hour_TextCircle_img_width / 2);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.SRC, normal_hour_TextCircle_ASCIIARRAY[charCode]);
                      normal_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_hour_TextCircle_img_angle + 7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_hour_TextCircle_unit_angle;
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle minute_TIME');
              let idle_minute_circle_string = parseInt(valueMinute).toString();
              idle_minute_circle_string = idle_minute_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 311;
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_circle_string.length > 0 && idle_minute_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_minute_TextCircle_img_angle = 0;
                  let idle_minute_TextCircle_dot_img_angle = 0;
                  idle_minute_TextCircle_img_angle = toDegree(Math.atan2(idle_minute_TextCircle_img_width/2, 49));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_minute_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_minute_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_minute_TextCircle_img_width / 2);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.SRC, idle_minute_TextCircle_ASCIIARRAY[charCode]);
                      idle_minute_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_minute_TextCircle_img_angle + 7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle hour_TIME');
              let idle_hour_circle_string = parseInt(valueHour).toString();
              idle_hour_circle_string = idle_hour_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 389;
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_circle_string.length > 0 && idle_hour_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_hour_TextCircle_img_angle = 0;
                  let idle_hour_TextCircle_dot_img_angle = 0;
                  let idle_hour_TextCircle_unit_angle = 0;
                  idle_hour_TextCircle_img_angle = toDegree(Math.atan2(idle_hour_TextCircle_img_width/2, 49));
                  idle_hour_TextCircle_unit_angle = toDegree(Math.atan2(idle_hour_TextCircle_unit_width/2, 49));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_hour_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_hour_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_hour_TextCircle_img_width / 2);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.SRC, idle_hour_TextCircle_ASCIIARRAY[charCode]);
                      idle_hour_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_hour_TextCircle_img_angle + 7;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= idle_hour_TextCircle_unit_angle;
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  idle_hour_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}