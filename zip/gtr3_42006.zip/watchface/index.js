﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_pai_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 317,
              font_array: ["numpai0.png","numpai1.png","numpai2.png","numpai3.png","numpai4.png","numpai5.png","numpai6.png","numpai7.png","numpai8.png","numpai9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 66,
              font_array: ["num_small_0.png","num_small_1.png","num_small_2.png","num_small_3.png","num_small_4.png","num_small_5.png","num_small_6.png","num_small_7.png","num_small_8.png","num_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 170,
              hour_array: ["numbig0.png","numbig1.png","numbig2.png","numbig3.png","numbig4.png","numbig5.png","numbig6.png","numbig7.png","numbig8.png","numbig9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'ddot_big.png',
              hour_unit_tc: 'ddot_big.png',
              hour_unit_en: 'ddot_big.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["numbig0.png","numbig1.png","numbig2.png","numbig3.png","numbig4.png","numbig5.png","numbig6.png","numbig7.png","numbig8.png","numbig9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 23,
              am_y: 172,
              am_sc_path: '37.png',
              am_en_path: '37.png',
              pm_x: 23,
              pm_y: 172,
              pm_sc_path: '39.png',
              pm_en_path: '39.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 87,
              y: 358,
              image_array: ["40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 324,
              font_array: ["num_active_0.png","num_active_1.png","num_active_2.png","num_active_3.png","num_active_4.png","num_active_5.png","num_active_6.png","num_active_7.png","num_active_8.png","num_active_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 358,
              image_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png"],
              image_length: 20,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 324,
              font_array: ["num_active_0.png","num_active_1.png","num_active_2.png","num_active_3.png","num_active_4.png","num_active_5.png","num_active_6.png","num_active_7.png","num_active_8.png","num_active_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 404,
              font_array: ["num_active_0.png","num_active_1.png","num_active_2.png","num_active_3.png","num_active_4.png","num_active_5.png","num_active_6.png","num_active_7.png","num_active_8.png","num_active_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: '90.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 68,
              y: 112,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 298,
              day_startY: 113,
              day_sc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_tc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_en_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'numdate_dot.png',
              day_unit_tc: 'numdate_dot.png',
              day_unit_en: 'numdate_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 355,
              month_startY: 113,
              month_sc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_tc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_en_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 66,
              font_array: ["num_small_0.png","num_small_1.png","num_small_2.png","num_small_3.png","num_small_4.png","num_small_5.png","num_small_6.png","num_small_7.png","num_small_8.png","num_small_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'num_small_percent.png',
              unit_tc: 'num_small_percent.png',
              unit_en: 'num_small_percent.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 54,
              image_array: ["145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 113,
              font_array: ["num_active_0.png","num_active_1.png","num_active_2.png","num_active_3.png","num_active_4.png","num_active_5.png","num_active_6.png","num_active_7.png","num_active_8.png","num_active_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_active_deegres.png',
              unit_tc: 'num_active_deegres.png',
              unit_en: 'num_active_deegres.png',
              negative_image: 'num_active_minus.png',
              invalid_image: 'num_active_question.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 305,
              month_startY: 113,
              month_sc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_tc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_en_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 113,
              day_sc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_tc_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_en_array: ["numdate0.png","numdate1.png","numdate2.png","numdate3.png","numdate4.png","numdate5.png","numdate6.png","numdate7.png","numdate8.png","numdate9.png"],
              day_zero: 1,
              day_space: 1,
              day_unit_sc: 'numdate_dot.png',
              day_unit_tc: 'numdate_dot.png',
              day_unit_en: 'numdate_dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 112,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 170,
              hour_array: ["numbig0.png","numbig1.png","numbig2.png","numbig3.png","numbig4.png","numbig5.png","numbig6.png","numbig7.png","numbig8.png","numbig9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'ddot_big.png',
              hour_unit_tc: 'ddot_big.png',
              hour_unit_en: 'ddot_big.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["numbig0.png","numbig1.png","numbig2.png","numbig3.png","numbig4.png","numbig5.png","numbig6.png","numbig7.png","numbig8.png","numbig9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 23,
              am_y: 172,
              am_sc_path: '37.png',
              am_en_path: '37.png',
              pm_x: 23,
              pm_y: 172,
              pm_sc_path: '39.png',
              pm_en_path: '39.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 303,
              w: 92,
              h: 91,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 303,
              w: 151,
              h: 85,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 303,
              w: 151,
              h: 85,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 395,
              w: 454,
              h: 62,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 35,
              w: 113,
              h: 113,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 47,
              y: 104,
              w: 118,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 170,
              w: 153,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 170,
              w: 40,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 248,
              y: 170,
              w: 153,
              h: 115,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 104,
              w: 109,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}