﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_day_text_img = ''
        let idle_pai_day_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


  // Start main change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 6

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

            hmUI.showToast({text: "Screen Color  " + parseInt(colornumber) });

                  normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
          
            }

      // Start handclock change
        let btncbackground = ''
        let cbackgroundnumber = 1
        let ctotalpictures = 7

        function click_cBackground() {
 if(backgroundnumber==1){
            if(cbackgroundnumber==ctotalpictures) {
            cbackgroundnumber=1;
                cUpdateBackgroundOne();
                }
            else {
                cbackgroundnumber=cbackgroundnumber+1;
                if(cbackgroundnumber==2) {
                  cUpdateBackgroundTwo();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==4) {
                  cUpdateBackgroundFour();
                }
	if(cbackgroundnumber==5) {
                  cUpdateBackgroundFive();
                }
	if(cbackgroundnumber==6) {
                  cUpdateBackgroundSix();
                }
	if(cbackgroundnumber==7) {
                  cUpdateBackgroundSeven();
                }

            }
            if(cbackgroundnumber==1) hmUI.showToast({text: 'Hand clock 1'});
            if(cbackgroundnumber==2) hmUI.showToast({text: 'Hand clock 2'});
            if(cbackgroundnumber==3) hmUI.showToast({text: 'Hand clock 3'});
            if(cbackgroundnumber==4) hmUI.showToast({text: 'Hand clock 4'});
            if(cbackgroundnumber==5) hmUI.showToast({text: 'Hand clock 5'});
            if(cbackgroundnumber==6) hmUI.showToast({text: 'Hand clock 6'});
            if(cbackgroundnumber==7) hmUI.showToast({text: 'Hand clock 7'});
        }
}
  


       //Hand clock change
        function cUpdateBackgroundOne(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H1.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M1.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S1.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               
        }

  
        function cUpdateBackgroundTwo(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H2.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M2.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
        }


        function cUpdateBackgroundThree(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H3.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M3.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
        }


        function cUpdateBackgroundFour(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H4.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M4.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }


        function cUpdateBackgroundFive(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H5.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M5.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S5.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }

        function cUpdateBackgroundSix(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H6.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M6.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S6.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }

        function cUpdateBackgroundSeven(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H7.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M7.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S7.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }



      // Start hidden hand clock  change
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 2

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }

            }
            if(backgroundnumber==1) hmUI.showToast({text: 'Hand clock ON'});
            if(backgroundnumber==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateBackgroundOne(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        //hand clock off
        function UpdateBackgroundTwo(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
              }
 





        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 284,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_per.png',
              unit_tc: 'Batt_per.png',
              unit_en: 'Batt_per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 228,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 284,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Pulse_font_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 226,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 368,
              font_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symob_02.png',
              unit_tc: 'Weather_symob_02.png',
              unit_en: 'Weather_symob_02.png',
              negative_image: 'Weather_symob_01.png',
              invalid_image: 'Weather_symob_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 304,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 27,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 170,
              y: 52,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 241,
              day_startY: 53,
              day_sc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_tc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_en_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 14,
              src: 'Day_bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 202,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 206,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 159,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 159,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 159,
              src: 'Act_Font_unit.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 121,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_font_kcal.png',
              unit_tc: 'Act_font_kcal.png',
              unit_en: 'Act_font_kcal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 118,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Font_KM.png',
              unit_tc: 'ACT_Font_KM.png',
              unit_en: 'ACT_Font_KM.png',
              imperial_unit_sc: 'ACT_Font_Mil.png',
              imperial_unit_tc: 'ACT_Font_Mil.png',
              imperial_unit_en: 'ACT_Font_Mil.png',
              dot_image: 'act_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 157,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 154,
              am_y: 240,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 154,
              pm_y: 240,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 207,
              hour_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 207,
              minute_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 201,
              w: 35,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 207,
              w: 42,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 94,
              y: 197,
              w: 37,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 207,
              w: 45,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 307,
              w: 65,
              h: 88,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 156,
              w: 158,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 315,
              w: 110,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 242,
              w: 97,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 66,
              y: 155,
              w: 146,
              h: 32,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 284,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_per.png',
              unit_tc: 'Batt_per.png',
              unit_en: 'Batt_per.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 228,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 284,
              font_array: ["Pulse_font_01.png","Pulse_font_02.png","Pulse_font_03.png","Pulse_font_04.png","Pulse_font_05.png","Pulse_font_06.png","Pulse_font_07.png","Pulse_font_08.png","Pulse_font_09.png","Pulse_font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Pulse_font_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 226,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 268,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 368,
              font_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symob_02.png',
              unit_tc: 'Weather_symob_02.png',
              unit_en: 'Weather_symob_02.png',
              negative_image: 'Weather_symob_01.png',
              invalid_image: 'Weather_symob_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 304,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 163,
              month_startY: 27,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 170,
              y: 52,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 241,
              day_startY: 53,
              day_sc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_tc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_en_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 14,
              src: 'Day_bar.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 202,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 206,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 159,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 159,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 159,
              src: 'Act_Font_unit.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 269,
              y: 121,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Act_font_kcal.png',
              unit_tc: 'Act_font_kcal.png',
              unit_en: 'Act_font_kcal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 118,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Font_KM.png',
              unit_tc: 'ACT_Font_KM.png',
              unit_en: 'ACT_Font_KM.png',
              imperial_unit_sc: 'ACT_Font_Mil.png',
              imperial_unit_tc: 'ACT_Font_Mil.png',
              imperial_unit_en: 'ACT_Font_Mil.png',
              dot_image: 'act_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 99,
              y: 157,
              font_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 154,
              am_y: 240,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 154,
              pm_y: 240,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 207,
              hour_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 172,
              minute_startY: 207,
              minute_array: ["Act_font_01.png","Act_font_02.png","Act_font_03.png","Act_font_04.png","Act_font_05.png","Act_font_06.png","Act_font_07.png","Act_font_08.png","Act_font_09.png","Act_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change main background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 81,
              y: 386,
              text: '',
              w: 82,
              h: 59,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);

  //Change color background shortcut end



//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change HandClock shortcut start

            btncbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 301,
              y: 390,
              text: '',
              w: 76,
              h: 51,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_cBackground();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change handclock shortcut end


///////////////////////////////

           // hidden shortcut start
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 418,
              y: 174,
              text: '',
              w: 34,
              h: 104,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end



            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  