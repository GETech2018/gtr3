﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let editGroup_4  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'tar_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'tar_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'tar_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'tar_4.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'tar_5.png' },
              ],
              count: 5,
              default_id: 1,
              fg: 'transp454.png',
              tips_bg: 'tt.png',
              tips_x: 152,
              tips_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 167,
              y: 46,
              src: 'zn_no_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 393,
              y: 169,
              src: 'zn_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [71,98,125,152,179,250,277,304,331,358],
              y: [225,225,225,225,225,225,225,225,225,225],
              image_array: ["seg_krok01.png","seg_krok02.png","seg_krok03.png","seg_krok04.png","seg_krok05.png","seg_krok06.png","seg_krok07.png","seg_krok08.png","seg_krok09.png","seg_krok10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 232,
              y: 294,
              w: 145,
              h: 30,
              text_size: 16,
              char_space: -1,
              line_space: 0,
              color: 0xFFFFFFA2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 126,
              font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cyf_ZOL_stC.png',
              unit_tc: 'cyf_ZOL_stC.png',
              unit_en: 'cyf_ZOL_stC.png',
              negative_image: 'cyf_ZOL_minus.png',
              invalid_image: 'zn_pusty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 57,
              image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 322,
              font_array: ["cyf_CZ_0.png","cyf_CZ_1.png","cyf_CZ_2.png","cyf_CZ_3.png","cyf_CZ_4.png","cyf_CZ_5.png","cyf_CZ_6.png","cyf_CZ_7.png","cyf_CZ_8.png","cyf_CZ_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cyf_CZ_proc.png',
              unit_tc: 'cyf_CZ_proc.png',
              unit_en: 'cyf_CZ_proc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 322,
              src: 'zn_AKU.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [222,222,222,222,222,222,222,222,222,222],
              y: [350,325,300,275,250,177,152,127,102,77],
              image_array: ["seg_AKU_01.png","seg_AKU_02.png","seg_AKU_03.png","seg_AKU_04.png","seg_AKU_05.png","seg_AKU_06.png","seg_AKU_07.png","seg_AKU_08.png","seg_AKU_09.png","seg_AKU_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 329,
              day_startY: 242,
              day_sc_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              day_tc_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              day_en_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 249,
              y: 233,
              week_en: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_tc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_sc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 251,
              hour_startY: 164,
              hour_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'cyf_dw.png',
              hour_unit_tc: 'cyf_dw.png',
              hour_unit_en: 'cyf_dw.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wS.png',
              // center_x: 227,
              // center_y: 227,
              // x: 12,
              // y: 215,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 12,
              pos_y: 227 - 215,
              center_x: 227,
              center_y: 227,
              src: 'wS.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 60,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 60,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'transp454.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 353,
              font_array: ["cyf_CZ_0.png","cyf_CZ_1.png","cyf_CZ_2.png","cyf_CZ_3.png","cyf_CZ_4.png","cyf_CZ_5.png","cyf_CZ_6.png","cyf_CZ_7.png","cyf_CZ_8.png","cyf_CZ_9.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'cyf_CZ_proc.png',
              unit_tc: 'cyf_CZ_proc.png',
              unit_en: 'cyf_CZ_proc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 351,
              src: 'zn_AKU.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 110,
              hour_startY: 100,
              hour_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              hour_zero: 1,
              hour_space: 16,
              hour_angle: 0,
              hour_unit_sc: 'cyf_dw.png',
              hour_unit_tc: 'cyf_dw.png',
              hour_unit_en: 'cyf_dw.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["cyf_0.png","cyf_1.png","cyf_2.png","cyf_3.png","cyf_4.png","cyf_5.png","cyf_6.png","cyf_7.png","cyf_8.png","cyf_9.png"],
              minute_zero: 1,
              minute_space: 10,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 0,
              second_startY: 0,
              second_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
              second_zero: 1,
              second_space: 5,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 50,
              y: 102,
              w: 182,
              h: 60,
              select_image: 'ram_akt.png',
              un_select_image: 'ram_pas.png',
              default_type: hmUI.edit_type.HUMIDITY,
              optional_types: [
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(1)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(1)_WIND.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(1)_ALTIMETER.png' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: 188,
              tips_y: 106,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 114,
                  y: 120,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 6,
                  unit_sc: 'zn_UV.png',
                  unit_tc: 'zn_UV.png',
                  unit_en: 'zn_UV.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 110,
                  y: 120,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_ZOL_proc.png',
                  unit_tc: 'cyf_ZOL_proc.png',
                  unit_en: 'cyf_ZOL_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 168,
                  y: 81,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 115,
                  y: 120,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 163,
                  y: 78,
                  src: 'cyf_ZOL_hPa.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 114,
                  y: 120,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 5,
                  unit_sc: 'zn_wiatr.png',
                  unit_tc: 'zn_wiatr.png',
                  unit_en: 'zn_wiatr.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 50,
              y: 161,
              w: 182,
              h: 60,
              select_image: 'ram_akt.png',
              un_select_image: 'ram_pas.png',
              default_type: hmUI.edit_type.ALTIMETER,
              optional_types: [
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
              ],
              count: 8,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: 188,
              tips_y: 47,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 74,
                  y: 175,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: true,
                  h_space: 1,
                  unit_sc: 'zn_krok.png',
                  unit_tc: 'zn_krok.png',
                  unit_en: 'zn_krok.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 80,
                  y: 175,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'zn_cal.png',
                  unit_tc: 'zn_cal.png',
                  unit_en: 'zn_cal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 94,
                  y: 175,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'zn_serce.png',
                  unit_tc: 'zn_serce.png',
                  unit_en: 'zn_serce.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 59,
                  y: 175,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: -4,
                  unit_sc: 'cyf_Z_km.png',
                  unit_tc: 'cyf_Z_km.png',
                  unit_en: 'cyf_Z_km.png',
                  dot_image: 'cyf_Z_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 100,
                  y: 175,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 6,
                  unit_sc: 'zn_UV.png',
                  unit_tc: 'zn_UV.png',
                  unit_en: 'zn_UV.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 75,
                  y: 175,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'cyf_ZOL_proc.png',
                  unit_tc: 'cyf_ZOL_proc.png',
                  unit_en: 'cyf_ZOL_proc.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 176,
                  y: 175,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 71,
                  y: 175,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_ZOL_hPa.png',
                  unit_tc: 'cyf_ZOL_hPa.png',
                  unit_en: 'cyf_ZOL_hPa.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 100,
                  y: 175,
                  font_array: ["cyf_ZOL_0.png","cyf_ZOL_1.png","cyf_ZOL_2.png","cyf_ZOL_3.png","cyf_ZOL_4.png","cyf_ZOL_5.png","cyf_ZOL_6.png","cyf_ZOL_7.png","cyf_ZOL_8.png","cyf_ZOL_9.png"],
                  padding: false,
                  h_space: 5,
                  unit_sc: 'zn_wiatr.png',
                  unit_tc: 'zn_wiatr.png',
                  unit_en: 'zn_wiatr.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 50,
              y: 240,
              w: 182,
              h: 60,
              select_image: 'ram_akt.png',
              un_select_image: 'ram_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(3)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(3)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(3)_CAL.png' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: 188,
              tips_y: -32,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 83,
                  y: 253,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: true,
                  h_space: -1,
                  unit_sc: 'zn_krok.png',
                  unit_tc: 'zn_krok.png',
                  unit_en: 'zn_krok.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 79,
                  y: 253,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'zn_cal.png',
                  unit_tc: 'zn_cal.png',
                  unit_en: 'zn_cal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 94,
                  y: 253,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'zn_serce.png',
                  unit_tc: 'zn_serce.png',
                  unit_en: 'zn_serce.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 52,
                  y: 253,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'cyf_Z_km.png',
                  unit_tc: 'cyf_Z_km.png',
                  unit_en: 'cyf_Z_km.png',
                  dot_image: 'cyf_Z_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 50,
              y: 300,
              w: 182,
              h: 60,
              select_image: 'ram_akt.png',
              un_select_image: 'ram_pas.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(4)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(4)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(4)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(4)_DISTANCE.png' },
              ],
              count: 4,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: 188,
              tips_y: -92,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 86,
                  y: 311,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: true,
                  h_space: -1,
                  unit_sc: 'zn_krok.png',
                  unit_tc: 'zn_krok.png',
                  unit_en: 'zn_krok.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 95,
                  y: 311,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'zn_cal.png',
                  unit_tc: 'zn_cal.png',
                  unit_en: 'zn_cal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 99,
                  y: 311,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'zn_serce.png',
                  unit_tc: 'zn_serce.png',
                  unit_en: 'zn_serce.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 71,
                  y: 311,
                  font_array: ["cyf_Z_0.png","cyf_Z_1.png","cyf_Z_2.png","cyf_Z_3.png","cyf_Z_4.png","cyf_Z_5.png","cyf_Z_6.png","cyf_Z_7.png","cyf_Z_8.png","cyf_Z_9.png"],
                  padding: false,
                  h_space: -4,
                  unit_sc: 'cyf_Z_km.png',
                  unit_tc: 'cyf_Z_km.png',
                  unit_en: 'cyf_Z_km.png',
                  dot_image: 'cyf_Z_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'transp454.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'transp454.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 25,
                    posY: 143,
                    path: 'wH.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 18,
                    posY: 209,
                    path: 'wM.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 18,
                    posY: 143,
                    path: 'wH2.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 25,
                    posY: 197,
                    path: 'wM2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_x: 152,
              tips_y: 300,
              tips_bg: 'tt.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(0);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 9,
            // });


            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(9);
              }
            };

            // end repeat alerts

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 267,
              w: 154,
              h: 176,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 316,
              w: 110,
              h: 130,
              src: 'zn_pusty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 143,
              w: 135,
              h: 121,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 110,
              w: 140,
              h: 100,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 231,
              y: 5,
              w: 201,
              h: 135,
              src: 'zn_pusty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 314,
              w: 152,
              h: 130,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 10,
              w: 185,
              h: 96,
              src: 'zn_pusty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 213,
              w: 140,
              h: 95,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}