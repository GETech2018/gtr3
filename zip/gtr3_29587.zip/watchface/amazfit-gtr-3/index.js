try {
    (() => {
        const e = __$$hmAppManager$$__.currentApp;

		const t = e.current,
            {
                px: n
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, t)), e.__globals__);
        let g = "",
            p = "",
            r = "",
            _ = "",
            o = "",
            h = "",
            a = "";
        const m = Logger.getLogger("watchface6");
        t.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 155,
                    y: 55,
                    image_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png"],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: "33.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 39,
                    y: 156,
                    week_en: ["34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    week_tc: ["34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    week_sc: ["34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 156,
                    month_startY: 270,
                    month_sc_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_tc_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_en_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_align: hmUI.align.LEFT,
                    month_zero: 0,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "53.png",
                    center_x: 343,
                    center_y: 227,
                    x: 13,
                    y: 71,
                    type: hmUI.data_type.STEP,
                    start_angle: 70,
                    end_angle: 340,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "54.png",
                    center_x: 343,
                    center_y: 227,
                    x: 13,
                    y: 71,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 325,
                    end_angle: 54,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "55.png",
                    center_x: 111,
                    center_y: 227,
                    x: 13,
                    y: 71,
                    type: hmUI.data_type.CAL,
                    start_angle: 328,
                    end_angle: 35,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), g = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 331,
                    y: 323,
                    w: 40,
                    h: 25,
                    text: "[DAY_Z]",
                    color: "0xFF000000",
                    text_size: 23,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), _ = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 86,
                    y: 324,
                    w: 60,
                    h: 25,
                    text: "[YEAR]",
                    color: "0xFF000000",
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 38,
                    hour_posY: 227,
                    hour_path: "56.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 38,
                    minute_posY: 227,
                    minute_path: "57.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 

				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "59.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 185,
                    y: 80,
                    week_en: ["60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png"],
                    week_tc: ["60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png"],
                    week_sc: ["60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png"],
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 205,
                    day_startY: 45,
                    day_sc_array: ["67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png", "75.png", "76.png"],
                    day_tc_array: ["67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png", "75.png", "76.png"],
                    day_en_array: ["67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png", "75.png", "76.png"],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), o = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 197,
                    y: 348,
                    w: 60,
                    h: 40,
                    text: "[SC]",
                    color: "0xFFf18026",
                    text_size: 18,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 17,
                    hour_posY: 150,
                    hour_path: "77.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 17,
                    minute_posY: 213,
                    minute_path: "78.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), h || (h = hmSensor.createSensor(hmSensor.id.TIME)), a || (a = hmSensor.createSensor(hmSensor.id.STEP)), h.addEventListener(h.event.DAYCHANGE, (function () {
                    p = hmSetting.getDateFormat(), r = [() => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(h.day).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(h.day).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(h.day).padStart(2,"0")}`
                        })
                    }], r[p](), p = hmSetting.getDateFormat(), r = [() => {
                        _.setProperty(hmUI.prop.MORE, {
                            text: `${h.year}`
                        })
                    }, () => {
                        _.setProperty(hmUI.prop.MORE, {
                            text: `${h.year}`
                        })
                    }, () => {
                        _.setProperty(hmUI.prop.MORE, {
                            text: `${h.year}`
                        })
                    }], r[p]()
                })), a.addEventListener(hmSensor.event.CHANGE, (function () {
                    o.setProperty(hmUI.prop.MORE, {
                        text: `${a.current}`
                    })
                })), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        p = hmSetting.getDateFormat(), r = [() => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(h.day).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(h.day).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(h.day).padStart(2,"0")}`
                            })
                        }], r[p](), p = hmSetting.getDateFormat(), r = [() => {
                            _.setProperty(hmUI.prop.MORE, {
                                text: `${h.year}`
                            })
                        }, () => {
                            _.setProperty(hmUI.prop.MORE, {
                                text: `${h.year}`
                            })
                        }, () => {
                            _.setProperty(hmUI.prop.MORE, {
                                text: `${h.year}`
                            })
                        }], r[p](), o.setProperty(hmUI.prop.MORE, {
                            text: `${a.current}`
                        })
                    }
                })
//代码开始
            let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 31;
            let second_posY = 227;
            let second_path = "58.png";

    	    let sec_pointer;
    	    let clock_timer;
	        let animAngle = 0;
            let animDelay = 0;                   
            const animFps = 60;                             // Frames per second 
            const animRepeat = 1000/animFps;                // then execute every <animRepeat>ms
            const deviceInfo = hmSetting.getDeviceInfo();
	    // SMOOTH SECONDS Definition End

            sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: deviceInfo.width / 2 - second_posX,
              pos_y: deviceInfo.height / 2 - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');

                    clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
                            animAngle = (now.second*6) + (((now.utc % 1000)/1000)*6);
                            sec_pointer.setProperty(hmUI.prop.ANGLE, animAngle);
                    }));
		}),
                pause_call: (function () {
                    console.log('ui pause');
					timer.stopTimer(clock_timer);
                }),
            });                
            // 代码结束                
            }, onInit() {
                m.log("index page.js on init invoke")
            }, build() {
                this.init_view(), m.log("index page.js on ready invoke")
            }, onDestroy() {
                m.log("index page.js on destroy invoke")
            }
        })
    })()
} catch (e) {
    console.log("Mini Program Error", e), e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}