﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_year = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_uvi_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 384,
              y: 297,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0221.png',
              unit_tc: '0221.png',
              unit_en: '0221.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 286,
              src: '0447.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 362,
              image_array: ["wind1.png","wind2.png","wind3.png","wind4.png","wind5.png","wind6.png","wind7.png","wind8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 401,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'metc.png',
              unit_tc: 'metc.png',
              unit_en: 'metc.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 386,
              y: 223,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 354,
              y: 223,
              src: '0493.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 152,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 285,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 2,
              dot_image: '0106.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 311,
              font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
              padding: false,
              h_space: 2,
              dot_image: '0104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 308,
              year_startY: 97,
              year_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              year_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              year_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 123,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              dot_image: '0042.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 5,
              src: '0520.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 30,
              src: '0521.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 369,
              y: 132,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 363,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0118.png',
              unit_tc: '0118.png',
              unit_en: '0118.png',
              negative_image: '0073.png',
              invalid_image: '0073.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 367,
              image_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png","0412.png","0413.png","0414.png","0415.png","0416.png","0417.png","0418.png","0419.png","0420.png","0421.png","0422.png","0423.png","0424.png","0425.png","0426.png","0427.png","0428.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 389,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0074.png',
              unit_tc: '0074.png',
              unit_en: '0074.png',
              negative_image: '0073.png',
              invalid_image: '0073.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 412,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0074.png',
              unit_tc: '0074.png',
              unit_en: '0074.png',
              negative_image: '0073.png',
              invalid_image: '0073.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 259,
              month_startY: 97,
              month_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              month_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              month_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: '0917.png',
              month_unit_tc: '0917.png',
              month_unit_en: '0917.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 209,
              day_startY: 97,
              day_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '0917.png',
              day_unit_tc: '0917.png',
              day_unit_en: '0917.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 393,
              y: 256,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 62,
              y: 70,
              week_en: ["0248.png","0249.png","0250.png","0251.png","0252.png","0253.png","0254.png"],
              week_tc: ["0248.png","0249.png","0250.png","0251.png","0252.png","0253.png","0254.png"],
              week_sc: ["0248.png","0249.png","0250.png","0251.png","0252.png","0253.png","0254.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 246,
              hour_startY: 67,
              hour_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_unit_sc: '0013.png',
              hour_unit_tc: '0013.png',
              hour_unit_en: '0013.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 289,
              minute_startY: 67,
              minute_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: '0013.png',
              minute_unit_tc: '0013.png',
              minute_unit_en: '0013.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 333,
              second_startY: 67,
              second_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 185,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              invalid_image: '44.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 43,
              image_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 249,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              invalid_image: '65.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 218,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              invalid_image: '86.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 378,
              y: 182,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0221.png',
              unit_tc: '0221.png',
              unit_en: '0221.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 328,
              font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              padding: false,
              h_space: 0,
              invalid_image: '103.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 31,
              y: 23,
              image_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0016.png',
              hour_centerX: 261,
              hour_centerY: 227,
              hour_posX: 8,
              hour_posY: 53,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0017.png',
              minute_centerX: 261,
              minute_centerY: 227,
              minute_posX: 9,
              minute_posY: 81,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0018.png',
              second_centerX: 261,
              second_centerY: 227,
              second_posX: 6,
              second_posY: 84,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -160,
              // end_angle: 160,
              // radius: 140,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            let screenType = hmSetting.getScreenType();
            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -160,
              end_angle: 160,
              radius: 139,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 350,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0221.png',
              unit_tc: '0221.png',
              unit_en: '0221.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 375,
              month_startY: 218,
              month_sc_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_tc_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_en_array: ["0180.png","0181.png","0182.png","0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 34,
              day_startY: 214,
              day_sc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_tc_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_en_array: ["0500.png","0501.png","0502.png","0503.png","0504.png","0505.png","0506.png","0507.png","0508.png","0509.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 199,
              week_en: ["0310.png","0311.png","0312.png","0313.png","0314.png","0315.png","0316.png"],
              week_tc: ["0310.png","0311.png","0312.png","0313.png","0314.png","0315.png","0316.png"],
              week_sc: ["0310.png","0311.png","0312.png","0313.png","0314.png","0315.png","0316.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 168,
              hour_startY: 125,
              hour_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 168,
              minute_startY: 253,
              minute_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: НЕТ СВЯЗИ!,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: СВЯЗЬ ЕСТЬ!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "НЕТ СВЯЗИ!"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "СВЯЗЬ ЕСТЬ!"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 47,
              w: 66,
              h: 47,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 180,
              w: 95,
              h: 95,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 113,
              y: 28,
              w: 95,
              h: 47,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 279,
              w: 132,
              h: 57,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 350,
              w: 95,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 288,
              w: 95,
              h: 47,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 213,
              w: 113,
              h: 47,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 123,
              w: 85,
              h: 85,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 28,
              w: 76,
              h: 95,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 208,
              w: 113,
              h: 47,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 279,
              w: 147,
              h: 57,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 123,
              w: 66,
              h: 85,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -160,
                      end_angle: 160,
                      radius: 139,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}