﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''

  // Start main change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 6

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

            hmUI.showToast({text: "Screen Color  " + parseInt(colornumber) });

                  normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
          
            }

      // Start handclock change
        let btncbackground = ''
        let cbackgroundnumber = 1
        let ctotalpictures = 8

        function click_cBackground() {
 if(backgroundnumber==1){
            if(cbackgroundnumber==ctotalpictures) {
            cbackgroundnumber=1;
                cUpdateBackgroundOne();
                }
            else {
                cbackgroundnumber=cbackgroundnumber+1;
                if(cbackgroundnumber==2) {
                  cUpdateBackgroundTwo();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==4) {
                  cUpdateBackgroundFour();
                }
	if(cbackgroundnumber==5) {
                  cUpdateBackgroundFive();
                }
	if(cbackgroundnumber==6) {
                  cUpdateBackgroundSix();
                }
	if(cbackgroundnumber==7) {
                  cUpdateBackgroundSeven();
                }
	if(cbackgroundnumber==8) {
                  cUpdateBackgroundEight();
                }

            }
            if(cbackgroundnumber==1) hmUI.showToast({text: 'Hand clock 1'});
            if(cbackgroundnumber==2) hmUI.showToast({text: 'Hand clock 2'});
            if(cbackgroundnumber==3) hmUI.showToast({text: 'Hand clock 3'});
            if(cbackgroundnumber==4) hmUI.showToast({text: 'Hand clock 4'});
            if(cbackgroundnumber==5) hmUI.showToast({text: 'Hand clock 5'});
            if(cbackgroundnumber==6) hmUI.showToast({text: 'Hand clock 6'});
            if(cbackgroundnumber==7) hmUI.showToast({text: 'Hand clock 7'});
            if(cbackgroundnumber==8) hmUI.showToast({text: 'Hand clock 8'});
        }
}
  


       //Hand clock change
        function cUpdateBackgroundOne(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H1.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M1.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S1.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               
        }

  
        function cUpdateBackgroundTwo(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H2.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M2.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
        }


        function cUpdateBackgroundThree(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H3.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M3.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
        }


        function cUpdateBackgroundFour(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H4.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M4.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }


        function cUpdateBackgroundFive(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H5.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M5.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S5.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }

        function cUpdateBackgroundSix(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H6.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M6.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S6.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }

        function cUpdateBackgroundSeven(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H7.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M7.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S7.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }

        function cUpdateBackgroundEight(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                   hour_path: 'Hand_H8.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 34,
                 hour_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M8.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 34,
                  minute_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2_4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 34,
                  second_posY: 220,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
 }



      // Start hidden hand clock  change
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 2

        function click_Background() {
            if(backgroundnumber==totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }

            }
            if(backgroundnumber==1) hmUI.showToast({text: 'Hand clock ON'});
            if(backgroundnumber==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateBackgroundOne(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        //hand clock off
        function UpdateBackgroundTwo(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
              }
 










        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Month_Pointer.png',
              center_x: 227,
              center_y: 227,
              posX: 38,
              posY: 222,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 238,
              font_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 174,
              image_array: ["Zone01.png","Zone02.png","Zone03.png","Zone04.png","Zone05.png","Zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Week_pointer.png',
              center_x: 227,
              center_y: 351,
              posX: 10,
              posY: 54,
              start_angle: -134,
              end_angle: 218,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 339,
              day_sc_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_tc_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_en_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 362,
              font_array: ["Weather_font_01.png","Weather_font_02.png","Weather_font_03.png","Weather_font_04.png","Weather_font_05.png","Weather_font_06.png","Weather_font_07.png","Weather_font_08.png","Weather_font_09.png","Weather_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_font_12.png',
              unit_tc: 'Weather_font_12.png',
              unit_en: 'Weather_font_12.png',
              negative_image: 'Weather_font_13.png',
              invalid_image: 'Weather_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 323,
              y: 332,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 323,
              font_array: ["Weather_font_01.png","Weather_font_02.png","Weather_font_03.png","Weather_font_04.png","Weather_font_05.png","Weather_font_06.png","Weather_font_07.png","Weather_font_08.png","Weather_font_09.png","Weather_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 291,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 266,
              y: 242,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 283,
              src: 'Systemp_icon_03.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 155,
              src: 'System_icon_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 262,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Font_S_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Step_pointer.png',
              center_x: 149,
              center_y: 124,
              x: 11,
              y: 56,
              start_angle: 258,
              end_angle: 398,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 122,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 122,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 67,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 285,
              am_y: 153,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 285,
              pm_y: 153,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 250,
              hour_startY: 185,
              hour_array: ["Font_B_01.png","Font_B_02.png","Font_B_03.png","Font_B_04.png","Font_B_05.png","Font_B_06.png","Font_B_07.png","Font_B_08.png","Font_B_09.png","Font_B_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 330,
              minute_startY: 185,
              minute_array: ["Font_B_01.png","Font_B_02.png","Font_B_03.png","Font_B_04.png","Font_B_05.png","Font_B_06.png","Font_B_07.png","Font_B_08.png","Font_B_09.png","Font_B_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 186,
              src: 'Font_B_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 184,
              w: 28,
              h: 48,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 204,
              w: 46,
              h: 46,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 153,
              w: 36,
              h: 23,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 261,
              y: 236,
              w: 39,
              h: 41,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 324,
              w: 59,
              h: 62,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 411,
              w: 73,
              h: 42,
              src: '0_empty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 62,
              w: 119,
              h: 28,
              src: '0_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 170,
              w: 111,
              h: 55,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 68,
              y: 228,
              w: 114,
              h: 49,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 99,
              w: 103,
              h: 40,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Month_Pointer.png',
              center_x: 227,
              center_y: 227,
              posX: 38,
              posY: 222,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 238,
              font_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 174,
              image_array: ["Zone01.png","Zone02.png","Zone03.png","Zone04.png","Zone05.png","Zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Week_pointer.png',
              center_x: 227,
              center_y: 351,
              posX: 10,
              posY: 54,
              start_angle: -134,
              end_angle: 218,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 339,
              day_sc_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_tc_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_en_array: ["Font_M_01.png","Font_M_02.png","Font_M_03.png","Font_M_04.png","Font_M_05.png","Font_M_06.png","Font_M_07.png","Font_M_08.png","Font_M_09.png","Font_M_10.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 362,
              font_array: ["Weather_font_01.png","Weather_font_02.png","Weather_font_03.png","Weather_font_04.png","Weather_font_05.png","Weather_font_06.png","Weather_font_07.png","Weather_font_08.png","Weather_font_09.png","Weather_font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_font_12.png',
              unit_tc: 'Weather_font_12.png',
              unit_en: 'Weather_font_12.png',
              negative_image: 'Weather_font_13.png',
              invalid_image: 'Weather_font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 323,
              y: 332,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 323,
              font_array: ["Weather_font_01.png","Weather_font_02.png","Weather_font_03.png","Weather_font_04.png","Weather_font_05.png","Weather_font_06.png","Weather_font_07.png","Weather_font_08.png","Weather_font_09.png","Weather_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 291,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 266,
              y: 242,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 156,
              y: 283,
              src: 'Systemp_icon_03.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 155,
              src: 'System_icon_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 319,
              y: 262,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Font_S_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Step_pointer.png',
              center_x: 149,
              center_y: 124,
              x: 11,
              y: 56,
              start_angle: 258,
              end_angle: 398,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 122,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 122,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 67,
              font_array: ["Font_S_01.png","Font_S_02.png","Font_S_03.png","Font_S_04.png","Font_S_05.png","Font_S_06.png","Font_S_07.png","Font_S_08.png","Font_S_09.png","Font_S_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 285,
              am_y: 153,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 285,
              pm_y: 153,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 250,
              hour_startY: 185,
              hour_array: ["Font_B_01.png","Font_B_02.png","Font_B_03.png","Font_B_04.png","Font_B_05.png","Font_B_06.png","Font_B_07.png","Font_B_08.png","Font_B_09.png","Font_B_10.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 330,
              minute_startY: 185,
              minute_array: ["Font_B_01.png","Font_B_02.png","Font_B_03.png","Font_B_04.png","Font_B_05.png","Font_B_06.png","Font_B_07.png","Font_B_08.png","Font_B_09.png","Font_B_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 186,
              src: 'Font_B_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_h1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_m1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_s1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 34,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_AOD,
            });

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change main background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 188,
              text: '',
              w: 41,
              h: 75,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);

  //Change color background shortcut end



//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change HandClock shortcut start

            btncbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 412,
              y: 186,
              text: '',
              w: 41,
              h: 75,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_cBackground();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change handclock shortcut end


///////////////////////////////

           // hidden shortcut start
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 411,
              text: '',
              w: 73,
              h: 42,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end



            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  