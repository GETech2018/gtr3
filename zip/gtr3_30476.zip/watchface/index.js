﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 48,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 374,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 320,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_FONT_11.png',
              unit_tc: 'ACT_FONT_11.png',
              unit_en: 'ACT_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 352,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 276,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 97,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_Font_11.png',
              unit_tc: 'Weather_Font_11.png',
              unit_en: 'Weather_Font_11.png',
              negative_image: 'Weather_Font_12.png',
              invalid_image: 'Weather_Font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 116,
              y: 144,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 251,
              y: 170,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 249,
              month_startY: 143,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 254,
              day_startY: 88,
              day_sc_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_tc_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_en_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 249,
              hour_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 324,
              minute_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 48,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 46,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   second_path: 'Hand_seconds.png',
            //   second_centerX: 227,
            //   second_centerY: 227,
            //   second_posX: 46,
            //   second_posY: 226,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

		let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 46;
            let second_posY = 226;
            let second_path = "Hand_seconds.png";
            // ----------------------------
            let lastTime = 0;
            let animTimer;
            const animDuration = 5000;
            const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
            const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection
            
            // Smooth Seconds
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: second_centerX - second_posX,
              pos_y: second_centerY - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
              }
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
            }

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {  // when the screen turns on, create a timer to update the animation
                console.log('ui resume');
      
                const screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.WATCHFACE) return;  // if not the main screen of the dial, then do nothing
                if (animTimer) return;  // if the timer is already running, then do nothing
      
                let duration = 0;
                const diffTime = now.utc - lastTime;
                if (diffTime < animDuration) {
                  duration = animDuration - diffTime;  // we calculate the timer start delay, depending on the time of its last start (so that there is no overlap of two animations)
                }
      
                console.log('createTimer');
                animTimer = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = now.utc;
                  let sec = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);  // we calculate the angle of the second hand depending on the seconds and milliseconds.
                  startSecAnim(sec);
                }));
              }),
              pause_call: (function () {  // when the screen turns off, delete the timer
                console.log('ui pause');
                if (animTimer) {
                  timer.stopTimer(animTimer);
                  animTimer = undefined;
                }
              }),
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 207,
              w: 42,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 329,
              w: 115,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 372,
              w: 38,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 144,
              w: 79,
              h: 67,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 89,
              w: 119,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 273,
              w: 117,
              h: 27,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 346,
              w: 27,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 346,
              w: 85,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 239,
              w: 95,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 48,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 374,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 107,
              y: 320,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_FONT_11.png',
              unit_tc: 'ACT_FONT_11.png',
              unit_en: 'ACT_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 352,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 276,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 97,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Weather_Font_11.png',
              unit_tc: 'Weather_Font_11.png',
              unit_en: 'Weather_Font_11.png',
              negative_image: 'Weather_Font_12.png',
              invalid_image: 'Weather_Font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 116,
              y: 144,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 255,
              y: 172,
              week_en: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_tc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              week_sc: ["DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png","DayWeek_icons_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 249,
              month_startY: 143,
              month_sc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_tc_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_en_array: ["month_icons_01.png","month_icons_02.png","month_icons_03.png","month_icons_04.png","month_icons_05.png","month_icons_06.png","month_icons_07.png","month_icons_08.png","month_icons_09.png","month_icons_10.png","month_icons_11.png","month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 254,
              day_startY: 88,
              day_sc_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_tc_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_en_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 248,
              am_y: 300,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 248,
              pm_y: 300,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 256,
              hour_startY: 249,
              hour_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 256,
              minute_startY: 324,
              minute_array: ["Time_HM_01.png","Time_HM_02.png","Time_HM_03.png","Time_HM_04.png","Time_HM_05.png","Time_HM_06.png","Time_HM_07.png","Time_HM_08.png","Time_HM_09.png","Time_HM_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 48,
              hour_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 46,
              minute_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_seconds.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 46,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  