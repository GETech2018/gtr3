﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_high_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Hex.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 115,
              y: 128,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 301,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 98,
              y: 297,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 328,
              font_array: ["DigBlackSmall0.png","DigBlackSmall1.png","DigBlackSmall2.png","DigBlackSmall3.png","DigBlackSmall4.png","DigBlackSmall5.png","DigBlackSmall6.png","DigBlackSmall7.png","DigBlackSmall8.png","DigBlackSmall9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 286,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 284,
              month_startY: 356,
              month_sc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_tc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_en_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 229,
              day_startY: 356,
              day_sc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_tc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_en_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_zero: 0,
              day_space: 0,
              day_unit_sc: 'guion.png',
              day_unit_tc: 'guion.png',
              day_unit_en: 'guion.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 136,
              y: 359,
              week_en: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_tc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_sc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 118,
              y: 62,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 54,
              y: 200,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 129,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'degrees.png',
              unit_tc: 'degrees.png',
              unit_en: 'degrees.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 67,
              image_array: ["Weather10.png","Weather11.png","Weather12.png","Weather13.png","Weather14.png","Weather15.png","Weather16.png","Weather17.png","Weather18.png","Weather19.png","Weather20.png","Weather21.png","Weather22.png","Weather23.png","Weather24.png","Weather25.png","Weather26.png","Weather27.png","Weather28.png","Weather29.png","Weather30.png","Weather31.png","Weather32.png","Weather33.png","Weather34.png","Weather35.png","Weather36.png","Weather37.png","Weather38.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 74,
              src: 'Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 212,
              // start_y: 76,
              // color: 0xFF39FF09,
              // lenght: 30,
              // line_width: 14,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 104,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 176,
              hour_array: ["DigBlack0.png","DigBlack1.png","DigBlack2.png","DigBlack3.png","DigBlack4.png","DigBlack5.png","DigBlack6.png","DigBlack7.png","DigBlack8.png","DigBlack9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 250,
              minute_startY: 176,
              minute_array: ["DigBlack0.png","DigBlack1.png","DigBlack2.png","DigBlack3.png","DigBlack4.png","DigBlack5.png","DigBlack6.png","DigBlack7.png","DigBlack8.png","DigBlack9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 12,
              hour_startY: 150,
              hour_array: ["NumWhite10.png","NumWhite11.png","NumWhite12.png","NumWhite13.png","NumWhite14.png","NumWhite15.png","NumWhite16.png","NumWhite17.png","NumWhite18.png","NumWhite19.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 231,
              minute_startY: 150,
              minute_array: ["NumWhite10.png","NumWhite11.png","NumWhite12.png","NumWhite13.png","NumWhite14.png","NumWhite15.png","NumWhite16.png","NumWhite17.png","NumWhite18.png","NumWhite19.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 212;
                  let start_y_normal_battery = 76;
                  let lenght_ls_normal_battery = 30;
                  let line_width_ls_normal_battery = 14;
                  let color_ls_normal_battery = 0xFF39FF09;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  