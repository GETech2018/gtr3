﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 399,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 94,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'FONT_ATC_13.png',
              unit_tc: 'FONT_ATC_13.png',
              unit_en: 'FONT_ATC_13.png',
              negative_image: 'FONT_ATC_14.png',
              invalid_image: 'FONT_ATC_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 52,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 261,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 265,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 384,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 223,
              y: 427,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 384,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 334,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'D-KM.png',
              unit_tc: 'D-KM.png',
              unit_en: 'D-KM.png',
              imperial_unit_sc: 'D-MI.png',
              imperial_unit_tc: 'D-MI.png',
              imperial_unit_en: 'D-MI.png',
              dot_image: 'FONT_ATC_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 334,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 304,
              font_array: ["Battery_Font_01.png","Battery_Font_02.png","Battery_Font_03.png","Battery_Font_04.png","Battery_Font_05.png","Battery_Font_06.png","Battery_Font_07.png","Battery_Font_08.png","Battery_Font_09.png","Battery_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_Font_11.png',
              unit_tc: 'Battery_Font_11.png',
              unit_en: 'Battery_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 295,
              image_array: ["Battery_icon_1.png","Battery_icon_2.png","Battery_icon_3.png","Battery_icon_4.png","Battery_icon_5.png","Battery_icon_6.png","Battery_icon_7.png","Battery_icon_8.png","Battery_icon_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 319,
              month_startY: 211,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 233,
              day_startY: 106,
              day_sc_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_tc_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_en_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'DayWeek_hand.png',
              center_x: 255,
              center_y: 126,
              posX: 17,
              posY: 73,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 80,
              am_y: 87,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 80,
              pm_y: 87,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 188,
              hour_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 202,
              minute_array: ["Time_M_01.png","Time_M_02.png","Time_M_03.png","Time_M_04.png","Time_M_05.png","Time_M_06.png","Time_M_07.png","Time_M_08.png","Time_M_09.png","Time_M_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 328,
              second_startY: 313,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Secondshand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 21,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 304,
              w: 78,
              h: 51,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 192,
              w: 62,
              h: 87,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 253,
              w: 48,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 201,
              w: 59,
              h: 56,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 346,
              y: 55,
              w: 69,
              h: 58,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 119,
              y: 380,
              w: 99,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 423,
              w: 92,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 378,
              w: 91,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 54,
              y: 332,
              w: 108,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 399,
              y: 216,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 351,
              y: 94,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'FONT_ATC_13.png',
              unit_tc: 'FONT_ATC_13.png',
              unit_en: 'FONT_ATC_13.png',
              negative_image: 'FONT_ATC_14.png',
              invalid_image: 'FONT_ATC_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 52,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 261,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 356,
              y: 265,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 384,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 223,
              y: 427,
              image_array: ["Zone_1.png","Zone_2.png","Zone_3.png","Zone_4.png","Zone_5.png","Zone_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 384,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 334,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'D-KM.png',
              unit_tc: 'D-KM.png',
              unit_en: 'D-KM.png',
              imperial_unit_sc: 'D-MI.png',
              imperial_unit_tc: 'D-MI.png',
              imperial_unit_en: 'D-MI.png',
              dot_image: 'FONT_ATC_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 334,
              font_array: ["FONT_ATC_01.png","FONT_ATC_02.png","FONT_ATC_03.png","FONT_ATC_04.png","FONT_ATC_05.png","FONT_ATC_06.png","FONT_ATC_07.png","FONT_ATC_08.png","FONT_ATC_09.png","FONT_ATC_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 304,
              font_array: ["Battery_Font_01.png","Battery_Font_02.png","Battery_Font_03.png","Battery_Font_04.png","Battery_Font_05.png","Battery_Font_06.png","Battery_Font_07.png","Battery_Font_08.png","Battery_Font_09.png","Battery_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Battery_Font_11.png',
              unit_tc: 'Battery_Font_11.png',
              unit_en: 'Battery_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 103,
              y: 295,
              image_array: ["Battery_icon_1.png","Battery_icon_2.png","Battery_icon_3.png","Battery_icon_4.png","Battery_icon_5.png","Battery_icon_6.png","Battery_icon_7.png","Battery_icon_8.png","Battery_icon_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 319,
              month_startY: 211,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 233,
              day_startY: 106,
              day_sc_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_tc_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_en_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'DayWeek_hand.png',
              center_x: 255,
              center_y: 126,
              posX: 17,
              posY: 73,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 80,
              am_y: 87,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 80,
              pm_y: 87,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 52,
              hour_startY: 188,
              hour_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 215,
              minute_startY: 202,
              minute_array: ["Time_M_01.png","Time_M_02.png","Time_M_03.png","Time_M_04.png","Time_M_05.png","Time_M_06.png","Time_M_07.png","Time_M_08.png","Time_M_09.png","Time_M_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 328,
              second_startY: 313,
              second_array: ["Time_S_01.png","Time_S_02.png","Time_S_03.png","Time_S_04.png","Time_S_05.png","Time_S_06.png","Time_S_07.png","Time_S_08.png","Time_S_09.png","Time_S_10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Secondshand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 21,
              second_posY: 227,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  