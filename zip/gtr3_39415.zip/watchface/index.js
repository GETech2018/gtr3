﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colornumber_main = 1
		let button_color1 = ''
		let button_color2 = ''
		let button_color3 = ''
		let button_color4 = ''
		let button_color5 = ''
		let button_color6 = ''
		let button_color7 = ''
		let button_color8 = ''
		let button_color9 = ''
		let button_color10 = ''
		let button_color11 = ''
		let button_color12 = ''
		let button_color13 = ''
		let button_color14 = ''
		let button_color15 = ''
		let button_color16 = ''
		
		function click_COLOR() {
			
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			button_color1.setProperty(hmUI.prop.VISIBLE, true);
			button_color2.setProperty(hmUI.prop.VISIBLE, true);
			button_color3.setProperty(hmUI.prop.VISIBLE, true);
			button_color4.setProperty(hmUI.prop.VISIBLE, true);
			button_color5.setProperty(hmUI.prop.VISIBLE, true);
			button_color6.setProperty(hmUI.prop.VISIBLE, true);
			button_color7.setProperty(hmUI.prop.VISIBLE, true);
			button_color8.setProperty(hmUI.prop.VISIBLE, true);
			button_color9.setProperty(hmUI.prop.VISIBLE, true);
			button_color10.setProperty(hmUI.prop.VISIBLE, true);
			button_color11.setProperty(hmUI.prop.VISIBLE, true);
			button_color12.setProperty(hmUI.prop.VISIBLE, true);
			button_color13.setProperty(hmUI.prop.VISIBLE, true);
			button_color14.setProperty(hmUI.prop.VISIBLE, true);
			button_color15.setProperty(hmUI.prop.VISIBLE, true);
			button_color16.setProperty(hmUI.prop.VISIBLE, true);
			Button_2.setProperty(hmUI.prop.VISIBLE, false);
			Button_3.setProperty(hmUI.prop.VISIBLE, false);
			Button_4.setProperty(hmUI.prop.VISIBLE, false);
			Button_5.setProperty(hmUI.prop.VISIBLE, false);
			Button_6.setProperty(hmUI.prop.VISIBLE, false);
			Button_7.setProperty(hmUI.prop.VISIBLE, false);
			Button_8.setProperty(hmUI.prop.VISIBLE, false);
			Button_9.setProperty(hmUI.prop.VISIBLE, false);
			Button_10.setProperty(hmUI.prop.VISIBLE, false);
			Button_11.setProperty(hmUI.prop.VISIBLE, false);
			Button_12.setProperty(hmUI.prop.VISIBLE, false);
			Button_13.setProperty(hmUI.prop.VISIBLE, false);
			Button_14.setProperty(hmUI.prop.VISIBLE, false);
			Button_15.setProperty(hmUI.prop.VISIBLE, false);
			Button_16.setProperty(hmUI.prop.VISIBLE, false);
            hmUI.showToast({text: 'CHOOSE YOUR BACKGROUND'});
        }

        function CHOOSE_COLOR(){
			
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "hand_sec" + parseInt(colornumber_main) + ".png");
			
			setTimeout(function(){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			Button_2.setProperty(hmUI.prop.VISIBLE, true);
			Button_3.setProperty(hmUI.prop.VISIBLE, true);
			Button_4.setProperty(hmUI.prop.VISIBLE, true);
			Button_5.setProperty(hmUI.prop.VISIBLE, true);
			Button_6.setProperty(hmUI.prop.VISIBLE, true);
			Button_7.setProperty(hmUI.prop.VISIBLE, true);
			Button_8.setProperty(hmUI.prop.VISIBLE, true);
			Button_9.setProperty(hmUI.prop.VISIBLE, true);
			Button_10.setProperty(hmUI.prop.VISIBLE, true);
			Button_11.setProperty(hmUI.prop.VISIBLE, true);
			Button_12.setProperty(hmUI.prop.VISIBLE, true);
			Button_13.setProperty(hmUI.prop.VISIBLE, true);
			Button_14.setProperty(hmUI.prop.VISIBLE, true);
			Button_15.setProperty(hmUI.prop.VISIBLE, true);
			Button_16.setProperty(hmUI.prop.VISIBLE, true);
			}, 1200);
		}
		
		function click_COLOR1() {
            colornumber_main=1;
			hmUI.showToast({text: 'O R A N G E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR2() {
            colornumber_main=2;
			hmUI.showToast({text: 'T E A L'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR3() {
            colornumber_main=3;
			hmUI.showToast({text: 'O L I V E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR4() {
            colornumber_main=4;
			hmUI.showToast({text: 'M A R O O N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR5() {
            colornumber_main=5;
			hmUI.showToast({text: 'A Q U A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR6() {
            colornumber_main=6;
			hmUI.showToast({text: 'G R E E N'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR7() {
            colornumber_main=7;
			hmUI.showToast({text: 'R E D'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR8() {
            colornumber_main=8;
			hmUI.showToast({text: 'Y E L L O W'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR9() {
            colornumber_main=9;
			hmUI.showToast({text: 'L I M E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR10() {
            colornumber_main=10;
			hmUI.showToast({text: 'P U R P L E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR11() {
            colornumber_main=11;
			hmUI.showToast({text: 'B L U E'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR12() {
            colornumber_main=12;
			hmUI.showToast({text: 'F U C H S I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR13() {
            colornumber_main=13;
			hmUI.showToast({text: 'S E P I A'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR14() {
            colornumber_main=14;
			hmUI.showToast({text: 'A M B E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR15() {
            colornumber_main=15;
			hmUI.showToast({text: 'S I L V E R'});
			CHOOSE_COLOR();
        }
		
		function click_COLOR16() {
            colornumber_main=16;
			hmUI.showToast({text: 'W H I T E'});
			CHOOSE_COLOR();
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_spo2_icon_img = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stress_icon_img = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_icon_img = ''
        let idle_calorie_current_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''
        let Button_14 = ''
        let Button_15 = ''
        let Button_16 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_sec1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 227,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 227,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'hand_sec1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 42,
              y: 159,
              image_array: ["weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 189,
              font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd20_12.png',
              unit_tc: 'd20_12.png',
              unit_en: 'd20_12.png',
              imperial_unit_sc: 'd20_13.png',
              imperial_unit_tc: 'd20_13.png',
              imperial_unit_en: 'd20_13.png',
              negative_image: 'd20_11.png',
              invalid_image: 'd20_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 209,
              font_array: ["d20_00.png","d20_01.png","d20_02.png","d20_03.png","d20_04.png","d20_05.png","d20_06.png","d20_07.png","d20_08.png","d20_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd20_12.png',
              unit_tc: 'd20_12.png',
              unit_en: 'd20_12.png',
              imperial_unit_sc: 'd20_13.png',
              imperial_unit_tc: 'd20_13.png',
              imperial_unit_en: 'd20_13.png',
              negative_image: 'd20_11.png',
              invalid_image: 'd20_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 197,
              font_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'd30_11.png',
              unit_tc: 'd30_11.png',
              unit_en: 'd30_11.png',
              imperial_unit_sc: 'd30_12.png',
              imperial_unit_tc: 'd30_12.png',
              imperial_unit_en: 'd30_12.png',
              negative_image: 'd30_13.png',
              invalid_image: 'd30_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 246,
              day_sc_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_tc_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_en_array: ["d30_00.png","d30_01.png","d30_02.png","d30_03.png","d30_04.png","d30_05.png","d30_06.png","d30_07.png","d30_08.png","d30_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 71,
              y: 231,
              week_en: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_tc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              week_sc: ["wd1.png","wd2.png","wd3.png","wd4.png","wd5.png","wd6.png","wd7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 132,
              month_startY: 246,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 88,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 17,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'l20_10.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 319,
              // center_y: 83,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 49,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 319,
              center_y: 83,
              start_angle: 360,
              end_angle: 0,
              radius: 44,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 87,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l20_11.png',
              unit_tc: 'l20_11.png',
              unit_en: 'l20_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 281,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 190,
              y: 328,
              image_array: ["hr1.png","hr2.png","hr3.png","hr4.png","hr5.png","hr6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 293,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l24_10.png',
              unit_tc: 'l24_10.png',
              unit_en: 'l24_10.png',
              imperial_unit_sc: 'l24_11.png',
              imperial_unit_tc: 'l24_11.png',
              imperial_unit_en: 'l24_11.png',
              dot_image: 'l24_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 329,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 171,
              // center_y: 380,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 36,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 171,
              center_y: 380,
              start_angle: 360,
              end_angle: 0,
              radius: 33,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 95,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 54,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 95,
              start_angle: 360,
              end_angle: 0,
              radius: 48,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 100,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 46,
              y: 111,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 289,
              hour_startY: 165,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 275,
              minute_startY: 275,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 368,
              second_startY: 250,
              second_array: ["sec_00.png","sec_01.png","sec_02.png","sec_03.png","sec_04.png","sec_05.png","sec_06.png","sec_07.png","sec_08.png","sec_09.png"],
              second_zero: 1,
              second_space: -20,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Theme_Picker.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 319,
              // center_y: 83,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 49,
              // line_width: 10,
              // line_cap: Flat,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 319,
              center_y: 83,
              start_angle: 0,
              end_angle: 360,
              radius: 44,
              line_width: 10,
              corner_flag: 3,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 285,
              y: 87,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l20_11.png',
              unit_tc: 'l20_11.png',
              unit_en: 'l20_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 293,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 55,
              y: 293,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'l24_10.png',
              unit_tc: 'l24_10.png',
              unit_en: 'l24_10.png',
              imperial_unit_sc: 'l24_11.png',
              imperial_unit_tc: 'l24_11.png',
              imperial_unit_en: 'l24_11.png',
              dot_image: 'l24_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 329,
              font_array: ["l20_00.png","l20_01.png","l20_02.png","l20_03.png","l20_04.png","l20_05.png","l20_06.png","l20_07.png","l20_08.png","l20_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 171,
              // center_y: 380,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 36,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 171,
              center_y: 380,
              start_angle: 0,
              end_angle: 360,
              radius: 33,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 132,
              // center_y: 95,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 54,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF808080,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 132,
              center_y: 95,
              start_angle: 0,
              end_angle: 360,
              radius: 48,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF808080,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 100,
              font_array: ["l24_00.png","l24_01.png","l24_02.png","l24_03.png","l24_04.png","l24_05.png","l24_06.png","l24_07.png","l24_08.png","l24_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 46,
              y: 111,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 289,
              hour_startY: 165,
              hour_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 275,
              minute_startY: 275,
              minute_array: ["time_00.png","time_01.png","time_02.png","time_03.png","time_04.png","time_05.png","time_06.png","time_07.png","time_08.png","time_09.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 288,
              y: 388,
              w: 48,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 104,
              w: 38,
              h: 38,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 284,
              y: 288,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 298,
              y: 178,
              w: 76,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TomatoMainScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 373,
              y: 246,
              w: 57,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 43,
              y: 178,
              w: 95,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 178,
              w: 114,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 229,
              w: 114,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 71,
              y: 298,
              w: 95,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 33,
              y: 242,
              w: 48,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 142,
              y: 350,
              w: 61,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 184,
              y: 279,
              w: 71,
              h: 71,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 90,
              y: 52,
              w: 85,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_14 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 43,
              w: 81,
              h: 81,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_15 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 81,
              w: 66,
              h: 66,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_16 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 15,
              w: 76,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 23,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

button_color1 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 92,
              y: 92,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR1();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color2 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 165,
              y: 92,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR2();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color3 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 238,
              y: 92,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR3();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color4 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 311,
              y: 92,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR4();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color5 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 92,
              y: 165,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR5();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color6 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 165,
              y: 165,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR6();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color7 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 238,
              y: 165,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR7();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color8 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 311,
              y: 165,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR8();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color9 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 92,
              y: 238,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR9();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color10 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 165,
              y: 238,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR10();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color11 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 238,
              y: 238,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR11();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color12 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 311,
              y: 238,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR12();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color13 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 92,
              y: 311,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR13();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color14 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 165,
              y: 311,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR14();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color15 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 238,
              y: 311,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR15();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			button_color16 = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 311,
              y: 311,
              w: 63,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_COLOR16();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			let cc = 0
			if (cc ==0 ){
			normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			button_color1.setProperty(hmUI.prop.VISIBLE, false);
			button_color2.setProperty(hmUI.prop.VISIBLE, false);
			button_color3.setProperty(hmUI.prop.VISIBLE, false);
			button_color4.setProperty(hmUI.prop.VISIBLE, false);
			button_color5.setProperty(hmUI.prop.VISIBLE, false);
			button_color6.setProperty(hmUI.prop.VISIBLE, false);
			button_color7.setProperty(hmUI.prop.VISIBLE, false);
			button_color8.setProperty(hmUI.prop.VISIBLE, false);
			button_color9.setProperty(hmUI.prop.VISIBLE, false);
			button_color10.setProperty(hmUI.prop.VISIBLE, false);
			button_color11.setProperty(hmUI.prop.VISIBLE, false);
			button_color12.setProperty(hmUI.prop.VISIBLE, false);
			button_color13.setProperty(hmUI.prop.VISIBLE, false);
			button_color14.setProperty(hmUI.prop.VISIBLE, false);
			button_color15.setProperty(hmUI.prop.VISIBLE, false);
			button_color16.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 319,
                      center_y: 83,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 44,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 171,
                      center_y: 380,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 33,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = 1 - progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 95,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 48,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 319,
                      center_y: 83,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 44,
                      line_width: 10,
                      corner_flag: 3,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 171,
                      center_y: 380,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 33,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 132,
                      center_y: 95,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 48,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF808080,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}