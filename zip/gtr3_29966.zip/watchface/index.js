﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let editGroup_4  = ''
        let fg_mask = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'bg_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'bg_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'bg_3.png' },
              ],
              count: 3,
              default_id: 1,
              fg: 'mask_bg.png',
              tips_bg: 'bg_tips.png',
              tips_x: 161,
              tips_y: 376,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 363,
              y: 101,
              week_en: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_tc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_sc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 101,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 123,
              am_y: 109,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 123,
              pm_y: 109,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 134,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 245,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 299,
              second_startY: 215,
              second_array: ["time_sec_0.png","time_sec_1.png","time_sec_2.png","time_sec_3.png","time_sec_4.png","time_sec_5.png","time_sec_6.png","time_sec_7.png","time_sec_8.png","time_sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 363,
              y: 101,
              week_en: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_tc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              week_sc: ["dow_1.png","dow_2.png","dow_3.png","dow_4.png","dow_5.png","dow_6.png","dow_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 101,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 123,
              am_y: 109,
              am_sc_path: 'time_am.png',
              am_en_path: 'time_am.png',
              pm_x: 123,
              pm_y: 109,
              pm_sc_path: 'time_pm.png',
              pm_en_path: 'time_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 134,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 245,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 153,
              y: -8,
              w: 148,
              h: 99,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
              ],
              count: 4,
              tips_BG: 'bg_tips.png',
              tips_x: 8,
              tips_y: 114,
              tips_width: 132,
              tips_margin: 5,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 0,
                  image_array: ["top_1.png","top_2.png","top_3.png","top_4.png","top_5.png","top_6.png","top_7.png","top_8.png","top_9.png","top_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 180,
                  y: 49,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'medium_digits_percent.png',
                  unit_tc: 'medium_digits_percent.png',
                  unit_en: 'medium_digits_percent.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 23,
                  src: 'top_name_BATTERY.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 153,
                //   y: -8,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 0,
                  image_array: ["top_1.png","top_2.png","top_3.png","top_4.png","top_5.png","top_6.png","top_7.png","top_8.png","top_9.png","top_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 167,
                  y: 49,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 23,
                  src: 'top_name_STEPS.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 153,
                //   y: -8,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 0,
                  image_array: ["top_1.png","top_2.png","top_3.png","top_4.png","top_5.png","top_6.png","top_7.png","top_8.png","top_9.png","top_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 179,
                  y: 49,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 23,
                  src: 'top_name_CALORIES.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 153,
                //   y: -8,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'SportListScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 132,
                  y: 49,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'medium_digits_km.png',
                  unit_tc: 'medium_digits_km.png',
                  unit_en: 'medium_digits_km.png',
                  imperial_unit_sc: 'medium_digits_ml.png',
                  imperial_unit_tc: 'medium_digits_ml.png',
                  imperial_unit_en: 'medium_digits_ml.png',
                  dot_image: 'medium_digits_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 23,
                  src: 'top_name_DISTANCE.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 153,
                //   y: -8,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 153,
              y: 363,
              w: 148,
              h: 99,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
              ],
              count: 4,
              tips_BG: 'bg_tips.png',
              tips_x: 8,
              tips_y: -52,
              tips_width: 132,
              tips_margin: 5,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 363,
                  image_array: ["bottom_1.png","bottom_2.png","bottom_3.png","bottom_4.png","bottom_5.png","bottom_6.png","bottom_7.png","bottom_8.png","bottom_9.png","bottom_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 180,
                  y: 375,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'medium_digits_percent.png',
                  unit_tc: 'medium_digits_percent.png',
                  unit_en: 'medium_digits_percent.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 415,
                  src: 'top_name_BATTERY.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 153,
                //   y: 363,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 363,
                  image_array: ["bottom_1.png","bottom_2.png","bottom_3.png","bottom_4.png","bottom_5.png","bottom_6.png","bottom_7.png","bottom_8.png","bottom_9.png","bottom_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 167,
                  y: 375,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 415,
                  src: 'top_name_STEPS.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 153,
                //   y: 363,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 0,
                  y: 363,
                  image_array: ["bottom_1.png","bottom_2.png","bottom_3.png","bottom_4.png","bottom_5.png","bottom_6.png","bottom_7.png","bottom_8.png","bottom_9.png","bottom_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 179,
                  y: 375,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 415,
                  src: 'top_name_CALORIES.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 153,
                //   y: 363,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'SportListScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 132,
                  y: 375,
                  font_array: ["medium_digits_0.png","medium_digits_1.png","medium_digits_2.png","medium_digits_3.png","medium_digits_4.png","medium_digits_5.png","medium_digits_6.png","medium_digits_7.png","medium_digits_8.png","medium_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'medium_digits_km.png',
                  unit_tc: 'medium_digits_km.png',
                  unit_en: 'medium_digits_km.png',
                  imperial_unit_sc: 'medium_digits_ml.png',
                  imperial_unit_tc: 'medium_digits_ml.png',
                  imperial_unit_en: 'medium_digits_ml.png',
                  dot_image: 'medium_digits_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 169,
                  y: 415,
                  src: 'top_name_DISTANCE.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 153,
                //   y: 363,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: -57,
              y: 253,
              w: 148,
              h: 99,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(3)_BATTERY.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(3)_DISTANCE.png' },
                { type: hmUI.edit_type.DATE, preview: 'ez(3)_DATE.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI.png' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(3)_SPO2.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(3)_UVI.png' },
              ],
              count: 7,
              tips_BG: 'bg_tips.png',
              tips_x: 164,
              tips_y: 29,
              tips_width: 132,
              tips_margin: 5,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 36,
                  day_startY: 299,
                  day_sc_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_tc_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_en_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_zero: 1,
                  day_space: 0,
                  day_align: hmUI.align.LEFT,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_DATE.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_BAT..png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 18,
                  y: 300,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'small_digits_percent.png',
                  unit_tc: 'small_digits_percent.png',
                  unit_en: 'small_digits_percent.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 26,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_HR.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.HEART,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_PAI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 26,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.PAI_WEEKLY,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 15,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'small_digits_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_DIST..png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 26,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 13,
                  y: 270,
                  src: 'name_SpO2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.SPO2,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 15,
                  y: 270,
                  src: 'name_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 36,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: -57,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.WEATHER_CURRENT,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 364,
              y: 253,
              w: 148,
              h: 99,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.DATE,
              optional_types: [
                { type: hmUI.edit_type.DATE, preview: 'ez(4)_DATE.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(4)_HEART.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(4)_BATTERY.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(4)_DISTANCE.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(4)_PAI.png' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(4)_SPO2.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(4)_UVI.png' },
              ],
              count: 7,
              tips_BG: 'bg_tips.png',
              tips_x: -149,
              tips_y: 29,
              tips_width: 132,
              tips_margin: 5,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.IMG_DATE, {
                  day_startX: 382,
                  day_startY: 299,
                  day_sc_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_tc_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_en_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  day_zero: 1,
                  day_space: 0,
                  day_align: hmUI.align.CENTER_H,
                  day_is_character: false,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'name_DATE.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'name_BAT..png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 365,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'small_digits_percent.png',
                  unit_tc: 'small_digits_percent.png',
                  unit_en: 'small_digits_percent.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                // hmUI.createWidget(hmUI.widget.BUTTON, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   text: '',
                //   normal_src: 'transparent_img.png',
                //   press_src: 'transparent_img.png',
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                //   click_func: () => {
                //     hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                //   }
                // });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'name_HR.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.HEART,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'name_PAI.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.PAI_WEEKLY,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 361,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'small_digits_point.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 270,
                  src: 'name_DIST..png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.STEP,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 270,
                  src: 'name_SpO2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.SPO2,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case hmUI.edit_type.UVI:
                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'name_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 382,
                  y: 299,
                  font_array: ["small_digits_0.png","small_digits_1.png","small_digits_2.png","small_digits_3.png","small_digits_4.png","small_digits_5.png","small_digits_6.png","small_digits_7.png","small_digits_8.png","small_digits_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                
                // hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                //   x: 364,
                //   y: 253,
                //   w: 148,
                //   h: 99,
                //   src: 'transparent_img.png',
                //   type: hmUI.data_type.WEATHER_CURRENT,
                //   show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;
            }; // end switch

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'external_glow.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 245,
              w: 132,
              h: 78,
              src: 'transparent_img.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 134,
              w: 132,
              h: 78,
              src: 'transparent_img.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 153,
                  y: -8,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                  }
                });

               
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 153,
                  y: -8,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 153,
                  y: -8,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'SportListScreen', native: true })
                  }
                });

                
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 153,
                  y: -8,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                
                break;
            }; // end switch

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 153,
                  y: 363,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                  }
                });

                
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 153,
                  y: 363,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

               
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 153,
                  y: 363,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'SportListScreen', native: true })
                  }
                });
              
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 153,
                  y: 363,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                
                break;
            }; // end switch

            switch (editType_3) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
                  }
                });

             
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                  }
                });

             
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
              
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
               
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: -57,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
                
                break;
            }; // end switch

            switch (editType_4) {
              case hmUI.edit_type.DATE:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
                  }
                });

               
                break;

              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  text: '',
                  normal_src: 'transparent_img.png',
                  press_src: 'transparent_img.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  click_func: () => {
                    hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
                  }
                });

                
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
               
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.PAI_WEEKLY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
              
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
              
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
              
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                  x: 364,
                  y: 253,
                  w: 148,
                  h: 99,
                  src: 'transparent_img.png',
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                
               
                break;
            }; // end switch


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  