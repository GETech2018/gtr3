try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
    //-----01此处添加下列代码 代码块 开始位置 ------

    let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 1000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 200,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 454,/*屏幕宽度  3p 480*/
          h: 454,/*屏幕宽度  3p 480*/
          pos_x: 454 / 2 - 14,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 454 / 2 - 225,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 227, /*表盘旋转中心 3p 240*/
          center_y: 227,/*表盘旋转中心 3p 240*/
          src: '80.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
     
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘

          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          easeInAnim();
          easeInAnim();
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------ 
 const n = e.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__);
        let t = "",
            p = "",
            _ = "",
            h = "",
            a = "",
            i = "",
            o = "",
            r = "",
            l = "",
            m = "",
            s = "";
        const I = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                function e(e) {
                    return "INVALID" === e
                }
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 89,
                    y: 202,
                    type: hmUI.data_type.STEP,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 207,
                    y: 276,
                    image_array: ["13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 202,
                    y: 332,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "54.png",
                    unit_tc: "54.png",
                    unit_en: "54.png",
                    negative_image: "53.png",
                    invalid_image: "52.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 89,
                    y: 226,
                    type: hmUI.data_type.DISTANCE,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -3,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "56.png",
                    unit_tc: "56.png",
                    unit_en: "56.png",
                    imperial_unit_sc: "57.png",
                    imperial_unit_tc: "57.png",
                    imperial_unit_en: "57.png",
                    dot_image: "55.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 350,
                    day_startY: 214,
                    day_sc_array: ["58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png", "67.png"],
                    day_tc_array: ["58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png", "67.png"],
                    day_en_array: ["58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png", "65.png", "66.png", "67.png"],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: -18,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), t = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 201,
                    y: 142,
                    w: 50,
                    h: 25,
                    text: "[HR]",
                    color: "0xFFd0ccc6",
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), p = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 191,
                    y: 96,
                    w: 70,
                    h: 40,
                    text: "心率",
                    color: "0xFFd3cfcf",
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 310,
                    y: 214,
                    week_en: ["68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png"],
                    week_tc: ["68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png"],
                    week_sc: ["68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), _ = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 379,
                    y: 182,
                    w: 63,
                    h: 25,
                    text: "",
                    color: "0xFFa6a8a8",
                    text_size: 17,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), h = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 303,
                    y: 182,
                    w: 80,
                    h: 25,
                    text: "",
                    color: "0xFFa6a8a8",
                    text_size: 18,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), a = hmSensor.createSensor(hmSensor.id.TIME), m = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 299,
                    y: 248,
                    w: 40,
                    h: 20,
                    text: "气压",
                    color: "0xFFa6a8a8",
                    text_size: 17,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 143,
                    y: 201,
                    src: "75.png",
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 341,
                    y: 249,
                    type: hmUI.data_type.ALTIMETER,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "77.png",
                    unit_tc: "77.png",
                    unit_en: "77.png",
                    invalid_image: "76.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 14,
                    hour_posY: 206,
                    hour_path: "78.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 13,
                    minute_posY: 206,
                    minute_path: "79.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 1001,
                    second_posY: 1001,
                    second_path: "80.png",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 
				    setSec()
				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "81.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 204,
                    y: 350,
                    type: hmUI.data_type.STEP,
                    font_array: ["82.png", "83.png", "84.png", "85.png", "86.png", "87.png", "88.png", "89.png", "90.png", "91.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 15,
                    hour_posY: 227,
                    hour_path: "92.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 15,
                    minute_posY: 227,
                    minute_path: "93.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), s || (s = hmSensor.createSensor(hmSensor.id.HEART)), s.addEventListener(s.event.LAST, (function () {
                    t.setProperty(hmUI.prop.MORE, {
                        text: `${s.last}`
                    })
                })), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        t.setProperty(hmUI.prop.MORE, {
                            text: `${s.last}`
                        }), p.setProperty(hmUI.prop.MORE, {
                            text: "心率"
                        }), o = a.lunar_month, r = a.lunar_day, l = a.getShowFestival(), l = e(l) ? "" : l, e(o) || (o.indexOf("闰") > -1 ? i = o : e(r) || (i = o + r)), h.setProperty(hmUI.prop.MORE, {
                            text: i
                        }), _.setProperty(hmUI.prop.MORE, {
                            text: l
                        }), m.setProperty(hmUI.prop.MORE, {
                            text: "气压"
                        })
                    }
                })
            }, onInit() {
                I.log("index page.js on init invoke")
            }, build() {
                this.init_view(), I.log("index page.js on ready invoke")
            }, onDestroy() {
                I.log("index page.js on destroy invoke")
            stopSecAnim()
			}
        })
    })()
} catch (e) {
    console.log(e)
}