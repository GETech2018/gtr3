﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_month_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_pai_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_stand_icon_img = ''
        let idle_background_bg = ''
        let idle_stress_icon_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_pai_icon_img = ''
        let idle_temperature_current_text_img = ''
        let idle_temperature_current_separator_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_stand_current_text_img = ''
        let idle_stand_current_separator_img = ''
        let idle_stand_icon_img = ''
        let idle_calorie_icon_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -75,
              y: -3,
              src: 'backgrou55.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 188,
              src: 'icon-batt-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 178,
              font_array: ["Med_Kazmann_16_dark_0001.png","Med_Kazmann_16_dark_0002.png","Med_Kazmann_16_dark_0003.png","Med_Kazmann_16_dark_0004.png","Med_Kazmann_16_dark_0005.png","Med_Kazmann_16_dark_0006.png","Med_Kazmann_16_dark_0007.png","Med_Kazmann_16_dark_0008.png","Med_Kazmann_16_dark_0009.png","Med_Kazmann_16_dark_0010.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 229,
              src: 'icon-batt-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 47,
              am_y: 296,
              am_sc_path: 'slender_zam.png',
              am_en_path: 'slender_zam.png',
              pm_x: 47,
              pm_y: 296,
              pm_sc_path: 'slender_zpm.png',
              pm_en_path: 'slender_zpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 117,
              hour_array: ["Kazmann_32_green_0001.png","Kazmann_32_green_0002.png","Kazmann_32_green_0003.png","Kazmann_32_green_0004.png","Kazmann_32_green_0005.png","Kazmann_32_green_0006.png","Kazmann_32_green_0007.png","Kazmann_32_green_0008.png","Kazmann_32_green_0009.png","Kazmann_32_green_0010.png"],
              hour_zero: 1,
              hour_space: -178,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 20,
              minute_startY: 223,
              minute_array: ["Kazmann_32_grey_0001.png","Kazmann_32_grey_0002.png","Kazmann_32_grey_0003.png","Kazmann_32_grey_0004.png","Kazmann_32_grey_0005.png","Kazmann_32_grey_0006.png","Kazmann_32_grey_0007.png","Kazmann_32_grey_0008.png","Kazmann_32_grey_0009.png","Kazmann_32_grey_0010.png"],
              minute_zero: 1,
              minute_space: -178,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 64,
              second_startY: 239,
              second_array: ["tiny_Slender_32_grey_0001.png","tiny_Slender_32_grey_0002.png","tiny_Slender_32_grey_0003.png","tiny_Slender_32_grey_0004.png","tiny_Slender_32_grey_0005.png","tiny_Slender_32_grey_0006.png","tiny_Slender_32_grey_0007.png","tiny_Slender_32_grey_0008.png","tiny_Slender_32_grey_0009.png","tiny_Slender_32_grey_0010.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 71,
              month_startY: 85,
              month_sc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_tc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_en_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 345,
              font_array: ["tiny_Slender_4_amber_0001.png","tiny_Slender_4_amber_0002.png","tiny_Slender_4_amber_0003.png","tiny_Slender_4_amber_0004.png","tiny_Slender_4_amber_0005.png","tiny_Slender_4_amber_0006.png","tiny_Slender_4_amber_0007.png","tiny_Slender_4_amber_0008.png","tiny_Slender_4_amber_0009.png","tiny_Slender_4_amber_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot_Picture_167.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 365,
              src: 'icon-steps-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 81,
              y: 15,
              src: 'icon_logo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 75,
              font_array: ["Ttiny_Slender_12_blue_0001.png","Ttiny_Slender_12_blue_0002.png","Ttiny_Slender_12_blue_0003.png","Ttiny_Slender_12_blue_0004.png","Ttiny_Slender_12_blue_0005.png","Ttiny_Slender_12_blue_0006.png","Ttiny_Slender_12_blue_0007.png","Ttiny_Slender_12_blue_0008.png","Ttiny_Slender_12_blue_0009.png","Ttiny_Slender_12_blue_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              negative_image: 'icon_weather_0.png',
              invalid_image: 'icon_weather_0.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 371,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 95,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 382,
              y: 188,
              src: 'icon-heart-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 179,
              font_array: ["Med_Kazmann_16_dark_0001.png","Med_Kazmann_16_dark_0002.png","Med_Kazmann_16_dark_0003.png","Med_Kazmann_16_dark_0004.png","Med_Kazmann_16_dark_0005.png","Med_Kazmann_16_dark_0006.png","Med_Kazmann_16_dark_0007.png","Med_Kazmann_16_dark_0008.png","Med_Kazmann_16_dark_0009.png","Med_Kazmann_16_dark_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 224,
              src: 'icon-heart-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 293,
              src: 'icon-acti-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 295,
              font_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 327,
              src: 'stepp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 127,
              week_en: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_tc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_sc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 158,
              day_startY: 79,
              day_sc_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_tc_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_en_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 380,
              y: 270,
              src: 'icon_stand_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 275,
              font_array: ["tiny_Slender_4_amber_0001.png","tiny_Slender_4_amber_0002.png","tiny_Slender_4_amber_0003.png","tiny_Slender_4_amber_0004.png","tiny_Slender_4_amber_0005.png","tiny_Slender_4_amber_0006.png","tiny_Slender_4_amber_0007.png","tiny_Slender_4_amber_0008.png","tiny_Slender_4_amber_0009.png","tiny_Slender_4_amber_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 302,
              src: 'icon_stand_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: -47,
              src: 'Picture2-Ring2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -75,
              y: -3,
              src: 'backgrou55 (2).png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 188,
              src: 'icon-batt-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 174,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 229,
              src: 'icon-batt-1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 71,
              month_startY: 85,
              month_sc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_tc_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_en_array: ["month_Slender_32_amber_0001.png","month_Slender_32_amber_0002.png","month_Slender_32_amber_0003.png","month_Slender_32_amber_0004.png","month_Slender_32_amber_0005.png","month_Slender_32_amber_0006.png","month_Slender_32_amber_0007.png","month_Slender_32_amber_0008.png","month_Slender_32_amber_0009.png","month_Slender_32_amber_0010.png","month_Slender_32_amber_0011.png","month_Slender_32_amber_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 345,
              font_array: ["tiny_Slender_4_amber_0001.png","tiny_Slender_4_amber_0002.png","tiny_Slender_4_amber_0003.png","tiny_Slender_4_amber_0004.png","tiny_Slender_4_amber_0005.png","tiny_Slender_4_amber_0006.png","tiny_Slender_4_amber_0007.png","tiny_Slender_4_amber_0008.png","tiny_Slender_4_amber_0009.png","tiny_Slender_4_amber_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              dot_image: 'dot_Picture_167.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 365,
              src: 'icon-steps-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 81,
              y: 15,
              src: 'icon_logo.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 83,
              font_array: ["Ttiny_Slender_12_blue_0001.png","Ttiny_Slender_12_blue_0002.png","Ttiny_Slender_12_blue_0003.png","Ttiny_Slender_12_blue_0004.png","Ttiny_Slender_12_blue_0005.png","Ttiny_Slender_12_blue_0006.png","Ttiny_Slender_12_blue_0007.png","Ttiny_Slender_12_blue_0008.png","Ttiny_Slender_12_blue_0009.png","Ttiny_Slender_12_blue_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              negative_image: 'icon_weather_0.png',
              invalid_image: 'icon_weather_0.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 371,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 102,
              image_array: ["w072.png","w073.png","w074.png","w075.png","w076.png","w077.png","w078.png","w079.png","w080.png","w081.png","w082.png","w083.png","w084.png","w085.png","w086.png","w087.png","w088.png","w089.png","w090.png","w091.png","w092.png","w093.png","w094.png","w095.png","w096.png","w097.png","w098.png","w099.png","w100.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 382,
              y: 188,
              src: 'icon-heart-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 387,
              y: 171,
              font_array: ["med_Slender_16_white_0001.png","med_Slender_16_white_0002.png","med_Slender_16_white_0003.png","med_Slender_16_white_0004.png","med_Slender_16_white_0005.png","med_Slender_16_white_0006.png","med_Slender_16_white_0007.png","med_Slender_16_white_0008.png","med_Slender_16_white_0009.png","med_Slender_16_white_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 224,
              src: 'icon-heart-1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 293,
              src: 'icon-acti-0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 295,
              font_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 327,
              src: 'stepp.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 127,
              week_en: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_tc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              week_sc: ["day_Slender_4_grey_0001.png","day_Slender_4_grey_0002.png","day_Slender_4_grey_0003.png","day_Slender_4_grey_0004.png","day_Slender_4_grey_0005.png","day_Slender_4_grey_0006.png","day_Slender_4_grey_0007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 158,
              day_startY: 79,
              day_sc_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_tc_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_en_array: ["Nmed_Slender_12_dark_0001.png","Nmed_Slender_12_dark_0002.png","Nmed_Slender_12_dark_0003.png","Nmed_Slender_12_dark_0004.png","Nmed_Slender_12_dark_0005.png","Nmed_Slender_12_dark_0006.png","Nmed_Slender_12_dark_0007.png","Nmed_Slender_12_dark_0008.png","Nmed_Slender_12_dark_0009.png","Nmed_Slender_12_dark_0010.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 380,
              y: 270,
              src: 'icon_stand_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 352,
              y: 275,
              font_array: ["tiny_Slender_4_amber_0001.png","tiny_Slender_4_amber_0002.png","tiny_Slender_4_amber_0003.png","tiny_Slender_4_amber_0004.png","tiny_Slender_4_amber_0005.png","tiny_Slender_4_amber_0006.png","tiny_Slender_4_amber_0007.png","tiny_Slender_4_amber_0008.png","tiny_Slender_4_amber_0009.png","tiny_Slender_4_amber_0010.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 302,
              src: 'icon_stand_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -47,
              y: -47,
              src: 'Picture2-Ring2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -47,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 47,
              am_y: 296,
              am_sc_path: 'slender_zam.png',
              am_en_path: 'slender_zam.png',
              pm_x: 47,
              pm_y: 296,
              pm_sc_path: 'slender_zpm.png',
              pm_en_path: 'slender_zpm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 117,
              hour_array: ["aob_aob_Slender_32_amber_0001.png","aob_aob_Slender_32_amber_0002.png","aob_aob_Slender_32_amber_0003.png","aob_aob_Slender_32_amber_0004.png","aob_aob_Slender_32_amber_0005.png","aob_aob_Slender_32_amber_0006.png","aob_aob_Slender_32_amber_0007.png","aob_aob_Slender_32_amber_0008.png","aob_aob_Slender_32_amber_0009.png","aob_aob_Slender_32_amber_0010.png"],
              hour_zero: 1,
              hour_space: -178,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 20,
              minute_startY: 223,
              minute_array: ["aob_aob_Slender_32_amber_0001.png","aob_aob_Slender_32_amber_0002.png","aob_aob_Slender_32_amber_0003.png","aob_aob_Slender_32_amber_0004.png","aob_aob_Slender_32_amber_0005.png","aob_aob_Slender_32_amber_0006.png","aob_aob_Slender_32_amber_0007.png","aob_aob_Slender_32_amber_0008.png","aob_aob_Slender_32_amber_0009.png","aob_aob_Slender_32_amber_0010.png"],
              minute_zero: 1,
              minute_space: -178,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 61,
              second_startY: 228,
              second_array: ["Nmed_Slender_16_white_0001.png","Nmed_Slender_16_white_0002.png","Nmed_Slender_16_white_0003.png","Nmed_Slender_16_white_0004.png","Nmed_Slender_16_white_0005.png","Nmed_Slender_16_white_0006.png","Nmed_Slender_16_white_0007.png","Nmed_Slender_16_white_0008.png","Nmed_Slender_16_white_0009.png","Nmed_Slender_16_white_0010.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}