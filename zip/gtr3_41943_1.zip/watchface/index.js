﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start


    console.log('user_functions.js');
    // start user_functions.js

    // INCIO DE FUNCION PERSONALIZADO

    ///NUEVA FUNCION
    let elementdate_1 = 1;
    const total_elemente = 5;

    // Función principal para manejar clicks
    function cambio_manecillas() {
      // Incrementar contador
      if (elementdate_1 === total_elemente) {
        elementdate_1 = 1;
      } else {
        elementdate_1 = elementdate_1 + 1;
      }

      // Actualizar visibilidad basada en el contador
      updateVisibility(elementdate_1);
    }

    // Función centralizada para actualizar visibilidad
    function updateVisibility(elementNumber) {
      // Arrays con todas las referencias a elementos
      const minElements = [
        normal_analog_clock_time_pointer_minute,
        normal_analog_clock_time_pointer_minute_2,
        normal_analog_clock_time_pointer_minute_3,
        normal_analog_clock_time_pointer_minute_4,
        normal_analog_clock_time_pointer_minute_5,
      ];

      const hourElements = [
        normal_analog_clock_time_pointer_hour,
        normal_analog_clock_time_pointer_hour_2,
        normal_analog_clock_time_pointer_hour_3,
        normal_analog_clock_time_pointer_hour_4,
        normal_analog_clock_time_pointer_hour_5,
      ];

      // ACTIVAR VISIBLE = TRU O FALSE
      // Actualizar elementos de calorías
      minElements.forEach((element, index) => {
        if (element) {
          element.setProperty(hmUI.prop.VISIBLE, index === elementNumber - 1);
        }
      });

      // Actualizar elementos de ritmo cardíaco
      hourElements.forEach((element, index) => {
        if (element) {
          element.setProperty(hmUI.prop.VISIBLE, index === elementNumber - 1);
        }
      });
    }

    // AGREGAR VARIABLES
    let normal_analog_clock_time_pointer_minute_2
    let normal_analog_clock_time_pointer_minute_3
    let normal_analog_clock_time_pointer_minute_4
    let normal_analog_clock_time_pointer_minute_5

    let normal_analog_clock_time_pointer_hour_2 = ''
    let normal_analog_clock_time_pointer_hour_3 = ''
    let normal_analog_clock_time_pointer_hour_4 = ''
    let normal_analog_clock_time_pointer_hour_5 = ''


    // end user_functions.js

    let normal_background_bg = ''
    let normal_image_img = ''
    let normal_temperature_current_text_img = ''
    let normal_date_img_date_week_img = ''
    let normal_date_img_date_month_img = ''
    let normal_date_img_date_day = ''
    let normal_battery_text_text_img = ''
    let normal_step_current_text_img = ''
    let normal_heart_rate_text_text_img = ''
    let normal_digital_clock_img_time_AmPm = ''
    let normal_digital_clock_img_time = ''
    let normal_analog_clock_time_pointer_hour = ''
    let normal_analog_clock_time_pointer_minute = ''
    let normal_analog_clock_time_pointer_second = ''
    let idle_background_bg = ''
    let idle_analog_clock_time_pointer_hour = ''
    let idle_analog_clock_time_pointer_minute = ''
    let Button_1 = ''
    let Button_2 = ''
    let Button_3 = ''
    let Button_4 = ''
    let Button_Switch_BG_Color = ''

    let bgColorIndex = 0;
    let bgColorList = [0xFF40B67A, 0xFFC0C0C0, 0xFFFC7701, 0xFFC8DCAB, 0xFF13F18E];
    let bgColorToastList = ['Color1 %s', 'Color2 %s', 'Color3 %s', 'Color4 %s', 'Color5 %s'];
    const watchfaceId = hmApp.packageInfo().watchfaceId;


    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start


        //start of ignored block
        console.log('SwitchBG_Color');
        function switchBG_Color() {
          bgColorIndex++;
          if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
          hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
          let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
          if (toastText.length > 0) hmUI.showToast({ text: toastText });
          normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
          cambio_manecillas();
        };
        //end of ignored block

        console.log('Watch_Face.ScreenNormal');
        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          color: '0xFF40B67A',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('user_script.js');


        normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'bg_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 285,
          y: 76,
          font_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          padding: false,
          h_space: -3,
          unit_sc: 'icon_1.png',
          unit_tc: 'icon_1.png',
          unit_en: 'icon_1.png',
          negative_image: 'icon_2.png',
          invalid_image: 'icon_2.png',
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 34,
          y: 236,
          week_en: ["dia_1.png", "dia_2.png", "dia_3.png", "dia_4.png", "dia_5.png", "dia_6.png", "dia_7.png"],
          week_tc: ["dia_1.png", "dia_2.png", "dia_3.png", "dia_4.png", "dia_5.png", "dia_6.png", "dia_7.png"],
          week_sc: ["dia_1.png", "dia_2.png", "dia_3.png", "dia_4.png", "dia_5.png", "dia_6.png", "dia_7.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 110,
          month_startY: 259,
          month_sc_array: ["mes_1.png", "mes_2.png", "mes_3.png", "mes_4.png", "mes_5.png", "mes_6.png", "mes_7.png", "mes_8.png", "mes_9.png", "mes_10.png", "mes_11.png", "mes_12.png"],
          month_tc_array: ["mes_1.png", "mes_2.png", "mes_3.png", "mes_4.png", "mes_5.png", "mes_6.png", "mes_7.png", "mes_8.png", "mes_9.png", "mes_10.png", "mes_11.png", "mes_12.png"],
          month_en_array: ["mes_1.png", "mes_2.png", "mes_3.png", "mes_4.png", "mes_5.png", "mes_6.png", "mes_7.png", "mes_8.png", "mes_9.png", "mes_10.png", "mes_11.png", "mes_12.png"],
          month_is_character: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          day_startX: 53,
          day_startY: 261,
          day_sc_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          day_tc_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          day_en_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          day_zero: 1,
          day_space: -2,
          day_align: hmUI.align.CENTER_H,
          day_is_character: false,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 120,
          y: 349,
          font_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          padding: false,
          h_space: -2,
          unit_sc: 'icon_3.png',
          unit_tc: 'icon_3.png',
          unit_en: 'icon_3.png',
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 94,
          y: 304,
          font_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          padding: false,
          h_space: -2,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
          x: 143,
          y: 395,
          font_array: ["numSS_0.png", "numSS_1.png", "numSS_2.png", "numSS_3.png", "numSS_4.png", "numSS_5.png", "numSS_6.png", "numSS_7.png", "numSS_8.png", "numSS_9.png"],
          padding: false,
          h_space: -3,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.HEART,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          am_x: 300,
          am_y: 46,
          am_sc_path: 'icon_4.png',
          am_en_path: 'icon_4.png',
          pm_x: 300,
          pm_y: 46,
          pm_sc_path: 'icon_5.png',
          pm_en_path: 'icon_5.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
          hour_startX: 83,
          hour_startY: 67,
          hour_array: ["numH_0.png", "numH_1.png", "numH_2.png", "numH_3.png", "numH_4.png", "numH_5.png", "numH_6.png", "numH_7.png", "numH_8.png", "numH_9.png"],
          hour_zero: 1,
          hour_space: -2,
          hour_angle: 0,
          hour_align: hmUI.align.CENTER_H,

          minute_startX: 83,
          minute_startY: 137,
          minute_array: ["numMI_0.png", "numMI_1.png", "numMI_2.png", "numMI_3.png", "numMI_4.png", "numMI_5.png", "numMI_6.png", "numMI_7.png", "numMI_8.png", "numMI_9.png"],
          minute_zero: 1,
          minute_space: -2,
          minute_angle: 0,
          minute_follow: 0,
          minute_align: hmUI.align.CENTER_H,

          second_startX: 267,
          second_startY: 269,
          second_array: ["numSEG_0.png", "numSEG_1.png", "numSEG_2.png", "numSEG_3.png", "numSEG_4.png", "numSEG_5.png", "numSEG_6.png", "numSEG_7.png", "numSEG_8.png", "numSEG_9.png"],
          second_zero: 1,
          second_space: -13,
          second_angle: 0,
          second_follow: 0,
          second_align: hmUI.align.CENTER_H,

          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_01.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // start user_script.js
        // // 222 ENTRA DESPUES DEL PRIMER hmUI.createWidget
        normal_analog_clock_time_pointer_hour_2 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_02.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_hour_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_hour_3 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_03.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_hour_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_hour_4 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_04.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_hour_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_hour_5 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_05.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_hour_5.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_01.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //=============
        normal_analog_clock_time_pointer_minute_2 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_02.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_minute_2.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_minute_3 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_03.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_minute_3.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_minute_4 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_04.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_minute_4.setProperty(hmUI.prop.VISIBLE, false);

        normal_analog_clock_time_pointer_minute_5 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_05.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        normal_analog_clock_time_pointer_minute_5.setProperty(hmUI.prop.VISIBLE, false);
        // end user_script.js

        normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'ana_seg.png',
          second_centerX: 227,
          second_centerY: 227,
          second_posX: 32,
          second_posY: 227,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('Watch_Face.ScreenAOD');
        idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0,
          y: 0,
          w: 454,
          h: 454,
          color: '0xFF000000',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hor_02.png',
          hour_centerX: 227,
          hour_centerY: 227,
          hour_posX: 32,
          hour_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'min_02.png',
          minute_centerX: 227,
          minute_centerY: 227,
          minute_posX: 32,
          minute_posY: 227,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        console.log('Watch_Face.Buttons');
        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 165,
          y: 394,
          w: 57,
          h: 40,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'transp.png',
          normal_src: 'transp.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'heart_app_Screen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 112,
          y: 299,
          w: 57,
          h: 40,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'transp.png',
          normal_src: 'transp.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'activityAppScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 73,
          y: 238,
          w: 57,
          h: 50,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'transp.png',
          normal_src: 'transp.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 285,
          y: 70,
          w: 57,
          h: 50,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'transp.png',
          normal_src: 'transp.png',
          click_func: (button_widget) => {
            hmApp.startApp({ url: 'WeatherScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        console.log('Watch_Face.SwitchBG_Color');
        // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
        // x: 268,
        // y: 389,
        // w: 60,
        // h: 60,
        // text: '',
        // color: 0xFFFF8C00,
        // text_size: 25,
        // press_src: 'transp.png',
        // normal_src: 'transp.png',
        // color_list: 0xFF40B67A|0xFFC0C0C0|0xFFFC7701|0xFFC8DCAB|0xFF13F18E,
        // toast_list: Color1 %s|Color2 %s|Color3 %s|Color4 %s|Color5 %s,
        // use_crown: False,
        // use_in_AOD: False,
        // vibro: False,
        // });

        Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 268,
          y: 389,
          w: 60,
          h: 60,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'transp.png',
          normal_src: 'transp.png',
          click_func: (button_widget) => {
            switchBG_Color();
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        let screenType = hmSetting.getScreenType();
        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');

            //SwitchBgColor
            if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
              bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
            } else {
              bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
            };
            if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
          }),
        });

        //dynamic modify end
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}