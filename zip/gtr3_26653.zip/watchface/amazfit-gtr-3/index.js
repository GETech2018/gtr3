try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
     //-----01此处添加下列代码 代码块 开始位置 ------

    let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 1000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 200,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 454,/*屏幕宽度  3p 480*/
          h: 454,/*屏幕宽度  3p 480*/
          pos_x: 454 / 2 - 33,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 454 / 2 - 227,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 227, /*表盘旋转中心 3p 240*/
          center_y: 227,/*表盘旋转中心 3p 240*/
          src: '90.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
     
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘

          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          easeInAnim();
          easeInAnim();
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------       
		const e = n.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, e)), n.app.__globals__);
        let p = "",
            _ = "",
            t = "",
            a = "",
            h = "";
        const r = Logger.getLogger("watchface6");
        e.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                function n(n) {
                    return "INVALID" === n
                }
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_mgokh",
                    anim_ext: "png",
                    anim_fps: 16,
                    anim_size: 25,
                    display_on_restart: !1,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: "3.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 203,
                    y: 129,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "16.png",
                    unit_tc: "16.png",
                    unit_en: "16.png",
                    negative_image: "15.png",
                    invalid_image: "14.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 200,
                    y: 61,
                    image_array: ["17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 290,
                    y: 144,
                    type: hmUI.data_type.PAI_WEEKLY,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 112,
                    y: 144,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 303,
                    y: 213,
                    week_sc: ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), p = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 299,
                    y: 180,
                    w: 80,
                    h: 30,
                    text: "",
                    color: "0xFFe7e5e5",
                    text_size: 19,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), _ = hmSensor.createSensor(hmSensor.id.TIME), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 319,
                    y: 249,
                    type: hmUI.data_type.STAND,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    dot_image: "53.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    year_startX: 76,
                    year_startY: 249,
                    year_sc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    year_tc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    year_en_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    year_align: hmUI.align.CENTER_H,
                    year_zero: 1,
                    year_space: 0,
                    year_is_character: !1,
                    month_startX: 70,
                    month_startY: 190,
                    month_sc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    month_tc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    month_en_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    month_align: hmUI.align.CENTER_H,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_startX: 119,
                    day_startY: 190,
                    day_sc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    day_tc_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    day_en_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 108,
                    y: 190,
                    w: 9,
                    h: 14,
                    src: "54.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 54,
                    hour_startY: 218,
                    hour_array: ["55.png", "56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png", "63.png", "64.png"],
                    hour_space: 0,
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 116,
                    minute_startY: 218,
                    minute_array: ["65.png", "66.png", "67.png", "68.png", "69.png", "70.png", "71.png", "72.png", "73.png", "74.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.CENTER_H,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 182,
                    y: 324,
                    type: hmUI.data_type.STEP,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 179,
                    y: 352,
                    type: hmUI.data_type.DISTANCE,
                    font_array: ["75.png", "76.png", "77.png", "78.png", "79.png", "80.png", "81.png", "82.png", "83.png", "84.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "86.png",
                    unit_tc: "86.png",
                    unit_en: "86.png",
                    dot_image: "85.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 112,
                    y: 290,
                    type: hmUI.data_type.HEART,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "87.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 281,
                    y: 291,
                    type: hmUI.data_type.CAL,
                    font_array: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 33,
                    hour_posY: 227,
                    hour_path: "88.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 33,
                    minute_posY: 227,
                    minute_path: "89.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 1001,
                    second_posY: 1001,
                    second_path: "90.png",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 
				    setSec()
				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "91.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 33,
                    hour_posY: 227,
                    hour_path: "88.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 33,
                    minute_posY: 227,
                    minute_path: "89.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        a = _.lunar_month, h = _.lunar_day, _.getShowFestival(), n(a) || (a.indexOf("闰") > -1 ? t = a : n(h) || (t = a + h)), p.setProperty(hmUI.prop.MORE, {
                            text: t
                        })
                    }
                })
            }, onInit() {
                r.log("index page.js on init invoke")
            }, build() {
                this.init_view(), r.log("index page.js on ready invoke")
            }, onDestory() {
                r.log("index page.js on destory invoke")
            stopSecAnim()
			}
        })
    })()
} catch (n) {
    console.log(n)
}