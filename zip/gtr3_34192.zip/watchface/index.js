﻿     /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
 
try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block


        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_image_progress_img_level = '' //Sky Change
        let normal_weather_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather2_image_progress_img_level = ''  //Night Weather Icon
        let normal_weather_text_sc_img_level = ''  //Night Weather Icon
        let normal_weather_text_tc_img_level = ''  //Night Weather Icon
        let normal_weather_text_en_img_level = ''  //Night Weather Icon
        let normal_masking_img = ''  //Changetable icon
        let normal_weather_languege_change_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_bg_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_paiw_image_progress_img_level = ''
        let normal_pai_weekly_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_stress_text_text_img = ''
        let normal_stress_icon_img = ''
        let normal_SLEEP_text_text_img = ''
        let normal_SLEEP_icon_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_training_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_masking_icon_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_system_disconnect_img = ''
		let con_rest = 'Connection Restored'  // text change
		let con_lost = 'Connection Lost'  // text change

        //dynamic modify end

//vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }


// Autocorrect night weather icons Start
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        let weather_icons = ["Weather-0.png","Weather-1.png","Weather-2.png","Weather-3.png","Weather-4.png","Weather-5.png","Weather-6.png","Weather-.png","Weather-8.png","Weather-9.png","Weather-10.png","Weather-11.png","Weather-.png","Weather-13.png","Weather-14.png","Weather-15.png","Weather-16.png","Weather-17.png","Weather-18.png","Weather-19.png","Weather-20.png","Weather-21.png","Weather-22.png","Weather-23.png","Weather-24.png","Weather-25.png","Weather-0n.png","Weather-1n.png","Weather-3n.png"]
        let weather2_icons = ["Weather2-0.png","Weather2-1.png","Weather2-2.png","Weather2-3.png","Weather2-4.png","Weather2-5.png","Weather2-6.png","Weather2-.png","Weather2-8.png","Weather2-9.png","Weather2-10.png","Weather2-11.png","Weather2-.png","Weather2-13.png","Weather2-14.png","Weather2-15.png","Weather2-16.png","Weather2-17.png","Weather2-18.png","Weather2-19.png","Weather2-20.png","Weather2-21.png","Weather2-22.png","Weather2-23.png","Weather2-24.png","Weather2-25.png","Weather2-0n.png","Weather2-1n.png","Weather2-3n.png"]
        let weather_text_sc	= ["Weather-sc-0.png","Weather-sc-1.png","Weather-sc-2.png","Weather-sc-3.png","Weather-sc-4.png","Weather-sc-5.png","Weather-sc-6.png","Weather-sc-.png","Weather-sc-8.png","Weather-sc-9.png","Weather-sc-10.png","Weather-sc-11.png","Weather-sc-.png","Weather-sc-13.png","Weather-sc-14.png","Weather-sc-15.png","Weather-sc-16.png","Weather-sc-17.png","Weather-sc-18.png","Weather-sc-19.png","Weather-sc-20.png","Weather-sc-21.png","Weather-sc-22.png","Weather-sc-23.png","Weather-sc-24.png","Weather-sc-25.png","Weather-sc-0n.png","Weather-sc-1n.png","Weather-sc-3n.png"]
        let weather_text_tc	= ["Weather-tc-0.png","Weather-tc-1.png","Weather-tc-2.png","Weather-tc-3.png","Weather-tc-4.png","Weather-tc-5.png","Weather-tc-6.png","Weather-tc-.png","Weather-tc-8.png","Weather-tc-9.png","Weather-tc-10.png","Weather-tc-11.png","Weather-tc-.png","Weather-tc-13.png","Weather-tc-14.png","Weather-tc-15.png","Weather-tc-16.png","Weather-tc-17.png","Weather-tc-18.png","Weather-tc-19.png","Weather-tc-20.png","Weather-tc-21.png","Weather-tc-22.png","Weather-tc-23.png","Weather-tc-24.png","Weather-tc-25.png","Weather-tc-0n.png","Weather-tc-1n.png","Weather-tc-3n.png"]
        let weather_text_en = ["Weather-en-0.png","Weather-en-1.png","Weather-en-2.png","Weather-en-3.png","Weather-en-4.png","Weather-en-5.png","Weather-en-6.png","Weather-en-.png","Weather-en-8.png","Weather-en-9.png","Weather-en-10.png","Weather-en-11.png","Weather-en-.png","Weather-en-13.png","Weather-en-14.png","Weather-en-15.png","Weather-en-16.png","Weather-en-17.png","Weather-en-18.png","Weather-en-19.png","Weather-en-20.png","Weather-en-21.png","Weather-en-22.png","Weather-en-23.png","Weather-en-24.png","Weather-en-25.png","Weather-en-0n.png","Weather-en-1n.png","Weather-en-3n.png"]
        
        let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
        let weatherData = weather.getForecastWeather();
        let forecastData = weatherData.forecastData;
        let sunData = weatherData.tideData;
        let today = '';
        let sunriseMins = '';
        let sunsetMins = '';
        let sunriseMins_def = 8 * 60;			// sunrise time
        let sunsetMins_def = 20 * 60;			//and default sunset
        
        let curMins = '';
        
        let isDayIcons = true;
        let wiReplacement = [0, 1, 2, 3];		// icon indexes for day-night replacement
        
        function autoToggleWeatherIcons() {
        
        weatherData = weather.getForecastWeather();
        sunData = weatherData.tideData;
        if (sunData.count > 0){
        today = sunData.data[0];
        sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
        sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
        } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
        }
        
        curMins = curTime.hour * 60 + curTime.minute;
        let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
        
        if(isDayNow){
        if(!isDayIcons) //Day Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_sc[wiReplacement[i]] = "Weather-sc-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_tc[wiReplacement[i]] = "Weather-tc-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + ".png";
          }
          isDayIcons = true;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG.png");
          }
          isDayIcons = true;}
		}
		else {
        if(isDayIcons) //Night Picture
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_icons[wiReplacement[i]] = "Weather-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather2_icons[wiReplacement[i]] = "Weather2-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_sc[wiReplacement[i]] = "Weather-sc-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_tc[wiReplacement[i]] = "Weather-tc-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{for (let i = 0; i < wiReplacement.length; i++) {
            weather_text_en[wiReplacement[i]] = "Weather-en-" + wiReplacement[i].toString() + "n.png";
          }
          isDayIcons = false;}
		{{
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG-n.png");
          }
          isDayIcons = false;}
		}
        }
        
// Autocorrect night weather icons End


// Lunar Data Start
    
	let dateText = null;
    let nongli = null;

    let zodiacs = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
    let Gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
    let Zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
    let weekday = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']

    let now = null
    let countDownTimer = null
    //用于计算农历年月日的数据
    let GY = 0
    let GM = 0
    let GD = 0

    let year = 0
    let month = 0
    let date = 0
    let hours = 0
    let minutes = 0
    let seconds = 0

    const calendar = {
      gregorianYear: null,          //公历年
      gregorianMonth: null,         //公历月
      gregorianDay: null,           //公历日
      weekday: null,                //星期
      hours: null,
      minutes: null,
      seconds: null,

      lunarYear: null,              //农历年
      lunarMonth: null,             //农历月
      lunarDay: null,               //农历日

      lunarYearCn: '',              //农历天干地支纪年
      lunarMonthCn: '',             //农历中文月
      lunarDayCn: '',               //农历中文日
      zodiacYear: '',               //农历生肖年

      solarTerm: '',                //节气
      gregorianFestival: '',        //公历节日
      lunarFestival: ''             //农历节日
    }

    let lunarInfo = [
      0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
      0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
      0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
      0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
      0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
      0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573, 0x052d0, 0x0a9a8, 0x0e950, 0x06aa0,
      0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
      0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6,
      0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
      0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0,
      0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
      0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
      0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
      0x05aa0, 0x076a3, 0x096d0, 0x04bd7, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
      0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0]

    /**
             * 阳历节日
             */
    let festival = {
      '1-1': { title: '元旦' },
      '2-2': { title: '世界湿地日' },
      '2-14': { title: '情人节' },
      '3-5': { title: '学雷锋纪念日' },
      '3-8': { title: '三八妇女节' },
      '3-12': { title: '植树节' },
      '3-14': { title: '白色情人节' },
      '3-15': { title: '消费者权益日' },
      '4-1': { title: '愚人节' },
      '4-22': { title: '地球日' },
      '5-1': { title: '国际劳动节' },
      '5-4': { title: '中国青年节' },
      '6-1': { title: '国际儿童节' },
      '7-1': { title: '建党节' },
      '8-1': { title: '建军节' },
      '8-19': { title: '中国医师节' },
      '9-3': { title: '抗日纪念日' },
      '9-10': { title: '教师节' },
      '9-30': { title: '烈士纪念日' },
      '10-1': { title: '中国国庆节' },
      '10-31': { title: '万圣前夜' },
      '11-1': { title: '万圣节' },
      '11-8': { title: '中国记者日' },
      '11-9': { title: '消防宣传日' },
      '11-11': { title: '光棍日' },
      '12-13': { title: '国家公祭日' },
      '12-20': { title: '澳门回归' },
      '12-24': { title: '平安夜' },
      '12-25': { title: '圣诞节' }
    }

    /**
    * 农历节日
    */
    let lfestival = {
      //'12-30': { title: '除夕' },
      '1-1': { title: '春节' },
      '1-15': { title: '元宵节' },
      '2-2': { title: '龙抬头' },
      '5-5': { title: '端午节' },
      '7-7': { title: '七夕情人节' },
      '7-15': { title: '中元节' },
      '8-15': { title: '中秋节' },
      '9-9': { title: '重阳节' },
      '12-8': { title: '腊八节' },
      '12-23': { title: '北方小年' },
      '12-24': { title: '南方小年' }
    }
	
    //母亲节和父亲节、感恩节
    function getMotherOrFatherDay(year, month, day) {
      if (month != 5 && month != 6 && month != 11) return null;
      if ((month == 5 && (day < 8 || day > 14)) || (month == 6 && (day < 15 || day > 21)) || (month == 11 && (day < 22 || day > 28))) return null;
      var d = new Date(year, month - 1, 1, 1, 1, 1, 0)
      var weekDate = (d.getDay() == 0 ? 7 : d.getDay()) - 1;

      switch (month) {
        case 5:
          weekDate = 7 - weekDate;
          if (day == 7 + weekDate) {
            return "母亲节";
          }
          break;
        case 6:
          weekDate = 7 - weekDate;
          if (day == 14 + weekDate) {
            return "父亲节";
          }
          break;
        case 11:
          weekDate = weekDate >= 4 ? (11 - weekDate) : (4 - weekDate)
          if (day == 21 + weekDate) {
            return "感恩节"
          }
          break;
      }
      return null;
    }

    //==== 传入 offset 传回干支, 0=甲子
    function cyclical(num) {
      return (Gan[num % 10] + Zhi[num % 12])
    }

    //==== 传回农历 year年的总天数
    function lYearDays(year) {
      let i, sum = 348
      for (i = 0x8000; i > 0x8; i >>= 1) {
        sum += (lunarInfo[year - 1900] & i) ? 1 : 0
      }
      return (sum + leapDays(year))
    }

    //==== 传回农历 year年闰月的天数
    function leapDays(year) {
      if (leapMonth(year)) {
        return ((lunarInfo[year - 1900] & 0x10000) ? 30 : 29)
      }
      else {
        return 0
      }
    }

    //==== 传回农历 year年闰哪个月 1-12 , 没闰传回 0
    function leapMonth(year) {
      return (lunarInfo[year - 1900] & 0xf)
    }

    //==== 传回农历 year年month月的总天数
    function monthDays(year, month) {
      return ((lunarInfo[year - 1900] & (0x10000 >> month)) ? 30 : 29)
    }

    //==== 算出农历, 传入日期对象, 传回农历日期对象
    //     该对象属性有 农历年year 农历月month 农历日day 是否闰年isLeap yearCyl dayCyl monCyl
    function Lunar(objDate) {
      let i, temp = 0
      let baseDate = new Date(1900, 0, 31)
      let offset = Math.floor((objDate - baseDate) / 86400000)

      let dayCyl = offset + 40
      let monCyl = 14

      for (i = 1900; i < 2050 && offset > 0; i++) {
        temp = lYearDays(i)
        offset -= temp
        monCyl += 12
      }
      if (offset < 0) {
        offset += temp;
        i--;
        monCyl -= 12
      }
      //农历年
      let year = i
      let yearCyl = i - 1864

      let leap = leapMonth(i) //闰哪个月
      let isLeap = false  //是否闰年

      for (i = 1; i < 13 && offset > 0; i++) {
        //闰月
        if (leap > 0 && i === (leap + 1) && isLeap === false) {
          --i; isLeap = true; temp = leapDays(year);
        }
        else {
          temp = monthDays(year, i);
        }

        //解除闰月
        if (isLeap === true && i === (leap + 1)) {
          isLeap = false
        }

        offset -= temp
        if (isLeap === false) {
          monCyl++
        }
      }

      if (offset === 0 && leap > 0 && i === leap + 1)
        if (isLeap) {
          isLeap = false
        }
        else {
          isLeap = true
          --i
          --monCyl
        }

      if (offset < 0) {
        offset += temp
        --i
        --monCyl
      }
      //农历月
      let month = i
      //农历日
      let day = offset + 1
      let dateStr = '' + month + "-" + day
      let holidayTemp = lfestival[dateStr]
      let holiday = holidayTemp ? holidayTemp.title : null
      if (holiday == null && month == 12 && ((temp == 29 && day == 29) || (temp == 30 && day == 30))) {
        holiday = '除夕';
      }

      return {
        year: year,
        month: month,
        day: day,
        isLeap: isLeap,
        leap: leap,
        yearCyl: yearCyl,
        dayCyl: dayCyl,
        monCyl: monCyl,
        holiday: holiday
      }
    }

    //==== 中文日期 m为传入月份，d为传入日期
    function cDay(m, d) {
      let nStrMonth = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊']
      let nStr1 = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
      let nStr2 = ['初', '十', '廿', '卅', '']
      //农历中文月
      let lunarMonthCn
      //农历中文日
      let lunarDayCn

      lunarMonthCn = nStrMonth[m - 1]

      lunarMonthCn += '月'

      switch (d) {
        case 10: lunarDayCn = '初十'; break;
        case 20: lunarDayCn = '二十'; break;
        case 30: lunarDayCn = '三十'; break;
        default: lunarDayCn = nStr2[Math.floor(d / 10)] + nStr1[d % 10]
      }
      return {
        lunarMonthCn: lunarMonthCn,
        lunarDayCn: lunarDayCn
      }
    }

    //节气
    function getSolarTerm() {
      let sTermInfo = [
        0, 21208, 42467, 63836, 85337, 107014,
        128867, 150921, 173149, 195551, 218072, 240693,
        263343, 285989, 308563, 331033, 353350, 375494,
        397447, 419210, 440795, 462224, 483532, 504758
      ]
      let solarTerm = [
        '小寒', '大寒', '立春', '雨水', '惊蛰', '春分',
        '清明', '谷雨', '立夏', '小满', '芒种', '夏至',
        '小暑', '大暑', '立秋', '处暑', '白露', '秋分',
        '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'
      ]

      let solarTerms = ''
      let tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2 + 1] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      let tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2 + 1]
      tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2]

      return solarTerms
    }

          now = hmSensor.createSensor(hmSensor.id.TIME);

        function add0(v) {
          if (v < 10) return "0" + v;
          else return v;
        }

        function updateCalendar() {
          if (now == null) {
            now = hmSensor.createSensor(hmSensor.id.TIME)
          }
          //用于计算农历年月日的数据
          GY = now.year
          GM = now.month - 1
          GD = now.day

          year = now.year
          month = now.month - 1 + 1
          date = now.day
          hours = now.hour
          minutes = now.minute
          seconds = now.second
		  
		  if (year != calendar.gregorianYear || month != calendar.gregorianMonth || date != calendar.gregorianDay) {
          let dateStr = '' + month + "-" + date
          let holidayTemp = festival[dateStr]
          let holiday = holidayTemp ? holidayTemp.title : null
          calendar.gregorianFestival = holiday
          if (calendar.gregorianFestival == '' || calendar.gregorianFestival == null) {
            calendar.gregorianFestival = getMotherOrFatherDay(year, month, date)
          }
          // month = month.toString().padStart(2, '0')
          // date = date.toString().padStart(2, '0')
          // hours = hours.toString().padStart(2, '0')
          // minutes = minutes.toString().padStart(2, '0')
          // seconds = seconds.toString().padStart(2, '0')
          //公历年月日、星期、时分秒
          calendar.gregorianYear = year
          calendar.gregorianMonth = month
          calendar.gregorianDay = date
          calendar.weekday = weekday[now.week - 1]
          calendar.hours = hours
          calendar.minutes = minutes
          calendar.seconds = seconds

          //去掉时分秒的日期
          let sDObj = new Date(GY, GM, GD);
          let lDObj = new Lunar(sDObj);

          //农历年月日、生肖年,数字
          calendar.lunarYear = lDObj.year
          calendar.lunarMonth = lDObj.month
          calendar.lunarDay = lDObj.day
          calendar.zodiacYear = zodiacs[(GY - 4) % 12]

          //农历中文年月日
          calendar.lunarYearCn = cyclical(GY - 1900 + 36)
          calendar.lunarMonthCn = cDay(lDObj.month, lDObj.day).lunarMonthCn
          calendar.lunarDayCn = cDay(lDObj.month, lDObj.day).lunarDayCn
          calendar.lunarFestival = lDObj.holiday

          //节气
          calendar.solarTerm = getSolarTerm()
		  if (dateText != null) {
                dateText.setProperty(hmUI.prop.TEXT, " " + add0(now.month) + "月" + add0(now.day) + "日 " + calendar.weekday);
            }
			
          if (nongli != null) {
            var str = "" + calendar.lunarMonthCn + "" + calendar.lunarDayCn + "\n";
            if (calendar.solarTerm != '') {//节气
              str += "" + calendar.solarTerm;
            }
            if (calendar.lunarFestival != null) {//农历节日
              str += " " + calendar.lunarFestival;
            }
            if (calendar.gregorianFestival != null) {//公历节日纪念日
              str += " " + calendar.gregorianFestival;
            }

            nongli.setProperty(hmUI.prop.TEXT, str);
          }
		   
        }
		}
// Lunar Data End

// Click Zona Start
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 3

		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
              if (zona1_num == 0) {		  
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            nongli.setProperty(hmUI.prop.VISIBLE, false);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			con_rest = 'Connection Restored';
			con_lost = 'Connection Lost';
		    hmUI.showToast({		  		  
				text: 'None'
            });
          };
           if (zona1_num == 1) {		  
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            nongli.setProperty(hmUI.prop.VISIBLE, true);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = '连接恢复';
			con_lost = '连接断开';
		    hmUI.showToast({		  		  
				text: '简体中文'
            });
          };
           if (zona1_num == 2) {		  
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, false);
            nongli.setProperty(hmUI.prop.VISIBLE, true);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			con_rest = '連接恢復';
			con_lost = '連接斷開';
		    hmUI.showToast({		  		  
				text: '繁體中文'
            });
          };
          if (zona1_num == 3) {
            normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
            nongli.setProperty(hmUI.prop.VISIBLE, false);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			con_rest = 'Connection Restored';
			con_lost = 'Connection Lost';
		    hmUI.showToast({		  		  
				text: 'English'
            });
          };
        }

// Click Zona End

//dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
          init_view() {
  
//dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Day-2.png","Day-3.png","Day-4.png","Day-5.png","Day-6.png","Day-7.png","Day-8.png","Day-9.png","Day-10.png","Day-11.png","Day-12.png"],
              image_length: 11,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

              autoToggleWeatherIcons();
            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array:  weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather2_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 10,
              y: 227,
              image_array:  weather2_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             normal_weather_text_sc_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_sc,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_tc_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_tc,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_text_en_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 88,
              y: 122,
              image_array:  weather_text_en,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 		
             //农历和节日        
			nongli = hmUI.createWidget(hmUI.widget.TEXT, {
			  x: 144,
			  y: 365,
			  w: 166,//文本容器宽度,文本会居中显示
			  h: 78,//文本容器高度
			  color: 0xFFFFFFFF,
			  text_size: 26,
			  line_space: 0,
			  text: " ",
			  align_h: h.ALIGN.CENTER_H,
			  text_style: hmUI.text_style.WRAP,
			  show_level: hmUI.show_level.ALL,
			});
		
            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 10,
              y: 201,
              w: 234,
              h: 39,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_languege_change_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 70,
              src: 'Icon-Language.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 127,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 14,
              y: 127,
              src: 'Logo-BA.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 167,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Temp.png',
              unit_tc: 'Temp.png',
              unit_en: 'Temp.png',
              negative_image: 'Number--.png',
              invalid_image: 'Number--.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 5,
              y: 170,
              src: 'Logo-Temp.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 249,
              y: 225,
              src: 'Bat-lvl-0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 225,
              image_array: ["Bat-lvl-1.png","Bat-lvl-2.png","Bat-lvl-3.png","Bat-lvl-4.png","Bat-lvl-5.png","Bat-lvl-6.png","Bat-lvl-7.png","Bat-lvl-8.png","Bat-lvl-9.png","Bat-lvl-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 248,
              hour_startY: 83,
              hour_array: ["Time-H1-0.png","Time-H1-1.png","Time-H1-2.png","Time-H1-3.png","Time-H1-4.png","Time-H1-5.png","Time-H1-6.png","Time-H1-7.png","Time-H1-8.png","Time-H1-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 248,
              minute_startY: 224,
              minute_array: ["Time-M1-0.png","Time-M1-1.png","Time-M1-2.png","Time-M1-3.png","Time-M1-4.png","Time-M1-5.png","Time-M1-6.png","Time-M1-7.png","Time-M1-8.png","Time-M1-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 398,
              second_startY: 229,
              second_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 227,
              src: 'Time-Mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 395,
              am_y: 175,
              am_sc_path: 'Time-sc-AM.png',
              am_en_path: 'Time-AM.png',
              pm_x: 395,
              pm_y: 175,
              pm_sc_path: 'Time-sc-PM.png',
              pm_en_path: 'Time-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 253,
              day_startY: 38,
              day_sc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_tc_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_en_array: ["Time-S1-0.png","Time-S1-1.png","Time-S1-2.png","Time-S1-3.png","Time-S1-4.png","Time-S1-5.png","Time-S1-6.png","Time-S1-7.png","Time-S1-8.png","Time-S1-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 48,
              month_sc_array: ["Month-sc-1.png","Month-sc-2.png","Month-sc-3.png","Month-sc-4.png","Month-sc-5.png","Month-sc-6.png","Month-sc-7.png","Month-sc-8.png","Month-sc-9.png","Month-sc-10.png","Month-sc-11.png","Month-sc-12.png"],
              month_tc_array: ["Month-sc-1.png","Month-sc-2.png","Month-sc-3.png","Month-sc-4.png","Month-sc-5.png","Month-sc-6.png","Month-sc-7.png","Month-sc-8.png","Month-sc-9.png","Month-sc-10.png","Month-sc-11.png","Month-sc-12.png"],
              month_en_array: ["Month-1.png","Month-2.png","Month-3.png","Month-4.png","Month-5.png","Month-6.png","Month-7.png","Month-8.png","Month-9.png","Month-10.png","Month-11.png","Month-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 219,
              y: 39,
              week_en: ["Week-1.png","Week-2.png","Week-3.png","Week-4.png","Week-5.png","Week-6.png","Week-7.png"],
              week_tc: ["Week-sc-1.png","Week-sc-2.png","Week-sc-3.png","Week-sc-4.png","Week-sc-5.png","Week-sc-6.png","Week-sc-7.png"],
              week_sc: ["Week-sc-1.png","Week-sc-2.png","Week-sc-3.png","Week-sc-4.png","Week-sc-5.png","Week-sc-6.png","Week-sc-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 302,
              src: 'pai00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 302,
              image_array: ["pai01.png","pai02.png","pai03.png","pai04.png","pai05.png","pai06.png","pai07.png","pai08.png","pai09.png","pai10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_paiw_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 302,
              image_array: ["PaiW01.png","PaiW02.png","PaiW03.png","PaiW04.png","PaiW05.png","PaiW06.png","PaiW07.png","PaiW08.png","PaiW09.png","PaiW10.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 317,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 248,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 248,
              src: 'Logo-Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 248,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 248,
              src: 'Logo-Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 288,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_en: 'Number-km.png',
              unit_sc: 'Number-sc-km.png',
              unit_tc: 'Number-sc-km.png',
              imperial_unit_en: 'Number-mi.png',
              imperial_unit_sc: 'Number-sc-mi.png',
              imperial_unit_tc: 'Number-sc-mi.png',
              dot_image: 'Number-..png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 17,
              y: 288,
              src: 'Logo-Distance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 66,
              y: 328,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Number-%.png',
              unit_tc: 'Number-%.png',
              unit_en: 'Number-%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 328,
              src: 'Logo-O2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 368,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 368,
              src: 'Logo-Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 155,
              y: 409,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              padding: false,
              h_space: 0,
              angle: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 400,
              src: 'Logo-Stress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
			normal_SLEEP_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 368,
              w: 59,
              h: 39,
              type: hmUI.data_type.SLEEP,
              font_array: ["Number-0.png","Number-1.png","Number-2.png","Number-3.png","Number-4.png","Number-5.png","Number-6.png","Number-7.png","Number-8.png","Number-9.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: "Number-..png", //小数点图片
              padding: true,
              isCharacter: false
           });

			normal_SLEEP_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
				x:360,
				y:368,
				src:"Logo-Sleep.png",
				show_level:hmUI.show_level.ONLY_NORMAL
				}),

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 104,
              src: 'Statuses-Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 141,
              src: 'Statuses-Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 404,
              y: 279,
              src: 'Statuses-DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 399,
              y: 316,
              src: 'Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


// Zona ShortCut Start
            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50, 
              y: 70, 
              text: '',
              w: 51, 
              h: 51, 
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
                click_zona1();
                click_Vibrate();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_en_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_text_sc_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_text_tc_img_level.setProperty(hmUI.prop.VISIBLE, false);
            nongli.setProperty(hmUI.prop.VISIBLE, false);
            normal_stress_text_text_img.setProperty(hmUI.prop.VISIBLE, true);


// Zona ShortCut End


            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,(0=Medium,9=Long,25=Short,27=Long Continuous),
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: con_lost});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: con_rest});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function


//Shortcut Jumable start
  
//START Battery Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 117,
              w: 88,
              h: 44,
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'LowBatteryScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

           normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 161,
              w: 88,
              h: 44,
              src: 'shortcut.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START Sport List Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 100,
				 y: 0,  
				 w: 118,     
				 h: 100,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'SportListScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 117,
              w: 118,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START World Clock Shortcut            
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 0,
				 y: 205,  
				 w: 244,     
				 h: 41,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'WorldClockScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 246,
              w: 244,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 285,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 325,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 365,
              w: 166,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 298,
              w: 68,
              h: 68,
              src: 'shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 405,
              w: 175,
              h: 40,
              src: 'shortcut.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//START Workout History Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
				 x: 216,
				 y: 34,  
				 w: 39,     
				 h: 170,     
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'SportRecordListScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

 //START Calendar Shortcut
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 253,
              y: 34,
              w: 141,
              h: 49,
				 text: '',    
				 normal_src: 'shortcut.png',   
				 press_src: 'shortcut.png', 
				 click_func: () => {
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
				 },
				 show_level: hmUI.show_level.ONLY_NORMAL,
			});

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 90,
              w: 130,
              h: 134,
              src: 'shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 224,
              w: 130,
              h: 134,
              src: 'shortcut.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 136,
              w: 97,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 395,
              y: 224,
              w: 97,
              h: 88,
              src: 'shortcut.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 292,
              y: 366,
              w: 107,
              h: 78,
              src: 'shortcut.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

//Shortcut Jumpable end


//Start AOD Screen
            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 49,
              src: 'Bat-lvl-AOD-0.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 49,
              image_array: ["Bat-lvl-AOD-1.png","Bat-lvl-AOD-2.png","Bat-lvl-AOD-3.png","Bat-lvl-AOD-4.png","Bat-lvl-AOD-5.png","Bat-lvl-AOD-6.png","Bat-lvl-AOD-7.png","Bat-lvl-AOD-8.png","Bat-lvl-AOD-9.png","Bat-lvl-AOD-10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 49,
              font_array: ["BA0.png","BA1.png","BA2.png","BA3.png","BA4.png","BA5.png","BA6.png","BA7.png","BA8.png","BA9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-BA%.png',
              unit_tc: 'AOD-BA%.png',
              unit_en: 'AOD-BA%.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 49,
              src: 'AOD-BA.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 320,
              am_y: 170,
              am_sc_path: 'AOD-sc-AM.png',
              am_en_path: 'AOD-AM.png',
              pm_x: 320,
              pm_y: 170,
              pm_sc_path: 'AOD-sc-PM.png',
              pm_en_path: 'AOD-PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 89,
              hour_array: ["AOD-H0.png","AOD-H1.png","AOD-H2.png","AOD-H3.png","AOD-H4.png","AOD-H5.png","AOD-H6.png","AOD-H7.png","AOD-H8.png","AOD-H9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 229,
              minute_startY: 234,
              minute_array: ["AOD-M0.png","AOD-M1.png","AOD-M2.png","AOD-M3.png","AOD-M4.png","AOD-M5.png","AOD-M6.png","AOD-M7.png","AOD-M8.png","AOD-M9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 75,
              day_startY: 273,
              day_sc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_tc_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_en_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 127,
              month_startY: 273,
              month_sc_array: ["AOD-Month-sc-1.png","AOD-Month-sc-2.png","AOD-Month-sc-3.png","AOD-Month-sc-4.png","AOD-Month-sc-5.png","AOD-Month-sc-6.png","AOD-Month-sc-7.png","AOD-Month-sc-8.png","AOD-Month-sc-9.png","AOD-Month-sc-10.png","AOD-Month-sc-11.png","AOD-Month-sc-12.png"],
              month_tc_array: ["AOD-Month-sc-1.png","AOD-Month-sc-2.png","AOD-Month-sc-3.png","AOD-Month-sc-4.png","AOD-Month-sc-5.png","AOD-Month-sc-6.png","AOD-Month-sc-7.png","AOD-Month-sc-8.png","AOD-Month-sc-9.png","AOD-Month-sc-10.png","AOD-Month-sc-11.png","AOD-Month-sc-12.png"],
              month_en_array: ["AOD-Month-1.png","AOD-Month-2.png","AOD-Month-3.png","AOD-Month-4.png","AOD-Month-5.png","AOD-Month-6.png","AOD-Month-7.png","AOD-Month-8.png","AOD-Month-9.png","AOD-Month-10.png","AOD-Month-11.png","AOD-Month-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 312,
              week_en: ["AOD-Week-1.png","AOD-Week-2.png","AOD-Week-3.png","AOD-Week-4.png","AOD-Week-5.png","AOD-Week-6.png","AOD-Week-7.png"],
              week_tc: ["AOD-Week-sc-1.png","AOD-Week-sc-2.png","AOD-Week-sc-3.png","AOD-Week-sc-4.png","AOD-Week-sc-5.png","AOD-Week-sc-6.png","AOD-Week-sc-7.png"],
              week_sc: ["AOD-Week-sc-1.png","AOD-Week-sc-2.png","AOD-Week-sc-3.png","AOD-Week-sc-4.png","AOD-Week-sc-5.png","AOD-Week-sc-6.png","AOD-Week-sc-7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 2,
              y: 210,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_masking_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 360,
              src: 'Lunar_Masking.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Step.png',
              unit_tc: 'AOD-Step.png',
              unit_en: 'AOD-Step.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 360,
              font_array: ["AOD-Number-0.png","AOD-Number-1.png","AOD-Number-2.png","AOD-Number-3.png","AOD-Number-4.png","AOD-Number-5.png","AOD-Number-6.png","AOD-Number-7.png","AOD-Number-8.png","AOD-Number-9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD-Heart.png',
              unit_tc: 'AOD-Heart.png',
              unit_en: 'AOD-Heart.png',
              invalid_image: 'Number--.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 336,
              y: 88,
              src: 'AOD-Statuses-BlueTooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
				autoToggleWeatherIcons(); // Night Weather Icon
				updateCalendar(); //Lunar Calendar
                checkConnection(); // DisconnectAlert
                stopVibro();
               }),
               pause_call: (function () { // DisconnectAlert
                stopVibro(); // DisconnectAlert

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}