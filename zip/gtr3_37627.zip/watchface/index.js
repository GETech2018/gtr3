﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_frame_animation_1 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_time_second_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'cyfb1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'cyfb2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'cyfb3.png' },
              ],
              count: 3,
              default_id: 1,
              fg: 'zn_pusty.png',
              tips_bg: 'tt.png',
              tips_x: 151,
              tips_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 71,
              y: 112,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 10,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 330,
              src: 'zn_noBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 325,
              y: 319,
              src: 'zn_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 226,
              y: 173,
              w: 120,
              h: 30,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF80,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 260,
              y: 140,
              font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cyf_m13.png',
              unit_tc: 'cyf_m13.png',
              unit_en: 'cyf_m13.png',
              negative_image: 'cyf_m10.png',
              invalid_image: 'zn_pusty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 113,
              image_array: ["pog01.png","pog02.png","pog03.png","pog04.png","pog05.png","pog06.png","pog07.png","pog08.png","pog09.png","pog10.png","pog11.png","pog12.png","pog13.png","pog14.png","pog15.png","pog16.png","pog17.png","pog18.png","pog19.png","pog20.png","pog21.png","pog22.png","pog23.png","pog24.png","pog25.png","pog26.png","pog27.png","pog28.png","pog29.png"],
              image_length: 29,
              shortcut: true,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 243,
              day_startY: 332,
              day_sc_array: ["cyf_dm00.png","cyf_dm01.png","cyf_dm02.png","cyf_dm03.png","cyf_dm04.png","cyf_dm05.png","cyf_dm06.png","cyf_dm07.png","cyf_dm08.png","cyf_dm09.png"],
              day_tc_array: ["cyf_dm00.png","cyf_dm01.png","cyf_dm02.png","cyf_dm03.png","cyf_dm04.png","cyf_dm05.png","cyf_dm06.png","cyf_dm07.png","cyf_dm08.png","cyf_dm09.png"],
              day_en_array: ["cyf_dm00.png","cyf_dm01.png","cyf_dm02.png","cyf_dm03.png","cyf_dm04.png","cyf_dm05.png","cyf_dm06.png","cyf_dm07.png","cyf_dm08.png","cyf_dm09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 169,
              y: 343,
              week_en: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_tc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_sc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 287,
              font_array: ["cyf_aku0.png","cyf_aku1.png","cyf_aku2.png","cyf_aku3.png","cyf_aku4.png","cyf_aku5.png","cyf_aku6.png","cyf_aku7.png","cyf_aku8.png","cyf_aku9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wsk_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 14,
              hour_posY: 147,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wsk_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 16,
              minute_posY: 202,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wsk_S.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 222,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 222,
              center_x: 227,
              center_y: 227,
              src: 'wsk_S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 60,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 60,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 359,
              font_array: ["cyf_dm00.png","cyf_dm01.png","cyf_dm02.png","cyf_dm03.png","cyf_dm04.png","cyf_dm05.png","cyf_dm06.png","cyf_dm07.png","cyf_dm08.png","cyf_dm09.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'cyf_dm10.png',
              unit_tc: 'cyf_dm10.png',
              unit_en: 'cyf_dm10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 259,
              y: 230,
              w: 145,
              h: 89,
              text_size: 80,
              char_space: 7,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 140,
              hour_array: ["cyf_D00.png","cyf_D01.png","cyf_D02.png","cyf_D03.png","cyf_D04.png","cyf_D05.png","cyf_D06.png","cyf_D07.png","cyf_D08.png","cyf_D09.png"],
              hour_zero: 1,
              hour_space: 14,
              hour_angle: 0,
              hour_unit_sc: 'cyf_D10.png',
              hour_unit_tc: 'cyf_D10.png',
              hour_unit_en: 'cyf_D10.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["cyf_D00.png","cyf_D01.png","cyf_D02.png","cyf_D03.png","cyf_D04.png","cyf_D05.png","cyf_D06.png","cyf_D07.png","cyf_D08.png","cyf_D09.png"],
              minute_zero: 1,
              minute_space: 14,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 271,
              y: 197,
              w: 110,
              h: 55,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(1)_ALTIMETER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(1)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(1)_UVI.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -18,
              tips_y: -40,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 288,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: true,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 351,
                  y: 174,
                  src: 'zn_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 299,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 353,
                  y: 176,
                  src: 'cyf_m17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 293,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'zn_BPM.png',
                  unit_tc: 'zn_BPM.png',
                  unit_en: 'zn_BPM.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 176,
                  src: 'zn_ser.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 294,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'cyf_m12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 352,
                  y: 174,
                  src: 'cyf_m14.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 303,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'zn_UV.png',
                  unit_tc: 'zn_UV.png',
                  unit_en: 'zn_UV.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 294,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'cyf_m11.png',
                  unit_tc: 'cyf_m11.png',
                  unit_en: 'cyf_m11.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 171,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 282,
                  y: 215,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m15.png',
                  unit_tc: 'cyf_m15.png',
                  unit_en: 'cyf_m15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 351,
                  y: 167,
                  src: 'zn_cis.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 254,
              y: 256,
              w: 110,
              h: 55,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -17,
              tips_y: 63,
              tips_width: 157,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 271,
                  y: 274,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: true,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 265,
                  src: 'zn_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 280,
                  y: 275,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 363,
                  y: 270,
                  src: 'cyf_m17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 274,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'zn_BPM.png',
                  unit_tc: 'zn_BPM.png',
                  unit_en: 'zn_BPM.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 268,
                  src: 'zn_ser.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 274,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  dot_image: 'cyf_m12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 362,
                  y: 270,
                  src: 'cyf_m14.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 276,
                  y: 275,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'cyf_m11.png',
                  unit_tc: 'cyf_m11.png',
                  unit_en: 'cyf_m11.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 267,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 266,
                  y: 275,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'cyf_m15.png',
                  unit_tc: 'cyf_m15.png',
                  unit_en: 'cyf_m15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 263,
                  src: 'zn_cis.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 280,
                  y: 274,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 4,
                  unit_sc: 'zn_wiatru.png',
                  unit_tc: 'zn_wiatru.png',
                  unit_en: 'zn_wiatru.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(0);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 9,
            // });


            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(9);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 236,
              y: 315,
              w: 65,
              h: 125,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 143,
              y: 326,
              w: 90,
              h: 108,
              src: 'zn_pusty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 315,
              w: 85,
              h: 70,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 200,
              w: 111,
              h: 53,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 117,
              w: 90,
              h: 90,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 83,
              y: 228,
              w: 90,
              h: 90,
              src: 'zn_pusty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 259,
              w: 103,
              h: 53,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      time_update(true, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}