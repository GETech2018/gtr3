﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -23,
              y: -45,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 50,
              anim_size: 180,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 78,
              font_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 129,
              y: 64,
              src: 'running-0009.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 31,
              font_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 32,
              src: 'pourcent-0009.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 33,
              image_array: ["battrouge-0001.png","battrouge-0002.png","battrouge-0003.png","battrouge-0004.png","battrouge-0005.png","battrouge-0006.png","battrouge-0007.png","battrouge-0008.png","battrouge-0009.png","battrouge-0010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 101,
              y: 294,
              src: 'bluetooth-0011.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 279,
              src: 'alarme-0009.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 252,
              year_startY: 340,
              year_sc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              year_tc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              year_en_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 340,
              month_sc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              month_tc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              month_en_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 340,
              src: 'Separation-0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 340,
              day_sc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              day_tc_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              day_en_array: ["rougepetit-0001.png","rougepetit-0002.png","rougepetit-0003.png","rougepetit-0004.png","rougepetit-0005.png","rougepetit-0006.png","rougepetit-0007.png","rougepetit-0008.png","rougepetit-0009.png","rougepetit-0010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 340,
              src: 'Separation-0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 139,
              hour_startY: 280,
              hour_array: ["rougeitalique0.png","rougeitalique1.png","rougeitalique2.png","rougeitalique3.png","rougeitalique4.png","rougeitalique5.png","rougeitalique6.png","rougeitalique7.png","rougeitalique8.png","rougeitalique9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 245,
              minute_startY: 280,
              minute_array: ["rougeitalique0.png","rougeitalique1.png","rougeitalique2.png","rougeitalique3.png","rougeitalique4.png","rougeitalique5.png","rougeitalique6.png","rougeitalique7.png","rougeitalique8.png","rougeitalique9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 279,
              src: 'deuxpoints-0015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  