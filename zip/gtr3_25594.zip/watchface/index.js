﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 	    let screenType = hmSetting.getScreenType();
            // animate
            if (screenType != hmSetting.screen_type.AOD) {

               let animate = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "Galope",
                    anim_ext: "png",
                    anim_fps: 25,
                    anim_size: 30,
                    anim_repeat: true,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START,
                    display_on_restart: false,
	           });
       	    }

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 370,
              y: 204,
              image_array: ["Moon11.png","Moon12.png","Moon13.png","Moon14.png","Moon15.png","Moon16.png","Moon17.png","Moon18.png","Moon19.png","Moon20.png","Moon21.png","Moon22.png","Moon23.png","Moon24.png","Moon25.png","Moon26.png","Moon27.png","Moon28.png","Moon29.png","Moon30.png","Moon31.png","Moon32.png","Moon33.png","Moon34.png","Moon35.png","Moon36.png","Moon37.png","Moon38.png","Moon39.png","Moon40.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 87,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 90,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 131,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Km.png',
              unit_tc: 'Km.png',
              unit_en: 'Km.png',
              dot_image: 'punto.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 88,
              src: 'pasos.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 88,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 270,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'degrees.png',
              unit_tc: 'degrees.png',
              unit_en: 'degrees.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 204,
              image_array: ["Weather10.png","Weather11.png","Weather12.png","Weather13.png","Weather14.png","Weather15.png","Weather16.png","Weather17.png","Weather18.png","Weather19.png","Weather20.png","Weather21.png","Weather22.png","Weather23.png","Weather24.png","Weather25.png","Weather26.png","Weather27.png","Weather28.png","Weather29.png","Weather30.png","Weather31.png","Weather32.png","Weather33.png","Weather34.png","Weather35.png","Weather36.png","Weather37.png","Weather38.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 186,
              y: 12,
              week_en: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_tc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              week_sc: ["Dia_0.png","Dia_1.png","Dia_2.png","Dia_3.png","Dia_4.png","Dia_5.png","Dia_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 236,
              month_startY: 48,
              month_sc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_tc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_en_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 169,
              day_startY: 48,
              day_sc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_tc_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_en_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'guion.png',
              day_unit_tc: 'guion.png',
              day_unit_en: 'guion.png',
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 23,
              y: 134,
              font_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 95,
              y: 28,
              src: '0025.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 34,
              src: '0026.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 105,
              hour_startY: 340,
              hour_array: ["DigBlack0.png","DigBlack1.png","DigBlack2.png","DigBlack3.png","DigBlack4.png","DigBlack5.png","DigBlack6.png","DigBlack7.png","DigBlack8.png","DigBlack9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 235,
              minute_startY: 340,
              minute_array: ["DigBlack0.png","DigBlack1.png","DigBlack2.png","DigBlack3.png","DigBlack4.png","DigBlack5.png","DigBlack6.png","DigBlack7.png","DigBlack8.png","DigBlack9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 340,
              second_array: ["DigBlackMed0.png","DigBlackMed1.png","DigBlackMed2.png","DigBlackMed3.png","DigBlackMed4.png","DigBlackMed5.png","DigBlackMed6.png","DigBlackMed7.png","DigBlackMed8.png","DigBlackMed9.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Spark.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 20,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 202,
              y: 192,
              src: '0025.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 34,
              hour_array: ["GoldBig_0.png","GoldBig_1.png","GoldBig_2.png","GoldBig_3.png","GoldBig_4.png","GoldBig_5.png","GoldBig_6.png","GoldBig_7.png","GoldBig_8.png","GoldBig_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 116,
              minute_startY: 236,
              minute_array: ["GoldBig_0.png","GoldBig_1.png","GoldBig_2.png","GoldBig_3.png","GoldBig_4.png","GoldBig_5.png","GoldBig_6.png","GoldBig_7.png","GoldBig_8.png","GoldBig_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  