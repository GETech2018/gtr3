﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_city_name_text = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview1.png', path: 'dail-01.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'dail-01.1.png' },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 140,
              font_array: ["15PT0001.png","15PT0002.png","15PT0003.png","15PT0004.png","15PT0005.png","15PT0006.png","15PT0007.png","15PT0008.png","15PT0009.png","15PT0010.png"],
              padding: false,
              h_space: 0,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 117,
              y: 103,
              src: 'sun01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 140,
              font_array: ["15PT0001.png","15PT0002.png","15PT0003.png","15PT0004.png","15PT0005.png","15PT0006.png","15PT0007.png","15PT0008.png","15PT0009.png","15PT0010.png"],
              padding: false,
              h_space: 0,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 103,
              src: 'sun02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 110,
              image_array: ["Weather01.png","Weather02.png","Weather03.png","Weather04.png","Weather05.png","Weather06.png","Weather07.png","Weather08.png","Weather09.png","Weather10.png","Weather11.png","Weather12.png","Weather13.png","Weather14.png","Weather15.png","Weather16.png","Weather17.png","Weather18.png","Weather19.png","Weather20.png","Weather21.png","Weather22.png","Weather23.png","Weather24.png","Weather25.png","Weather26.png","Weather27.png","Weather28.png","Weather29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 150,
              font_array: ["18PT0001.png","18PT0002.png","18PT0003.png","18PT0004.png","18PT0005.png","18PT0006.png","18PT0007.png","18PT0008.png","18PT0009.png","18PT0010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Weather31.png',
              unit_tc: 'Weather31.png',
              unit_en: 'Weather31.png',
              negative_image: 'Minus.png',
              invalid_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 153,
              y: 175,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 300,
              src: 'Alarm01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 300,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 118,
              // center_y: 230,
              // start_angle: 9,
              // end_angle: 171,
              // radius: 53,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFFF8000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 118,
              center_y: 230,
              start_angle: 9,
              end_angle: 171,
              radius: 51,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFFF8000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 202,
              font_array: ["15PT0001.png","15PT0002.png","15PT0003.png","15PT0004.png","15PT0005.png","15PT0006.png","15PT0007.png","15PT0008.png","15PT0009.png","15PT0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 112,
              // center_y: 230,
              // start_angle: 190,
              // end_angle: 351,
              // radius: 53,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 112,
              center_y: 230,
              start_angle: 190,
              end_angle: 351,
              radius: 51,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF0080FF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 230,
              font_array: ["18PT0001.png","18PT0002.png","18PT0003.png","18PT0004.png","18PT0005.png","18PT0006.png","18PT0007.png","18PT0008.png","18PT0009.png","18PT0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 305,
              y: 235,
              image_array: ["batterylevel0001.png","batterylevel0002.png","batterylevel0003.png","batterylevel0004.png","batterylevel0005.png","batterylevel0006.png","batterylevel0007.png","batterylevel0008.png","batterylevel0009.png","batterylevel0010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 270,
              image_array: ["moonphase0001.png","moonphase0002.png","moonphase0003.png","moonphase0004.png","moonphase0005.png","moonphase0006.png","moonphase0007.png","moonphase0008.png","moonphase0009.png","moonphase0010.png","moonphase0011.png","moonphase0012.png","moonphase0013.png","moonphase0014.png","moonphase0015.png","moonphase0016.png","moonphase0017.png","moonphase0018.png","moonphase0019.png","moonphase0020.png","moonphase0021.png","moonphase0022.png","moonphase0023.png","moonphase0024.png","moonphase0025.png","moonphase0026.png","moonphase0027.png","moonphase0028.png","moonphase0029.png","moonphase0030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 360,
              month_startY: 235,
              month_sc_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_tc_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_en_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 365,
              day_startY: 205,
              day_sc_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_tc_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_en_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 200,
              week_en: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              week_tc: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              week_sc: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 70,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 215,
              pm_y: 70,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 195,
              hour_startY: 85,
              hour_array: ["30PDark0001.png","30PDark0002.png","30PDark0003.png","30PDark0004.png","30PDark0005.png","30PDark0006.png","30PDark0007.png","30PDark0008.png","30PDark0009.png","30PDark0010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 235,
              minute_startY: 85,
              minute_array: ["30PDark0001.png","30PDark0002.png","30PDark0003.png","30PDark0004.png","30PDark0005.png","30PDark0006.png","30PDark0007.png","30PDark0008.png","30PDark0009.png","30PDark0010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 87,
              src: '30PTdarkwhite0013.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Analog0003.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Analog0004.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 188,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Analog0001.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 17,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 300,
              src: 'Alarm01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 300,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 305,
              y: 235,
              image_array: ["batterylevel0001.png","batterylevel0002.png","batterylevel0003.png","batterylevel0004.png","batterylevel0005.png","batterylevel0006.png","batterylevel0007.png","batterylevel0008.png","batterylevel0009.png","batterylevel0010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 155,
              y: 270,
              image_array: ["moonphase0001.png","moonphase0002.png","moonphase0003.png","moonphase0004.png","moonphase0005.png","moonphase0006.png","moonphase0007.png","moonphase0008.png","moonphase0009.png","moonphase0010.png","moonphase0011.png","moonphase0012.png","moonphase0013.png","moonphase0014.png","moonphase0015.png","moonphase0016.png","moonphase0017.png","moonphase0018.png","moonphase0019.png","moonphase0020.png","moonphase0021.png","moonphase0022.png","moonphase0023.png","moonphase0024.png","moonphase0025.png","moonphase0026.png","moonphase0027.png","moonphase0028.png","moonphase0029.png","moonphase0030.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 360,
              month_startY: 235,
              month_sc_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_tc_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_en_array: ["Month0001.png","Month0002.png","Month0003.png","Month0004.png","Month0005.png","Month0006.png","Month0007.png","Month0008.png","Month0009.png","Month0010.png","Month0011.png","Month0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 365,
              day_startY: 205,
              day_sc_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_tc_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_en_array: ["30PT0001.png","30PT0002.png","30PT0003.png","30PT0004.png","30PT0005.png","30PT0006.png","30PT0007.png","30PT0008.png","30PT0009.png","30PT0010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 200,
              week_en: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              week_tc: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              week_sc: ["weekdays0001.png","weekdays0002.png","weekdays0003.png","weekdays0004.png","weekdays0005.png","weekdays0006.png","weekdays0007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 70,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 215,
              pm_y: 70,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 195,
              hour_startY: 85,
              hour_array: ["30PDark0001.png","30PDark0002.png","30PDark0003.png","30PDark0004.png","30PDark0005.png","30PDark0006.png","30PDark0007.png","30PDark0008.png","30PDark0009.png","30PDark0010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 235,
              minute_startY: 85,
              minute_array: ["30PDark0001.png","30PDark0002.png","30PDark0003.png","30PDark0004.png","30PDark0005.png","30PDark0006.png","30PDark0007.png","30PDark0008.png","30PDark0009.png","30PDark0010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 87,
              src: '30PTdarkwhite0013.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Analog0003.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Analog0004.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 188,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Analog0001.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 17,
              second_posY: 225,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,
              // disconneсnt_toast_text: Phone connection is lost,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Phone connection is successful,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Phone connection is lost"});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: "Phone connection is successful"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 139,
              y: 96,
              w: 30,
              h: 28,
              src: 'Shortcut.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 98,
              w: 37,
              h: 57,
              src: 'Shortcut.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 307,
              w: 39,
              h: 40,
              src: 'Shortcut.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 193,
              w: 39,
              h: 32,
              src: 'Shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 118,
                      center_y: 230,
                      start_angle: 9,
                      end_angle: 171,
                      radius: 51,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFFF8000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 112,
                      center_y: 230,
                      start_angle: 190,
                      end_angle: 351,
                      radius: 51,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF0080FF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}