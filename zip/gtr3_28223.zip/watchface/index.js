﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_lock_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 313,
              image_array: ["whthr001.png","whthr002.png","whthr003.png","whthr004.png","whthr005.png","whthr006.png","whthr007.png","whthr008.png","whthr009.png","whthr010.png","whthr011.png","whthr012.png","whthr013.png","whthr014.png","whthr015.png","whthr016.png","whthr017.png","whthr018.png","whthr019.png","whthr020.png","whthr021.png","whthr022.png","whthr023.png","whthr024.png","whthr025.png","whthr026.png","whthr027.png","whthr028.png","whthr029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bkg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 312,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min011.png',
              unit_tc: 'min011.png',
              unit_en: 'min011.png',
              negative_image: 'min012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 312,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min011.png',
              unit_tc: 'min011.png',
              unit_en: 'min011.png',
              negative_image: 'min012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 405,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'min011.png',
              unit_tc: 'min011.png',
              unit_en: 'min011.png',
              negative_image: 'min012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 9,
              image_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png","M13.png","M14.png","M15.png","M16.png","M17.png","M18.png","M19.png","M20.png","M21.png","M22.png","M23.png","M24.png","M25.png","M26.png","M27.png","M28.png","M29.png","M30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 345,
              y: 325,
              image_array: ["h1.png","h2.png","h3.png","h4.png","h5.png","h6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 325,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'min012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 366,
              y: 280,
              src: 'sg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 286,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 366,
              y: 280,
              image_array: ["sg0.png","sg1.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 308,
              y: 360,
              image_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 367,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 369,
              day_startY: 172,
              day_sc_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              day_tc_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              day_en_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 321,
              month_startY: 172,
              month_sc_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              month_tc_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              month_en_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              month_zero: 1,
              month_space: -1,
              month_unit_sc: 'sml012.png',
              month_unit_tc: 'sml012.png',
              month_unit_en: 'sml012.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 331,
              y: 134,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 106,
              y: 68,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 58,
              y: 163,
              src: 'lck.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 87,
              y: 109,
              src: 'alrm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 273,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'min013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 273,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'min013.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 271,
              src: 'sun.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HH.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 18,
              hour_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MH.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 18,
              minute_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'SH.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 18,
              second_posY: 182,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 127,
              y: 9,
              image_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png","M13.png","M14.png","M15.png","M16.png","M17.png","M18.png","M19.png","M20.png","M21.png","M22.png","M23.png","M24.png","M25.png","M26.png","M27.png","M28.png","M29.png","M30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AH.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 18,
              hour_posY: 182,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AM.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 18,
              minute_posY: 182,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  