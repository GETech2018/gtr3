﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 252,
              image_array: ["whthr001.png","whthr002.png","whthr003.png","whthr004.png","whthr005.png","whthr006.png","whthr007.png","whthr008.png","whthr009.png","whthr010.png","whthr011.png","whthr012.png","whthr013.png","whthr014.png","whthr015.png","whthr016.png","whthr017.png","whthr018.png","whthr019.png","whthr020.png","whthr021.png","whthr022.png","whthr023.png","whthr024.png","whthr025.png","whthr026.png","whthr027.png","whthr028.png","whthr029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Fon3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 309,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'min011.png',
              unit_tc: 'min011.png',
              unit_en: 'min011.png',
              negative_image: 'min012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 309,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'min011.png',
              unit_tc: 'min011.png',
              unit_en: 'min011.png',
              negative_image: 'min012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 404,
              font_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              padding: false,
              h_space: -4,
              unit_sc: 'med011.png',
              unit_tc: 'med011.png',
              unit_en: 'med011.png',
              negative_image: 'med012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 0,
              year_startY: 0,
              year_sc_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              year_tc_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              year_en_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Fon2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 389,
              y: 150,
              src: 'lck.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 13,
              y: 191,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 146,
              src: 'alrm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 98,
              font_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 93,
              image_array: ["bat001.png","bat002.png","bat003.png","bat004.png","bat005.png","bat006.png","bat007.png","bat008.png","bat009.png","bat010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 231,
              hour_startY: 84,
              hour_array: ["big001.png","big002.png","big003.png","big004.png","big005.png","big006.png","big007.png","big008.png","big009.png","big010.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 178,
              minute_array: ["big001.png","big002.png","big003.png","big004.png","big005.png","big006.png","big007.png","big008.png","big009.png","big010.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 383,
              second_startY: 213,
              second_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 152,
              y: 50,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 198,
              day_startY: 8,
              day_sc_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_tc_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_en_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 143,
              font_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 83,
              y: 189,
              font_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 232,
              font_array: ["sml001.png","sml002.png","sml003.png","sml004.png","sml005.png","sml006.png","sml007.png","sml008.png","sml009.png","sml010.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sml013.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 278,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -3,
              dot_image: 'min013.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 278,
              font_array: ["min001.png","min002.png","min003.png","min004.png","min005.png","min006.png","min007.png","min008.png","min009.png","min010.png"],
              padding: false,
              h_space: -3,
              dot_image: 'min013.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 180,
              w: 139,
              h: 87,
              src: '0001.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 231,
              y: 75,
              w: 130,
              h: 100,
              src: '0001.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 278,
              w: 118,
              h: 136,
              src: '0001.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 278,
              w: 118,
              h: 136,
              src: '0001.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 278,
              w: 151,
              h: 163,
              src: '0001.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 75,
              w: 133,
              h: 100,
              src: '0001.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 81,
              y: 178,
              w: 142,
              h: 88,
              src: '0001.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 146,
              y: 142,
              week_en: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_tc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              week_sc: ["day001.png","day002.png","day003.png","day004.png","day005.png","day006.png","day007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 106,
              day_sc_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_tc_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_en_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 186,
              hour_array: ["big001.png","big002.png","big003.png","big004.png","big005.png","big006.png","big007.png","big008.png","big009.png","big010.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_unit_sc: '0001.png',
              hour_unit_tc: '0001.png',
              hour_unit_en: '0001.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 238,
              minute_startY: 186,
              minute_array: ["big001.png","big002.png","big003.png","big004.png","big005.png","big006.png","big007.png","big008.png","big009.png","big010.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 378,
              second_startY: 235,
              second_array: ["med001.png","med002.png","med003.png","med004.png","med005.png","med006.png","med007.png","med008.png","med009.png","med010.png"],
              second_zero: 1,
              second_space: -6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  