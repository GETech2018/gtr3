﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_calorie_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_step_icon_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: -65,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: -291,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 13,
              minute_startY: 111,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: -291,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 32,
              day_startY: 137,
              day_sc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_tc_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_en_array: ["Date_share_28_0001.png","Date_share_28_0002.png","Date_share_28_0003.png","Date_share_28_0004.png","Date_share_28_0005.png","Date_share_28_0006.png","Date_share_28_0007.png","Date_share_28_0008.png","Date_share_28_0009.png","Date_share_28_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 52,
              y: -10,
              week_en: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_tc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              week_sc: ["Day_share_28_0001.png","Day_share_28_0002.png","Day_share_28_0003.png","Day_share_28_0004.png","Day_share_28_0005.png","Day_share_28_0006.png","Day_share_28_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 0,
              w: 146,
              h: 29,
              text_size: 19,
              char_space: 0,
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Picture42M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 197,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Picture42H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 30,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Picture27.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 12,
              second_posY: 230,
              second_cover_path: 'Picture29.png',
              second_cover_x: 197,
              second_cover_y: 197,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -32,
              y: -20,
              src: 'ring_edge_double.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: -65,
              hour_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              hour_zero: 1,
              hour_space: -291,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 13,
              minute_startY: 111,
              minute_array: ["shadow_0001.png","shadow_0002.png","shadow_0003.png","shadow_0004.png","shadow_0005.png","shadow_0006.png","shadow_0007.png","shadow_0008.png","shadow_0009.png","shadow_0010.png"],
              minute_zero: 1,
              minute_space: -291,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -37,
              y: 12,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}