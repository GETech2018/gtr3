﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editableTimPointers = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: True,
              bg_config: [
                { id: 1, preview: 'main1.png', path: 'main1.png' },
                { id: 2, preview: 'main2.png', path: 'main2.png' },
                { id: 3, preview: 'main3.png', path: 'main3.png' },
                { id: 4, preview: 'main4.png', path: 'main4.png' },
                { id: 5, preview: 'main5.png', path: 'main5.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: 'Option.png',
              tips_x: 355,
              tips_y: 355,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 50,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 338,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 48,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 160,
              font_array: ["Time_Second_font_01.png","Time_Second_font_02.png","Time_Second_font_03.png","Time_Second_font_04.png","Time_Second_font_05.png","Time_Second_font_06.png","Time_Second_font_07.png","Time_Second_font_08.png","Time_Second_font_09.png","Time_Second_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 157,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 361,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'act_font_12.png',
              unit_tc: 'act_font_12.png',
              unit_en: 'act_font_12.png',
              negative_image: 'act_font_11.png',
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 323,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 329,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 226,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 126,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 212,
              month_startY: 106,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 58,
              week_en: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_tc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_sc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 293,
              day_startY: 115,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 365,
              am_y: 263,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 365,
              pm_y: 263,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 293,
              hour_startY: 192,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 0,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 296,
              minute_startY: 249,
              minute_array: ["Time_Minute_font_01.png","Time_Minute_font_02.png","Time_Minute_font_03.png","Time_Minute_font_04.png","Time_Minute_font_05.png","Time_Minute_font_06.png","Time_Minute_font_07.png","Time_Minute_font_08.png","Time_Minute_font_09.png","Time_Minute_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 366,
              second_startY: 247,
              second_array: ["Time_Second_font_01.png","Time_Second_font_02.png","Time_Second_font_03.png","Time_Second_font_04.png","Time_Second_font_05.png","Time_Second_font_06.png","Time_Second_font_07.png","Time_Second_font_08.png","Time_Second_font_09.png","Time_Second_font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 307,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 51,
              y: 179,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 78,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 50,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 338,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 48,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 160,
              font_array: ["Time_Second_font_01.png","Time_Second_font_02.png","Time_Second_font_03.png","Time_Second_font_04.png","Time_Second_font_05.png","Time_Second_font_06.png","Time_Second_font_07.png","Time_Second_font_08.png","Time_Second_font_09.png","Time_Second_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 157,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","Batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 361,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'act_font_12.png',
              unit_tc: 'act_font_12.png',
              unit_en: 'act_font_12.png',
              negative_image: 'act_font_11.png',
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 246,
              y: 323,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 329,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 226,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 126,
              font_array: ["act_font_01.png","act_font_02.png","act_font_03.png","act_font_04.png","act_font_05.png","act_font_06.png","act_font_07.png","act_font_08.png","act_font_09.png","act_font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 212,
              month_startY: 106,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 58,
              week_en: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_tc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              week_sc: ["Day_Week_1.png","Day_Week_2.png","Day_Week_3.png","Day_Week_4.png","Day_Week_5.png","Day_Week_6.png","Day_Week_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 293,
              day_startY: 115,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 365,
              am_y: 263,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 365,
              pm_y: 263,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 293,
              hour_startY: 192,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 0,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 296,
              minute_startY: 249,
              minute_array: ["Time_Minute_font_01.png","Time_Minute_font_02.png","Time_Minute_font_03.png","Time_Minute_font_04.png","Time_Minute_font_05.png","Time_Minute_font_06.png","Time_Minute_font_07.png","Time_Minute_font_08.png","Time_Minute_font_09.png","Time_Minute_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 366,
              second_startY: 247,
              second_array: ["Time_Second_font_01.png","Time_Second_font_02.png","Time_Second_font_03.png","Time_Second_font_04.png","Time_Second_font_05.png","Time_Second_font_06.png","Time_Second_font_07.png","Time_Second_font_08.png","Time_Second_font_09.png","Time_Second_font_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 123,
                    path: 'Clock_hour_1.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 188,
                    path: 'Clock_minute_1.png',
                  },
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 209,
                    path: 'Clock_sec_1.png',
                  },
                },
                {
                  id: 2,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 123,
                    path: 'Clock_hour_2.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 188,
                    path: 'Clock_minute_2.png',
                  },
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 209,
                    path: 'Clock_sec_2.png',
                  },
                },
                {
                  id: 3,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 123,
                    path: 'Clock_hour_3.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 188,
                    path: 'Clock_minute_3.png',
                  },
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 209,
                    path: 'Clock_sec_3.png',
                  },
                },
                {
                  id: 4,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 123,
                    path: 'Clock_hour_4.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 188,
                    path: 'Clock_minute_4.png',
                  },
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 209,
                    path: 'Clock_sec_4.png',
                  },
                },
                {
                  id: 5,
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 123,
                    path: 'Clock_hour_5.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 188,
                    path: 'Clock_minute_5.png',
                  },
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 15,
                    posY: 209,
                    path: 'Clock_sec_5.png',
                  },
                },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_x: 327,
              tips_y: 315,
              tips_bg: 'option_clock.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimPointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  