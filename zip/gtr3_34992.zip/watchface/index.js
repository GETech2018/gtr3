﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''

        let normal2_heart_rate_text_text_img = ''
        let normal2_heart_rate_text_separator_img = ''
        let normal2_distance_text_text_img = ''
        let normal2_distance_text_separator_img = ''
        let normal2_calorie_current_text_img = ''
        let normal2_calorie_current_separator_img = ''
        let normal2_step_current_text_img = ''
        let normal2_step_current_separator_img = ''
        let normal2_step_image_progress_img_level = ''

        let normal3_moon_image_progress_img_level = ''
        let normal3_temperature_high_text_img = ''
        let normal3_temperature_low_text_img = ''
        let normal3_temperature_icon_img = ''
        let normal3_temperature_current_text_img = ''
        let normal3_temperature_current_separator_img = ''
        let normal3_weather_image_progress_img_level = ''

        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''
        let cc = 0

        let normal_image1_img = ''
        let normal_image2_img = ''
        let normal_image3_img = ''

       // on/off analog
        let btn_element_4= ''
        let elementnumber_4= 1
        let total_elemente4 = 2

        function click_elemente4() {
            if(elementnumber_4==total_elemente4) {
            elementnumber_4=1;
                UpdateElemente4One();
                }
            else {
                elementnumber_4=elementnumber_4+1;
                if(elementnumber_4==2) {
                  UpdateElemente4Two();
                }

            }
            if(elementnumber_4==1) hmUI.showToast({text: 'Hand clock ON'});
            if(elementnumber_4==2) hmUI.showToast({text: 'Handclock OFF'});
        }

        //Hand clock on
        function UpdateElemente4One(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

        }

        //hand clock off
        function UpdateElemente4Two(){
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }






        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 3
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { 
      namecolor = "White";
         normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: "Black_hour.png",
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 31,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: "Black_min.png",
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}
if ( colornumber == 2) { 
        namecolor = "Gray" ;
         normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: "Black_hour.png",
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 31,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: "Black_min.png",
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}

if ( colornumber == 3) {
namecolor = "Black";

         normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: "White_hour.png",
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 31,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: "White_min.png",
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////




        // Switch Weather / Temp.
        let btn_element_1 = ''
        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Weather icons'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Temperature'});
        }

        //Weather icon 
        function UpdateElementeOne(){
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        }

        //Temp
        function UpdateElementeTwo(){
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        }
///////////////////////////////////////////////////////


      // Activity , weathr , date
        let btn_element_2 = ''
        let btn_element3 = ''
        let elementnumber_2 = 1
        let elementnumber3 = ''
        let total_elemente2 = 3

        function click_elemente2() {
            if(elementnumber_2 > total_elemente2) {
            elementnumber_2=1;
                UpdateElemente2One();
                }
            else {
                if (elementnumber_2 < total_elemente2){elementnumber_2=elementnumber_2+1;}
                if(elementnumber_2==2) {
                  UpdateElemente2Two();
                }

               if(elementnumber_2==3) {
                  UpdateElemente2Three();
                }

            }
            if(elementnumber_2==1) hmUI.showToast({text: 'Time'});
            if(elementnumber_2==2) hmUI.showToast({text: 'Activity'});
            if(elementnumber_2==3) hmUI.showToast({text: 'Weather'});
        }

        function click_elemente3() {
             elementnumber3 = elementnumber_2;
            if(elementnumber3 >=2){elementnumber3 = elementnumber3 - 1 ;}
           
            if (elementnumber3==1){
                UpdateElemente2One();
                }

               if(elementnumber3==2) {
                  UpdateElemente2Two();
                }

               if(elementnumber3==3) {
                  UpdateElemente2Three();
                }
      if(elementnumber_2 >=2){elementnumber_2 = elementnumber_2 -1 ; }

        
            if(elementnumber3==1) hmUI.showToast({text: 'Time'});
            if(elementnumber3==2) hmUI.showToast({text: 'Activity'});
            if(elementnumber3==3) hmUI.showToast({text: 'Weather'});
        }



        //Time
        function UpdateElemente2One(){
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);

        normal2_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal3_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);




        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        normal_image1_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_image2_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_image3_img.setProperty(hmUI.prop.VISIBLE, false);


        }

        //Activity
        function UpdateElemente2Two(){

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);

        normal2_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal2_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal3_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);




        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_image1_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_image2_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_image3_img.setProperty(hmUI.prop.VISIBLE, false);

        }

      //Weather
        function UpdateElemente2Three(){

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);

        normal2_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal3_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal3_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal3_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal3_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal3_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal3_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);




        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_image1_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_image2_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_image3_img.setProperty(hmUI.prop.VISIBLE, true);

        }


 
        //dynamic modify end


        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_image1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 315,
              src: 'line_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 315,
              src: 'line_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image3_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 315,
              src: 'line_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 295,
              week_en: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_tc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              week_sc: ["Week_B_1.png","Week_B_2.png","Week_B_3.png","Week_B_4.png","Week_B_5.png","Week_B_6.png","Week_B_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 106,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PointerOrange.png',
              center_x: 122,
              center_y: 227,
              x: 14,
              y: 53,
              start_angle: 226,
              end_angle: 494,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 261,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_B_Symbo.png',
              unit_tc: 'Batt_B_Symbo.png',
              unit_en: 'Batt_B_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 114,
              font_array: ["Weather_font_0.png","Weather_font_1.png","Weather_font_2.png","Weather_font_3.png","Weather_font_4.png","Weather_font_5.png","Weather_font_6.png","Weather_font_7.png","Weather_font_8.png","Weather_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 100,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PointerBlack.png',
              center_x: 332,
              center_y: 226,
              x: 14,
              y: 53,
              start_angle: 248,
              end_angle: 469,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 261,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 30,
              month_startY: 31,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 304,
              second_startY: 337,
              second_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 363,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 237,
              minute_startY: 322,
              minute_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 130,
              y: 319,
              src: 'topBTAlarm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 322,
              hour_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 322,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 155,
              am_y: 363,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 155,
              pm_y: 363,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 325,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 319,
              src: 'Systemp_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'PointerOrange.png',
              // center_x: 227,
              // center_y: 122,
              // x: 14,
              // y: 53,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });




///////////////////// activity ///////////////////

            normal2_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 126,
              y: 341,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 320,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 297,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_KM.png',
              unit_tc: 'Act_KM.png',
              unit_en: 'Act_KM.png',
              imperial_unit_sc: 'Act_Mi.png',
              imperial_unit_tc: 'Act_Mi.png',
              imperial_unit_en: 'Act_Mi.png',
              dot_image: 'Act_Dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 254,
              y: 283,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 297,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 283,
              src: 'icon_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 170,
              y: 323,
              font_array: ["Step_font_0.png","Step_font_1.png","Step_font_2.png","Step_font_3.png","Step_font_4.png","Step_font_5.png","Step_font_6.png","Step_font_7.png","Step_font_8.png","Step_font_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 124,
              y: 323,
              src: 'icon_Steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal2_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 153,
              y: 362,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


////////////////////////////////////

///////////// weather3 ////////////

           normal3_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 135,
              y: 317,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 290,
              font_array: ["Weather_font_0.png","Weather_font_1.png","Weather_font_2.png","Weather_font_3.png","Weather_font_4.png","Weather_font_5.png","Weather_font_6.png","Weather_font_7.png","Weather_font_8.png","Weather_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 290,
              font_array: ["Weather_font_0.png","Weather_font_1.png","Weather_font_2.png","Weather_font_3.png","Weather_font_4.png","Weather_font_5.png","Weather_font_6.png","Weather_font_7.png","Weather_font_8.png","Weather_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_SymboBig1.png',
              unit_tc: 'Weather_SymboBig1.png',
              unit_en: 'Weather_SymboBig1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 158,
              y: 296,
              src: 'lowhigh.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 324,
              font_array: ["Time_Font_0.png","Time_Font_1.png","Time_Font_2.png","Time_Font_3.png","Time_Font_4.png","Time_Font_5.png","Time_Font_6.png","Time_Font_7.png","Time_Font_8.png","Time_Font_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_SymboBig1.png',
              unit_tc: 'Weather_SymboBig1.png',
              unit_en: 'Weather_SymboBig1.png',
              negative_image: 'Weather_SymboBig2.png',
              invalid_image: 'Weather_SymboBig2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 121,
              y: 319,
              src: 'icon_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal3_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 147,
              y: 364,
              image_array: ["Weather_txt_01.png","Weather_txt_02.png","Weather_txt_03.png","Weather_txt_04.png","Weather_txt_05.png","Weather_txt_06.png","Weather_txt_07.png","Weather_txt_08.png","Weather_txt_09.png","Weather_txt_10.png","Weather_txt_11.png","Weather_txt_12.png","Weather_txt_13.png","Weather_txt_14.png","Weather_txt_15.png","Weather_txt_16.png","Weather_txt_17.png","Weather_txt_18.png","Weather_txt_19.png","Weather_txt_20.png","Weather_txt_21.png","Weather_txt_22.png","Weather_txt_23.png","Weather_txt_24.png","Weather_txt_25.png","Weather_txt_26.png","Weather_txt_27.png","Weather_txt_28.png","Weather_txt_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 122 - 53,
              center_x: 227,
              center_y: 122,
              src: 'PointerOrange.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Black_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 31,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Black_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec_Orange.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 31,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'mainAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 325,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 311,
              y: 319,
              src: 'Systemp_W_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 160,
              y: 295,
              week_en: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              week_tc: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              week_sc: ["Week_W_1.png","Week_W_2.png","Week_W_3.png","Week_W_4.png","Week_W_5.png","Week_W_6.png","Week_W_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 106,
              day_sc_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_tc_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_en_array: ["Day_B0.png","Day_B1.png","Day_B2.png","Day_B3.png","Day_B4.png","Day_B5.png","Day_B6.png","Day_B7.png","Day_B8.png","Day_B9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PointerOrange.png',
              center_x: 122,
              center_y: 227,
              x: 14,
              y: 53,
              start_angle: 226,
              end_angle: 494,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 261,
              font_array: ["Act_Small_0.png","Act_Small_1.png","Act_Small_2.png","Act_Small_3.png","Act_Small_4.png","Act_Small_5.png","Act_Small_6.png","Act_Small_7.png","Act_Small_8.png","Act_Small_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_B_Symbo.png',
              unit_tc: 'Batt_B_Symbo.png',
              unit_en: 'Batt_B_Symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 114,
              font_array: ["Weather_font_0.png","Weather_font_1.png","Weather_font_2.png","Weather_font_3.png","Weather_font_4.png","Weather_font_5.png","Weather_font_6.png","Weather_font_7.png","Weather_font_8.png","Weather_font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 100,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'PointerOrange.png',
              center_x: 332,
              center_y: 226,
              x: 14,
              y: 53,
              start_angle: 248,
              end_angle: 469,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 261,
              font_array: ["Act_white_small_0.png","Act_white_small_1.png","Act_white_small_2.png","Act_white_small_3.png","Act_white_small_4.png","Act_white_small_5.png","Act_white_small_6.png","Act_white_small_7.png","Act_white_small_8.png","Act_white_small_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 31,
              month_startY: 30,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 304,
              second_startY: 337,
              second_array: ["Act_white_small_0.png","Act_white_small_1.png","Act_white_small_2.png","Act_white_small_3.png","Act_white_small_4.png","Act_white_small_5.png","Act_white_small_6.png","Act_white_small_7.png","Act_white_small_8.png","Act_white_small_9.png"],
              second_zero: 1,
              second_space: 1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 363,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 237,
              minute_startY: 322,
              minute_array: ["Time_W_Font_0.png","Time_W_Font_1.png","Time_W_Font_2.png","Time_W_Font_3.png","Time_W_Font_4.png","Time_W_Font_5.png","Time_W_Font_6.png","Time_W_Font_7.png","Time_W_Font_8.png","Time_W_Font_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 152,
              hour_startY: 322,
              hour_array: ["Time_W_Font_0.png","Time_W_Font_1.png","Time_W_Font_2.png","Time_W_Font_3.png","Time_W_Font_4.png","Time_W_Font_5.png","Time_W_Font_6.png","Time_W_Font_7.png","Time_W_Font_8.png","Time_W_Font_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 322,
              src: 'Time_w_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 155,
              am_y: 363,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 155,
              pm_y: 363,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'PointerOrange.png',
              // center_x: 227,
              // center_y: 122,
              // x: 14,
              // y: 53,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 122 - 53,
              center_x: 227,
              center_y: 122,
              src: 'PointerOrange.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'White_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 31,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'White_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 31,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Sec_Orange.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 31,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 80,
              w: 90,
              h: 90,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 94,
              w: 60,
              h: 60,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////



            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 322,
              w: 34,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 308,
              w: 34,
              h: 46,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 310,
              w: 41,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 221,
              y: 300,
              w: 64,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 282,
              w: 99,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 305,
              w: 32,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 345,
              w: 33,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 250,
              w: 71,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

if (cc==0) {


        normal_image1_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_image2_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_image3_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_hour.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);

        normal2_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal2_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

        normal3_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal3_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);




        normal_countdown_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


cc = 1
}



///////////////////////////////

           // Change background shortcut start
            btn_element_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 94,
              y: 94,
              text: '',
              w: 60,
              h: 60,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_1.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end


           // Change background shortcut start
            btn_element_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 93,
              y: 324,
              text: '',
              w: 30,
              h: 30,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente2();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end


           // Change background shortcut start
            btn_element3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 336,
              y: 324,
              text: '',
              w: 30,
              h: 30,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente3();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element3.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end


  //////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 207,
              y: 406,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////

           // Change background shortcut start
            btn_element_4= hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 209,
              text: '',
              w: 30,
              h: 30,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente4();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_2.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}