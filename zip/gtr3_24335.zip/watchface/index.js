﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_image_progress_img_progress = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_stress_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_pai_image_progress_img_level = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_stress_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 352,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 5,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 351,
              src: 'sun_0078.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 353,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 344,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [203],
              y: [345],
              image_array: ["SUN_0090.png"],
              image_length: 1,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 37,
              y: 197,
              src: 'pp_0116.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 128,
              src: 'pp_0032.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 161,
              src: 'pp_0033.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 152,
              y: 379,
              image_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              image_length: 9,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 25,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 24,
              image_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 308,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 300,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 248,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 317,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 317,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 271,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 225,
              image_array: ["wat_0039.png","wat_0040.png","wat_0041.png","wat_0042.png","wat_0043.png","wat_0044.png","wat_0045.png","wat_0046.png","wat_0047.png","wat_0048.png","wat_0049.png","wat_0050.png","wat_0051.png","wat_0052.png","wat_0053.png","wat_0054.png","wat_0055.png","wat_0056.png","wat_0057.png","wat_0058.png","wat_0059.png","wat_0060.png","wat_0061.png","wat_0062.png","wat_0063.png","wat_0064.png","wat_0065.png","wat_0066.png","wat_0067.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 146,
              y: 405,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 49,
              week_en: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png"],
              week_tc: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png"],
              week_sc: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 293,
              year_startY: 180,
              year_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 180,
              month_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 180,
              day_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 268,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SUN_0093.png',
              unit_tc: 'SUN_0093.png',
              unit_en: 'SUN_0093.png',
              dot_image: 'SUN_0092.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 238,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 419,
              y: 237,
              image_array: ["PO_001.png","PO_002.png","PO_003.png","PO_004.png","PO_005.png","PO_006.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 91,
              hour_array: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 221,
              minute_startY: 91,
              minute_array: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 339,
              second_startY: 108,
              second_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 37,
              y: 197,
              src: 'pp_0116.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 42,
              y: 128,
              src: 'pp_0032.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 35,
              y: 161,
              src: 'pp_0033.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 152,
              y: 379,
              image_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png"],
              image_length: 9,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 354,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 95,
              y: 345,
              src: 'SUN_0090.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 354,
              font_array: ["sun_0054.png","sun_0055.png","sun_0056.png","sun_0057.png","sun_0058.png","sun_0059.png","sun_0060.png","sun_0061.png","sun_0062.png","sun_0063.png"],
              padding: false,
              h_space: 0,
              dot_image: 'sun_0078.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 345,
              src: 'SUN_0091.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '3.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 224,
              y: 25,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 24,
              image_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 346,
              y: 308,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 300,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 248,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 317,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 112,
              y: 317,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 271,
              font_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              padding: false,
              h_space: 0,
              negative_image: '24.png',
              invalid_image: '24.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 37,
              y: 225,
              image_array: ["wat_0039.png","wat_0040.png","wat_0041.png","wat_0042.png","wat_0043.png","wat_0044.png","wat_0045.png","wat_0046.png","wat_0047.png","wat_0048.png","wat_0049.png","wat_0050.png","wat_0051.png","wat_0052.png","wat_0053.png","wat_0054.png","wat_0055.png","wat_0056.png","wat_0057.png","wat_0058.png","wat_0059.png","wat_0060.png","wat_0061.png","wat_0062.png","wat_0063.png","wat_0064.png","wat_0065.png","wat_0066.png","wat_0067.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 152,
              y: 47,
              week_en: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              week_tc: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              week_sc: ["cz_0069.png","cz_0070.png","cz_0071.png","cz_0072.png","cz_0073.png","cz_0074.png","cz_0075.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 293,
              year_startY: 180,
              year_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 207,
              month_startY: 180,
              month_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 118,
              day_startY: 180,
              day_sc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_tc_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_en_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 268,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SUN_0093.png',
              unit_tc: 'SUN_0093.png',
              unit_en: 'SUN_0093.png',
              dot_image: 'SUN_0092.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 306,
              y: 238,
              font_array: ["85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 419,
              y: 237,
              image_array: ["PO_001.png","PO_002.png","PO_003.png","PO_004.png","PO_005.png","PO_006.png"],
              image_length: 6,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 87,
              hour_startY: 91,
              hour_array: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 221,
              minute_startY: 91,
              minute_array: ["4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 339,
              second_startY: 108,
              second_array: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  