﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_pointer_progress_img_pointer = ''
        let normal_stand_target_TextRotate = new Array(2);
        let normal_stand_target_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_target_TextRotate_img_width = 21;
        let normal_stand_target_TextRotate_error_img_width = 14;
        let normal_stand_TextRotate = new Array(2);
        let normal_stand_TextRotate_ASCIIARRAY = new Array(10);
        let normal_stand_TextRotate_img_width = 21;
        let normal_stand_TextRotate_unit = null;
        let normal_stand_TextRotate_unit_width = 21;
        let normal_stand_TextRotate_error_img_width = 14;
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_TextRotate = new Array(3);
        let normal_heart_rate_TextRotate_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextRotate_img_width = 21;
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_TextRotate = new Array(3);
        let normal_battery_TextRotate_ASCIIARRAY = new Array(10);
        let normal_battery_TextRotate_img_width = 21;
        let normal_calorie_circle_scale = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 21;
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 21;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 397,
              y: 277,
              src: 'icon_9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 24,
              y: 274,
              src: 'icon_8.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 125,
              week_en: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_tc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              week_sc: ["dia_1.png","dia_2.png","dia_3.png","dia_4.png","dia_5.png","dia_6.png","dia_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 186,
              // end_angle: 246,
              // radius: 215,
              // line_width: 25,
              // line_cap: Rounded,
              // color: 0xFF20ADFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 186,
              end_angle: 246,
              radius: 203,
              line_width: 25,
              corner_flag: 0,
              color: 0xFF20ADFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_stand_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'color_4.png',
              center_x: 227,
              center_y: 227,
              x: 21,
              y: 227,
              start_angle: 186,
              end_angle: 246,
              invalid_visible: false,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_target_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 185,
              // y: 368,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 30,
              // invalid_image: 'icon_2.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_target_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_stand_target_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_target_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 185,
                center_y: 368,
                pos_x: 185,
                pos_y: 368,
                angle: 30,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_target_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_stand_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 134,
              // y: 335,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 36,
              // unit_en: 'icon_4.png',
              // invalid_image: 'icon_2.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_stand_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_stand_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 134,
                center_y: 335,
                pos_x: 134,
                pos_y: 335,
                angle: 36,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_stand_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 134,
              center_y: 335,
              pos_x: 134,
              pos_y: 335,
              angle: 36,
              src: 'icon_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -102,
              // end_angle: -42,
              // radius: 215,
              // line_width: 25,
              // line_cap: Rounded,
              // color: 0xFFE8003A,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -102,
              end_angle: -42,
              radius: 203,
              line_width: 25,
              corner_flag: 0,
              color: 0xFFE8003A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'color_5.png',
              center_x: 227,
              center_y: 227,
              x: 21,
              y: 227,
              start_angle: -102,
              end_angle: -42,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 72,
              // y: 161,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -68,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_heart_rate_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 72,
                center_y: 161,
                pos_x: 72,
                pos_y: 161,
                angle: -68,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 114,
              // end_angle: 174,
              // radius: 215,
              // line_width: 25,
              // line_cap: Rounded,
              // color: 0xFF40FF1B,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 114,
              end_angle: 174,
              radius: 203,
              line_width: 25,
              corner_flag: 0,
              color: 0xFF40FF1B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'color_3.png',
              center_x: 227,
              center_y: 227,
              x: 21,
              y: 227,
              start_angle: 114,
              end_angle: 174,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 319,
              // y: 334,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: -40,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_battery_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 319,
                center_y: 334,
                pos_x: 319,
                pos_y: 334,
                angle: -40,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 41,
              // end_angle: 102,
              // radius: 215,
              // line_width: 25,
              // line_cap: Rounded,
              // color: 0xFFFFE526,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 41,
              end_angle: 102,
              radius: 203,
              line_width: 25,
              corner_flag: 0,
              color: 0xFFFFE526,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'color_2.png',
              center_x: 227,
              center_y: 227,
              x: 21,
              y: 227,
              start_angle: 41,
              end_angle: 102,
              invalid_visible: false,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 390,
              // y: 182,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 77,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 390,
                center_y: 182,
                pos_x: 390,
                pos_y: 182,
                angle: 77,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 124,
              day_sc_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              day_tc_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              day_en_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 164,
              y: 273,
              image_array: ["clima_1.png","clima_2.png","clima_3.png","clima_4.png","clima_5.png","clima_6.png","clima_7.png","clima_8.png","clima_9.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 289,
              font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_1.png',
              unit_tc: 'icon_1.png',
              unit_en: 'icon_1.png',
              negative_image: 'icon_2.png',
              invalid_image: 'icon_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: -31,
              // end_angle: 30,
              // radius: 215,
              // line_width: 24,
              // line_cap: Rounded,
              // color: 0xFFFF7900,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: -31,
              end_angle: 30,
              radius: 203,
              line_width: 24,
              corner_flag: 0,
              color: 0xFFFF7900,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'color_1.png',
              center_x: 227,
              center_y: 227,
              x: 21,
              y: 227,
              start_angle: -30,
              end_angle: 30,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 247,
              // y: 62,
              // font_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: -1,
              // angle: 5,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'numD_0.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'numD_1.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'numD_2.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'numD_3.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'numD_4.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'numD_5.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'numD_6.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'numD_7.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'numD_8.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'numD_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 247,
                center_y: 62,
                pos_x: 247,
                pos_y: 62,
                angle: 5,
                src: 'numD_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 107,
              am_y: 206,
              am_sc_path: 'icon_6.png',
              am_en_path: 'icon_6.png',
              pm_x: 107,
              pm_y: 206,
              pm_sc_path: 'icon_7.png',
              pm_en_path: 'icon_7.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 137,
              hour_startY: 173,
              hour_array: ["numH_0.png","numH_1.png","numH_2.png","numH_3.png","numH_4.png","numH_5.png","numH_6.png","numH_7.png","numH_8.png","numH_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'icon_5.png',
              hour_unit_tc: 'icon_5.png',
              hour_unit_en: 'icon_5.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 237,
              minute_startY: 193,
              minute_array: ["numH_0.png","numH_1.png","numH_2.png","numH_3.png","numH_4.png","numH_5.png","numH_6.png","numH_7.png","numH_8.png","numH_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 303,
              second_startY: 206,
              second_array: ["numD_0.png","numD_1.png","numD_2.png","numD_3.png","numD_4.png","numD_5.png","numD_6.png","numD_7.png","numD_8.png","numD_9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 107,
              am_y: 206,
              am_sc_path: 'icon_6.png',
              am_en_path: 'icon_6.png',
              pm_x: 107,
              pm_y: 206,
              pm_sc_path: 'icon_7.png',
              pm_en_path: 'icon_7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 137,
              hour_startY: 173,
              hour_array: ["numH_0.png","numH_1.png","numH_2.png","numH_3.png","numH_4.png","numH_5.png","numH_6.png","numH_7.png","numH_8.png","numH_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'icon_5.png',
              hour_unit_tc: 'icon_5.png',
              hour_unit_en: 'icon_5.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 237,
              minute_startY: 193,
              minute_array: ["numH_0.png","numH_1.png","numH_2.png","numH_3.png","numH_4.png","numH_5.png","numH_6.png","numH_7.png","numH_8.png","numH_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 116,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transp.png',
              normal_src: 'transp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 167,
              y: 287,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transp.png',
              normal_src: 'transp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 52,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transp.png',
              normal_src: 'transp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 172,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transp.png',
              normal_src: 'transp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 304,
              y: 326,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'transp.png',
              normal_src: 'transp.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate stand_target_STAND');
              let targetStand = stand.target;
              let normal_stand_target_rotate_string = parseInt(targetStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_target_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (targetStand != null && targetStand != undefined && isFinite(targetStand) && normal_stand_target_rotate_string.length > 0 && normal_stand_target_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_target_TextRotate_posOffset = normal_stand_target_TextRotate_img_width * normal_stand_target_rotate_string.length;
                  img_offset -= normal_stand_target_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_target_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_target_TextRotate[index].setProperty(hmUI.prop.POS_X, 185 + img_offset);
                      normal_stand_target_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_target_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_target_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_target_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_stand_target_TextRotate[0].setProperty(hmUI.prop.POS_X, 185 - normal_stand_target_TextRotate_error_img_width / 2);
                  normal_stand_target_TextRotate[0].setProperty(hmUI.prop.SRC, 'icon_2.png');
                  normal_stand_target_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate stand_STAND');
              let valueStand = stand.current;
              let normal_stand_rotate_string = parseInt(valueStand).toString();
              normal_stand_rotate_string = normal_stand_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_rotate_string.length > 0 && normal_stand_rotate_string.length <= 2) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_stand_TextRotate_posOffset = normal_stand_TextRotate_img_width * normal_stand_rotate_string.length;
                  img_offset -= normal_stand_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_stand_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.POS_X, 134 + img_offset);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.SRC, normal_stand_TextRotate_ASCIIARRAY[charCode]);
                      normal_stand_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_stand_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.POS_X, 134 + img_offset);
                  normal_stand_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_stand_TextRotate[0].setProperty(hmUI.prop.POS_X, 134 - normal_stand_TextRotate_error_img_width / 2);
                  normal_stand_TextRotate[0].setProperty(hmUI.prop.SRC, 'icon_2.png');
                  normal_stand_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_rotate_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_rotate_string.length > 0 && normal_heart_rate_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_img_width * normal_heart_rate_rotate_string.length;
                  normal_heart_rate_TextRotate_posOffset = normal_heart_rate_TextRotate_posOffset + 1 * (normal_heart_rate_rotate_string.length - 1);
                  img_offset -= normal_heart_rate_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_heart_rate_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.POS_X, 72 + img_offset);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextRotate_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_heart_rate_TextRotate_img_width + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_rotate_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_rotate_string.length > 0 && normal_battery_rotate_string.length <= 3) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_battery_TextRotate_posOffset = normal_battery_TextRotate_img_width * normal_battery_rotate_string.length;
                  img_offset -= normal_battery_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_battery_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.POS_X, 319 + img_offset);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.SRC, normal_battery_TextRotate_ASCIIARRAY[charCode]);
                      normal_battery_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_battery_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 390 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + -1 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 247 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 186,
                      end_angle: 246,
                      radius: 203,
                      line_width: 25,
                      corner_flag: 0,
                      color: 0xFF20ADFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -102,
                      end_angle: -42,
                      radius: 203,
                      line_width: 25,
                      corner_flag: 0,
                      color: 0xFFE8003A,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 114,
                      end_angle: 174,
                      radius: 203,
                      line_width: 25,
                      corner_flag: 0,
                      color: 0xFF40FF1B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 41,
                      end_angle: 102,
                      radius: 203,
                      line_width: 25,
                      corner_flag: 0,
                      color: 0xFFFFE526,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: -31,
                      end_angle: 30,
                      radius: 203,
                      line_width: 24,
                      corner_flag: 0,
                      color: 0xFFFF7900,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}