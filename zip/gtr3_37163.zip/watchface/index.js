﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_frame_animation_1 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_image_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 314,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 320,
              src: 'System_Alarm2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 252,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 255,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 129,
              y: 279,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 170,
              y: 104,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "heart",
              anim_fps: 7,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 104,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 4,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 204,
              month_startY: 346,
              month_sc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_tc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_en_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 322,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 218,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 128,
              y: 185,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 139,
              image_array: ["Batt_icon01.png","Batt_icon02.png","Batt_icon03.png","Batt_icon04.png","Batt_icon05.png","Batt_icon06.png","Batt_icon07.png","Batt_icon08.png","Batt_icon09.png","Batt_icon10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 174,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Act_font_KM.png',
              unit_tc: 'Act_font_KM.png',
              unit_en: 'Act_font_KM.png',
              imperial_unit_sc: 'Act_font_MI.png',
              imperial_unit_tc: 'Act_font_MI.png',
              imperial_unit_en: 'Act_font_MI.png',
              dot_image: 'Act_Font_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 171,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 147,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 145,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 219,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 171,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 139,
              image_array: ["Step_img01.png","Step_img02.png","Step_img03.png","Step_img04.png","Step_img05.png","Step_img06.png","Step_img07.png","Step_img08.png","Step_img09.png","Step_img10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 287,
              week_en: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              week_tc: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              week_sc: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 96,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '24circle_1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 224,
              // y: 224,
              // start_angle: 360,
              // end_angle: 0,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 224,
              pos_y: 227 - 224,
              center_x: 227,
              center_y: 227,
              src: '24circle_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0_Empty.png',
              // center_x: 0,
              // center_y: 0,
              // x: 0,
              // y: 0,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 0 - 0,
              pos_y: 0 - 0,
              center_x: 0,
              center_y: 0,
              src: '0_Empty.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 291,
              second_startY: 297,
              second_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 313,
              minute_startY: 255,
              minute_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 260,
              hour_startY: 255,
              hour_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 255,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 28,
              hour_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 28,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 187,
              second_cover_path: 'AnalogDot.png',
              second_cover_x: 202,
              second_cover_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 148,
              y: 314,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 292,
              y: 320,
              src: 'System_Alarm2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 214,
              y: 252,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 255,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 129,
              y: 279,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 104,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 4,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 104,
              src: 'heart_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 204,
              month_startY: 346,
              month_sc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_tc_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_en_array: ["0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0198.png","0199.png","0200.png","0201.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 322,
              day_sc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_tc_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_en_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 102,
              y: 218,
              font_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 128,
              y: 185,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 97,
              y: 139,
              image_array: ["Batt_icon01.png","Batt_icon02.png","Batt_icon03.png","Batt_icon04.png","Batt_icon05.png","Batt_icon06.png","Batt_icon07.png","Batt_icon08.png","Batt_icon09.png","Batt_icon10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AODblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 174,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 1,
              angle: 0,
              unit_sc: 'Act_font_KM.png',
              unit_tc: 'Act_font_KM.png',
              unit_en: 'Act_font_KM.png',
              imperial_unit_sc: 'Act_font_MI.png',
              imperial_unit_tc: 'Act_font_MI.png',
              imperial_unit_en: 'Act_font_MI.png',
              dot_image: 'Act_Font_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 171,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 147,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 145,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 268,
              y: 219,
              font_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 171,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 306,
              y: 139,
              image_array: ["Step_img01.png","Step_img02.png","Step_img03.png","Step_img04.png","Step_img05.png","Step_img06.png","Step_img07.png","Step_img08.png","Step_img09.png","Step_img10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 287,
              week_en: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              week_tc: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              week_sc: ["we1.png","we2.png","we3.png","we4.png","we5.png","we6.png","we7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 97,
              y: 96,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '24circle_5.png',
              // center_x: 227,
              // center_y: 227,
              // x: 224,
              // y: 224,
              // start_angle: 360,
              // end_angle: 0,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 224,
              pos_y: 227 - 224,
              center_x: 227,
              center_y: 227,
              src: '24circle_5.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0_Empty.png',
              // center_x: 0,
              // center_y: 0,
              // x: 0,
              // y: 0,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 0 - 0,
              pos_y: 0 - 0,
              center_x: 0,
              center_y: 0,
              src: '0_Empty.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 291,
              second_startY: 297,
              second_array: ["act_font_0.png","act_font_1.png","act_font_2.png","act_font_3.png","act_font_4.png","act_font_5.png","act_font_6.png","act_font_7.png","act_font_8.png","act_font_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 313,
              minute_startY: 255,
              minute_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 260,
              hour_startY: 255,
              hour_array: ["Day_Font_0.png","Day_Font_1.png","Day_Font_2.png","Day_Font_3.png","Day_Font_4.png","Day_Font_5.png","Day_Font_6.png","Day_Font_7.png","Day_Font_8.png","Day_Font_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 255,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 28,
              hour_posY: 187,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 28,
              minute_posY: 187,
              minute_cover_path: 'AODblend.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 187,
              second_cover_path: 'AnalogDot.png',
              second_cover_x: 202,
              second_cover_y: 209,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: НЕТ СВЯЗИ!,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: СВЯЗЬ ЕСТЬ!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "НЕТ СВЯЗИ!"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "СВЯЗЬ ЕСТЬ!"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 254,
              w: 44,
              h: 25,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 255,
              w: 39,
              h: 22,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 282,
              y: 310,
              w: 46,
              h: 37,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 252,
              w: 33,
              h: 31,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 113,
              y: 255,
              w: 66,
              h: 47,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 143,
              w: 98,
              h: 23,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 96,
              w: 41,
              h: 34,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 95,
              w: 75,
              h: 33,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 210,
              w: 87,
              h: 34,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 137,
              w: 66,
              h: 66,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 293,
              w: 76,
              h: 76,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 137,
              w: 66,
              h: 66,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = -360;
                let normal_angle_hour = 360 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = -360;
                let idle_angle_hour = 360 + idle_fullAngle_hour*idle_hour/24 + (idle_fullAngle_hour/24)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}