﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFF7E20, 0xFFFD2323, 0xFFC920FF, 0xFFC0C0C0, 0xFF3DFC42, 0xFF3DA0FC, 0xFF3DF1FC, 0xFFF9A73C, 0xFFE3FC8E, 0xFF3DFD8E];
        let bgColorToastList = ['BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s', 'BG %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //start of ignored block
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
            };
            //end of ignored block

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF00FF80',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 379,
              y: 144,
              src: 'icon_8.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 28,
              y: 135,
              src: 'icon_9.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 120,
              font_array: ["numWH_0.png","numWH_1.png","numWH_2.png","numWH_3.png","numWH_4.png","numWH_5.png","numWH_6.png","numWH_7.png","numWH_8.png","numWH_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 161,
              y: 40,
              image_array: ["clima_1.png","clima_2.png","clima_3.png","clima_4.png","clima_5.png","clima_6.png","clima_7.png","clima_8.png","clima_9.png","clima_10.png","clima_11.png","clima_12.png","clima_13.png","clima_14.png","clima_15.png","clima_16.png","clima_17.png","clima_18.png","clima_19.png","clima_20.png","clima_21.png","clima_22.png","clima_23.png","clima_24.png","clima_25.png","clima_26.png","clima_27.png","clima_28.png","clima_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 246,
              y: 47,
              font_array: ["numSA_0.png","numSA_1.png","numSA_2.png","numSA_3.png","numSA_4.png","numSA_5.png","numSA_6.png","numSA_7.png","numSA_8.png","numSA_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_3.png',
              unit_tc: 'icon_3.png',
              unit_en: 'icon_3.png',
              negative_image: 'icon_4.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 393,
              font_array: ["numSA_0.png","numSA_1.png","numSA_2.png","numSA_3.png","numSA_4.png","numSA_5.png","numSA_6.png","numSA_7.png","numSA_8.png","numSA_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_2.png',
              unit_tc: 'icon_2.png',
              unit_en: 'icon_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 336,
              font_array: ["numWH_0.png","numWH_1.png","numWH_2.png","numWH_3.png","numWH_4.png","numWH_5.png","numWH_6.png","numWH_7.png","numWH_8.png","numWH_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'icon_1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 336,
              font_array: ["numWH_0.png","numWH_1.png","numWH_2.png","numWH_3.png","numWH_4.png","numWH_5.png","numWH_6.png","numWH_7.png","numWH_8.png","numWH_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 75,
              month_startY: 127,
              month_sc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              month_tc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              month_en_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 67,
              y: 97,
              week_en: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
              week_tc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
              week_sc: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 159,
              day_startY: 108,
              day_sc_array: ["munBL_0.png","munBL_1.png","munBL_2.png","munBL_3.png","munBL_4.png","munBL_5.png","munBL_6.png","munBL_7.png","munBL_8.png","munBL_9.png"],
              day_tc_array: ["munBL_0.png","munBL_1.png","munBL_2.png","munBL_3.png","munBL_4.png","munBL_5.png","munBL_6.png","munBL_7.png","munBL_8.png","munBL_9.png"],
              day_en_array: ["munBL_0.png","munBL_1.png","munBL_2.png","munBL_3.png","munBL_4.png","munBL_5.png","munBL_6.png","munBL_7.png","munBL_8.png","munBL_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 210,
              am_y: 179,
              am_sc_path: 'icon_5.png',
              am_en_path: 'icon_5.png',
              pm_x: 210,
              pm_y: 179,
              pm_sc_path: 'icon_6.png',
              pm_en_path: 'icon_6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 173,
              hour_array: ["numGR_0.png","numGR_1.png","numGR_2.png","numGR_3.png","numGR_4.png","numGR_5.png","numGR_6.png","numGR_7.png","numGR_8.png","numGR_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 173,
              minute_array: ["numBG_0.png","numBG_1.png","numBG_2.png","numBG_3.png","numBG_4.png","numBG_5.png","numBG_6.png","numBG_7.png","numBG_8.png","numBG_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 209,
              second_startY: 256,
              second_array: ["numSA_0.png","numSA_1.png","numSA_2.png","numSA_3.png","numSA_4.png","numSA_5.png","numSA_6.png","numSA_7.png","numSA_8.png","numSA_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 210,
              am_y: 179,
              am_sc_path: 'icon_5.png',
              am_en_path: 'icon_5.png',
              pm_x: 210,
              pm_y: 179,
              pm_sc_path: 'icon_6.png',
              pm_en_path: 'icon_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 50,
              hour_startY: 173,
              hour_array: ["numGR_0.png","numGR_1.png","numGR_2.png","numGR_3.png","numGR_4.png","numGR_5.png","numGR_6.png","numGR_7.png","numGR_8.png","numGR_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 173,
              minute_array: ["numGR_0.png","numGR_1.png","numGR_2.png","numGR_3.png","numGR_4.png","numGR_5.png","numGR_6.png","numGR_7.png","numGR_8.png","numGR_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 3,
              // y: 190,
              // w: 49,
              // h: 70,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'nul.png',
              // normal_src: 'nul.png',
              // color_list: 0xFFFF7E20|0xFFFD2323|0xFFC920FF|0xFFC0C0C0|0xFF3DFC42|0xFF3DA0FC|0xFF3DF1FC|0xFFF9A73C|0xFFE3FC8E|0xFF3DFD8E,
              // toast_list: BG %s|BG %s|BG %s|BG %s|BG %s|BG %s|BG %s|BG %s|BG %s|BG %s,
              // use_crown: False,
              // use_in_AOD: False,
              // vibro: False,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 190,
              w: 49,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'nul.png',
              normal_src: 'nul.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}