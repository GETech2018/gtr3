﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_image_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
   
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analogsmall_clock_time_pointer_second = ''

        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_img_click_calendar = ''
           
        let timeSensor = ''
       // Start color change circle second
        let btn_s_color = ''
        let color_s_number = 1
        let total_s_colors = 3
        let name_s_color = ''

        function click_s_Color() {
            if(color_s_number>=total_s_colors) {
            color_s_number=1;
                }
            else {
                color_s_number=color_s_number+1;
            }
if ( color_s_number == 1) { 
name_s_color = "White"
       normal_analog_clock_pro_second_pointer_img .setProperty(hmUI.prop.SRC, "circle_second.png");  
}

if ( color_s_number == 2) { 
name_s_color = "Black"
       normal_analog_clock_pro_second_pointer_img .setProperty(hmUI.prop.SRC, "circle_second_black.png");  
}
if ( color_s_number == 3) { 
name_s_color = "Orange"
       normal_analog_clock_pro_second_pointer_img .setProperty(hmUI.prop.SRC, "circle_second_orange.png");  
}

hmUI.showToast({text: name_s_color });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });

}

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 3
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }
if ( colornumber == 1) { 
namecolor = "White"
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.SRC, "mask_pulse.png");  
       normal_date_day_separator_img.setProperty(hmUI.prop.SRC, "mask_calendar.png");  
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "mask_digit_time.png");  
}

if ( colornumber == 2) { 
namecolor = "Black"
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.SRC, "mask_pulse_W.png");  
       normal_date_day_separator_img.setProperty(hmUI.prop.SRC, "mask_calendar_W.png");  
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "mask_digit_time_W.png");  
}
if ( colornumber == 3) { 
namecolor = "Orange"
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.SRC, "mask_pulse.png");  
       normal_date_day_separator_img.setProperty(hmUI.prop.SRC, "mask_calendar.png");  
       normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, "mask_digit_time.png");  
}

hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_image_img.setProperty(hmUI.prop.SRC, "bg_" + parseInt(colornumber) + ".png");  


}



      ///////////////////////////// Start handclock change
        let btncbackground = ''
        let cbackgroundnumber = 1
        let ctotalpictures = 4

        function click_cBackground() {
 // if(backgroundnumber==1){
            if(cbackgroundnumber==ctotalpictures) {
            cbackgroundnumber=1;
                cUpdateBackgroundOne();
                }
            else {
                cbackgroundnumber=cbackgroundnumber+1;
                if(cbackgroundnumber==2) {
                  cUpdateBackgroundTwo();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==4) {
                  cUpdateBackgroundFour();
                }


            }
            if(cbackgroundnumber==1) hmUI.showToast({text: 'Hand Orange'});
            if(cbackgroundnumber==2) hmUI.showToast({text: 'Hand Black'});
            if(cbackgroundnumber==3) hmUI.showToast({text: 'Hand Gray'});
            if(cbackgroundnumber==4) hmUI.showToast({text: 'Hand White'});
 
        }
// }
  


       //Hand clock change
        function cUpdateBackgroundOne(){
           normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'hands_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'hands_minute.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'hands_seconds_s.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }
        function cUpdateBackgroundTwo(){
           normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'hands_hour_B.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'hands_minute_B.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'hands_seconds_B.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }
        function cUpdateBackgroundThree(){
           normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'hands_hour_G.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'hands_minute_G.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'hands_seconds_s.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }
        function cUpdateBackgroundFour(){
           normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'hands_hour_W.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'hands_minute_W.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'hands_seconds_red.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        }


//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Heart Rate'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calendar'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Digital Time'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Heart Rate
        function UpdateBackgroundOne(){
        normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analogsmall_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);


       normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_img_click_calendar.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calendar
        function UpdateBackgroundTwo(){

        normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analogsmall_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, true);


       normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_img_click_calendar.setProperty(hmUI.prop.VISIBLE, true);

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Digital Time
        function UpdateBackgroundThree(){

        normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_analogsmall_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);


       normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_img_click_calendar.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////





        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'circle_second.png',
              // center_x: 227,
              // center_y: 227,
              // x: 145,
              // y: 145,
              // start_angle: 360,
              // end_angle: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 145,
              pos_y: 227 - 145,
              center_x: 227,
              center_y: 227,
              src: 'circle_second.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (-360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 339,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 66,
              // line_width: 20,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 262,
              src: 'pulse_mask_shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 315,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 239,
              y: 230,
              src: 'mask_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 342,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 159,
              y: 265,
              week_en: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_tc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_sc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 343,
              day_sc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_tc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_en_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 232,
              src: 'mask_calendar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 309,
              month_sc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_tc_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_en_array: ["mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png","mon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });





            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 203,
              hour_startY: 309,
              hour_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 203,
              minute_startY: 339,
              minute_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 266,
              src: 'clocks_mini.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 232,
              src: 'mask_digit_time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analogsmall_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second-small.png',
              second_centerX: 227,
              second_centerY: 339,
              second_posX: 59,
              second_posY: 59,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 91,
              // end_angle: -32,
              // radius: 111,
              // line_width: 16,
              // color: 0xFFC0C0C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'steps_point.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 108,
              start_angle: 92,
              end_angle: -30,
              cover_path: 'steps_mask_shadow.png',
              cover_x: 162,
              cover_y: 115,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 115,
              src: 'steps_mask_shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'hands_small.png',
              center_x: 114,
              center_y: 227,
              x: 12,
              y: 54,
              start_angle: 225,
              end_angle: 494,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 79,
              y: 260,
              font_array: ["digits_medium_0.png","digits_medium_1.png","digits_medium_2.png","digits_medium_3.png","digits_medium_4.png","digits_medium_5.png","digits_medium_6.png","digits_medium_7.png","digits_medium_8.png","digits_medium_9.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 91,
              y: 311,
              image_array: ["w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hands_seconds_s.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 15,
              second_posY: 217,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_bg_F.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour_G.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 33,
              hour_posY: 130,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute_G.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              minute_cover_path: 'aod_mask.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth OFF,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 386,
              y: 207,
              w: 57,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 9,
              w: 56,
              h: 65,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_img_click_calendar = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 291,
              w: 84,
              h: 84,
              src: '0_Empty.png', // transparent image
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal_img_click_calendar.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
		hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 300,
              w: 58,
              h: 74,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 300,
              w: 62,
              h: 71,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 370,
              w: 41,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 310,
              w: 60,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 298,
              y: 173,
              w: 40,
              h: 60,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 118,
              w: 117,
              h: 43,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 45)/(targetHeartRate - 45);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                let start_angle_normal_heart_rate = -90;
                  let end_angle_normal_heart_rate = 270;
                  let center_x_normal_heart_rate = 227;
                  let center_y_normal_heart_rate = 339;
                  let radius_normal_heart_rate = 64;
                  let line_width_cs_normal_heart_rate = 19;
                  let color_cs_normal_heart_rate = 0xFFFF8C00;

                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = 1;
                  let end_angle_normal_step = -122;
                  let center_x_normal_step = 227;
                  let center_y_normal_step = 227;
                  let radius_normal_step = 108;
                  let line_width_cs_normal_step = 16;
                  let color_cs_normal_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                let secAngle = 360 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 360 + (-360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });


/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1
        normal_heart_rate_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
 
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_analogsmall_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
 
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, false);


       normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_img_click_calendar.setProperty(hmUI.prop.VISIBLE, false);
}

//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
        btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 407,
              text: '',
              w: 36,
              h: 36,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end


//////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change HandClock shortcut start

            btncbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 200,
              text: '',
              w: 49,
              h: 49,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_cBackground();
              },
              show_level: hmUI.show_level.ALL,
            });
            btncbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change handclock shortcut end


///////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 4,
              y: 201,
              text: '',
              w: 49,
              h: 49,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
 ///////////////////////////////Change color background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btn_s_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 132,
              y: 88,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_s_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_s_color.setProperty(hmUI.prop.VISIBLE, true);
 ///////////////////////////////Change color background shortcut end



                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}