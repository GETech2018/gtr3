    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 370,
              day_startY: 218,
              day_sc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_tc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_en_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 330,
              month_startY: 218,
              month_sc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_tc_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_en_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 68,
              y: 217,
              week_en: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              week_tc: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              week_sc: ["14.png","15.png","16.png","17.png","18.png","19.png","20.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 229,
              y: 127,
              font_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              padding: false,
              h_space: 0,
              invalid_image: '13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 225,
              hour_startY: 309,
              hour_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 285,
              minute_startY: 309,
              minute_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '31.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 30,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '32.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 30,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
           //   second_path: '33.png',
            //  second_centerX: 227,
           //   second_centerY: 227,
          //    second_posX: 30,
           //   second_posY: 224,
           //   show_level: hmUI.show_level.ONLY_NORMAL,
         //   });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 350,
              font_array: ["36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '34.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 30,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '35.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 30,
              minute_posY: 224,
              show_level: hmUI.show_level.ONLY_AOD,
            });
// SMOOTH SECONDS Definition
           let             normal_analog_clock_time_pointer_second = ''          
            // ----------------------------
            let lastTime = 0;
            let animTimer;
            const animDuration = 5000;
            const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
            const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection

            // Smooth Seconds
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    pos_x: 227 - 30,
                    pos_y: 227 - 224,
                    center_x: 227,
                    center_y: 227,
                    src: '33.png',
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                });

            function startSecAnim(sec) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
              }
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
            }

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {  // when the screen turns on, create a timer to update the animation
                console.log('ui resume');

                const screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.WATCHFACE) return;  // if not the main screen of the dial, then do nothing
                if (animTimer) return;  // if the timer is already running, then do nothing

                let duration = 0;
                const diffTime = now.utc - lastTime;
                if (diffTime < animDuration) {
                  duration = animDuration - diffTime;  // we calculate the timer start delay, depending on the time of its last start (so that there is no overlap of two animations)
                }

                console.log('createTimer');
                animTimer = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = now.utc;
                  let sec = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);  // we calculate the angle of the second hand depending on the seconds and milliseconds.
                  startSecAnim(sec);
                }));
              }),
              pause_call: (function () {  // when the screen turns off, delete the timer
                console.log('ui pause');
                if (animTimer) {
                  timer.stopTimer(animTimer);
                  animTimer = undefined;
                }
              }),
            });
            // SMOOTH SECONDS Definition End

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
