﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_stress_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_stress_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -7,
              y: -178,
              src: 'Back_0017 (Custom) (Custom).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 389,
              font_array: ["small_fami_digi_10_0001.png","small_fami_digi_10_0002.png","small_fami_digi_10_0003.png","small_fami_digi_10_0004.png","small_fami_digi_10_0005.png","small_fami_digi_10_0006.png","small_fami_digi_10_0007.png","small_fami_digi_10_0008.png","small_fami_digi_10_0009.png","small_fami_digi_10_0010.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 173,
              y: 376,
              src: 'Powericture80.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 42,
              week_en: ["day_fami_digi_10_0001.png","day_fami_digi_10_0002.png","day_fami_digi_10_0003.png","day_fami_digi_10_0004.png","day_fami_digi_10_0005.png","day_fami_digi_10_0006.png","day_fami_digi_10_0007.png"],
              week_tc: ["day_fami_digi_10_0001.png","day_fami_digi_10_0002.png","day_fami_digi_10_0003.png","day_fami_digi_10_0004.png","day_fami_digi_10_0005.png","day_fami_digi_10_0006.png","day_fami_digi_10_0007.png"],
              week_sc: ["day_fami_digi_10_0001.png","day_fami_digi_10_0002.png","day_fami_digi_10_0003.png","day_fami_digi_10_0004.png","day_fami_digi_10_0005.png","day_fami_digi_10_0006.png","day_fami_digi_10_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 10,
              day_sc_array: ["small_fami_digi_10_0001.png","small_fami_digi_10_0002.png","small_fami_digi_10_0003.png","small_fami_digi_10_0004.png","small_fami_digi_10_0005.png","small_fami_digi_10_0006.png","small_fami_digi_10_0007.png","small_fami_digi_10_0008.png","small_fami_digi_10_0009.png","small_fami_digi_10_0010.png"],
              day_tc_array: ["small_fami_digi_10_0001.png","small_fami_digi_10_0002.png","small_fami_digi_10_0003.png","small_fami_digi_10_0004.png","small_fami_digi_10_0005.png","small_fami_digi_10_0006.png","small_fami_digi_10_0007.png","small_fami_digi_10_0008.png","small_fami_digi_10_0009.png","small_fami_digi_10_0010.png"],
              day_en_array: ["small_fami_digi_10_0001.png","small_fami_digi_10_0002.png","small_fami_digi_10_0003.png","small_fami_digi_10_0004.png","small_fami_digi_10_0005.png","small_fami_digi_10_0006.png","small_fami_digi_10_0007.png","small_fami_digi_10_0008.png","small_fami_digi_10_0009.png","small_fami_digi_10_0010.png"],
              day_zero: 1,
              day_space: -5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -31,
              minute_startY: -19,
              minute_array: ["fami_digi_58_0001.png","fami_digi_58_0002.png","fami_digi_58_0003.png","fami_digi_58_0004.png","fami_digi_58_0005.png","fami_digi_58_0006.png","fami_digi_58_0007.png","fami_digi_58_0008.png","fami_digi_58_0009.png","fami_digi_58_0010.png"],
              minute_zero: 1,
              minute_space: -61,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 113,
              hour_array: ["Hour_fami_digi_10_0001.png","Hour_fami_digi_10_0002.png","Hour_fami_digi_10_0003.png","Hour_fami_digi_10_0004.png","Hour_fami_digi_10_0005.png","Hour_fami_digi_10_0006.png","Hour_fami_digi_10_0007.png","Hour_fami_digi_10_0008.png","Hour_fami_digi_10_0009.png","Hour_fami_digi_10_0010.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 196,
              y: 412,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: -31,
              minute_startY: -19,
              minute_array: ["fami_digi_58_0001.png","fami_digi_58_0002.png","fami_digi_58_0003.png","fami_digi_58_0004.png","fami_digi_58_0005.png","fami_digi_58_0006.png","fami_digi_58_0007.png","fami_digi_58_0008.png","fami_digi_58_0009.png","fami_digi_58_0010.png"],
              minute_zero: 1,
              minute_space: -61,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 113,
              hour_array: ["Hour_fami_digi_10_0001.png","Hour_fami_digi_10_0002.png","Hour_fami_digi_10_0003.png","Hour_fami_digi_10_0004.png","Hour_fami_digi_10_0005.png","Hour_fami_digi_10_0006.png","Hour_fami_digi_10_0007.png","Hour_fami_digi_10_0008.png","Hour_fami_digi_10_0009.png","Hour_fami_digi_10_0010.png"],
              hour_zero: 1,
              hour_space: -24,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 159,
              y: 422,
              src: 'logoure102.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOB Overlay - 2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  