﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_wind_text_text_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_spo2_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg2d.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 35,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -17,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 65,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 100,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 99,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -13,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 302,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -10,
              unit_sc: 'Dist002.png',
              unit_tc: 'Dist002.png',
              unit_en: 'Dist002.png',
              dot_image: 'POINT_1.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 141,
              y: 266,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -13,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 210,
              y: 249,
              image_array: ["b0.png","b1.png","b2.png","b3.png","b31.png","b4.png","b41.png","b5.png","b51.png","b6.png","b61.png","b7.png","b71.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 296,
              y: 252,
              week_en: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_tc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_sc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 214,
              year_startY: 136,
              year_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              year_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              year_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              year_zero: 1,
              year_space: -13,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 151,
              month_startY: 136,
              month_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              month_zero: 1,
              month_space: -13,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 87,
              day_startY: 136,
              day_sc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_tc_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_en_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              day_zero: 1,
              day_space: -13,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 66,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -14,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 54,
              y: 94,
              image_array: ["weather0001.png","weather0002.png","weather0003.png","weather0004.png","weather0005.png","weather0006.png","weather0007.png","weather0008.png","weather0009.png","weather0010.png","weather0011.png","weather0012.png","weather0013.png","weather0014.png","weather0015.png","weather0016.png","weather0017.png","weather0018.png","weather0019.png","weather0020.png","weather0021.png","weather0022.png","weather0023.png","weather0024.png","weather0025.png","weather0026.png","weather0027.png","weather0028.png","weather0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 343,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -13,
              unit_sc: 'PROCENT.png',
              unit_tc: 'PROCENT.png',
              unit_en: 'PROCENT.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 379,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: -13,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 83,
              hour_startY: 178,
              hour_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 178,
              minute_array: ["50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 332,
              second_startY: 136,
              second_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              second_zero: 1,
              second_space: -13,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 219,
              y: 185,
              src: '0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 9,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
