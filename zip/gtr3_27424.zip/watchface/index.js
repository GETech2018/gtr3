﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_uvi_text_text_img = ''
        let idle_uvi_image_progress_img_level = ''
        let idle_moon_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_humidity_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 391,
              y: 233,
              src: 'stat_4.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 232,
              src: 'stat_3.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392,
              y: 206,
              src: 'stat_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 335,
              font_array: ["Dstep_0.png","Dstep_1.png","Dstep_2.png","Dstep_3.png","Dstep_4.png","Dstep_5.png","Dstep_6.png","Dstep_7.png","Dstep_8.png","Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 282,
              image_array: ["uf_1.png","uf_2.png","uf_3.png","uf_4.png","uf_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 314,
              image_array: ["lun_0.png","lun_1.png","lun_2.png","lun_3.png","lun_4.png","lun_5.png","lun_6.png","lun_7.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 335,
              font_array: ["Dstep_0.png","Dstep_1.png","Dstep_2.png","Dstep_3.png","Dstep_4.png","Dstep_5.png","Dstep_6.png","Dstep_7.png","Dstep_8.png","Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 282,
              image_array: ["vlag_1.png","vlag_2.png","vlag_3.png","vlag_4.png","vlag_5.png","vlag_6.png","vlag_7.png","vlag_8.png","vlag_9.png","vlag_10.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 122,
              font_array: ["Dstep_0.png","Dstep_1.png","Dstep_2.png","Dstep_3.png","Dstep_4.png","Dstep_5.png","Dstep_6.png","Dstep_7.png","Dstep_8.png","Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 72,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png","cal_7.png","cal_8.png","cal_9.png","cal_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 122,
              font_array: ["Dstep_0.png","Dstep_1.png","Dstep_2.png","Dstep_3.png","Dstep_4.png","Dstep_5.png","Dstep_6.png","Dstep_7.png","Dstep_8.png","Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 72,
              image_array: ["Puls_1.png","Puls_2.png","Puls_3.png","Puls_4.png","Puls_5.png","Puls_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 114,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_10.png',
              unit_tc: 'data_10.png',
              unit_en: 'data_10.png',
              negative_image: 'data_11.png',
              invalid_image: 'data_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 54,
              image_array: ["0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 26,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 22,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 404,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'data_13.png',
              unit_tc: 'data_13.png',
              unit_en: 'data_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 34,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 372,
              font_array: ["Dstep_0.png","Dstep_1.png","Dstep_2.png","Dstep_3.png","Dstep_4.png","Dstep_5.png","Dstep_6.png","Dstep_7.png","Dstep_8.png","Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 301,
              y: 34,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 182,
              y: 167,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 190,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 280,
              minute_startY: 190,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 15,
              hour_posY: 127,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0001.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 20,
              minute_posY: 192,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0005.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 335,
              font_array: ["A_Dstep_0.png","A_Dstep_1.png","A_Dstep_2.png","A_Dstep_3.png","A_Dstep_4.png","A_Dstep_5.png","A_Dstep_6.png","A_Dstep_7.png","A_Dstep_8.png","A_Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 282,
              image_array: ["A_uf_1.png","A_uf_2.png","A_uf_3.png","A_uf_4.png","A_uf_5.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 314,
              image_array: ["A_lun_0.png","A_lun_1.png","A_lun_2.png","A_lun_3.png","A_lun_4.png","A_lun_5.png","A_lun_6.png","A_lun_7.png"],
              image_length: 8,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 335,
              font_array: ["A_Dstep_0.png","A_Dstep_1.png","A_Dstep_2.png","A_Dstep_3.png","A_Dstep_4.png","A_Dstep_5.png","A_Dstep_6.png","A_Dstep_7.png","A_Dstep_8.png","A_Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 282,
              image_array: ["A_vlag_1.png","A_vlag_2.png","A_vlag_3.png","A_vlag_4.png","A_vlag_5.png","A_vlag_6.png","A_vlag_7.png","A_vlag_8.png","A_vlag_9.png","A_vlag_10.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 122,
              font_array: ["A_Dstep_0.png","A_Dstep_1.png","A_Dstep_2.png","A_Dstep_3.png","A_Dstep_4.png","A_Dstep_5.png","A_Dstep_6.png","A_Dstep_7.png","A_Dstep_8.png","A_Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 93,
              y: 72,
              image_array: ["A_cal_1.png","A_cal_2.png","A_cal_3.png","A_cal_4.png","A_cal_5.png","A_cal_6.png","A_cal_7.png","A_cal_8.png","A_cal_9.png","A_cal_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 122,
              font_array: ["A_Dstep_0.png","A_Dstep_1.png","A_Dstep_2.png","A_Dstep_3.png","A_Dstep_4.png","A_Dstep_5.png","A_Dstep_6.png","A_Dstep_7.png","A_Dstep_8.png","A_Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 72,
              image_array: ["A_Puls_1.png","A_Puls_2.png","A_Puls_3.png","A_Puls_4.png","A_Puls_5.png","A_Puls_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 114,
              font_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A_data_10.png',
              unit_tc: 'A_data_10.png',
              unit_en: 'A_data_10.png',
              negative_image: 'A_data_11.png',
              invalid_image: 'A_data_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 54,
              image_array: ["A_0109.png","A_0110.png","A_0111.png","A_0112.png","A_0113.png","A_0114.png","A_0115.png","A_0116.png","A_0117.png","A_0118.png","A_0119.png","A_0120.png","A_0121.png","A_0122.png","A_0123.png","A_0124.png","A_0125.png","A_0126.png","A_0127.png","A_0128.png","A_0129.png","A_0130.png","A_0131.png","A_0132.png","A_0133.png","A_0134.png","A_0135.png","A_0136.png","A_0137.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 187,
              day_startY: 26,
              day_sc_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_tc_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_en_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 22,
              month_sc_array: ["A_m_1.png","A_m_2.png","A_m_3.png","A_m_4.png","A_m_5.png","A_m_6.png","A_m_7.png","A_m_8.png","A_m_9.png","A_m_10.png","A_m_11.png","A_m_12.png"],
              month_tc_array: ["A_m_1.png","A_m_2.png","A_m_3.png","A_m_4.png","A_m_5.png","A_m_6.png","A_m_7.png","A_m_8.png","A_m_9.png","A_m_10.png","A_m_11.png","A_m_12.png"],
              month_en_array: ["A_m_1.png","A_m_2.png","A_m_3.png","A_m_4.png","A_m_5.png","A_m_6.png","A_m_7.png","A_m_8.png","A_m_9.png","A_m_10.png","A_m_11.png","A_m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 404,
              font_array: ["A_data_0.png","A_data_1.png","A_data_2.png","A_data_3.png","A_data_4.png","A_data_5.png","A_data_6.png","A_data_7.png","A_data_8.png","A_data_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'A_data_13.png',
              unit_tc: 'A_data_13.png',
              unit_en: 'A_data_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 17,
              y: 34,
              image_array: ["A_bat_1.png","A_bat_2.png","A_bat_3.png","A_bat_4.png","A_bat_5.png","A_bat_6.png","A_bat_7.png","A_bat_8.png","A_bat_9.png","A_bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 372,
              font_array: ["A_Dstep_0.png","A_Dstep_1.png","A_Dstep_2.png","A_Dstep_3.png","A_Dstep_4.png","A_Dstep_5.png","A_Dstep_6.png","A_Dstep_7.png","A_Dstep_8.png","A_Dstep_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 301,
              y: 34,
              image_array: ["A_step_1.png","A_step_2.png","A_step_3.png","A_step_4.png","A_step_5.png","A_step_6.png","A_step_7.png","A_step_8.png","A_step_9.png","A_step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 182,
              y: 167,
              week_en: ["A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png","A_week_7.png"],
              week_tc: ["A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png","A_week_7.png"],
              week_sc: ["A_week_1.png","A_week_2.png","A_week_3.png","A_week_4.png","A_week_5.png","A_week_6.png","A_week_7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 190,
              hour_array: ["A_H_0.png","A_H_1.png","A_H_2.png","A_H_3.png","A_H_4.png","A_H_5.png","A_H_6.png","A_H_7.png","A_H_8.png","A_H_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 280,
              minute_startY: 190,
              minute_array: ["A_H_0.png","A_H_1.png","A_H_2.png","A_H_3.png","A_H_4.png","A_H_5.png","A_H_6.png","A_H_7.png","A_H_8.png","A_H_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0004.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 15,
              hour_posY: 127,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0002.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 20,
              minute_posY: 192,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  