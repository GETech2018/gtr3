﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_stand_circle_scale = ''
        let normal_stand_icon_img = ''
        let normal_stand_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_img = ''
        let idle_fat_burning_current_text_img = ''
        let idle_stand_circle_scale = ''
        let idle_stand_icon_img = ''
        let idle_stand_current_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 346,
              y: 183,
              src: '0170.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 354,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 354,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 107,
              // center_y: 249,
              // start_angle: 316,
              // end_angle: 400,
              // radius: 60,
              // line_width: 13,
              // color: 0xFF5E0021,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 215,
              font_array: ["0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 253,
              font_array: ["0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 107,
              // center_y: 249,
              // start_angle: 191,
              // end_angle: 292,
              // radius: 61,
              // line_width: 12,
              // color: 0xFF015C5C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 286,
              src: 'icon_stand_big_BW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 253,
              font_array: ["0171.png","0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 48,
              y: 202,
              src: 'icon_kcal_big_BW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 330,
              font_array: ["0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 132,
              y: 202,
              image_array: ["icon_min_big_BW.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 256,
              font_array: ["0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 337,
              y: 256,
              src: '0060.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [297,297,297,297,297],
              y: [234,234,234,234,234],
              image_array: ["0165.png","0166.png","0167.png","0168.png","0169.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 148,
              font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0071.png',
              unit_tc: '0071.png',
              unit_en: '0071.png',
              negative_image: '0072.png',
              invalid_image: '0072.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 95,
              image_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 164,
              month_startY: 99,
              month_sc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_tc_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_en_array: ["0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 241,
              y: 68,
              week_en: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
              week_tc: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
              week_sc: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 142,
              year_startY: 73,
              year_sc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              year_tc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              year_en_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 218,
              day_startY: 73,
              day_sc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              day_tc_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              day_en_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 129,
              hour_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 129,
              minute_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 347,
              second_startY: 137,
              second_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 123,
              src: '0020.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 351,
              y: 112,
              src: '0039.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0002shadow.png',
              hour_centerX: 227,
              hour_centerY: 237,
              hour_posX: 23,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0001shadow.png',
              minute_centerX: 227,
              minute_centerY: 237,
              minute_posX: 21,
              minute_posY: 201,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0003shadow.png',
              second_centerX: 227,
              second_centerY: 237,
              second_posX: 11,
              second_posY: 181,
              second_cover_path: '0004.png',
              second_cover_x: 216,
              second_cover_y: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 47,
              y: 95,
              w: 95,
              h: 95,
              src: 'shortcut.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 304,
              w: 95,
              h: 95,
              src: 'shortcut.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 60,
              y: 202,
              w: 95,
              h: 95,
              src: 'shortcut.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 354,
              font_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 354,
              font_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 107,
              // center_y: 249,
              // start_angle: 307,
              // end_angle: 408,
              // radius: 60,
              // line_width: 9,
              // color: 0xFF353535,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 218,
              font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 250,
              font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 107,
              // center_y: 249,
              // start_angle: 187,
              // end_angle: 289,
              // radius: 60,
              // line_width: 9,
              // color: 0xFF353535,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 99,
              y: 295,
              src: 'icon_stand_BW.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 250,
              font_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 213,
              src: 'icon_kcal_BW.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 330,
              font_array: ["0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 213,
              image_array: ["icon_min_BW.png"],
              image_length: 1,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 166,
              hour_startY: 123,
              hour_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 123,
              minute_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 244,
              y: 123,
              src: '0103.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0002_aod.png',
              hour_centerX: 227,
              hour_centerY: 237,
              hour_posX: 23,
              hour_posY: 150,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0001_aod.png',
              minute_centerX: 227,
              minute_centerY: 237,
              minute_posX: 21,
              minute_posY: 201,
              minute_cover_path: '0004_aod.png',
              minute_cover_x: 216,
              minute_cover_y: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = 226;
                  let end_angle_normal_calorie = 310;
                  let center_x_normal_calorie = 107;
                  let center_y_normal_calorie = 249;
                  let radius_normal_calorie = 60;
                  let line_width_cs_normal_calorie = 13;
                  let color_cs_normal_calorie = 0xFF5E0021;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale
                  // initial parameters
                  let start_angle_normal_stand = 101;
                  let end_angle_normal_stand = 202;
                  let center_x_normal_stand = 107;
                  let center_y_normal_stand = 249;
                  let radius_normal_stand = 61;
                  let line_width_cs_normal_stand = 12;
                  let color_cs_normal_stand = 0xFF015C5C;
                  
                  // calculated parameters
                  let arcX_normal_stand = center_x_normal_stand - radius_normal_stand;
                  let arcY_normal_stand = center_y_normal_stand - radius_normal_stand;
                  let CircleWidth_normal_stand = 2 * radius_normal_stand;
                  let angle_offset_normal_stand = end_angle_normal_stand - start_angle_normal_stand;
                  angle_offset_normal_stand = angle_offset_normal_stand * progress_cs_normal_stand;
                  let end_angle_normal_stand_draw = start_angle_normal_stand + angle_offset_normal_stand;
                  
                  normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_stand,
                    y: arcY_normal_stand,
                    w: CircleWidth_normal_stand,
                    h: CircleWidth_normal_stand,
                    start_angle: start_angle_normal_stand,
                    end_angle: end_angle_normal_stand_draw,
                    color: color_cs_normal_stand,
                    line_width: line_width_cs_normal_stand,
                  });
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale
                  // initial parameters
                  let start_angle_idle_calorie = 217;
                  let end_angle_idle_calorie = 318;
                  let center_x_idle_calorie = 107;
                  let center_y_idle_calorie = 249;
                  let radius_idle_calorie = 60;
                  let line_width_cs_idle_calorie = 9;
                  let color_cs_idle_calorie = 0xFF353535;
                  
                  // calculated parameters
                  let arcX_idle_calorie = center_x_idle_calorie - radius_idle_calorie;
                  let arcY_idle_calorie = center_y_idle_calorie - radius_idle_calorie;
                  let CircleWidth_idle_calorie = 2 * radius_idle_calorie;
                  let angle_offset_idle_calorie = end_angle_idle_calorie - start_angle_idle_calorie;
                  angle_offset_idle_calorie = angle_offset_idle_calorie * progress_cs_idle_calorie;
                  let end_angle_idle_calorie_draw = start_angle_idle_calorie + angle_offset_idle_calorie;
                  
                  idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_calorie,
                    y: arcY_idle_calorie,
                    w: CircleWidth_idle_calorie,
                    h: CircleWidth_idle_calorie,
                    start_angle: start_angle_idle_calorie,
                    end_angle: end_angle_idle_calorie_draw,
                    color: color_cs_idle_calorie,
                    line_width: line_width_cs_idle_calorie,
                  });
                };

                console.log('update scales STAND');
                let progress_cs_idle_stand = progressStand;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_stand_circle_scale
                  // initial parameters
                  let start_angle_idle_stand = 97;
                  let end_angle_idle_stand = 199;
                  let center_x_idle_stand = 107;
                  let center_y_idle_stand = 249;
                  let radius_idle_stand = 60;
                  let line_width_cs_idle_stand = 9;
                  let color_cs_idle_stand = 0xFF353535;
                  
                  // calculated parameters
                  let arcX_idle_stand = center_x_idle_stand - radius_idle_stand;
                  let arcY_idle_stand = center_y_idle_stand - radius_idle_stand;
                  let CircleWidth_idle_stand = 2 * radius_idle_stand;
                  let angle_offset_idle_stand = end_angle_idle_stand - start_angle_idle_stand;
                  angle_offset_idle_stand = angle_offset_idle_stand * progress_cs_idle_stand;
                  let end_angle_idle_stand_draw = start_angle_idle_stand + angle_offset_idle_stand;
                  
                  idle_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_stand,
                    y: arcY_idle_stand,
                    w: CircleWidth_idle_stand,
                    h: CircleWidth_idle_stand,
                    start_angle: start_angle_idle_stand,
                    end_angle: end_angle_idle_stand_draw,
                    color: color_cs_idle_stand,
                    line_width: line_width_cs_idle_stand,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  