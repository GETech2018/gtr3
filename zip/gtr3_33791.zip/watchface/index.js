﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'conn_tag_aodg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 113,
              font_array: ["0053a.png","0054a.png","0055a.png","0056a.png","0057a.png","0058a.png","0059a.png","0060a.png","0061a.png","0062a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 113,
              font_array: ["0053a.png","0054a.png","0055a.png","0056a.png","0057a.png","0058a.png","0059a.png","0060a.png","0061a.png","0062a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 285,
              year_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 199,
              month_startY: 285,
              month_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 128,
              day_startY: 285,
              day_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 361,
              src: '0063a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 355,
              font_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 187,
              hour_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 187,
              minute_startY: 187,
              minute_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 292,
              second_startY: 187,
              second_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'conn_tag_green.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 76,
              y: 113,
              font_array: ["0053a.png","0054a.png","0055a.png","0056a.png","0057a.png","0058a.png","0059a.png","0060a.png","0061a.png","0062a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 113,
              font_array: ["0053a.png","0054a.png","0055a.png","0056a.png","0057a.png","0058a.png","0059a.png","0060a.png","0061a.png","0062a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 285,
              year_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 199,
              month_startY: 285,
              month_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 128,
              day_startY: 285,
              day_sc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_tc_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_en_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 361,
              src: '0063a.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 186,
              y: 355,
              font_array: ["0043a.png","0044a.png","0045a.png","0046a.png","0047a.png","0048a.png","0049a.png","0050a.png","0051a.png","0052a.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 81,
              hour_startY: 187,
              hour_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 187,
              minute_startY: 187,
              minute_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 292,
              second_startY: 187,
              second_array: ["0003a.png","0004a.png","0005a.png","0006a.png","0007a.png","0008a.png","0009a.png","0010a.png","0011a.png","0012a.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 196,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 193,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 176,
              y: 192,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 350,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 88,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 88,
              w: 100,
              h: 100,
              src: 'atajos.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
