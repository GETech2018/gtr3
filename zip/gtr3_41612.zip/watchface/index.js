﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// INCIO DE FUNCION PERSONALIZADO
let currentColorIndex = 0;
const colorNames = [
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    "Ok",
    // "BLUE STYLE",
    // "BLACK STYLE",
    // "INDIGO STYLE",
    // "GREEN STYLE",
    // "RED STYLE",
    // "BRONZE STYLE"
];
const totalColors = colorNames.length;

// Función para manejar el cambio de color
function click_Color() {
    // Incrementar índice y reiniciar si es necesario
    currentColorIndex = (currentColorIndex + 1) % totalColors;

    // Obtener el nombre del color actual
    const currentColorName = colorNames[currentColorIndex];

    // Mostrar mensaje en pantalla
    hmUI.showToast({ text: currentColorName });

    // Actualizar imagen correspondiente
    normal_background_bg_img.setProperty(hmUI.prop.SRC, `main_${currentColorIndex + 1}.png`);
}

let currentArrowIndex = 0;
const arrows = [
    "Ok",
    "Ok",
    "Ok",
    "Ok",
];

const totalArrows = arrows.length;

// Función para cambiar puntero
function click_Arrow() {
    // Incrementar índice y reiniciar si es necesario
    currentArrowIndex = (currentArrowIndex + 1) % totalArrows;

    // Obtener el nombre del color actual
    const currentArrowName = colorNames[currentArrowIndex];

    // Mostrar mensaje en pantalla
    // hmUI.showToast({ text: currentArrowName });

    // Actualizar imagen SEGUNDO
    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, `seg_0${currentArrowIndex + 1}.png`);
    // // Actualizar imagen MINUTO
    // normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
    //     minute_path: `min_0${currentArrowIndex + 1}.png`,
    //     minute_centerX: 227,
    //     minute_centerY: 227,
    //     minute_posX: 25,
    //     minute_posY: 212,
    //     show_level: hmUI.show_level.ONLY_NORMAL,
    // });
    // // Actualizar imagen HORA
    // normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
    //     hour_path: `hor_0${currentArrowIndex + 1}.png`,
    //     hour_centerX: 227,
    //     hour_centerY: 227,
    //     hour_posX: 27,
    //     hour_posY: 141,
    //     show_level: hmUI.show_level.ONLY_NORMAL,
    // });
    click_cahe();
}

// FIN FUNCION PERSONALIZADA

///NUEVA FUNCION
let elementdate_1 = 1;
const total_elemente = 4;

// Función principal para manejar clicks
function click_cahe() {
    // Incrementar contador
    if (elementdate_1 === total_elemente) {
        elementdate_1 = 1;
    } else {
        elementdate_1 = elementdate_1 + 1;
    }

    // Actualizar visibilidad basada en el contador
    updateVisibility(elementdate_1);
}

// Función centralizada para actualizar visibilidad
function updateVisibility(elementNumber) {
    // Arrays con todas las referencias a elementos
    const minElements = [
        normal_analog_clock_time_pointer_minute,
        normal_analog_clock_time_pointer_minute_2,
        normal_analog_clock_time_pointer_minute_3,
        normal_analog_clock_time_pointer_minute_4,
    ];

    const hourElements = [
        normal_analog_clock_time_pointer_hour,
        normal_analog_clock_time_pointer_hour_2,
        normal_analog_clock_time_pointer_hour_3,
        normal_analog_clock_time_pointer_hour_4,
    ];

    // ACTIVAR VISIBLE = TRU O FALSE
    // Actualizar elementos de calorías
    minElements.forEach((element, index) => {
        if (element) {
            element.setProperty(hmUI.prop.VISIBLE, index === elementNumber - 1);
        }
    });

    // Actualizar elementos de ritmo cardíaco
    hourElements.forEach((element, index) => {
        if (element) {
            element.setProperty(hmUI.prop.VISIBLE, index === elementNumber - 1);
        }
    });
}

// AGREGAR VARIABLES
let normal_analog_clock_time_pointer_minute_2
let normal_analog_clock_time_pointer_minute_3
let normal_analog_clock_time_pointer_minute_4

let normal_analog_clock_time_pointer_hour_2 = ''
let normal_analog_clock_time_pointer_hour_3 = ''
let normal_analog_clock_time_pointer_hour_4 = ''


        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
// // 222 ENTRA DESPUES DEL PRIMER hmUI.createWidget
// Función para crear un widget
function createWidgetMin(prefix) {
    const widget = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        minute_path: prefix,
        minute_centerX: 227,
        minute_centerY: 227,
        minute_posX: 25,
        minute_posY: 212,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    widget.setProperty(hmUI.prop.VISIBLE, false);
    return widget;
}

function createWidgetHor(prefix) {
    const widget = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
        hour_path: prefix,
        hour_centerX: 227,
        hour_centerY: 227,
        hour_posX: 27,
        hour_posY: 141,
        show_level: hmUI.show_level.ONLY_NORMAL,
    });

    widget.setProperty(hmUI.prop.VISIBLE, false);
    return widget;
}


// Crear widgets de minutos
normal_analog_clock_time_pointer_minute_2 = createWidgetMin('min_02.png');
normal_analog_clock_time_pointer_minute_3 = createWidgetMin('min_03.png');
normal_analog_clock_time_pointer_minute_4 = createWidgetMin('min_04.png');


// Crear widgets de ritmo horas
normal_analog_clock_time_pointer_hour_2 = createWidgetHor('hor_02.png');
normal_analog_clock_time_pointer_hour_3 = createWidgetHor('hor_03.png');
normal_analog_clock_time_pointer_hour_4 = createWidgetHor('hor_04.png');
            // end user_script.js

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'seg_01.png',
              // center_x: 227,
              // center_y: 227,
              // x: 25,
              // y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 25,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'seg_01.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hor_01.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 27,
              hour_posY: 141,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_01.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hor_aod.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 16,
              hour_posY: 157,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_aod.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 17,
              minute_posY: 196,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 3,
              y: 199,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                click_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 199,
              w: 58,
              h: 58,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: '0_empty.png',
              normal_src: '0_empty.png',
              click_func: (button_widget) => {
                click_Arrow()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}