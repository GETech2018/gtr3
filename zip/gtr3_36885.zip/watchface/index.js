﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_image_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_stress_icon_img = ''
        let idle_image_img = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''

// start user_functions.js
        let normal_image_img_second =''
    let intervalId;

        // Start color change
        let btncolormain = ''
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_Color() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "Color Style 1"}
if ( colornumber_main == 2) { namecolor_main = "Color Style 2"}
if ( colornumber_main == 3) { namecolor_main = "Color Style 3"}
if ( colornumber_main == 4) { namecolor_main = "Color Style 4"}
if ( colornumber_main == 5) { namecolor_main = "Color Style 5"}
if ( colornumber_main == 6) { namecolor_main = "Color Style 6"}
hmUI.showToast({text: namecolor_main });

             //hmUI.showToast({text: "color " + parseInt(colornumber_main) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber_main) + ".png");
             normal_stress_icon_img.setProperty(hmUI.prop.SRC, "smain" + parseInt(colornumber_main) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////



        // Start color change
        let btncolormain2 = ''
        let colornumber_main2 = 1
        let totalcolors_main2 = 6
        let namecolor_main2 = ''

        function click_Color2() {
            if(colornumber_main2>=totalcolors_main2) {
            colornumber_main2=1;
                }
            else {
                colornumber_main2=colornumber_main2+1;
            }

if ( colornumber_main2 == 1) { namecolor_main2 = "Color Minute 1"}
if ( colornumber_main2 == 2) { namecolor_main2 = "Color Minute 2"}
if ( colornumber_main2 == 3) { namecolor_main2 = "Color Minute 3"}
if ( colornumber_main2 == 4) { namecolor_main2 = "Color Minute 4"}
if ( colornumber_main2 == 5) { namecolor_main2 = "Color Minute 5"}
if ( colornumber_main2 == 6) { namecolor_main2 = "Color Minute 6"}
hmUI.showToast({text: namecolor_main2 });

             normal_stress_icon_img.setProperty(hmUI.prop.SRC, "smain" + parseInt(colornumber_main2) + ".png");
                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////////

          // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 3
        let cc = 0

        function click_activity() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }

    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calorie
        function UpdateBackgroundTwo(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundThree(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);


        }

//////////////////////////////////////////////////////////////////////////////////////////////////

// end user_functions.js

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 352,
              src: 'smain1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 301,
              y: 68,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 21,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 67,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 302,
              y: 29,
              src: 'icon_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 67,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 22,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 74,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 372,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 406,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 375,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 405,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 36,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 63,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 24,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 155,
              minute_startY: 349,
              minute_array: ["TimeM0.png","TimeM1.png","TimeM2.png","TimeM3.png","TimeM4.png","TimeM5.png","TimeM6.png","TimeM7.png","TimeM8.png","TimeM9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 99,
              hour_array: ["TimeH0.png","TimeH1.png","TimeH2.png","TimeH3.png","TimeH4.png","TimeH5.png","TimeH6.png","TimeH7.png","TimeH8.png","TimeH9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 209,
              am_y: 5,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 209,
              pm_y: 5,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 88,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392,
              y: 102,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 36,
              y: 115,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });







            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 352,
              src: 'smain1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 67,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 22,
              src: 'icon_Step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 74,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 372,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 406,
              src: 'icon_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 375,
              font_array: ["ACT_Font_0.png","ACT_Font_1.png","ACT_Font_2.png","ACT_Font_3.png","ACT_Font_4.png","ACT_Font_5.png","ACT_Font_6.png","ACT_Font_7.png","ACT_Font_8.png","ACT_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Battery_symbo.png',
              unit_tc: 'Battery_symbo.png',
              unit_en: 'Battery_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 120,
              y: 405,
              src: 'icon_battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 192,
              day_startY: 36,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 63,
              font_array: ["Weather_Font_0.png","Weather_Font_1.png","Weather_Font_2.png","Weather_Font_3.png","Weather_Font_4.png","Weather_Font_5.png","Weather_Font_6.png","Weather_Font_7.png","Weather_Font_8.png","Weather_Font_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Weather_Symbo1.png',
              unit_tc: 'Weather_Symbo1.png',
              unit_en: 'Weather_Symbo1.png',
              negative_image: 'Weather_Symbo2.png',
              invalid_image: 'Weather_Symbo2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 24,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 155,
              minute_startY: 349,
              minute_array: ["TimeM0.png","TimeM1.png","TimeM2.png","TimeM3.png","TimeM4.png","TimeM5.png","TimeM6.png","TimeM7.png","TimeM8.png","TimeM9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 22,
              hour_startY: 99,
              hour_array: ["TimeH0.png","TimeH1.png","TimeH2.png","TimeH3.png","TimeH4.png","TimeH5.png","TimeH6.png","TimeH7.png","TimeH8.png","TimeH9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 209,
              am_y: 5,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 209,
              pm_y: 5,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 88,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 392,
              y: 102,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 36,
              y: 115,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

          console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 192,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 370,
              w: 60,
              h: 56,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 27,
              y: 112,
              w: 45,
              h: 36,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 19,
              w: 62,
              h: 34,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 59,
              w: 75,
              h: 28,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 58,
              w: 89,
              h: 28,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 401,
              w: 73,
              h: 33,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 365,
              w: 79,
              h: 29,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 58,
              w: 86,
              h: 28,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 16,
              w: 45,
              h: 36,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
click_activity() 
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 422,
              y: 207,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
// change color minute
click_Color2()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 209,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
// change color style
click_Color()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

           Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 372,
              w: 67,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 35,
              w: 87,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button



// start user_script_end.js


           normal_image_img_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 's_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,

            });
            

        let screenType = hmSetting.getScreenType();

        const time = hmSensor.createSensor(hmSensor.id.TIME);

        function time_image_call() {
          console.log('update scales TIME');
if (screenType != hmSetting.screen_type.AOD) {

          let image_second = "s_"+ time.second +".png"
   

    normal_image_img_second.setProperty(hmUI.prop.MORE, {

            x: (227-15)+211 * Math.cos( 6* (time.second -15) * (Math.PI / 180) ),
            y: (227-15)+211 * Math.sin(6* (time.second-15)  * (Math.PI / 180)),

         src: image_second,
              show_level: hmUI.show_level.ONLY_NORMAL,
                });    
}
}
        function startInterval() {
          intervalId = setInterval(time_image_call, 1000); 
        }
        startInterval();

////////////////////////////////////////////////////////////////////////////////


let cc=0
if (cc==0) { 
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

        normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);




cc = 1
}


// end user_script_end.js



 



                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}