﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Quadrante_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 332,
              image_array: ["CLIMA01.png","CLIMA02.png","CLIMA03.png","CLIMA04.png","CLIMA05.png","CLIMA06.png","CLIMA07.png","CLIMA08.png","CLIMA09.png","CLIMA10.png","CLIMA11.png","CLIMA12.png","CLIMA13.png","CLIMA14.png","CLIMA16.png","CLIMA17.png","CLIMA18.png","CLIMA19.png","CLIMA20.png","CLIMA21.png","CLIMA22.png","CLIMA23.png","CLIMA24.png","CLIMA25.png","CLIMA26.png","CLIMA27.png","CLIMA28.png","CLIMA29.png","CLIMA30.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 285,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Att_14.png',
              unit_tc: 'Att_14.png',
              unit_en: 'Att_14.png',
              imperial_unit_sc: 'Att_14.png',
              imperial_unit_tc: 'Att_14.png',
              imperial_unit_en: 'Att_14.png',
              negative_image: 'Att_13.png',
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 54,
              y: 330,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 89,
              month_startY: 285,
              month_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 285,
              day_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 285,
              src: 'Att_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 85,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 74,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 32,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 44,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Puntatore_01.png',
              center_x: 139,
              center_y: 118,
              x: 12,
              y: 90,
              start_angle: 270,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 132,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 239,
              minute_startY: 132,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 151,
              second_startY: 287,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 132,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Quadrante_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 332,
              image_array: ["CLIMA01.png","CLIMA02.png","CLIMA03.png","CLIMA04.png","CLIMA05.png","CLIMA06.png","CLIMA07.png","CLIMA08.png","CLIMA09.png","CLIMA10.png","CLIMA11.png","CLIMA12.png","CLIMA13.png","CLIMA14.png","CLIMA16.png","CLIMA17.png","CLIMA18.png","CLIMA19.png","CLIMA20.png","CLIMA21.png","CLIMA22.png","CLIMA23.png","CLIMA24.png","CLIMA25.png","CLIMA26.png","CLIMA27.png","CLIMA28.png","CLIMA29.png","CLIMA30.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 285,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Att_14.png',
              unit_tc: 'Att_14.png',
              unit_en: 'Att_14.png',
              imperial_unit_sc: 'Att_14.png',
              imperial_unit_tc: 'Att_14.png',
              imperial_unit_en: 'Att_14.png',
              negative_image: 'Att_13.png',
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 54,
              y: 330,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 89,
              month_startY: 285,
              month_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 285,
              day_sc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_tc_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_en_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 285,
              src: 'Att_15.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 85,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Att_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 74,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Att_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 32,
              font_array: ["Att_01.png","Att_02.png","Att_03.png","Att_04.png","Att_05.png","Att_06.png","Att_07.png","Att_08.png","Att_09.png","Att_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 44,
              font_array: ["Sist_01.png","Sist_02.png","Sist_03.png","Sist_04.png","Sist_05.png","Sist_06.png","Sist_07.png","Sist_08.png","Sist_09.png","Sist_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Puntatore_01.png',
              center_x: 139,
              center_y: 118,
              x: 12,
              y: 90,
              start_angle: 270,
              end_angle: 360,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 5,
              hour_startY: 132,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 239,
              minute_startY: 132,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 132,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}