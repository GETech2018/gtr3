﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_linear_scale = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 279,
              src: 'dn.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 363,
              y: 223,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 362,
              y: 251,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 66,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_3_12.png',
              unit_tc: 'dig_3_12.png',
              unit_en: 'dig_3_12.png',
              negative_image: 'dig_3_10.png',
              invalid_image: 'err.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'short.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 320,
              y: 106,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 106,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 159,
              y: 109,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 109,
              month_startY: 108,
              month_sc_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              month_tc_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              month_en_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 108,
              day_sc_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              day_tc_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              day_en_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 283,
              y: 357,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dig_3_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 357,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 357,
              font_array: ["dig_3_0.png","dig_3_1.png","dig_3_2.png","dig_3_3.png","dig_3_4.png","dig_3_5.png","dig_3_6.png","dig_3_7.png","dig_3_8.png","dig_3_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 163,
              // start_y: 409,
              // color: 0xFFC0C0C0,
              // lenght: 123,
              // line_width: 8,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 155,
              hour_array: ["dig_1_0.png","dig_1_1.png","dig_1_2.png","dig_1_3.png","dig_1_4.png","dig_1_5.png","dig_1_6.png","dig_1_7.png","dig_1_8.png","dig_1_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 209,
              minute_startY: 155,
              minute_array: ["dig_1_0.png","dig_1_1.png","dig_1_2.png","dig_1_3.png","dig_1_4.png","dig_1_5.png","dig_1_6.png","dig_1_7.png","dig_1_8.png","dig_1_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 356,
              second_startY: 156,
              second_array: ["dig_2_0.png","dig_2_1.png","dig_2_2.png","dig_2_3.png","dig_2_4.png","dig_2_5.png","dig_2_6.png","dig_2_7.png","dig_2_8.png","dig_2_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 155,
              src: 'dig_1_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_hand.png',
              second_centerX: 228,
              second_centerY: 227,
              second_posX: 9,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 23,
              w: 121,
              h: 33,
              src: 'short.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 64,
              w: 129,
              h: 36,
              src: 'short.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 65,
              w: 72,
              h: 75,
              src: 'short.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 320,
              w: 93,
              h: 74,
              src: 'short.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 163;
                  let start_y_normal_step = 409;
                  let lenght_ls_normal_step = 123;
                  let line_width_ls_normal_step = 8;
                  let color_ls_normal_step = 0xFFC0C0C0;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  