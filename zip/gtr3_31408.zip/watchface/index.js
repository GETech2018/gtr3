    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                  // required variables
            const valueImg = new Array(5);  // maximum display data length 5 characters (99999)
            const ASCIIARRAY = new Array(10);
            for (let i = 0; i < 10; i++) {
              ASCIIARRAY[i] = "N" + i + ".png";  // set of images with numbers
            }
            let units_img = ''
            // *******************************************************************
            // initial variables, affect the position and display of data
            // *******************************************************************
            const Circle_Radius = 108;        // 显示文本的圆半径
            const Circle_x = 454/2;           // Circle center x relative to display
            const Circle_y = 454/2;           // Circle center y relative to display
            const Angle = 275;                // 第一个字符的角度，0度对应于12点钟方向
            const CharSpaceAngle = 1;         // 字符之间的角度
            const ImageWidht = 16;            // 字符图像的宽度
            const ImageHeight = 25;           // 字符图像的高度
            const UnitsWidht = 50;            // 单位图像的宽度。度量单位的高度必须与带有数字的图像的高度相同。
            const Vertical_Alignment = 0;     // 相对于圆的字符垂直对齐:-1 =顶部，0 =中心，1 =底部
            const ReverseDirection = true;    // 影响文本的方向。如果文本位于圆的底部，建议使用true
            const Aligment = 1;               // -1 =左对齐；0 =中心对齐；1 =右对齐。
            // *******************************************************************
            // auxiliary variables, for calculating the position of characters
            // *******************************************************************
            let WI_x = Circle_x - Circle_Radius - ImageHeight;        // Widget X position relative to display
            let WI_y = Circle_y - Circle_Radius - ImageHeight;        // Widget Y position relative to display
            let WI_h = Circle_Radius*2 + ImageHeight * 2;             // Widget hight
            let WI_w = Circle_Radius*2 + ImageHeight * 2;             // Widget widht
            let WI_center = WI_h/2;
            let startAngle = Angle;
            let imagePos_x = WI_center - ImageWidht/2;
            let imagePos_y = WI_center - Circle_Radius - (ImageHeight + Vertical_Alignment*ImageHeight)/2;
            if (ReverseDirection) imagePos_y = WI_center + Circle_Radius - ImageHeight + (ImageHeight - Vertical_Alignment*ImageHeight)/2;

            let WI_units_x = Circle_x - Circle_Radius - ImageHeight - ImageWidht/2;
            let WI_units_y = Circle_y - Circle_Radius - ImageHeight - ImageWidht/2;
            let WI_units_h = Circle_Radius*2 + ImageHeight * 2 + ImageWidht;
            let WI_units_w = Circle_Radius*2 + ImageHeight * 2 + ImageWidht; 
            let WI_units_center = WI_units_h/2;
            let imagePos_units_x = WI_units_center - UnitsWidht/2;
            let imagePos_units_y = WI_units_center - Circle_Radius - (ImageHeight + Vertical_Alignment*ImageHeight)/2;
            if (ReverseDirection) imagePos_units_y = WI_units_center + Circle_Radius - ImageHeight + (ImageHeight - Vertical_Alignment*ImageHeight)/2;
            // *******************************************************************
            // Auxiliary functions
            function toDegree (radian) {
                return radian * (180 / Math.PI);
            }
            // *******************************************************************

            let charAngle=(toDegree(Math.atan2(ImageWidht/2, Circle_Radius)));
            let unitAngle=(toDegree(Math.atan2(UnitsWidht/2, Circle_Radius)));

            for ( let i = 0; i < 5; i++ ){
              valueImg[i] = hmUI.createWidget(hmUI.widget.IMG, { });
            }
            units_img = hmUI.createWidget(hmUI.widget.IMG, { });
            // *******************************************************************
            // *******************************************************************

            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() { text_circle() });  // Should update the text on the AOD screen if the data has changed

            function text_circle() {  //  Get the parameter value and display it

              console.log('update STEP');
              
              let stepCurrent=step.current;
              let stepString = String(stepCurrent);
              let index = 0;
              valueImg[0].setProperty(hmUI.prop.SRC, "error.png"); // 没有数据时显示的图像。如果没有该字符串，将显示“0”。
              for (var i = 1; i < 5; i++) {  // clear all symbols
                valueImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
              }             
              if (isFinite(stepCurrent) && stepString.length>0 && stepString.length<6) {  // display data if it was possible to get it
                switch(Aligment)
                {
                  case -1:
                    console.log('Left aligment');
                    startAngle = Angle;
                    break;
                  case 0:
                    console.log('Centr aligment');
                    startAngle = Angle - charAngle*(stepString.length-1) - CharSpaceAngle*(stepString.length-1)/2;
                    if (ReverseDirection) startAngle = Angle + charAngle*(stepString.length-1) + CharSpaceAngle*(stepString.length-1)/2;
                    break;
                  case 1:
                    console.log('Right aligment');
                    startAngle = Angle - 2*charAngle*(stepString.length-1) - CharSpaceAngle*(stepString.length-1);
                    if (ReverseDirection) startAngle = Angle + 2*charAngle*(stepString.length-1) + CharSpaceAngle*(stepString.length-1);
                    break;
                }
                if (ReverseDirection) startAngle = startAngle - 180;

                for (let char of stepString) {
                  const charCode = char.charCodeAt()-48;
                  if (charCode < 0) {
                    continue;
                  }
                  if (index >= 5) {
                    break;
                  }
                  let char_Angle = startAngle + 2*charAngle*index + CharSpaceAngle*index;
                  if (ReverseDirection) char_Angle = startAngle - 2*charAngle*index - CharSpaceAngle*index;
                  console.log("char_Angle: {0}", char_Angle);

                  if(charCode >= 0 && charCode < 10) valueImg[index].setProperty(hmUI.prop.MORE, { 
                    x: WI_x,
                    y: WI_y,
                    w: WI_w,
                    h: WI_h,
                    pos_x: imagePos_x,
                    pos_y: imagePos_y,
                    center_x: WI_center,
                    center_y:  WI_center,
                    angle: char_Angle,
                    src: ASCIIARRAY[charCode],
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  index++;
                }
                if (index > 0)  // display units
                {
                  index--;
                  let units_Angle = startAngle + 2*charAngle*(stepString.length-0.5) + unitAngle + CharSpaceAngle*stepString.length;
                  if (ReverseDirection) units_Angle = startAngle - 2*charAngle*(stepString.length-0.5) - unitAngle  - CharSpaceAngle*stepString.length;
                  units_img.setProperty(hmUI.prop.VISIBLE, true);
                  units_img.setProperty(hmUI.prop.MORE, {  // pre-calculate the position of the unit image
                    x: WI_units_x,
                    y: WI_units_y,
                    w: WI_units_w,
                    h: WI_units_h,
                    pos_x: imagePos_units_x,
                    pos_y: imagePos_units_y,
                    center_x: WI_units_center,
                    center_y:  WI_units_center,
                    angle: units_Angle,
                    src: "steps.png",  // unit image
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                }
                else units_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
              else  // in case of data error
              {
                console.log('error');
                startAngle = Angle
                if (ReverseDirection) startAngle = startAngle - 180;
                valueImg[0].setProperty(hmUI.prop.MORE, {  
                  x: WI_x,
                  y: WI_y,
                  w: WI_w,
                  h: WI_h,
                  pos_x: imagePos_x,
                  pos_y: imagePos_y,
                  center_x: WI_center,
                  center_y:  WI_center,
                  angle: startAngle,
                  src: "error.png",
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                units_img.setProperty(hmUI.prop.VISIBLE, false);  // hide the units of measure if the data could not be retrieved
              }
            };
            

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                text_circle();  // update text when screen turns on
              }),
            });


            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: -10,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["111.png","112..png","113.png","114.png","115.png","116.png","117.png"],
              week_tc: ["111.png","112..png","113.png","114.png","115.png","116.png","117.png"],
              week_sc: ["111.png","112..png","113.png","114.png","115.png","116.png","117.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 156,
              y: 57,
              image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 353,
              image_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 306,
              font_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              padding: false,
              h_space: 0,
              unit_sc: '75.png',
              unit_tc: '75.png',
              unit_en: '75.png',
              negative_image: '74.png',
              invalid_image: '73.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 397,
              day_startY: 216,
              day_sc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_tc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_en_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 156,
              y: 57,
              src: '33.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '89.png',
              center_x: 227,
              center_y: 332,
              x: 11,
              y: 71,
              start_angle: -140,
              end_angle: 140,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '86.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 24,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '87.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
         //     second_path: '88.png',
         //     second_centerX: 227,
             // second_centerY: 227,
          //    second_posX: 24,
            //  second_posY: 227,
          //    show_level: hmUI.show_level.ONLY_NORMAL,
         //   });




            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '90.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 24,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '91.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });
//代码开始
            let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 24;
            let second_posY = 227;
            let second_path = "88.png";

    	    let sec_pointer;
    	    let clock_timer;
	        let animAngle = 0;
            let animDelay = 0;                   
            const animFps = 12;                             // Frames per second 
            const animRepeat = 1000/animFps;                // then execute every <animRepeat>ms
            const deviceInfo = hmSetting.getDeviceInfo();
	    // SMOOTH SECONDS Definition End

            sec_pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: deviceInfo.width / 2 - second_posX,
              pos_y: deviceInfo.height / 2 - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {
                    console.log('ui resume');

                    clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
                            animAngle = (now.second*6) + (((now.utc % 1000)/1000)*6);
                            sec_pointer.setProperty(hmUI.prop.ANGLE, animAngle);
                    }));
		}),
                pause_call: (function () {
                    console.log('ui pause');
					timer.stopTimer(clock_timer);
                }),
            });                
            // 代码结束

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
