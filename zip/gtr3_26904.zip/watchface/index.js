﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 40,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 52,
              y: 86,
              font_array: ["032px_turquoise_0.png","032px_turquoise_1.png","032px_turquoise_2.png","032px_turquoise_3.png","032px_turquoise_4.png","032px_turquoise_5.png","032px_turquoise_6.png","032px_turquoise_7.png","032px_turquoise_8.png","032px_turquoise_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 86,
              font_array: ["032px_orange_0.png","032px_orange_1.png","032px_orange_2.png","032px_orange_3.png","032px_orange_4.png","032px_orange_5.png","032px_orange_6.png","032px_orange_7.png","032px_orange_8.png","032px_orange_9.png"],
              padding: false,
              h_space: -4,
              dot_image: 'decimal.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 293,
              y: 40,
              src: 'distance2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 405,
              image_array: ["battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png","battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 431,
              font_array: ["016px_white_0.png","016px_white_1.png","016px_white_2.png","016px_white_3.png","016px_white_4.png","016px_white_5.png","016px_white_6.png","016px_white_7.png","016px_white_8.png","016px_white_9.png"],
              padding: true,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 405,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 405,
              src: 'bluetooth-off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 215,
              y: 12,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 310,
              day_sc_array: ["048px_springgreen_0.png","048px_springgreen_1.png","048px_springgreen_2.png","048px_springgreen_3.png","048px_springgreen_4.png","048px_springgreen_5.png","048px_springgreen_6.png","048px_springgreen_7.png","048px_springgreen_8.png","048px_springgreen_9.png"],
              day_tc_array: ["048px_springgreen_0.png","048px_springgreen_1.png","048px_springgreen_2.png","048px_springgreen_3.png","048px_springgreen_4.png","048px_springgreen_5.png","048px_springgreen_6.png","048px_springgreen_7.png","048px_springgreen_8.png","048px_springgreen_9.png"],
              day_en_array: ["048px_springgreen_0.png","048px_springgreen_1.png","048px_springgreen_2.png","048px_springgreen_3.png","048px_springgreen_4.png","048px_springgreen_5.png","048px_springgreen_6.png","048px_springgreen_7.png","048px_springgreen_8.png","048px_springgreen_9.png"],
              day_zero: 1,
              day_space: -4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 100,
              month_startY: 310,
              month_sc_array: ["064px_orange_0.png","064px_orange_1.png","064px_orange_2.png","064px_orange_3.png","064px_orange_4.png","064px_orange_5.png","064px_orange_6.png","064px_orange_7.png","064px_orange_8.png","064px_orange_9.png"],
              month_tc_array: ["064px_orange_0.png","064px_orange_1.png","064px_orange_2.png","064px_orange_3.png","064px_orange_4.png","064px_orange_5.png","064px_orange_6.png","064px_orange_7.png","064px_orange_8.png","064px_orange_9.png"],
              month_en_array: ["064px_orange_0.png","064px_orange_1.png","064px_orange_2.png","064px_orange_3.png","064px_orange_4.png","064px_orange_5.png","064px_orange_6.png","064px_orange_7.png","064px_orange_8.png","064px_orange_9.png"],
              month_zero: 1,
              month_space: -4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 6,
              hour_startY: 156,
              hour_array: ["128px_white_0.png","128px_white_1.png","128px_white_2.png","128px_white_3.png","128px_white_4.png","128px_white_5.png","128px_white_6.png","128px_white_7.png","128px_white_8.png","128px_white_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["096px_white_0.png","096px_white_1.png","096px_white_2.png","096px_white_3.png","096px_white_4.png","096px_white_5.png","096px_white_6.png","096px_white_7.png","096px_white_8.png","096px_white_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_follow: 1,
              minute_align: hmUI.align.RIGHT,

              second_startX: 380,
              second_startY: 251,
              second_array: ["032px_springgreen_0.png","032px_springgreen_1.png","032px_springgreen_2.png","032px_springgreen_3.png","032px_springgreen_4.png","032px_springgreen_5.png","032px_springgreen_6.png","032px_springgreen_7.png","032px_springgreen_8.png","032px_springgreen_9.png"],
              second_zero: 1,
              second_space: -4,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 143,
              y: 376,
              w: 166,
              h: 81,
              src: 'trans.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 33,
              w: 176,
              h: 100,
              src: 'trans.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 9,
              y: 142,
              w: 440,
              h: 160,
              src: 'trans.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 33,
              w: 176,
              h: 100,
              src: 'trans.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 6,
              hour_startY: 156,
              hour_array: ["128px_white_0.png","128px_white_1.png","128px_white_2.png","128px_white_3.png","128px_white_4.png","128px_white_5.png","128px_white_6.png","128px_white_7.png","128px_white_8.png","128px_white_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["096px_white_0.png","096px_white_1.png","096px_white_2.png","096px_white_3.png","096px_white_4.png","096px_white_5.png","096px_white_6.png","096px_white_7.png","096px_white_8.png","096px_white_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_follow: 1,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  