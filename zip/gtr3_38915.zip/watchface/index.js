/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_animation1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_hour_imagecombo10 = '';
		let normal_minute_imagecombo11 = '';
		let normal_second_imagecombo12 = '';
		let normal_distance_imagecombo14 = '';
		let normal_weather_imageset16 = '';
		let normal_heart_current_imagecombo18 = '';
		let normal_battery_imagecombo20 = '';
		let normal_date_imagecombo22 = '';
		let normal_wind_imagecombo24 = '';
		let normal_calories_imagecombo26 = '';
		let idle_img29 = '';
		let idle_img30 = '';
		let idle_img31 = '';
		let idle_hour_imagecombo32 = '';
		let idle_minute_imagecombo33 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 188,
					y: 1,
					w: 272,
					h: 454,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: -190,
					y: -1,
					anim_path: '',
					anim_prefix: '1713956402459',
					anim_ext: 'png',
					anim_fps: 20,
					anim_size: 50,
					anim_repeat: false,
					repeat_count: 1,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -80,
					y: 0,
					w: 351,
					h: 479,
					src: '0053.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 194,
					y: 192,
					w: 37,
					h: 54,
					src: '0054.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 193,
					y: 136,
					w: 40,
					h: 40,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 195,
					y: 268,
					w: 35,
					h: 33,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 188,
					y: 351,
					w: 50,
					h: 28,
					src: '0057.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 295,
					y: 23,
					w: 38,
					h: 38,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 295,
					y: 328,
					w: 47,
					h: 47,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 271,
					hour_startY: 119,
					hour_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 295,
					minute_startY: 208,
					minute_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 319,
					second_startY: 286,
					second_array: ["0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 45,
					y: 201,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: 0,
					dot_image: '0100.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset16 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 132,
					y: 15,
					image_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 54,
					y: 267,
					font_array: ["0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0140.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo20 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 63,
					y: 350,
					font_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0151.png',
					unit_tc: '0151.png',
					unit_en: '0151.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo22 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 281,
					day_startY: 67,
					day_sc_array: ["0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
					day_tc_array: ["0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
					day_en_array: ["0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_wind_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 279,
					y: 368,
					font_array: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WIND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 49,
					y: 137,
					font_array: ["0172.png","0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 448,
					src: '0182.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 466,
					h: 466,
					src: '0183.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0184.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo32 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 132,
					hour_startY: 117,
					hour_array: ["0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo33 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 132,
					minute_startY: 242,
					minute_array: ["0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
					}),
					pause_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}