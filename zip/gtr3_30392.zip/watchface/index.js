﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: -24,
              y: -16,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "sunlight",
              anim_fps: 15,
              anim_size: 31,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 29,
              font_array: ["vertpetit-0001.png","vertpetit-0002.png","vertpetit-0003.png","vertpetit-0004.png","vertpetit-0005.png","vertpetit-0006.png","vertpetit-0007.png","vertpetit-0008.png","vertpetit-0009.png","vertpetit-0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 167,
              y: 10,
              src: 'running-0006.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 375,
              src: 'bluetooth-0007.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 205,
              y: 151,
              src: 'alarme-0011.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 253,
              year_startY: 85,
              year_sc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              year_tc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              year_en_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 85,
              month_sc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              month_tc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              month_en_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 84,
              src: 'Separation-0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 129,
              day_startY: 85,
              day_sc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              day_tc_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              day_en_array: ["White0.png","White1.png","White2.png","White3.png","White4.png","White5.png","White6.png","White7.png","White8.png","White9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 172,
              y: 84,
              src: 'Separation-0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 188,
              y: 407,
              image_array: ["battgros-0001.png","battgros-0002.png","battgros-0003.png","battgros-0004.png","battgros-0005.png","battgros-0006.png","battgros-0007.png","battgros-0008.png","battgros-0009.png","battgros-0010.png","battgros-0011.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 417,
              font_array: ["vertpetit-0001.png","vertpetit-0002.png","vertpetit-0003.png","vertpetit-0004.png","vertpetit-0005.png","vertpetit-0006.png","vertpetit-0007.png","vertpetit-0008.png","vertpetit-0009.png","vertpetit-0010.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 414,
              src: 'pourcent-0013.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 114,
              hour_array: ["OutlineBlancItal0.png","OutlineBlancItal1.png","OutlineBlancItal2.png","OutlineBlancItal3.png","OutlineBlancItal4.png","OutlineBlancItal5.png","OutlineBlancItal6.png","OutlineBlancItal7.png","OutlineBlancItal8.png","OutlineBlancItal9.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 234,
              minute_startY: 114,
              minute_array: ["OutlineBlancItal0.png","OutlineBlancItal1.png","OutlineBlancItal2.png","OutlineBlancItal3.png","OutlineBlancItal4.png","OutlineBlancItal5.png","OutlineBlancItal6.png","OutlineBlancItal7.png","OutlineBlancItal8.png","OutlineBlancItal9.png"],
              minute_zero: 1,
              minute_space: -20,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 200,
              y: 201,
              src: 'divers-0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  