﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // start user_functions.js
// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Menu START
		let menunumber = 1
        let total_menu = 2

        function click_MENU() {
            if(menunumber==total_menu) {
            menunumber=1;
                UpdatemenuOne();
                }
            else {
                menunumber=menunumber+1;
                if(menunumber==2) {
                  UpdatemenuTwo();
                }
            }
        }

        function UpdatemenuOne(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				Button_2.setProperty(hmUI.prop.VISIBLE, false);
				Button_3.setProperty(hmUI.prop.VISIBLE, false);
				
				Button_4.setProperty(hmUI.prop.VISIBLE, true);
				Button_5.setProperty(hmUI.prop.VISIBLE, true);
				Button_6.setProperty(hmUI.prop.VISIBLE, true);
				Button_7.setProperty(hmUI.prop.VISIBLE, true);
				Button_8.setProperty(hmUI.prop.VISIBLE, true);
				Button_9.setProperty(hmUI.prop.VISIBLE, true);
				Button_10.setProperty(hmUI.prop.VISIBLE, true);
				Button_11.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatemenuTwo(){
				normal_stress_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				Button_2.setProperty(hmUI.prop.VISIBLE, true);
				Button_3.setProperty(hmUI.prop.VISIBLE, true);
				
				Button_4.setProperty(hmUI.prop.VISIBLE, false);
				Button_5.setProperty(hmUI.prop.VISIBLE, false);
				Button_6.setProperty(hmUI.prop.VISIBLE, false);
				Button_7.setProperty(hmUI.prop.VISIBLE, false);
				Button_8.setProperty(hmUI.prop.VISIBLE, false);
				Button_9.setProperty(hmUI.prop.VISIBLE, false);
				Button_10.setProperty(hmUI.prop.VISIBLE, false);
				Button_11.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Menu END
		
		// Hands START
		let handsnumber = 1
        let total_hands = 4

        function click_HANDS() {
            if(handsnumber==total_hands) {
            handsnumber=1;
                UpdatehandsOne();
                }
            else {
                handsnumber=handsnumber+1;
                if(handsnumber==2) {
                  UpdatehandsTwo();
                }
				if(handsnumber==3) {
                  UpdatehandsThree();
                }
				if(handsnumber==4) {
                  UpdatehandsFour();
                }
            }
            if(handsnumber==1) hmUI.showToast({text: 'NORMAL SEC'});
            if(handsnumber==2) hmUI.showToast({text: 'SMOOTH SEC'});
			if(handsnumber==3) hmUI.showToast({text: 'NO SECOND'});
			if(handsnumber==4) hmUI.showToast({text: 'NO HANDS'});
        }

        function UpdatehandsOne(){
				normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatehandsTwo(){
				normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsThree(){
				normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
        function UpdatehandsFour(){
				normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		// Hands END
		
		// Color START	
		let colornumber_main = 1
        let totalcolors_main = 9
		let colorstring = '0xFFFA9650'
	
		function click_COLOR() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
            }
            else {
                colornumber_main=colornumber_main+1;
            }
			if ( colornumber_main == 1) {colorstring = '0xFFFA9650'}
			if ( colornumber_main == 2) {colorstring = '0xFF50FAEA'}
			if ( colornumber_main == 3) {colorstring = '0xFFFAEA50'}
			if ( colornumber_main == 4) {colorstring = '0xFFFA505F'}
			if ( colornumber_main == 5) {colorstring = '0xFF5FFA50'}
			if ( colornumber_main == 6) {colorstring = '0xFFFA50B4'}
			if ( colornumber_main == 7) {colorstring = '0xFF505FFA'}
			if ( colornumber_main == 8) {colorstring = '0xFFC050FA'}
			if ( colornumber_main == 9) {colorstring = '0xFFFFFFFF'}
			if ( colornumber_main <= 9) { 
			
			 normal_time_hour_text_font.setProperty(hmUI.prop.MORE, {
              x: 190,
              y: 334,
              w: 100,
              h: 60,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Pixel LCD 7.ttf',
              color: colorstring,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font.setProperty(hmUI.prop.MORE, {
              x: 308,
              y: 334,
              w: 100,
              h: 60,
              text_size: 60,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Pixel LCD 7.ttf',
              color: colorstring,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_image_img.setProperty(hmUI.prop.SRC, "color" + parseInt(colornumber_main) + ".png"); 
			normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hand_hour" + parseInt(colornumber_main) + ".png");
			normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "hand_min" + parseInt(colornumber_main) + ".png");
			} 
			
		}
		// Color END
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_spo2_icon_img = ''
        let normal_image_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_fat_burning_icon_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_fat_burning_icon_img = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'batt.png',
              center_x: 227,
              center_y: 227,
              x: 227,
              y: 227,
              start_angle: 180,
              end_angle: -180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 322,
              y: 375,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 138,
              y: 299,
              src: '0302.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 260,
              second_startY: 297,
              second_array: ["light_00.png","light_01.png","light_02.png","light_03.png","light_04.png","light_05.png","light_06.png","light_07.png","light_08.png","light_09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 204,
              hour_startY: 325,
              hour_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 299,
              minute_startY: 325,
              minute_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 128,
              week_en: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              week_tc: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              week_sc: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 97,
              month_sc_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_tc_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_en_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 96,
              day_sc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_tc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_en_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 87,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 85,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 64,
              font_array: ["dark_00.png","dark_01.png","dark_02.png","dark_03.png","dark_04.png","dark_05.png","dark_06.png","dark_07.png","dark_08.png","dark_09.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dark_12.png',
              unit_tc: 'dark_12.png',
              unit_en: 'dark_12.png',
              imperial_unit_sc: 'dark_12.png',
              imperial_unit_tc: 'dark_12.png',
              imperial_unit_en: 'dark_12.png',
              negative_image: 'dark_11.png',
              invalid_image: 'dark_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'gauge.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'color13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 347,
              center_y: 226,
              x: 76,
              y: 76,
              start_angle: 180,
              end_angle: 0,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 225,
              font_array: ["light_00.png","light_01.png","light_02.png","light_03.png","light_04.png","light_05.png","light_06.png","light_07.png","light_08.png","light_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 106,
              center_y: 226,
              x: 76,
              y: 76,
              start_angle: 180,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 227,
              font_array: ["light_00.png","light_01.png","light_02.png","light_03.png","light_04.png","light_05.png","light_06.png","light_07.png","light_08.png","light_09.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour9.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min9.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 230,
              month_startY: 97,
              month_sc_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_tc_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_en_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 96,
              day_sc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_tc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_en_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 128,
              week_en: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              week_tc: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              week_sc: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 383,
              font_array: ["light_00.png","light_01.png","light_02.png","light_03.png","light_04.png","light_05.png","light_06.png","light_07.png","light_08.png","light_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'light_10.png',
              unit_tc: 'light_10.png',
              unit_en: 'light_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 347,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_hour4.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_min4.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hand_sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'hand_top.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 180,
              w: 95,
              h: 95,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 284,
              w: 95,
              h: 95,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 161,
              y: 284,
              w: 95,
              h: 95,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 57,
              w: 95,
              h: 95,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 76,
              y: 57,
              w: 95,
              h: 95,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 5,
              w: 95,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 284,
              w: 95,
              h: 95,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 303,
              y: 180,
              w: 95,
              h: 95,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 57,
              y: 180,
              w: 95,
              h: 95,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}