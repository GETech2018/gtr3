﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_year = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 322,
              y: 130,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 129,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'circle_pointer.png',
              center_x: 226,
              center_y: 332,
              x: 15,
              y: 81,
              start_angle: 314,
              end_angle: 405,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 281,
              font_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 191,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Weather_Symbo01.png',
              unit_tc: 'Weather_Symbo01.png',
              unit_en: 'Weather_Symbo01.png',
              negative_image: 'Weather_Symbo02.png',
              invalid_image: 'Weather_Symbo02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 386,
              y: 154,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 382,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 310,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'circle_pointer.png',
              center_x: 132,
              center_y: 346,
              x: 15,
              y: 60,
              start_angle: 285,
              end_angle: 508,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 242,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 328,
              image_array: ["Step_icon_01.png","Step_icon_02.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 242,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 199,
              font_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'symbo_km.png',
              unit_tc: 'symbo_km.png',
              unit_en: 'symbo_km.png',
              imperial_unit_sc: 'symbo_mi.png',
              imperial_unit_tc: 'symbo_mi.png',
              imperial_unit_en: 'symbo_mi.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month_pointer.png',
              center_x: 227,
              center_y: 227,
              posX: 23,
              posY: 205,
              start_angle: 290,
              end_angle: 413,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 59,
              day_sc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_tc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_en_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 59,
              month_sc_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_tc_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_en_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 191,
              year_startY: 107,
              year_sc_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_tc_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_en_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_zero: 1,
              year_space: 7,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 118,
              am_y: 101,
              am_sc_path: 'clock_AM.png',
              am_en_path: 'clock_AM.png',
              pm_x: 118,
              pm_y: 101,
              pm_sc_path: 'clock_PM.png',
              pm_en_path: 'clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 129,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 129,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 302,
              second_startY: 97,
              second_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 23,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 322,
              y: 130,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 129,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'circle_pointer.png',
              center_x: 226,
              center_y: 332,
              x: 15,
              y: 81,
              start_angle: 314,
              end_angle: 405,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 281,
              font_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 191,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'Weather_Symbo01.png',
              unit_tc: 'Weather_Symbo01.png',
              unit_en: 'Weather_Symbo01.png',
              negative_image: 'Weather_Symbo02.png',
              invalid_image: 'Weather_Symbo02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 386,
              y: 154,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 382,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 285,
              y: 310,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'circle_pointer.png',
              center_x: 132,
              center_y: 346,
              x: 15,
              y: 60,
              start_angle: 285,
              end_angle: 508,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 242,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 117,
              y: 328,
              image_array: ["Step_icon_01.png","Step_icon_02.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 242,
              font_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 26,
              y: 199,
              font_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'symbo_km.png',
              unit_tc: 'symbo_km.png',
              unit_en: 'symbo_km.png',
              imperial_unit_sc: 'symbo_mi.png',
              imperial_unit_tc: 'symbo_mi.png',
              imperial_unit_en: 'symbo_mi.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month_pointer.png',
              center_x: 227,
              center_y: 227,
              posX: 23,
              posY: 205,
              start_angle: 290,
              end_angle: 413,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 59,
              day_sc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_tc_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_en_array: ["Day_font_01.png","Day_font_02.png","Day_font_03.png","Day_font_04.png","Day_font_05.png","Day_font_06.png","Day_font_07.png","Day_font_08.png","Day_font_09.png","Day_font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 59,
              month_sc_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_tc_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_en_array: ["Month_font_01.png","Month_font_02.png","Month_font_03.png","Month_font_04.png","Month_font_05.png","Month_font_06.png","Month_font_07.png","Month_font_08.png","Month_font_09.png","Month_font_10.png","Month_font_11.png","Month_font_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 191,
              year_startY: 107,
              year_sc_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_tc_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_en_array: ["Year_font_01.png","Year_font_02.png","Year_font_03.png","Year_font_04.png","Year_font_05.png","Year_font_06.png","Year_font_07.png","Year_font_08.png","Year_font_09.png","Year_font_10.png"],
              year_zero: 1,
              year_space: 7,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 118,
              am_y: 101,
              am_sc_path: 'clock_AM.png',
              am_en_path: 'clock_AM.png',
              pm_x: 118,
              pm_y: 101,
              pm_sc_path: 'clock_PM.png',
              pm_en_path: 'clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 129,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 232,
              minute_startY: 129,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 302,
              second_startY: 97,
              second_array: ["Second_font_01.png","Second_font_02.png","Second_font_03.png","Second_font_04.png","Second_font_05.png","Second_font_06.png","Second_font_07.png","Second_font_08.png","Second_font_09.png","Second_font_10.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 23,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 297,
              y: 97,
              w: 59,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 137,
              w: 27,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 119,
              w: 39,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 373,
              y: 147,
              w: 61,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 191,
              w: 91,
              h: 32,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 243,
              w: 110,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 288,
              y: 317,
              w: 71,
              h: 62,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 381,
              w: 90,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 241,
              w: 114,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
