﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg019.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 155,
              year_startY: 21,
              year_sc_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              year_tc_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              year_en_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 242,
              day_startY: 61,
              day_sc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_tc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_en_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'MF_Medium_Minus.png',
              day_unit_tc: 'MF_Medium_Minus.png',
              day_unit_en: 'MF_Medium_Minus.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 149,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'chars_7A5135B0_010.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 148,
              src: 'custom_icon_1765586369283_27x26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 299,
              month_startY: 61,
              month_sc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_tc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_en_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 407,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_7A5135B0_011.png',
              unit_tc: 'chars_7A5135B0_011.png',
              unit_en: 'chars_7A5135B0_011.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 236,
              src: 'custom_icon_1761128843535_1761132216181_26x26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 271,
              image_array: ["set_9_16x138_h0s90b100_r270_img_level_1.png","set_9_16x138_h0s90b100_r270_img_level_2.png","set_9_16x138_h0s90b100_r270_img_level_3.png","set_9_16x138_h0s90b100_r270_img_level_4.png","set_9_16x138_h0s90b100_r270_img_level_5.png","set_9_16x138_h0s90b100_r270_img_level_6.png","set_9_16x138_h0s90b100_r270_img_level_7.png","set_9_16x138_h0s90b100_r270_img_level_8.png","set_9_16x138_h0s90b100_r270_img_level_9.png","set_9_16x138_h0s90b100_r270_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 194,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 189,
              src: 'custom_icon_1765626696304_33x33_h193s100b100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 198,
              y: 45,
              image_array: ["set_17_22x149_h33s57b100_r270_img_level_1.png","set_17_22x149_h33s57b100_r270_img_level_2.png","set_17_22x149_h33s57b100_r270_img_level_3.png","set_17_22x149_h33s57b100_r270_img_level_4.png","set_17_22x149_h33s57b100_r270_img_level_5.png","set_17_22x149_h33s57b100_r270_img_level_6.png","set_17_22x149_h33s57b100_r270_img_level_7.png","set_17_22x149_h33s57b100_r270_img_level_8.png","set_17_22x149_h33s57b100_r270_img_level_9.png","set_17_22x149_h33s57b100_r270_img_level_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 189,
              src: 'Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 238,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 28,
              y: 231,
              src: 'chars_7F3EB0DE_000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 405,
              y: 209,
              src: 'sveglia_2_b_34x35.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 283,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 282,
              src: 'custom_icon_1765588460160_29x29.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 57,
              image_array: ["set_8_35x35_meteo_1.png","set_8_35x35_meteo_2.png","set_8_35x35_meteo_3.png","set_8_35x35_meteo_4.png","set_8_35x35_meteo_5.png","set_8_35x35_meteo_6.png","set_8_35x35_meteo_7.png","set_8_35x35_meteo_8.png","set_8_35x35_meteo_9.png","set_8_35x35_meteo_10.png","set_8_35x35_meteo_11.png","set_8_35x35_meteo_12.png","set_8_35x35_meteo_13.png","set_8_35x35_meteo_14.png","set_8_35x35_meteo_15.png","set_8_35x35_meteo_16.png","set_8_35x35_meteo_17.png","set_8_35x35_meteo_18.png","set_8_35x35_meteo_19.png","set_8_35x35_meteo_20.png","set_8_35x35_meteo_21.png","set_8_35x35_meteo_22.png","set_8_35x35_meteo_23.png","set_8_35x35_meteo_24.png","set_8_35x35_meteo_25.png","set_8_35x35_meteo_26.png","set_8_35x35_meteo_27.png","set_8_35x35_meteo_28.png","set_8_35x35_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 62,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_7A26EF2D_011.png',
              unit_tc: 'chars_7A26EF2D_011.png',
              unit_en: 'chars_7A26EF2D_011.png',
              negative_image: 'MF_Medium_Minus.png',
              invalid_image: 'chars_7A5135B0_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 327,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 52,
              y: 326,
              src: 'cuore_27x27.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 123,
              y: 367,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_7A5135B0_011.png',
              unit_tc: 'chars_7A5135B0_011.png',
              unit_en: 'chars_7A5135B0_011.png',
              invalid_image: 'chars_7A5135B0_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 367,
              src: 'custom_icon_1765629930242_26x26.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 104,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 52,
              y: 104,
              src: 'custom_icon_1765667979645_27x27.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 405,
              y: 210,
              src: 'custom_icon_1765754750722_34x34.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 265,
              y: 217,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 219,
              y: 23,
              week_en: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              week_tc: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              week_sc: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 247,
              hour_startY: 110,
              hour_array: ["chars_EDD2CF96_000.png","chars_EDD2CF96_001.png","chars_EDD2CF96_002.png","chars_EDD2CF96_003.png","chars_EDD2CF96_004.png","chars_EDD2CF96_005.png","chars_EDD2CF96_006.png","chars_EDD2CF96_007.png","chars_EDD2CF96_008.png","chars_EDD2CF96_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 247,
              minute_startY: 249,
              minute_array: ["chars_EDD2CF96_000.png","chars_EDD2CF96_001.png","chars_EDD2CF96_002.png","chars_EDD2CF96_003.png","chars_EDD2CF96_004.png","chars_EDD2CF96_005.png","chars_EDD2CF96_006.png","chars_EDD2CF96_007.png","chars_EDD2CF96_008.png","chars_EDD2CF96_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 290,
              second_startY: 377,
              second_array: ["chars_477B7356_000.png","chars_477B7356_001.png","chars_477B7356_002.png","chars_477B7356_003.png","chars_477B7356_004.png","chars_477B7356_005.png","chars_477B7356_006.png","chars_477B7356_007.png","chars_477B7356_008.png","chars_477B7356_009.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg020.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 61,
              day_sc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_tc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_en_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'MF_Medium_Minus.png',
              day_unit_tc: 'MF_Medium_Minus.png',
              day_unit_en: 'MF_Medium_Minus.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 238,
              month_startY: 61,
              month_sc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_tc_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_en_array: ["chars_C19E0C8A_000.png","chars_C19E0C8A_001.png","chars_C19E0C8A_002.png","chars_C19E0C8A_003.png","chars_C19E0C8A_004.png","chars_C19E0C8A_005.png","chars_C19E0C8A_006.png","chars_C19E0C8A_007.png","chars_C19E0C8A_008.png","chars_C19E0C8A_009.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 387,
              font_array: ["chars_7A5135B0_000.png","chars_7A5135B0_001.png","chars_7A5135B0_002.png","chars_7A5135B0_003.png","chars_7A5135B0_004.png","chars_7A5135B0_005.png","chars_7A5135B0_006.png","chars_7A5135B0_007.png","chars_7A5135B0_008.png","chars_7A5135B0_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_7A5135B0_011.png',
              unit_tc: 'chars_7A5135B0_011.png',
              unit_en: 'chars_7A5135B0_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 385,
              src: 'custom_icon_1761128843535_1761132216181_26x26_h0s0b70.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 388,
              y: 210,
              src: 'custom_icon_1765754750722_34x34.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 175,
              y: 218,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 23,
              week_en: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              week_tc: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              week_sc: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 112,
              hour_array: ["chars_9DA9257E_000.png","chars_9DA9257E_001.png","chars_9DA9257E_002.png","chars_9DA9257E_003.png","chars_9DA9257E_004.png","chars_9DA9257E_005.png","chars_9DA9257E_006.png","chars_9DA9257E_007.png","chars_9DA9257E_008.png","chars_9DA9257E_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 251,
              minute_array: ["chars_9DA9257E_000.png","chars_9DA9257E_001.png","chars_9DA9257E_002.png","chars_9DA9257E_003.png","chars_9DA9257E_004.png","chars_9DA9257E_005.png","chars_9DA9257E_006.png","chars_9DA9257E_007.png","chars_9DA9257E_008.png","chars_9DA9257E_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 322,
              second_startY: 211,
              second_array: ["chars_477B7356_000.png","chars_477B7356_001.png","chars_477B7356_002.png","chars_477B7356_003.png","chars_477B7356_004.png","chars_477B7356_005.png","chars_477B7356_006.png","chars_477B7356_007.png","chars_477B7356_008.png","chars_477B7356_009.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}