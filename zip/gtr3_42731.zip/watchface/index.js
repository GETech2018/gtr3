﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_stress_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'base.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 52,
              y: 152,
              src: '0595.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 282,
              y: 153,
              src: '0596.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 113,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 262,
              month_startY: 382,
              month_sc_array: ["0263.png","0264.png","0265.png","0266.png","0267.png","0268.png","0269.png","0270.png","0271.png","0272.png","0273.png","0274.png"],
              month_tc_array: ["0263.png","0264.png","0265.png","0266.png","0267.png","0268.png","0269.png","0270.png","0271.png","0272.png","0273.png","0274.png"],
              month_en_array: ["0263.png","0264.png","0265.png","0266.png","0267.png","0268.png","0269.png","0270.png","0271.png","0272.png","0273.png","0274.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 338,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0611.png',
              unit_tc: '0611.png',
              unit_en: '0611.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_Dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 293,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 106,
              y: 79,
              image_array: ["bateriagrafico01.png","bateriagrafico02.png","bateriagrafico03.png","bateriagrafico04.png","bateriagrafico05.png","bateriagrafico06.png","bateriagrafico07.png","bateriagrafico08.png","bateriagrafico09.png","bateriagrafico10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 382,
              day_sc_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              day_tc_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              day_en_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 126,
              y: 382,
              week_en: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png"],
              week_tc: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png"],
              week_sc: ["0256.png","0257.png","0258.png","0259.png","0260.png","0261.png","0262.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 78,
              src: 'zagl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 113,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'bateria-por.png',
              unit_tc: 'bateria-por.png',
              unit_en: 'bateria-por.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 100,
              y: 87,
              image_array: ["0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 124,
              y: 298,
              image_array: ["WEATHER01.png","WEATHER02.png","WEATHER03.png","WEATHER04.png","WEATHER05.png","WEATHER06.png","WEATHER07.png","WEATHER08.png","WEATHER09.png","WEATHER10.png","WEATHER11.png","WEATHER12.png","WEATHER13.png","WEATHER14.png","WEATHER15.png","WEATHER16.png","WEATHER17.png","WEATHER18.png","WEATHER19.png","WEATHER20.png","WEATHER21.png","WEATHER22.png","WEATHER23.png","WEATHER24.png","WEATHER25.png","WEATHER26.png","WEATHER27.png","WEATHER28.png","WEATHER29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 293,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Temp_Unit.png',
              unit_tc: 'Temp_Unit.png',
              unit_en: 'Temp_Unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 113,
              font_array: ["bateria00.png","bateria01.png","bateria02.png","bateria03.png","bateria04.png","bateria05.png","bateria06.png","bateria07.png","bateria08.png","bateria09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 185,
              hour_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 174,
              minute_startY: 185,
              minute_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 312,
              second_startY: 185,
              second_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aodbase.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 36,
              hour_startY: 185,
              hour_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 174,
              minute_startY: 185,
              minute_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 312,
              second_startY: 185,
              second_array: ["hora_min00.png","hora_min01.png","hora_min02.png","hora_min03.png","hora_min04.png","hora_min05.png","hora_min06.png","hora_min07.png","hora_min08.png","hora_min09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 81,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 81,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 300,
              y: 81,
              w: 65,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 368,
              y: 68,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 368,
              y: 283,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 105,
              y: 290,
              w: 89,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 51,
              y: 178,
              w: 89,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 178,
              w: 89,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 291,
              w: 144,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 338,
              w: 144,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 173,
              y: 382,
              w: 106,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -13,
              y: 68,
              w: 95,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 24,
              press_src: 'WF_-_BUTTONS.png',
              normal_src: 'WF_-_BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}