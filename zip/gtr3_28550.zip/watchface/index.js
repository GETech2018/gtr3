﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_circle_scale = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 369,
              y: 118,
              src: 'ikony_03.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 118,
              src: 'ikony_02.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '0001alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 216,
              y: 36,
              src: 'ikony_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 154,
              y: 255,
              w: 150,
              h: 30,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 324,
              y: 178,
              image_array: ["pogoda_01.png","pogoda_02.png","pogoda_03.png","pogoda_04.png","pogoda_05.png","pogoda_06.png","pogoda_07.png","pogoda_08.png","pogoda_09.png","pogoda_10.png","pogoda_11.png","pogoda_12.png","pogoda_13.png","pogoda_14.png","pogoda_15.png","pogoda_16.png","pogoda_17.png","pogoda_18.png","pogoda_19.png","pogoda_20.png","pogoda_21.png","pogoda_22.png","pogoda_23.png","pogoda_24.png","pogoda_25.png","pogoda_26.png","pogoda_27.png","pogoda_28.png","pogoda_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 232,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              negative_image: 'cyfr_sr_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 294,
              // center_y: 106,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 57,
              // line_width: 5,
              // color: 0xFFAE0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 99,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 99,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'cyfr_sr_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 95,
              // center_y: 222,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 61,
              // line_width: 5,
              // color: 0xFF717171,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 214,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 329,
              year_startY: 306,
              year_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 257,
              month_startY: 306,
              month_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 303,
              y: 307,
              src: 'cyfr_mini_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 181,
              day_startY: 306,
              day_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 307,
              src: 'cyfr_mini_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 44,
              y: 305,
              week_en: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              week_tc: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              week_sc: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 155,
              hour_startY: 368,
              hour_array: ["cyfr_sr_01.png","cyfr_sr_02.png","cyfr_sr_03.png","cyfr_sr_04.png","cyfr_sr_05.png","cyfr_sr_06.png","cyfr_sr_07.png","cyfr_sr_08.png","cyfr_sr_09.png","cyfr_sr_10.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 236,
              minute_startY: 368,
              minute_array: ["cyfr_sr_01.png","cyfr_sr_02.png","cyfr_sr_03.png","cyfr_sr_04.png","cyfr_sr_05.png","cyfr_sr_06.png","cyfr_sr_07.png","cyfr_sr_08.png","cyfr_sr_09.png","cyfr_sr_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 363,
              src: 'cyfr_sr_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wskaz_n_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 228,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wskaz_n_2.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wskaz_n_3.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 25,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 226,
              // line_width: 7,
              // color: 0xFF008800,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 111,
              y: 55,
              w: 100,
              h: 100,
              src: 'puste.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 360,
              w: 123,
              h: 84,
              src: 'puste.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 360,
              w: 123,
              h: 84,
              src: 'puste.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 155,
              w: 125,
              h: 66,
              src: 'puste.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 225,
              w: 125,
              h: 57,
              src: 'puste.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 46,
              y: 171,
              w: 100,
              h: 100,
              src: 'puste.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_tarcza.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_wskaz_01.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 15,
              hour_posY: 226,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_wskaz_02.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 15,
              minute_posY: 226,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 269;
                  let center_x_normal_calorie = 294;
                  let center_y_normal_calorie = 106;
                  let radius_normal_calorie = 57;
                  let line_width_cs_normal_calorie = 5;
                  let color_cs_normal_calorie = 0xFFAE0000;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 269;
                  let center_x_normal_step = 95;
                  let center_y_normal_step = 222;
                  let radius_normal_step = 61;
                  let line_width_cs_normal_step = 5;
                  let color_cs_normal_step = 0xFF717171;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -90;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 227;
                  let center_y_normal_battery = 227;
                  let radius_normal_battery = 226;
                  let line_width_cs_normal_battery = 7;
                  let color_cs_normal_battery = 0xFF008800;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  