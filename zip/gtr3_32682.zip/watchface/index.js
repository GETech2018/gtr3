﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let idle_background_bg_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let timeSensor = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 4
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Battery'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);




        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Calorie
        function UpdateBackgroundTwo(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);



        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //Distance
        function UpdateBackgroundThree(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);



     }
//////////////////////////////////////////////////////////////////////////////////////////////////


        //Battery
        function UpdateBackgroundFour(){

        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);



     }
//////////////////////////////////////////////////////////////////////////////////////////////////

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'pix.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 228,
              // center_y: 336,
              // start_angle: 30,
              // end_angle: 331,
              // radius: 53,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 326,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Act_font_14.png',
              unit_tc: 'Act_font_14.png',
              unit_en: 'Act_font_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 279,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 323,
              font_array: ["ACT_Small_01.png","ACT_Small_02.png","ACT_Small_03.png","ACT_Small_04.png","ACT_Small_05.png","ACT_Small_06.png","ACT_Small_07.png","ACT_Small_08.png","ACT_Small_09.png","ACT_Small_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Small_dot.png',
              unit_tc: 'ACT_Small_dot.png',
              unit_en: 'ACT_Small_dot.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'ACT_Small_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 270,
              src: 'icon_KM_MI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 228,
              // center_y: 336,
              // start_angle: 30,
              // end_angle: 331,
              // radius: 54,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 328,
              font_array: ["ACT_Small_01.png","ACT_Small_02.png","ACT_Small_03.png","ACT_Small_04.png","ACT_Small_05.png","ACT_Small_06.png","ACT_Small_07.png","ACT_Small_08.png","ACT_Small_09.png","ACT_Small_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 265,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 228,
              // center_y: 336,
              // start_angle: 30,
              // end_angle: 331,
              // radius: 54,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 328,
              font_array: ["ACT_Small_01.png","ACT_Small_02.png","ACT_Small_03.png","ACT_Small_04.png","ACT_Small_05.png","ACT_Small_06.png","ACT_Small_07.png","ACT_Small_08.png","ACT_Small_09.png","ACT_Small_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 273,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 229,
              // center_y: 119,
              // start_angle: 31,
              // end_angle: 331,
              // radius: 54,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 107,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 60,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 302,
              y: 237,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 206,
              day_sc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_tc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_en_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 215,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act_font_13.png',
              unit_tc: 'Act_font_13.png',
              unit_en: 'Act_font_13.png',
              negative_image: 'Act_font_12.png',
              invalid_image: 'Act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 153,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 22,
              hour_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 22,
              minute_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_S.png',
              // center_x: 227,
              // center_y: 227,
              // x: 22,
              // y: 229,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 22,
              pos_y: 227 - 229,
              center_x: 227,
              center_y: 227,
              src: 'hand_S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });



            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'pix.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 228,
              // center_y: 336,
              // start_angle: 30,
              // end_angle: 331,
              // radius: 54,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 328,
              font_array: ["ACT_Small_01.png","ACT_Small_02.png","ACT_Small_03.png","ACT_Small_04.png","ACT_Small_05.png","ACT_Small_06.png","ACT_Small_07.png","ACT_Small_08.png","ACT_Small_09.png","ACT_Small_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 273,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 229,
              // center_y: 119,
              // start_angle: 31,
              // end_angle: 331,
              // radius: 54,
              // line_width: 6,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 107,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 60,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 302,
              y: 237,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 316,
              day_startY: 206,
              day_sc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_tc_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_en_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 215,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act_font_13.png',
              unit_tc: 'Act_font_13.png',
              unit_en: 'Act_font_13.png',
              negative_image: 'Act_font_12.png',
              invalid_image: 'Act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 153,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hand_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 22,
              hour_posY: 229,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hand_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 22,
              minute_posY: 229,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hand_S.png',
              // center_x: 227,
              // center_y: 227,
              // x: 22,
              // y: 229,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 22,
              pos_y: 227 - 229,
              center_x: 227,
              center_y: 227,
              src: 'hand_S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 153,
              w: 101,
              h: 54,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 71,
              y: 217,
              w: 95,
              h: 59,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 56,
              w: 98,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

		// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 283,
              y: 174,
              w: 100,
              h: 100,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 111,
              w: 104,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -60;
                  let end_angle_normal_battery = 241;
                  let center_x_normal_battery = 228;
                  let center_y_normal_battery = 336;
                  let radius_normal_battery = 53;
                  let line_width_cs_normal_battery = 6;
                  let color_cs_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -60;
                  let end_angle_normal_calorie = 241;
                  let center_x_normal_calorie = 228;
                  let center_y_normal_calorie = 336;
                  let radius_normal_calorie = 54;
                  let line_width_cs_normal_calorie = 6;
                  let color_cs_normal_calorie = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -60;
                  let end_angle_normal_step = 241;
                  let center_x_normal_step = 228;
                  let center_y_normal_step = 336;
                  let radius_normal_step = 54;
                  let line_width_cs_normal_step = 6;
                  let color_cs_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 45)/(targetHeartRate - 45);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = -59;
                  let end_angle_normal_heart_rate = 241;
                  let center_x_normal_heart_rate = 229;
                  let center_y_normal_heart_rate = 119;
                  let radius_normal_heart_rate = 54;
                  let line_width_cs_normal_heart_rate = 6;
                  let color_cs_normal_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -60;
                  let end_angle_idle_step = 241;
                  let center_x_idle_step = 228;
                  let center_y_idle_step = 336;
                  let radius_idle_step = 54;
                  let line_width_cs_idle_step = 6;
                  let color_cs_idle_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_idle_heart_rate = -59;
                  let end_angle_idle_heart_rate = 241;
                  let center_x_idle_heart_rate = 229;
                  let center_y_idle_heart_rate = 119;
                  let radius_idle_heart_rate = 54;
                  let line_width_cs_idle_heart_rate = 6;
                  let color_cs_idle_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_heart_rate = center_x_idle_heart_rate - radius_idle_heart_rate;
                  let arcY_idle_heart_rate = center_y_idle_heart_rate - radius_idle_heart_rate;
                  let CircleWidth_idle_heart_rate = 2 * radius_idle_heart_rate;
                  let angle_offset_idle_heart_rate = end_angle_idle_heart_rate - start_angle_idle_heart_rate;
                  angle_offset_idle_heart_rate = angle_offset_idle_heart_rate * progress_cs_idle_heart_rate;
                  let end_angle_idle_heart_rate_draw = start_angle_idle_heart_rate + angle_offset_idle_heart_rate;
                  
                  idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_heart_rate,
                    y: arcY_idle_heart_rate,
                    w: CircleWidth_idle_heart_rate,
                    h: CircleWidth_idle_heart_rate,
                    start_angle: start_angle_idle_heart_rate,
                    end_angle: end_angle_idle_heart_rate_draw,
                    color: color_cs_idle_heart_rate,
                    line_width: line_width_cs_idle_heart_rate,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }

              }),
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1
        normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
        normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 176,
              y: 284,
              text: '',
              w: 100,
              h: 100,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ALL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}