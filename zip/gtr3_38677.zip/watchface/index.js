/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_animation0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_img4 = '';
		let timeInterval;
		let normal_minute_high_imageset6 = '';
		let normal_minute_high_imageset6_array = ['0056.png','0057.png','0058.png','0059.png','0060.png','0061.png'];
		let normal_minute_low_imageset7 = '';
		let normal_minute_low_imageset7_array = ['0062.png','0063.png','0064.png','0065.png','0066.png','0067.png','0068.png','0069.png','0070.png','0071.png'];
		let normal_hour_high_imageset8 = '';
		let normal_hour_high_imageset8_array = ['0072.png','0073.png','0074.png'];
		let normal_hour_low_imageset9 = '';
		let normal_hour_low_imageset9_array = ['0075.png','0076.png','0077.png','0078.png','0079.png','0080.png','0081.png','0082.png','0083.png','0084.png'];
		let normal_second_imagecombo10 = '';
		let normal_date_imagecombo12 = '';
		let normal_battery_imageset14 = '';
		let normal_distance_imagecombo16 = '';
		let idle_hour_high_imageset19 = '';
		let idle_hour_high_imageset19_array = ['0126.png','0127.png','0128.png'];
		let idle_hour_low_imageset20 = '';
		let idle_hour_low_imageset20_array = ['0129.png','0130.png','0131.png','0132.png','0133.png','0134.png','0135.png','0136.png','0137.png','0138.png'];
		let idle_minute_high_imageset21 = '';
		let idle_minute_high_imageset21_array = ['0139.png','0140.png','0141.png','0142.png','0143.png','0144.png'];
		let idle_minute_low_imageset22 = '';
		let idle_minute_low_imageset22_array = ['0145.png','0146.png','0147.png','0148.png','0149.png','0150.png','0151.png','0152.png','0153.png','0154.png'];
		let idle_img23 = '';
		let idle_second_rotary25 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_animation0 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 0,
					y: 0,
					anim_path: '',
					anim_prefix: '1711019216624',
					anim_ext: 'png',
					anim_fps: 10,
					anim_size: 50,
					anim_repeat: false,
					repeat_count: 1,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0052.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 288,
					y: 207,
					w: 28,
					h: 38,
					src: '0053.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 46,
					y: 201,
					w: 30,
					h: 16,
					src: '0054.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 378,
					y: 193,
					w: 24,
					h: 23,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_high_imageset6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 111,
					y: 264,
					w: 111,
					h: 264,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_low_imageset7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 263,
					w: 233,
					h: 263,
					src: '0071.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_high_imageset8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 82,
					y: 70,
					w: 82,
					h: 70,
					src: '0074.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_low_imageset9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 70,
					w: 230,
					h: 70,
					src: '0084.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_second_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 159,
					second_startY: 372,
					second_array: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 339,
					day_startY: 218,
					day_sc_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
					day_tc_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
					day_en_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset14 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 13,
					y: 224,
					image_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					image_length: 10,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 136,
					y: 213,
					font_array: ["0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png"],
					padding: false,
					h_space: 0,
					dot_image: '0125.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_high_imageset19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 79,
					y: 78,
					w: 79,
					h: 78,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_hour_low_imageset20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 233,
					y: 79,
					w: 233,
					h: 79,
					src: '0138.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_high_imageset21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 86,
					y: 233,
					w: 86,
					h: 233,
					src: '0144.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_low_imageset22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 243,
					y: 233,
					w: 243,
					h: 233,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0155.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_rotary25 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0156.png',
					second_centerX: 227,
					second_centerY: 227,
					second_posX: 227,
					second_posY: 227,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_minute_high_imageset6.setProperty(hmUI.prop.MORE, {
						src: normal_minute_high_imageset6_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					normal_minute_low_imageset7.setProperty(hmUI.prop.MORE, {
						src: normal_minute_low_imageset7_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
					normal_hour_high_imageset8.setProperty(hmUI.prop.MORE, {
						src: normal_hour_high_imageset8_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					normal_hour_low_imageset9.setProperty(hmUI.prop.MORE, {
						src: normal_hour_low_imageset9_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					idle_hour_high_imageset19.setProperty(hmUI.prop.MORE, {
						src: idle_hour_high_imageset19_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(0) : 0)]
					})
					idle_hour_low_imageset20.setProperty(hmUI.prop.MORE, {
						src: idle_hour_low_imageset20_array[(timeSensor.format_hour.toString().length == 2 ? timeSensor.format_hour.toString().charAt(1) : timeSensor.format_hour.toString().charAt(0))]
					})
					idle_minute_high_imageset21.setProperty(hmUI.prop.MORE, {
						src: idle_minute_high_imageset21_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(0) : 0)]
					})
					idle_minute_low_imageset22.setProperty(hmUI.prop.MORE, {
						src: idle_minute_low_imageset22_array[(timeSensor.minute.toString().length == 2 ? timeSensor.minute.toString().charAt(1) : timeSensor.minute.toString().charAt(0))]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						normal_animation0.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						normal_animation0.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation0.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}