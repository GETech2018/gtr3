﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Printemps2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 178,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Paques1",
              anim_fps: 15,
              anim_size: 30,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 216,
              y: 113,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Paques3",
              anim_fps: 15,
              anim_size: 6,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 62,
              src: 'bluetooth-0010.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 19,
              y: 142,
              src: 'alarme-0015.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 118,
              font_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 320,
              year_startY: 73,
              year_sc_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              year_tc_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              year_en_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 70,
              month_sc_array: ["Mois02-0001.png","Mois02-0002.png","Mois02-0003.png","Mois02-0004.png","Mois02-0005.png","Mois02-0006.png","Mois02-0007.png","Mois02-0008.png","Mois02-0009.png","Mois02-0010.png","Mois02-0011.png","Mois02-0012.png"],
              month_tc_array: ["Mois02-0001.png","Mois02-0002.png","Mois02-0003.png","Mois02-0004.png","Mois02-0005.png","Mois02-0006.png","Mois02-0007.png","Mois02-0008.png","Mois02-0009.png","Mois02-0010.png","Mois02-0011.png","Mois02-0012.png"],
              month_en_array: ["Mois02-0001.png","Mois02-0002.png","Mois02-0003.png","Mois02-0004.png","Mois02-0005.png","Mois02-0006.png","Mois02-0007.png","Mois02-0008.png","Mois02-0009.png","Mois02-0010.png","Mois02-0011.png","Mois02-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 73,
              day_sc_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              day_tc_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              day_en_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 70,
              week_en: ["Semaine02-0001.png","Semaine02-0002.png","Semaine02-0003.png","Semaine02-0004.png","Semaine02-0005.png","Semaine02-0006.png","Semaine02-0007.png"],
              week_tc: ["Semaine02-0001.png","Semaine02-0002.png","Semaine02-0003.png","Semaine02-0004.png","Semaine02-0005.png","Semaine02-0006.png","Semaine02-0007.png"],
              week_sc: ["Semaine02-0001.png","Semaine02-0002.png","Semaine02-0003.png","Semaine02-0004.png","Semaine02-0005.png","Semaine02-0006.png","Semaine02-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 6,
              image_array: ["battgros-0001.png","battgros-0002.png","battgros-0003.png","battgros-0004.png","battgros-0005.png","battgros-0006.png","battgros-0007.png","battgros-0008.png","battgros-0009.png","battgros-0010.png","battgros-0011.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 14,
              font_array: ["blackrounded0.png","blackrounded1.png","blackrounded2.png","blackrounded3.png","blackrounded4.png","blackrounded5.png","blackrounded6.png","blackrounded7.png","blackrounded8.png","blackrounded9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 257,
              minute_startY: 170,
              minute_array: ["digitnoirgros-0001.png","digitnoirgros-0002.png","digitnoirgros-0003.png","digitnoirgros-0004.png","digitnoirgros-0005.png","digitnoirgros-0006.png","digitnoirgros-0007.png","digitnoirgros-0008.png","digitnoirgros-0009.png","digitnoirgros-0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 167,
              src: 'deuxpoints-0004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 170,
              hour_array: ["digitnoirgros-0001.png","digitnoirgros-0002.png","digitnoirgros-0003.png","digitnoirgros-0004.png","digitnoirgros-0005.png","digitnoirgros-0006.png","digitnoirgros-0007.png","digitnoirgros-0008.png","digitnoirgros-0009.png","digitnoirgros-0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  