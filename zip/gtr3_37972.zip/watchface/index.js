﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 17;
        let normal_sunrise_TextCircle_img_height = 21;
        let normal_sunrise_TextCircle_dot_width = 8;
        let normal_sunrise_TextCircle_error_img_width = 17;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 17;
        let normal_sunset_TextCircle_img_height = 21;
        let normal_sunset_TextCircle_dot_width = 8;
        let normal_sunset_TextCircle_error_img_width = 17;
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 21;
        let normal_battery_TextCircle_img_height = 25;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 23;
        let normal_battery_TextCircle_error_img_width = 17;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 21;
        let normal_distance_TextCircle_img_height = 25;
        let normal_distance_TextCircle_dot_width = 11;
        let normal_distance_TextCircle_error_img_width = 17;
        let normal_calorie_current_text_img = ''
        let normal_month_TextCircle = new Array(2);
        let normal_month_TextCircle_ASCIIARRAY = new Array(10);
        let normal_month_TextCircle_img_width = 21;
        let normal_month_TextCircle_img_height = 25;
        let normal_month_TextCircle_unit = null;
        let normal_month_TextCircle_unit_width = 11;
        let normal_timerTextUpdate = undefined;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 21;
        let normal_heart_rate_TextCircle_img_height = 25;
        let normal_heart_rate_TextCircle_error_img_width = 17;
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 21;
        let normal_day_TextCircle_img_height = 25;
        let normal_day_TextCircle_unit = null;
        let normal_day_TextCircle_unit_width = 11;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 21;
        let normal_step_TextCircle_img_height = 25;
        let normal_step_TextCircle_error_img_width = 17;
        let normal_digital_clock_img_time = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background-garmin.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 244,
              y: 134,
              src: 'DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 169,
              y: 134,
              src: 'BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 204,
              y: 134,
              src: 'AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 265,
              y: 72,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 85,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digital7_12.png',
              unit_tc: 'digital7_12.png',
              unit_en: 'digital7_12.png',
              negative_image: 'digital7_13.png',
              invalid_image: 'digital7_15.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 75,
              image_array: ["weat_01.png","weat_02.png","weat_03.png","weat_04.png","weat_05.png","weat_06.png","weat_07.png","weat_08.png","weat_09.png","weat_10.png","weat_11.png","weat_12.png","weat_13.png","weat_14.png","weat_15.png","weat_16.png","weat_17.png","weat_18.png","weat_19.png","weat_20.png","weat_21.png","weat_22.png","weat_23.png","weat_24.png","weat_25.png","weat_26.png","weat_27.png","weat_28.png","weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              // radius: 216,
              // angle: 144,
              // char_space_angle: 1,
              // dot_image: 'digital9_10.png',
              // error_image: 'digital7_15.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'digital9_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'digital9_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'digital9_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'digital9_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'digital9_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'digital9_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'digital9_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'digital9_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'digital9_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'digital9_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 227 + 195,
                src: 'digital9_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital9_0.png","digital9_1.png","digital9_2.png","digital9_3.png","digital9_4.png","digital9_5.png","digital9_6.png","digital9_7.png","digital9_8.png","digital9_9.png"],
              // radius: 216,
              // angle: 115,
              // char_space_angle: 1,
              // dot_image: 'digital9_10.png',
              // error_image: 'digital7_15.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'digital9_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'digital9_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'digital9_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'digital9_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'digital9_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'digital9_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'digital9_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'digital9_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'digital9_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'digital9_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 227 + 195,
                src: 'digital9_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 142,
              y: 312,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              negative_image: 'digital7_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 237,
              y: 312,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              angle: -66,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 198,
              y: 48,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 216,
              // angle: 158,
              // char_space_angle: 1,
              // unit: 'digital7_14.png',
              // error_image: 'digital7_15.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_battery_TextCircle_img_width / 2,
                pos_y: 227 + 191,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 227 + 191,
              src: 'digital7_14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 190,
              // angle: -37,
              // char_space_angle: 0,
              // dot_image: 'digital7_10.png',
              // error_image: 'digital7_15.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_distance_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 349,
              font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_month_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 190,
              // angle: 5,
              // char_space_angle: 0,
              // unit: 'digital7_10.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.MONTH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_month_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_month_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_month_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_month_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_month_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_month_TextCircle_unit_width / 2,
              pos_y: 227 - 215,
              src: 'digital7_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 216,
              // angle: -141,
              // char_space_angle: 0,
              // error_image: 'digital7_15.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 227 + 191,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 190,
              // angle: -12,
              // char_space_angle: 0,
              // unit: 'digital7_10.png',
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_day_TextCircle_img_width / 2,
                pos_y: 227 - 215,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_day_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_day_TextCircle_unit_width / 2,
              pos_y: 227 - 215,
              src: 'digital7_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 228,
              // circle_center_Y: 228,
              // font_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              // radius: 190,
              // angle: 82,
              // char_space_angle: 0,
              // error_image: 'digital7_15.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'digital7_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'digital7_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'digital7_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'digital7_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'digital7_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'digital7_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'digital7_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'digital7_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'digital7_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'digital7_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 228,
                center_y: 228,
                pos_x: 228 - normal_step_TextCircle_img_width / 2,
                pos_y: 228 - 215,
                src: 'digital7_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 190,
              hour_array: ["digital8_0.png","digital8_1.png","digital8_2.png","digital8_3.png","digital8_4.png","digital8_5.png","digital8_6.png","digital8_7.png","digital8_8.png","digital8_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 231,
              minute_startY: 190,
              minute_array: ["digital6_0.png","digital6_1.png","digital6_2.png","digital6_3.png","digital6_4.png","digital6_5.png","digital6_6.png","digital6_7.png","digital6_8.png","digital6_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 354,
              second_startY: 190,
              second_array: ["digital7_0.png","digital7_1.png","digital7_2.png","digital7_3.png","digital7_4.png","digital7_5.png","digital7_6.png","digital7_7.png","digital7_8.png","digital7_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 261,
              y: 70,
              w: 56,
              h: 55,
              src: 'short.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 230,
              y: 281,
              w: 100,
              h: 57,
              src: 'short.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 75,
              w: 115,
              h: 45,
              src: 'short.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 47,
              y: 342,
              w: 78,
              h: 68,
              src: 'short.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 388,
              y: 104,
              w: 97,
              h: 111,
              src: 'short.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 324;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 216));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunrise_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'digital9_10.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunrise_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_sunrise_TextCircle_error_img_width / 2);
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_sunrise_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 295;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 216));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 216));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunset_TextCircle_img_angle + 1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle -= normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'digital9_10.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_sunset_TextCircle_dot_img_angle + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_sunset_TextCircle_error_img_width / 2);
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_sunset_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 338;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 216));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 216));
                  // alignment = RIGHT
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 1 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 1) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -37;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 190));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 190));
                  // alignment = RIGHT
                  let normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_img_angle * (normal_distance_circle_string.length - 1);
                  normal_distance_TextCircle_angleOffset = normal_distance_TextCircle_angleOffset - normal_distance_TextCircle_img_angle + normal_distance_TextCircle_dot_img_angle;
                  char_Angle -= 2 * normal_distance_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'digital7_10.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_distance_TextCircle_error_img_width / 2);
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_distance_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle month_TIME');
              let valueMonth = timeSensor.month;
              let normal_month_circle_string = parseInt(valueMonth).toString();
              normal_month_circle_string = normal_month_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_month_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 5;
                if (valueMonth != null && valueMonth != undefined && isFinite(valueMonth) && normal_month_circle_string.length > 0 && normal_month_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_month_TextCircle_img_angle = 0;
                  let normal_month_TextCircle_dot_img_angle = 0;
                  let normal_month_TextCircle_unit_angle = 0;
                  normal_month_TextCircle_img_angle = toDegree(Math.atan2(normal_month_TextCircle_img_width/2, 190));
                  normal_month_TextCircle_unit_angle = toDegree(Math.atan2(normal_month_TextCircle_unit_width/2, 190));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_month_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_month_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_month_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_month_TextCircle_img_width / 2);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.SRC, normal_month_TextCircle_ASCIIARRAY[charCode]);
                      normal_month_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_month_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_month_TextCircle_unit_angle;
                  normal_month_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_month_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 39;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 216));
                  // alignment = RIGHT
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -12;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  let normal_day_TextCircle_unit_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 190));
                  normal_day_TextCircle_unit_angle = toDegree(Math.atan2(normal_day_TextCircle_unit_width/2, 190));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_day_TextCircle_unit_angle;
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 82;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 190));
                  // alignment = RIGHT
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  char_Angle -= 2 * normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 228 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 228 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'digital7_15.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}