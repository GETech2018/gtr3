﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let editableZone_1_step_circle_scale = null;
        let editableZone_1_calorie_circle_scale = null;
        let editableZone_1_heart_rate_circle_scale = null;
        let editableZone_1_pai_circle_scale = null;
        let editableZone_1_stand_circle_scale = null;
        let editGroup_1  = ''
        let editableZone_2_step_circle_scale = null;
        let editableZone_2_calorie_circle_scale = null;
        let editableZone_2_heart_rate_circle_scale = null;
        let editableZone_2_pai_circle_scale = null;
        let editableZone_2_stand_circle_scale = null;
        let editGroup_2  = ''
        let editableZone_3_step_circle_scale = null;
        let editableZone_3_calorie_circle_scale = null;
        let editableZone_3_heart_rate_circle_scale = null;
        let editableZone_3_pai_circle_scale = null;
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 0,
              hour_array: ["H2_0.png","H2_1.png","H2_2.png","H2_3.png","H2_4.png","H2_5.png","H2_6.png","H2_7.png","H2_8.png","H2_9.png"],
              hour_zero: 1,
              hour_space: -11,
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 207,
              minute_array: ["H1_0.png","H1_1.png","H1_2.png","H1_3.png","H1_4.png","H1_5.png","H1_6.png","H1_7.png","H1_8.png","H1_9.png"],
              minute_zero: 1,
              minute_space: -11,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 321,
              y: 369,
              image_array: ["Weat_1.png","Weat_2.png","Weat_3.png","Weat_4.png","Weat_5.png","Weat_6.png","Weat_7.png","Weat_8.png","Weat_9.png","Weat_10.png","Weat_11.png","Weat_12.png","Weat_13.png","Weat_14.png","Weat_15.png","Weat_16.png","Weat_17.png","Weat_18.png","Weat_19.png","Weat_20.png","Weat_21.png","Weat_22.png","Weat_23.png","Weat_24.png","Weat_25.png","Weat_26.png","Weat_27.png","Weat_28.png","Weat_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 31,
              src: 'icon_18.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 58,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'dig_sm_15.png',
              unit_tc: 'dig_sm_15.png',
              unit_en: 'dig_sm_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 293,
              y: 166,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 279,
              day_startY: 194,
              day_sc_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_tc_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_en_array: ["Data_0.png","Data_1.png","Data_2.png","Data_3.png","Data_4.png","Data_5.png","Data_6.png","Data_7.png","Data_8.png","Data_9.png"],
              day_zero: 0,
              day_space: -6,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 291,
              month_startY: 252,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 154,
              src: 'status_1.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 274,
              src: 'status_2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            let screenType = hmSetting.getScreenType();            
            const step = hmSensor.createSensor(hmSensor.id.STEP);

                        
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

                        
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);

                        
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

                        
            const stand = hmSensor.createSensor(hmSensor.id.STAND);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 362,
              y: 173,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              tips_BG: '00003.png',
              tips_x: -265,
              tips_y: 35,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 401,
                  y: 175,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                step.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 369,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -4,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 400,
                  y: 176,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_1_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                calorie.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 376,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_1_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                heart_rate.addEventListener(hmSensor.event.LAST, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 395,
                  y: 183,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_1_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                pai.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 396,
                  y: 180,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 371,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 392,
                  y: 176,
                  src: 'icon_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                // editableZone_1_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 407,
                  // center_y: 227,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                stand.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 362,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 401,
                  y: 180,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 384,
                  y: 216,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 397,
                  y: 178,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 397,
              y: 181,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 383,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 396,
                  y: 180,
                  src: 'icon_10.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 380,
                  y: 208,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 380,
                  y: 234,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 380,
                  y: 181,
                  font_array: ["dig_sm_b_1.png","dig_sm_b_2.png","dig_sm_b_3.png","dig_sm_b_4.png","dig_sm_b_5.png","dig_sm_b_6.png","dig_sm_b_7.png","dig_sm_b_8.png","dig_sm_b_9.png","dig_sm_b_10.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_b_11.png',
                  unit_tc: 'dig_sm_b_11.png',
                  unit_en: 'dig_sm_b_11.png',
                  negative_image: 'dig_sm_b_12.png',
                  invalid_image: 'dig_sm_b_13.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 390,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 396,
                  y: 182,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 376,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 400,
                  y: 178,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 374,
                  y: 215,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 395,
                  y: 180,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 206,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 396,
                  y: 176,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 373,
                  y: 228,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 390,
                  y: 214,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 396,
              y: 182,
              src: 'icon_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 362,
                  y: 192,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            
            
            
            
            
            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 331,
              y: 76,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              tips_BG: '00003.png',
              tips_x: -234,
              tips_y: 36,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                // editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -4,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 370,
                  y: 84,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_2_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 367,
                  y: 82,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_2_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 362,
                  y: 85,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                // editableZone_2_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 84,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 340,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 360,
                  y: 82,
                  src: 'icon_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                // editableZone_2_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 130,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STAND,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_2_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 119,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 369,
                  y: 83,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 82,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 117,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 364,
              y: 83,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 83,
                  src: 'icon_10.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 349,
                  y: 109,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 349,
                  y: 134,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 349,
                  y: 84,
                  font_array: ["dig_sm_b_1.png","dig_sm_b_2.png","dig_sm_b_3.png","dig_sm_b_4.png","dig_sm_b_5.png","dig_sm_b_6.png","dig_sm_b_7.png","dig_sm_b_8.png","dig_sm_b_9.png","dig_sm_b_10.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_b_11.png',
                  unit_tc: 'dig_sm_b_11.png',
                  unit_en: 'dig_sm_b_11.png',
                  negative_image: 'dig_sm_b_12.png',
                  invalid_image: 'dig_sm_b_13.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 117,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 84,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 345,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 368,
                  y: 84,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 120,
                  font_array: ["dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png","dig_sm_10.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 82,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 109,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 79,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 132,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 359,
                  y: 118,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 86,
              src: 'icon_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 95,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            
            
            
            
            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 331,
              y: 271,
              w: 90,
              h: 107,
              select_image: '00002.png',
              un_select_image: '00001.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL_preview.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART_preview.png' },
                { type: hmUI.edit_type.PAI, preview: 'ez(3)_PAI_preview.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE_preview.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
                { type: hmUI.edit_type.STRESS, preview: 'ez(1)_STRESS.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'Fat burning', title_tc: 'Fat burning', title_en: 'Fat burning' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(2)_SPO2.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER_preview.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND_preview.png' },
              ],
              count: 15,
              tips_BG: '00003.png',
              tips_x: -234,
              tips_y: 35,
              tips_width: 212,
              tips_margin: 6,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                // editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.STEP,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 337,
                  y: 316,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 369,
                  y: 276,
                  src: 'icon_9.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                // editableZone_3_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.CAL,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 368,
                  y: 276,
                  src: 'icon_1.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                // editableZone_3_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 40,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.HEART,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 353,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 280,
                  src: 'icon_6.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.PAI:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 279,
                  src: 'icon_5.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                // editableZone_3_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
                  // center_x: 376,
                  // center_y: 324,
                  // start_angle: 37,
                  // end_angle: 320,
                  // radius: 44,
                  // line_width: 8,
                  // color: 0xFF04B5BB,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.PAI_WEEKLY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_3_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
                };
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  dot_image: 'dig_sm_14.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 361,
                  y: 276,
                  src: 'icon_19.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 369,
                  y: 279,
                  src: 'icon_11.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STAND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STRESS:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 351,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 277,
                  src: 'icon_12.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STRESS,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.FAT_BURNING,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 365,
              y: 277,
              src: 'icon_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 352,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 277,
                  src: 'icon_10.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 305,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_HIGH,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 330,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_10.png',
                  unit_tc: 'dig_sm_10.png',
                  unit_en: 'dig_sm_10.png',
                  negative_image: 'dig_sm_11.png',
                  invalid_image: 'dig_sm_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_LOW,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 279,
                  font_array: ["dig_sm_b_1.png","dig_sm_b_2.png","dig_sm_b_3.png","dig_sm_b_4.png","dig_sm_b_5.png","dig_sm_b_6.png","dig_sm_b_7.png","dig_sm_b_8.png","dig_sm_b_9.png","dig_sm_b_10.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_b_11.png',
                  unit_tc: 'dig_sm_b_11.png',
                  unit_en: 'dig_sm_b_11.png',
                  negative_image: 'dig_sm_b_12.png',
                  invalid_image: 'dig_sm_b_13.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 357,
                  y: 313,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 278,
                  src: 'icon_8.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog5_1.png","prog5_2.png","prog5_3.png","prog5_4.png","prog5_5.png"],
                  image_length: 5,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 369,
                  y: 278,
                  src: 'icon_7.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 344,
                  y: 314,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'dig_sm_15.png',
                  unit_tc: 'dig_sm_15.png',
                  unit_en: 'dig_sm_15.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 343,
                  y: 315,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 364,
                  y: 275,
                  src: 'icon_4.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 342,
                  y: 304,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_RISE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 365,
                  y: 274,
                  src: 'icon_17.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 341,
                  y: 326,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -3,
                  dot_image: 'dig_sm_13.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SUN_SET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.SUN_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 360,
                  y: 313,
                  font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                  padding: false,
                  h_space: -2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 367,
              y: 278,
              src: 'icon_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 332,
                  y: 289,
                  image_array: ["prog10_1.png","prog10_2.png","prog10_3.png","prog10_4.png","prog10_5.png","prog10_6.png","prog10_7.png","prog10_8.png","prog10_9.png","prog10_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '000005.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '00004.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            function scale_call() {

                console.log('update editable circle_scale STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_editableZone_1_step = progressStep;

                if (editableZone_1_step_circle_scale) {

                  // editableZone_1_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_step = -50;
                  let end_angle_editableZone_1_step = 230;
                  let center_x_editableZone_1_step = 407;
                  let center_y_editableZone_1_step = 227;
                  let radius_editableZone_1_step = 44;
                  let line_width_cs_editableZone_1_step = 8;
                  let color_cs_editableZone_1_step = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_1_step = center_x_editableZone_1_step - radius_editableZone_1_step;
                  let arcY_editableZone_1_step = center_y_editableZone_1_step - radius_editableZone_1_step;
                  let CircleWidth_editableZone_1_step = 2 * radius_editableZone_1_step;
                  let angle_offset_editableZone_1_step = end_angle_editableZone_1_step - start_angle_editableZone_1_step;
                  angle_offset_editableZone_1_step = angle_offset_editableZone_1_step * progress_cs_editableZone_1_step;
                  let end_angle_editableZone_1_step_draw = start_angle_editableZone_1_step + angle_offset_editableZone_1_step;
                  
                  editableZone_1_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_step,
                    y: arcY_editableZone_1_step,
                    w: CircleWidth_editableZone_1_step,
                    h: CircleWidth_editableZone_1_step,
                    start_angle: start_angle_editableZone_1_step,
                    end_angle: end_angle_editableZone_1_step_draw,
                    color: color_cs_editableZone_1_step,
                    line_width: line_width_cs_editableZone_1_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_editableZone_1_calorie = progressCalories;

                if (editableZone_1_calorie_circle_scale) {

                  // editableZone_1_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_calorie = -50;
                  let end_angle_editableZone_1_calorie = 230;
                  let center_x_editableZone_1_calorie = 407;
                  let center_y_editableZone_1_calorie = 227;
                  let radius_editableZone_1_calorie = 44;
                  let line_width_cs_editableZone_1_calorie = 8;
                  let color_cs_editableZone_1_calorie = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_1_calorie = center_x_editableZone_1_calorie - radius_editableZone_1_calorie;
                  let arcY_editableZone_1_calorie = center_y_editableZone_1_calorie - radius_editableZone_1_calorie;
                  let CircleWidth_editableZone_1_calorie = 2 * radius_editableZone_1_calorie;
                  let angle_offset_editableZone_1_calorie = end_angle_editableZone_1_calorie - start_angle_editableZone_1_calorie;
                  angle_offset_editableZone_1_calorie = angle_offset_editableZone_1_calorie * progress_cs_editableZone_1_calorie;
                  let end_angle_editableZone_1_calorie_draw = start_angle_editableZone_1_calorie + angle_offset_editableZone_1_calorie;
                  
                  editableZone_1_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_calorie,
                    y: arcY_editableZone_1_calorie,
                    w: CircleWidth_editableZone_1_calorie,
                    h: CircleWidth_editableZone_1_calorie,
                    start_angle: start_angle_editableZone_1_calorie,
                    end_angle: end_angle_editableZone_1_calorie_draw,
                    color: color_cs_editableZone_1_calorie,
                    line_width: line_width_cs_editableZone_1_calorie,
                  });
                };

                console.log('update editable circle_scale HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_editableZone_1_heart_rate = progressHeartRate;

                if (editableZone_1_heart_rate_circle_scale) {

                  // editableZone_1_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_heart_rate = -50;
                  let end_angle_editableZone_1_heart_rate = 230;
                  let center_x_editableZone_1_heart_rate = 407;
                  let center_y_editableZone_1_heart_rate = 227;
                  let radius_editableZone_1_heart_rate = 44;
                  let line_width_cs_editableZone_1_heart_rate = 8;
                  let color_cs_editableZone_1_heart_rate = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_1_heart_rate = center_x_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let arcY_editableZone_1_heart_rate = center_y_editableZone_1_heart_rate - radius_editableZone_1_heart_rate;
                  let CircleWidth_editableZone_1_heart_rate = 2 * radius_editableZone_1_heart_rate;
                  let angle_offset_editableZone_1_heart_rate = end_angle_editableZone_1_heart_rate - start_angle_editableZone_1_heart_rate;
                  angle_offset_editableZone_1_heart_rate = angle_offset_editableZone_1_heart_rate * progress_cs_editableZone_1_heart_rate;
                  let end_angle_editableZone_1_heart_rate_draw = start_angle_editableZone_1_heart_rate + angle_offset_editableZone_1_heart_rate;
                  
                  editableZone_1_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_heart_rate,
                    y: arcY_editableZone_1_heart_rate,
                    w: CircleWidth_editableZone_1_heart_rate,
                    h: CircleWidth_editableZone_1_heart_rate,
                    start_angle: start_angle_editableZone_1_heart_rate,
                    end_angle: end_angle_editableZone_1_heart_rate_draw,
                    color: color_cs_editableZone_1_heart_rate,
                    line_width: line_width_cs_editableZone_1_heart_rate,
                  });
                };

                console.log('update editable circle_scale PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_editableZone_1_pai = progressPAI;

                if (editableZone_1_pai_circle_scale) {

                  // editableZone_1_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_pai = -50;
                  let end_angle_editableZone_1_pai = 230;
                  let center_x_editableZone_1_pai = 407;
                  let center_y_editableZone_1_pai = 227;
                  let radius_editableZone_1_pai = 44;
                  let line_width_cs_editableZone_1_pai = 8;
                  let color_cs_editableZone_1_pai = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_1_pai = center_x_editableZone_1_pai - radius_editableZone_1_pai;
                  let arcY_editableZone_1_pai = center_y_editableZone_1_pai - radius_editableZone_1_pai;
                  let CircleWidth_editableZone_1_pai = 2 * radius_editableZone_1_pai;
                  let angle_offset_editableZone_1_pai = end_angle_editableZone_1_pai - start_angle_editableZone_1_pai;
                  angle_offset_editableZone_1_pai = angle_offset_editableZone_1_pai * progress_cs_editableZone_1_pai;
                  let end_angle_editableZone_1_pai_draw = start_angle_editableZone_1_pai + angle_offset_editableZone_1_pai;
                  
                  editableZone_1_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_pai,
                    y: arcY_editableZone_1_pai,
                    w: CircleWidth_editableZone_1_pai,
                    h: CircleWidth_editableZone_1_pai,
                    start_angle: start_angle_editableZone_1_pai,
                    end_angle: end_angle_editableZone_1_pai_draw,
                    color: color_cs_editableZone_1_pai,
                    line_width: line_width_cs_editableZone_1_pai,
                  });
                };

                console.log('update editable circle_scale STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_editableZone_1_stand = progressStand;

                if (editableZone_1_stand_circle_scale) {

                  // editableZone_1_stand_circle_scale
                  // initial parameters
                  let start_angle_editableZone_1_stand = -50;
                  let end_angle_editableZone_1_stand = 230;
                  let center_x_editableZone_1_stand = 407;
                  let center_y_editableZone_1_stand = 227;
                  let radius_editableZone_1_stand = 44;
                  let line_width_cs_editableZone_1_stand = 8;
                  let color_cs_editableZone_1_stand = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_1_stand = center_x_editableZone_1_stand - radius_editableZone_1_stand;
                  let arcY_editableZone_1_stand = center_y_editableZone_1_stand - radius_editableZone_1_stand;
                  let CircleWidth_editableZone_1_stand = 2 * radius_editableZone_1_stand;
                  let angle_offset_editableZone_1_stand = end_angle_editableZone_1_stand - start_angle_editableZone_1_stand;
                  angle_offset_editableZone_1_stand = angle_offset_editableZone_1_stand * progress_cs_editableZone_1_stand;
                  let end_angle_editableZone_1_stand_draw = start_angle_editableZone_1_stand + angle_offset_editableZone_1_stand;
                  
                  editableZone_1_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_1_stand,
                    y: arcY_editableZone_1_stand,
                    w: CircleWidth_editableZone_1_stand,
                    h: CircleWidth_editableZone_1_stand,
                    start_angle: start_angle_editableZone_1_stand,
                    end_angle: end_angle_editableZone_1_stand_draw,
                    color: color_cs_editableZone_1_stand,
                    line_width: line_width_cs_editableZone_1_stand,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_2_step = progressStep;

                if (editableZone_2_step_circle_scale) {

                  // editableZone_2_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_step = -50;
                  let end_angle_editableZone_2_step = 230;
                  let center_x_editableZone_2_step = 376;
                  let center_y_editableZone_2_step = 130;
                  let radius_editableZone_2_step = 44;
                  let line_width_cs_editableZone_2_step = 8;
                  let color_cs_editableZone_2_step = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_2_step = center_x_editableZone_2_step - radius_editableZone_2_step;
                  let arcY_editableZone_2_step = center_y_editableZone_2_step - radius_editableZone_2_step;
                  let CircleWidth_editableZone_2_step = 2 * radius_editableZone_2_step;
                  let angle_offset_editableZone_2_step = end_angle_editableZone_2_step - start_angle_editableZone_2_step;
                  angle_offset_editableZone_2_step = angle_offset_editableZone_2_step * progress_cs_editableZone_2_step;
                  let end_angle_editableZone_2_step_draw = start_angle_editableZone_2_step + angle_offset_editableZone_2_step;
                  
                  editableZone_2_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_step,
                    y: arcY_editableZone_2_step,
                    w: CircleWidth_editableZone_2_step,
                    h: CircleWidth_editableZone_2_step,
                    start_angle: start_angle_editableZone_2_step,
                    end_angle: end_angle_editableZone_2_step_draw,
                    color: color_cs_editableZone_2_step,
                    line_width: line_width_cs_editableZone_2_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_2_calorie = progressCalories;

                if (editableZone_2_calorie_circle_scale) {

                  // editableZone_2_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_calorie = -50;
                  let end_angle_editableZone_2_calorie = 230;
                  let center_x_editableZone_2_calorie = 376;
                  let center_y_editableZone_2_calorie = 130;
                  let radius_editableZone_2_calorie = 44;
                  let line_width_cs_editableZone_2_calorie = 8;
                  let color_cs_editableZone_2_calorie = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_2_calorie = center_x_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let arcY_editableZone_2_calorie = center_y_editableZone_2_calorie - radius_editableZone_2_calorie;
                  let CircleWidth_editableZone_2_calorie = 2 * radius_editableZone_2_calorie;
                  let angle_offset_editableZone_2_calorie = end_angle_editableZone_2_calorie - start_angle_editableZone_2_calorie;
                  angle_offset_editableZone_2_calorie = angle_offset_editableZone_2_calorie * progress_cs_editableZone_2_calorie;
                  let end_angle_editableZone_2_calorie_draw = start_angle_editableZone_2_calorie + angle_offset_editableZone_2_calorie;
                  
                  editableZone_2_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_calorie,
                    y: arcY_editableZone_2_calorie,
                    w: CircleWidth_editableZone_2_calorie,
                    h: CircleWidth_editableZone_2_calorie,
                    start_angle: start_angle_editableZone_2_calorie,
                    end_angle: end_angle_editableZone_2_calorie_draw,
                    color: color_cs_editableZone_2_calorie,
                    line_width: line_width_cs_editableZone_2_calorie,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_2_heart_rate = progressHeartRate;

                if (editableZone_2_heart_rate_circle_scale) {

                  // editableZone_2_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_heart_rate = -50;
                  let end_angle_editableZone_2_heart_rate = 230;
                  let center_x_editableZone_2_heart_rate = 376;
                  let center_y_editableZone_2_heart_rate = 130;
                  let radius_editableZone_2_heart_rate = 44;
                  let line_width_cs_editableZone_2_heart_rate = 8;
                  let color_cs_editableZone_2_heart_rate = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_2_heart_rate = center_x_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let arcY_editableZone_2_heart_rate = center_y_editableZone_2_heart_rate - radius_editableZone_2_heart_rate;
                  let CircleWidth_editableZone_2_heart_rate = 2 * radius_editableZone_2_heart_rate;
                  let angle_offset_editableZone_2_heart_rate = end_angle_editableZone_2_heart_rate - start_angle_editableZone_2_heart_rate;
                  angle_offset_editableZone_2_heart_rate = angle_offset_editableZone_2_heart_rate * progress_cs_editableZone_2_heart_rate;
                  let end_angle_editableZone_2_heart_rate_draw = start_angle_editableZone_2_heart_rate + angle_offset_editableZone_2_heart_rate;
                  
                  editableZone_2_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_heart_rate,
                    y: arcY_editableZone_2_heart_rate,
                    w: CircleWidth_editableZone_2_heart_rate,
                    h: CircleWidth_editableZone_2_heart_rate,
                    start_angle: start_angle_editableZone_2_heart_rate,
                    end_angle: end_angle_editableZone_2_heart_rate_draw,
                    color: color_cs_editableZone_2_heart_rate,
                    line_width: line_width_cs_editableZone_2_heart_rate,
                  });
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_2_pai = progressPAI;

                if (editableZone_2_pai_circle_scale) {

                  // editableZone_2_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_pai = -50;
                  let end_angle_editableZone_2_pai = 230;
                  let center_x_editableZone_2_pai = 376;
                  let center_y_editableZone_2_pai = 130;
                  let radius_editableZone_2_pai = 44;
                  let line_width_cs_editableZone_2_pai = 8;
                  let color_cs_editableZone_2_pai = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_2_pai = center_x_editableZone_2_pai - radius_editableZone_2_pai;
                  let arcY_editableZone_2_pai = center_y_editableZone_2_pai - radius_editableZone_2_pai;
                  let CircleWidth_editableZone_2_pai = 2 * radius_editableZone_2_pai;
                  let angle_offset_editableZone_2_pai = end_angle_editableZone_2_pai - start_angle_editableZone_2_pai;
                  angle_offset_editableZone_2_pai = angle_offset_editableZone_2_pai * progress_cs_editableZone_2_pai;
                  let end_angle_editableZone_2_pai_draw = start_angle_editableZone_2_pai + angle_offset_editableZone_2_pai;
                  
                  editableZone_2_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_pai,
                    y: arcY_editableZone_2_pai,
                    w: CircleWidth_editableZone_2_pai,
                    h: CircleWidth_editableZone_2_pai,
                    start_angle: start_angle_editableZone_2_pai,
                    end_angle: end_angle_editableZone_2_pai_draw,
                    color: color_cs_editableZone_2_pai,
                    line_width: line_width_cs_editableZone_2_pai,
                  });
                };

                console.log('update editable circle_scale STAND');
                let progress_cs_editableZone_2_stand = progressStand;

                if (editableZone_2_stand_circle_scale) {

                  // editableZone_2_stand_circle_scale
                  // initial parameters
                  let start_angle_editableZone_2_stand = -50;
                  let end_angle_editableZone_2_stand = 230;
                  let center_x_editableZone_2_stand = 376;
                  let center_y_editableZone_2_stand = 130;
                  let radius_editableZone_2_stand = 44;
                  let line_width_cs_editableZone_2_stand = 8;
                  let color_cs_editableZone_2_stand = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_2_stand = center_x_editableZone_2_stand - radius_editableZone_2_stand;
                  let arcY_editableZone_2_stand = center_y_editableZone_2_stand - radius_editableZone_2_stand;
                  let CircleWidth_editableZone_2_stand = 2 * radius_editableZone_2_stand;
                  let angle_offset_editableZone_2_stand = end_angle_editableZone_2_stand - start_angle_editableZone_2_stand;
                  angle_offset_editableZone_2_stand = angle_offset_editableZone_2_stand * progress_cs_editableZone_2_stand;
                  let end_angle_editableZone_2_stand_draw = start_angle_editableZone_2_stand + angle_offset_editableZone_2_stand;
                  
                  editableZone_2_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_2_stand,
                    y: arcY_editableZone_2_stand,
                    w: CircleWidth_editableZone_2_stand,
                    h: CircleWidth_editableZone_2_stand,
                    start_angle: start_angle_editableZone_2_stand,
                    end_angle: end_angle_editableZone_2_stand_draw,
                    color: color_cs_editableZone_2_stand,
                    line_width: line_width_cs_editableZone_2_stand,
                  });
                };

                console.log('update editable circle_scale STEP');
                let progress_cs_editableZone_3_step = progressStep;

                if (editableZone_3_step_circle_scale) {

                  // editableZone_3_step_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_step = -50;
                  let end_angle_editableZone_3_step = 230;
                  let center_x_editableZone_3_step = 376;
                  let center_y_editableZone_3_step = 324;
                  let radius_editableZone_3_step = 44;
                  let line_width_cs_editableZone_3_step = 8;
                  let color_cs_editableZone_3_step = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_3_step = center_x_editableZone_3_step - radius_editableZone_3_step;
                  let arcY_editableZone_3_step = center_y_editableZone_3_step - radius_editableZone_3_step;
                  let CircleWidth_editableZone_3_step = 2 * radius_editableZone_3_step;
                  let angle_offset_editableZone_3_step = end_angle_editableZone_3_step - start_angle_editableZone_3_step;
                  angle_offset_editableZone_3_step = angle_offset_editableZone_3_step * progress_cs_editableZone_3_step;
                  let end_angle_editableZone_3_step_draw = start_angle_editableZone_3_step + angle_offset_editableZone_3_step;
                  
                  editableZone_3_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_step,
                    y: arcY_editableZone_3_step,
                    w: CircleWidth_editableZone_3_step,
                    h: CircleWidth_editableZone_3_step,
                    start_angle: start_angle_editableZone_3_step,
                    end_angle: end_angle_editableZone_3_step_draw,
                    color: color_cs_editableZone_3_step,
                    line_width: line_width_cs_editableZone_3_step,
                  });
                };

                console.log('update editable circle_scale CALORIE');
                let progress_cs_editableZone_3_calorie = progressCalories;

                if (editableZone_3_calorie_circle_scale) {

                  // editableZone_3_calorie_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_calorie = -50;
                  let end_angle_editableZone_3_calorie = 230;
                  let center_x_editableZone_3_calorie = 376;
                  let center_y_editableZone_3_calorie = 324;
                  let radius_editableZone_3_calorie = 44;
                  let line_width_cs_editableZone_3_calorie = 8;
                  let color_cs_editableZone_3_calorie = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_3_calorie = center_x_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let arcY_editableZone_3_calorie = center_y_editableZone_3_calorie - radius_editableZone_3_calorie;
                  let CircleWidth_editableZone_3_calorie = 2 * radius_editableZone_3_calorie;
                  let angle_offset_editableZone_3_calorie = end_angle_editableZone_3_calorie - start_angle_editableZone_3_calorie;
                  angle_offset_editableZone_3_calorie = angle_offset_editableZone_3_calorie * progress_cs_editableZone_3_calorie;
                  let end_angle_editableZone_3_calorie_draw = start_angle_editableZone_3_calorie + angle_offset_editableZone_3_calorie;
                  
                  editableZone_3_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_calorie,
                    y: arcY_editableZone_3_calorie,
                    w: CircleWidth_editableZone_3_calorie,
                    h: CircleWidth_editableZone_3_calorie,
                    start_angle: start_angle_editableZone_3_calorie,
                    end_angle: end_angle_editableZone_3_calorie_draw,
                    color: color_cs_editableZone_3_calorie,
                    line_width: line_width_cs_editableZone_3_calorie,
                  });
                };

                console.log('update editable circle_scale HEART');
                let progress_cs_editableZone_3_heart_rate = progressHeartRate;

                if (editableZone_3_heart_rate_circle_scale) {

                  // editableZone_3_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_heart_rate = -50;
                  let end_angle_editableZone_3_heart_rate = 230;
                  let center_x_editableZone_3_heart_rate = 376;
                  let center_y_editableZone_3_heart_rate = 324;
                  let radius_editableZone_3_heart_rate = 44;
                  let line_width_cs_editableZone_3_heart_rate = 8;
                  let color_cs_editableZone_3_heart_rate = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_3_heart_rate = center_x_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let arcY_editableZone_3_heart_rate = center_y_editableZone_3_heart_rate - radius_editableZone_3_heart_rate;
                  let CircleWidth_editableZone_3_heart_rate = 2 * radius_editableZone_3_heart_rate;
                  let angle_offset_editableZone_3_heart_rate = end_angle_editableZone_3_heart_rate - start_angle_editableZone_3_heart_rate;
                  angle_offset_editableZone_3_heart_rate = angle_offset_editableZone_3_heart_rate * progress_cs_editableZone_3_heart_rate;
                  let end_angle_editableZone_3_heart_rate_draw = start_angle_editableZone_3_heart_rate + angle_offset_editableZone_3_heart_rate;
                  
                  editableZone_3_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_heart_rate,
                    y: arcY_editableZone_3_heart_rate,
                    w: CircleWidth_editableZone_3_heart_rate,
                    h: CircleWidth_editableZone_3_heart_rate,
                    start_angle: start_angle_editableZone_3_heart_rate,
                    end_angle: end_angle_editableZone_3_heart_rate_draw,
                    color: color_cs_editableZone_3_heart_rate,
                    line_width: line_width_cs_editableZone_3_heart_rate,
                  });
                };

                console.log('update editable circle_scale PAI');
                let progress_cs_editableZone_3_pai = progressPAI;

                if (editableZone_3_pai_circle_scale) {

                  // editableZone_3_pai_circle_scale
                  // initial parameters
                  let start_angle_editableZone_3_pai = -53;
                  let end_angle_editableZone_3_pai = 230;
                  let center_x_editableZone_3_pai = 376;
                  let center_y_editableZone_3_pai = 324;
                  let radius_editableZone_3_pai = 44;
                  let line_width_cs_editableZone_3_pai = 8;
                  let color_cs_editableZone_3_pai = 0xFF04B5BB;
                  
                  // calculated parameters
                  let arcX_editableZone_3_pai = center_x_editableZone_3_pai - radius_editableZone_3_pai;
                  let arcY_editableZone_3_pai = center_y_editableZone_3_pai - radius_editableZone_3_pai;
                  let CircleWidth_editableZone_3_pai = 2 * radius_editableZone_3_pai;
                  let angle_offset_editableZone_3_pai = end_angle_editableZone_3_pai - start_angle_editableZone_3_pai;
                  angle_offset_editableZone_3_pai = angle_offset_editableZone_3_pai * progress_cs_editableZone_3_pai;
                  let end_angle_editableZone_3_pai_draw = start_angle_editableZone_3_pai + angle_offset_editableZone_3_pai;
                  
                  editableZone_3_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_editableZone_3_pai,
                    y: arcY_editableZone_3_pai,
                    w: CircleWidth_editableZone_3_pai,
                    h: CircleWidth_editableZone_3_pai,
                    start_angle: start_angle_editableZone_3_pai,
                    end_angle: end_angle_editableZone_3_pai_draw,
                    color: color_cs_editableZone_3_pai,
                    line_width: line_width_cs_editableZone_3_pai,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
              pause_call: (function () {
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});
                if (heart_rate) heart_rate.removeEventListener(heart_rate.event.LAST, function () {});

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
