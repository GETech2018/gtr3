﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 15;
        let normal_battery_TextCircle_img_height = 23;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 23;
        let normal_battery_TextCircle_error_img_width = 1;
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_day_text_font = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let editableZone_1_city_name_text = null;
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let editGroup_4  = ''
        let editGroup_5  = ''
        let editGroup_6  = ''
        let mask = ''
        let fg_mask = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'tar_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'tar_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'tar_3.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'tar_4.png' },
              ],
              count: 4,
              default_id: 1,
              fg: '.png',
              tips_bg: 'tt.png',
              tips_x: 152,
              tips_y: 209,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 363,
              src: 'zn_noBT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 282,
              y: 362,
              src: 'zn_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
              // radius: 68,
              // angle: 171,
              // char_space_angle: 3,
              // unit: 'cyf_m11.png',
              // error_image: 'zn_pusty.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'cyf_m00.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'cyf_m01.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'cyf_m02.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'cyf_m03.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'cyf_m04.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'cyf_m05.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'cyf_m06.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'cyf_m07.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'cyf_m08.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'cyf_m09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_battery_TextCircle_img_width / 2,
                pos_y: 227 + 57,
                src: 'cyf_m00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 227,
              center_y: 227,
              pos_x: 227 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 227 + 57,
              src: 'cyf_m11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 308,
              image_array: ["s00.png","s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png","s10.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 201,
              y: 352,
              week_en: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_tc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_sc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 194,
              y: 27,
              w: 69,
              h: 89,
              text_size: 48,
              char_space: -2,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 193,
              hour_startY: 200,
              hour_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wsk_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 53,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wsk_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 11,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'tar_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 380,
              font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'cyf_m11.png',
              unit_tc: 'cyf_m11.png',
              unit_en: 'cyf_m11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wH_AOD.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 8,
              hour_posY: 118,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wM_AOD.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 8,
              minute_posY: 178,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'wS_AOD.png',
              // center_x: 227,
              // center_y: 227,
              // x: 8,
              // y: 194,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 8,
              pos_y: 227 - 194,
              center_x: 227,
              center_y: 227,
              src: 'wS_AOD.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 6,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 273,
              y: 82,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -19,
              tips_y: 38,
              tips_width: 160,
              tips_margin: 4,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.WEATHER:
                editableZone_1_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
                  x: 260,
                  y: 232,
                  w: 150,
                  h: 30,
                  text_size: 15,
                  char_space: 0,
                  line_space: 0,
                  color: 0xFFFFFFFF,
                  align_h: hmUI.align.RIGHT,
                  align_v: hmUI.align.TOP,
                  text_style: hmUI.text_style.NONE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 273,
                  y: 82,
                  image_array: ["pog01.png","pog02.png","pog03.png","pog04.png","pog05.png","pog06.png","pog07.png","pog08.png","pog09.png","pog10.png","pog11.png","pog12.png","pog13.png","pog14.png","pog15.png","pog16.png","pog17.png","pog18.png","pog19.png","pog20.png","pog21.png","pog22.png","pog23.png","pog24.png","pog25.png","pog26.png","pog27.png","pog28.png","pog29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 339,
                  y: 165,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m13.png',
                  unit_tc: 'cyf_m13.png',
                  unit_en: 'cyf_m13.png',
                  negative_image: 'cyf_m10.png',
                  invalid_image: 'zn_pusty.png',
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 320,
              y: 182,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.ALTIMETER,
              optional_types: [
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: 1300002, preview: 'ez(2)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 5,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -49,
              tips_y: 47,
              tips_width: 160,
              tips_margin: 4,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 374,
                  y: 199,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 348,
                  y: 199,
                  src: 'zn_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 347,
                  y: 200,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: -1,
                  unit_sc: 'cyf_m11.png',
                  unit_tc: 'cyf_m11.png',
                  unit_en: 'cyf_m11.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 330,
                  y: 199,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 327,
                  y: 200,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'cyf_m15.png',
                  unit_tc: 'cyf_m15.png',
                  unit_en: 'cyf_m15.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 291,
                  y: 200,
                  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 374,
                  y: 199,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.RIGHT,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 340,
                  y: 199,
                  src: 'zn_wiatru.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 276,
              y: 282,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.HEART,
              optional_types: [
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.SPO2, preview: 'ez(3)_SPO2.png' },
                { type: 1300002, preview: 'ez(3)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 3,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -23,
              tips_y: 49,
              tips_width: 160,
              tips_margin: 4,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 321,
                  y: 304,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m16.png',
                  unit_tc: 'cyf_m16.png',
                  unit_en: 'cyf_m16.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 296,
                  y: 306,
                  src: 'zn_ser.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SPO2:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 335,
                  y: 296,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m11.png',
                  unit_tc: 'cyf_m11.png',
                  unit_en: 'cyf_m11.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.SPO2,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 286,
                  y: 294,
                  src: 'zn_SpO2.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 83,
              y: 286,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.CAL,
              optional_types: [
                { type: hmUI.edit_type.CAL, preview: 'ez(4)_CAL.png' },
                { type: 1300002, preview: 'ez(4)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -24,
              tips_y: 53,
              tips_width: 155,
              tips_margin: 4,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 83,
                  y: 285,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: -2,
                  unit_sc: 'cyf_m17.png',
                  unit_tc: 'cyf_m17.png',
                  unit_en: 'cyf_m17.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 59,
                  y: 285,
                  src: 'zn_kal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

               case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
           }; // end switch

            editGroup_5 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10025,
              x: 45,
              y: 95,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(5)_STEP.png' },
                { type: 1300002, preview: 'ez(5)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -26,
              tips_y: 72,
              tips_width: 150,
              tips_margin: 4,
            });

            const editType_5 = editGroup_5.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_5) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 82,
                  y: 151,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 57,
                  y: 142,
                  src: 'zn_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_6 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10026,
              x: 34,
              y: 187,
              w: 100,
              h: 100,
              select_image: 'r_akt.png',
              un_select_image: 'r_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(6)_DISTANCE.png' },
                { type: 1300002, preview: 'ez(6)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 2,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tt.png',
              tips_x: -22,
              tips_y: 64,
              tips_width: 150,
              tips_margin: 4,
            });

            const editType_6 = editGroup_6.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_6) {
              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 40,
                  y: 218,
                  font_array: ["cyf_m00.png","cyf_m01.png","cyf_m02.png","cyf_m03.png","cyf_m04.png","cyf_m05.png","cyf_m06.png","cyf_m07.png","cyf_m08.png","cyf_m09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m14.png',
                  unit_tc: 'cyf_m14.png',
                  unit_en: 'cyf_m14.png',
                  dot_image: 'cyf_m12.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 227,
                  y: 227,
              	  src: 'zn_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'zn_pusty.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'zn_pusty.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(25);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 9,
            // });


            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(9);
              }
            };

            // end repeat alerts
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 312,
              w: 78,
              h: 52,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 360,
              w: 107,
              h: 67,
              src: 'zn_pusty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 232,
              y: 360,
              w: 100,
              h: 67,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 318,
              y: 194,
              w: 127,
              h: 80,
              src: 'zn_pusty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 92,
              w: 108,
              h: 100,
              src: 'zn_pusty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 197,
              w: 117,
              h: 80,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 276,
              w: 100,
              h: 80,
              src: 'zn_pusty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 115,
              w: 118,
              h: 80,
              src: 'zn_pusty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 133,
              y: 313,
              w: 44,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'kal_akt.png',
              normal_src: 'kal_pas.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 351;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 68));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 68));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + 3 * (normal_battery_circle_string.length - 1) / 2;
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 3) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle + 3;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 227 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'zn_pusty.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            function scale_call() {
              console.log('scale_call()');

              console.log('Edit element Wearther city name');

              if(editableZone_1_city_name_text){
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              editableZone_1_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/6;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}