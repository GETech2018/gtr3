﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_circle_scale = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 325,
              src: '0017.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 51,
              src: '0019.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 226,
              // center_y: 227,
              // start_angle: 0,
              // end_angle: 361,
              // radius: 221,
              // line_width: 7,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 371,
              image_array: ["0024.png","0025.png","0026.png","0027.png","0028.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 121,
              font_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 167,
              month_startY: 123,
              month_sc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              month_tc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              month_en_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 123,
              day_startY: 123,
              day_sc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_tc_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_en_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 307,
              font_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 307,
              font_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0023.png',
              unit_tc: '0023.png',
              unit_en: '0023.png',
              negative_image: '0022.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 59,
              y: 206,
              image_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","Preview.png","W0025.png","W0026.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 191,
              hour_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 191,
              minute_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 361,
              second_startY: 210,
              second_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 197,
              src: '0040.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 271;
                  let center_x_normal_calorie = 226;
                  let center_y_normal_calorie = 227;
                  let radius_normal_calorie = 221;
                  let line_width_cs_normal_calorie = 7;
                  let color_cs_normal_calorie = 0xFFFF0000;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  