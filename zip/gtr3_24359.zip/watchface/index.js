﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_altimeter_text_text_img = ''
        let normal_system_clock_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 393,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 311,
              y: 393,
              src: 'Batt_Font_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 273,
              year_startY: 211,
              year_sc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              year_tc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              year_en_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 258,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 358,
              y: 118,
              src: 'system_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 376,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 338,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'ACT_fONT_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 82,
              y: 67,
              week_en: ["WDay-01.png","WDay-02.png","WDay-03.png","WDay-04.png","WDay-05.png","WDay-06.png","WDay-07.png"],
              week_tc: ["WDay-01.png","WDay-02.png","WDay-03.png","WDay-04.png","WDay-05.png","WDay-06.png","WDay-07.png"],
              week_sc: ["WDay-01.png","WDay-02.png","WDay-03.png","WDay-04.png","WDay-05.png","WDay-06.png","WDay-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 127,
              day_startY: 211,
              day_sc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_tc_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_en_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 352,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 44,
              y: 253,
              w: 91,
              h: 28,
              text_size: 19,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 258,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_fONT_13.png',
              unit_tc: 'SMALL_fONT_13.png',
              unit_en: 'SMALL_fONT_13.png',
              negative_image: 'SMALL_fONT_14.png',
              invalid_image: 'SMALL_fONT_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 368,
              y: 258,
              font_array: ["SMALL_fONT_01.png","SMALL_fONT_02.png","SMALL_fONT_03.png","SMALL_fONT_04.png","SMALL_fONT_05.png","SMALL_fONT_06.png","SMALL_fONT_07.png","SMALL_fONT_08.png","SMALL_fONT_09.png","SMALL_fONT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_fONT_13.png',
              unit_tc: 'SMALL_fONT_13.png',
              unit_en: 'SMALL_fONT_13.png',
              negative_image: 'SMALL_fONT_14.png',
              invalid_image: 'SMALL_fONT_14.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 11,
              font_array: ["ACT_fONT_01.png","ACT_fONT_02.png","ACT_fONT_03.png","ACT_fONT_04.png","ACT_fONT_05.png","ACT_fONT_06.png","ACT_fONT_07.png","ACT_fONT_08.png","ACT_fONT_09.png","ACT_fONT_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'SMALL_fONT_13.png',
              unit_tc: 'SMALL_fONT_13.png',
              unit_en: 'SMALL_fONT_13.png',
              negative_image: 'ACT_fONT_Minus.png',
              invalid_image: 'ACT_fONT_Minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 244,
              y: 23,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 357,
              y: 297,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_Font_11.png',
              unit_tc: 'Batt_Font_11.png',
              unit_en: 'Batt_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 293,
              image_array: ["Battery_01.png","Battery_02.png","Battery_03.png","Battery_04.png","Battery_05.png","Battery_06.png","Battery_07.png","Battery_08.png","Battery_09.png","Battery_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 191,
              month_startY: 212,
              month_sc_array: ["Month-3-01.png","Month-3-02.png","Month-3-03.png","Month-3-04.png","Month-3-05.png","Month-3-06.png","Month-3-07.png","Month-3-08.png","Month-3-09.png","Month-3-10.png","Month-3-11.png","Month-3-12.png"],
              month_tc_array: ["Month-3-01.png","Month-3-02.png","Month-3-03.png","Month-3-04.png","Month-3-05.png","Month-3-06.png","Month-3-07.png","Month-3-08.png","Month-3-09.png","Month-3-10.png","Month-3-11.png","Month-3-12.png"],
              month_en_array: ["Month-3-01.png","Month-3-02.png","Month-3-03.png","Month-3-04.png","Month-3-05.png","Month-3-06.png","Month-3-07.png","Month-3-08.png","Month-3-09.png","Month-3-10.png","Month-3-11.png","Month-3-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 319,
              am_y: 115,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 319,
              pm_y: 115,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 98,
              hour_array: ["New0.png","New1.png","New2.png","New3.png","New4.png","New5.png","New6.png","New7.png","New8.png","New9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 198,
              minute_startY: 98,
              minute_array: ["New0.png","New1.png","New2.png","New3.png","New4.png","New5.png","New6.png","New7.png","New8.png","New9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 320,
              second_startY: 137,
              second_array: ["TIME_HM_fONT_01.png","TIME_HM_fONT_02.png","TIME_HM_fONT_03.png","TIME_HM_fONT_04.png","TIME_HM_fONT_05.png","TIME_HM_fONT_06.png","TIME_HM_fONT_07.png","TIME_HM_fONT_08.png","TIME_HM_fONT_09.png","TIME_HM_fONT_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 257,
              w: 233,
              h: 22,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 209,
              w: 50,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 326,
              w: 120,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 140,
              hour_startY: 215,
              hour_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '0_Empty.png',
              hour_unit_tc: '0_Empty.png',
              hour_unit_en: '0_Empty.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 209,
              minute_startY: 215,
              minute_array: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png","Day_08.png","Day_09.png","Day_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_unit_en: '0_Empty.png',
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 215,
              src: 'Day_Separator.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  