﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_uvi_text_text_img = ''
        let idle_humidity_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_text_img = ''
        let idle_temperature_low_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_second = ''

 // Start main change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 4

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

            hmUI.showToast({text: "main " + parseInt(colornumber) });

                  normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
          
            }

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 352,
              y: 351,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 39,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 235,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Act_small_FONT_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 263,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Act_small_FONT_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 162,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 306,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 340,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Small_FONT_11.png',
              unit_tc: 'ACT_Small_FONT_11.png',
              unit_en: 'ACT_Small_FONT_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 157,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_Small_FONT_11.png',
              unit_tc: 'ACT_Small_FONT_11.png',
              unit_en: 'ACT_Small_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 157,
              image_array: ["BATT_01.png","BATT_02.png","BATT_03.png","BATT_04.png","BATT_05.png","BATT_06.png","BATT_07.png","BATT_08.png","BATT_09.png","BATT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 83,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 84,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'ACT_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 83,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 122,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 265,
              y: 119,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 265,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 266,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 265,
              day_sc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_tc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_en_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 323,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_FONT_13.png',
              unit_tc: 'ACT_FONT_13.png',
              unit_en: 'ACT_FONT_13.png',
              negative_image: 'ACT_FONT_12.png',
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 126,
              y: 337,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 374,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Small_Font_14.png',
              unit_tc: 'ACT_Small_Font_14.png',
              unit_en: 'ACT_Small_Font_14.png',
              negative_image: 'ACT_Small_Font_13.png',
              invalid_image: 'ACT_Small_Font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 374,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Small_Font_14.png',
              unit_tc: 'ACT_Small_Font_14.png',
              unit_en: 'ACT_Small_Font_14.png',
              negative_image: 'ACT_Small_Font_13.png',
              invalid_image: 'ACT_Small_Font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 179,
              hour_startY: 184,
              hour_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 306,
              minute_startY: 186,
              minute_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 362,
              second_startY: 306,
              second_array: ["Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png","Time_s_10.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 334,
              am_y: 276,
              am_sc_path: 'System_AM.png',
              am_en_path: 'System_AM.png',
              pm_x: 334,
              pm_y: 276,
              pm_sc_path: 'System_PM.png',
              pm_en_path: 'System_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 9,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 343,
              y: 294,
              w: 66,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 186,
              w: 41,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 350,
              w: 69,
              h: 225,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 73,
              y: 232,
              w: 57,
              h: 51,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 307,
              w: 67,
              h: 87,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 58,
              w: 67,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 118,
              w: 58,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 116,
              w: 106,
              h: 29,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 188,
              y: 56,
              w: 92,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 352,
              y: 351,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 343,
              y: 39,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 235,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Act_small_FONT_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 263,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'Act_small_FONT_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 162,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 251,
              y: 306,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 340,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'ACT_Small_FONT_11.png',
              unit_tc: 'ACT_Small_FONT_11.png',
              unit_en: 'ACT_Small_FONT_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 157,
              font_array: ["ACT_Small_FONT_01.png","ACT_Small_FONT_02.png","ACT_Small_FONT_03.png","ACT_Small_FONT_04.png","ACT_Small_FONT_05.png","ACT_Small_FONT_06.png","ACT_Small_FONT_07.png","ACT_Small_FONT_08.png","ACT_Small_FONT_09.png","ACT_Small_FONT_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'ACT_Small_FONT_11.png',
              unit_tc: 'ACT_Small_FONT_11.png',
              unit_en: 'ACT_Small_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 157,
              image_array: ["BATT_01.png","BATT_02.png","BATT_03.png","BATT_04.png","BATT_05.png","BATT_06.png","BATT_07.png","BATT_08.png","BATT_09.png","BATT_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 83,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 84,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'ACT_FONT_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 83,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 122,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 265,
              y: 119,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 267,
              month_startY: 265,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 175,
              y: 266,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 236,
              day_startY: 265,
              day_sc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_tc_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_en_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 323,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_FONT_13.png',
              unit_tc: 'ACT_FONT_13.png',
              unit_en: 'ACT_FONT_13.png',
              negative_image: 'ACT_FONT_12.png',
              invalid_image: 'ACT_FONT_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 126,
              y: 337,
              image_array: ["Weather_01.png","Weather_02.png","Weather_03.png","Weather_04.png","Weather_05.png","Weather_06.png","Weather_07.png","Weather_08.png","Weather_09.png","Weather_10.png","Weather_11.png","Weather_12.png","Weather_13.png","Weather_14.png","Weather_15.png","Weather_16.png","Weather_17.png","Weather_18.png","Weather_19.png","Weather_20.png","Weather_21.png","Weather_22.png","Weather_23.png","Weather_24.png","Weather_25.png","Weather_26.png","Weather_27.png","Weather_28.png","Weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 374,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Small_Font_14.png',
              unit_tc: 'ACT_Small_Font_14.png',
              unit_en: 'ACT_Small_Font_14.png',
              negative_image: 'ACT_Small_Font_13.png',
              invalid_image: 'ACT_Small_Font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 374,
              font_array: ["ACT_FONT_01.png","ACT_FONT_02.png","ACT_FONT_03.png","ACT_FONT_04.png","ACT_FONT_05.png","ACT_FONT_06.png","ACT_FONT_07.png","ACT_FONT_08.png","ACT_FONT_09.png","ACT_FONT_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_Small_Font_14.png',
              unit_tc: 'ACT_Small_Font_14.png',
              unit_en: 'ACT_Small_Font_14.png',
              negative_image: 'ACT_Small_Font_13.png',
              invalid_image: 'ACT_Small_Font_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 179,
              hour_startY: 184,
              hour_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 306,
              minute_startY: 186,
              minute_array: ["Time_H_01.png","Time_H_02.png","Time_H_03.png","Time_H_04.png","Time_H_05.png","Time_H_06.png","Time_H_07.png","Time_H_08.png","Time_H_09.png","Time_H_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 362,
              second_startY: 306,
              second_array: ["Time_s_01.png","Time_s_02.png","Time_s_03.png","Time_s_04.png","Time_s_05.png","Time_s_06.png","Time_s_07.png","Time_s_08.png","Time_s_09.png","Time_s_10.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 334,
              am_y: 276,
              am_sc_path: 'System_AM.png',
              am_en_path: 'System_AM.png',
              pm_x: 334,
              pm_y: 276,
              pm_sc_path: 'System_PM.png',
              pm_en_path: 'System_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 9,
              second_posY: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change main background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 1,
              y: 198,
              text: '',
              w: 43,
              h: 59,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  