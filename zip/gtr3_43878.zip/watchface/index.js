﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let colorNumber = 1
let totalColors = 3
let colorName = ''


function click_color() {

    if(colorNumber >= totalColors) {
        colorNumber = 1;
    }
    else {
        colorNumber = colorNumber + 1;
    }


    //*** Toast with text / Toast con texto ***
    if ( colorNumber == 1) { colorName = "Original"}
    if ( colorNumber > 1)  { colorName = "Variant " + parseInt(colorNumber - 1)}
    hmUI.showToast({text: colorName });


    //*** Toast with text and index / Toast con texto e indice ***
    //hmUI.showToast({text: "Color " + parseInt(colorNumber) });


    //*** Toast with index / Toast con indice ***
	//hmUI.showToast({text: "" + parseInt(colorNumber) });


    normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colorNumber) + ".png");
         
    }
  let elementnumber_1 = 1
        let total_elemente = 3

        function click_HANDS() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Mov-Cuarzo'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Mov-Automático'});
			if(elementnumber_1==3) hmUI.showToast({text: 'Sin-Manecillas'});
        }

        function UpdateElementeOne(){
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdateElementeTwo(){
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		function UpdateElementeThree(){
				normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
				normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 18;
        let normal_day_TextCircle_img_height = 32;
        let normal_timerTextUpdate = undefined;
        let normal_year_TextCircle = new Array(4);
        let normal_year_TextCircle_ASCIIARRAY = new Array(10);
        let normal_year_TextCircle_img_width = 18;
        let normal_year_TextCircle_img_height = 32;
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 18;
        let normal_step_TextCircle_img_height = 32;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 18;
        let normal_heart_rate_TextCircle_img_height = 32;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_day_TextCircle = new Array(2);
        let idle_day_TextCircle_ASCIIARRAY = new Array(10);
        let idle_day_TextCircle_img_width = 18;
        let idle_day_TextCircle_img_height = 32;
        let idle_timerTextUpdate = undefined;
        let idle_year_TextCircle = new Array(4);
        let idle_year_TextCircle_ASCIIARRAY = new Array(10);
        let idle_year_TextCircle_img_width = 18;
        let idle_year_TextCircle_img_height = 32;
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_TextCircle = new Array(5);
        let idle_step_TextCircle_ASCIIARRAY = new Array(10);
        let idle_step_TextCircle_img_width = 18;
        let idle_step_TextCircle_img_height = 32;
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 18;
        let idle_heart_rate_TextCircle_img_height = 32;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_right.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 209,
              start_angle: 140,
              end_angle: 100,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 172,
              // circle_center_Y: 261,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 178,
              // angle: 60,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 172,
                center_y: 261,
                pos_x: 172 - normal_day_TextCircle_img_width / 2,
                pos_y: 261 - 210,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 281,
              // circle_center_Y: 265,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 177,
              // angle: -57,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              normal_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 281,
                center_y: 265,
                pos_x: 281 - normal_year_TextCircle_img_width / 2,
                pos_y: 265 - 209,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              week_tc: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              week_sc: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_left.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 209,
              start_angle: 220,
              end_angle: 260,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 175,
              // angle: 182,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - normal_step_TextCircle_img_width / 2,
                pos_y: 227 + 159,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 220,
              // circle_center_Y: 179,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 177,
              // angle: 179,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 220,
                center_y: 179,
                pos_x: 220 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 179 + 161,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 56,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 10,
              minute_posY: 80,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 7,
              second_posY: 84,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'str_S.png',
              // center_x: 227,
              // center_y: 227,
              // x: 7,
              // y: 84,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 7,
              pos_y: 227 - 84,
              center_x: 227,
              center_y: 227,
              src: 'str_S.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 185,
              hour_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: 'dig_a_dot2.png',
              hour_unit_tc: 'dig_a_dot2.png',
              hour_unit_en: 'dig_a_dot2.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 238,
              minute_startY: 185,
              minute_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_right.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 209,
              start_angle: 140,
              end_angle: 100,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 172,
              // circle_center_Y: 261,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 178,
              // angle: 60,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: false,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_day_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_day_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              idle_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 172,
                center_y: 261,
                pos_x: 172 - idle_day_TextCircle_img_width / 2,
                pos_y: 261 - 210,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 281,
              // circle_center_Y: 265,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 177,
              // angle: -57,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 4; i++) {
              idle_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 281,
                center_y: 265,
                pos_x: 281 - idle_year_TextCircle_img_width / 2,
                pos_y: 265 - 209,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              week_tc: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              week_sc: ["se_1.png","se_2.png","se_3.png","se_4.png","se_5.png","se_6.png","se_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'str_left.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 209,
              start_angle: 220,
              end_angle: 260,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 227,
              // circle_center_Y: 227,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 175,
              // angle: 182,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_step_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              idle_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 227,
                center_y: 227,
                pos_x: 227 - idle_step_TextCircle_img_width / 2,
                pos_y: 227 + 159,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 220,
              // circle_center_Y: 179,
              // font_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              // radius: 177,
              // angle: 179,
              // char_space_angle: 1,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'dig_a_0.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'dig_a_1.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'dig_a_2.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'dig_a_3.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'dig_a_4.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'dig_a_5.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'dig_a_6.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'dig_a_7.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'dig_a_8.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'dig_a_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 220,
                center_y: 179,
                pos_x: 220 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 179 + 161,
                src: 'dig_a_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_H.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 11,
              hour_posY: 56,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_M.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 9,
              minute_posY: 80,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 7,
              second_posY: 84,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 185,
              hour_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: 'dig_a_dot2.png',
              hour_unit_tc: 'dig_a_dot2.png',
              hour_unit_en: 'dig_a_dot2.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 238,
              minute_startY: 185,
              minute_array: ["dig_a_0.png","dig_a_1.png","dig_a_2.png","dig_a_3.png","dig_a_4.png","dig_a_5.png","dig_a_6.png","dig_a_7.png","dig_a_8.png","dig_a_9.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 188,
              y: 19,
              w: 80,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 194,
              w: 80,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                click_HANDS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();
              normal_day_circle_string = normal_day_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 60;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 178));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  normal_day_TextCircle_angleOffset = normal_day_TextCircle_angleOffset + 1 * (normal_day_circle_string.length - 1) / 2;
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 172 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle year_TIME');
              let valueYear = timeSensor.year;
              let normal_year_circle_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -57;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_circle_string.length > 0 && normal_year_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_year_TextCircle_img_angle = 0;
                  let normal_year_TextCircle_dot_img_angle = 0;
                  normal_year_TextCircle_img_angle = toDegree(Math.atan2(normal_year_TextCircle_img_width/2, 177));
                  // alignment = CENTER_H
                  let normal_year_TextCircle_angleOffset = normal_year_TextCircle_img_angle * (normal_year_circle_string.length - 1);
                  normal_year_TextCircle_angleOffset = normal_year_TextCircle_angleOffset + 1 * (normal_year_circle_string.length - 1) / 2;
                  char_Angle -= normal_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_year_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 281 - normal_year_TextCircle_img_width / 2);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.SRC, normal_year_TextCircle_ASCIIARRAY[charCode]);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_year_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();
              normal_step_circle_string = normal_step_circle_string.padStart(5, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 362;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 1 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();
              normal_heart_rate_circle_string = normal_heart_rate_circle_string.padStart(3, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 359;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 177));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_angleOffset + 1 * (normal_heart_rate_circle_string.length - 1) / 2;
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 220 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle day_TIME');
              let idle_day_circle_string = parseInt(valueDay).toString();
              idle_day_circle_string = idle_day_circle_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 60;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && idle_day_circle_string.length > 0 && idle_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let idle_day_TextCircle_img_angle = 0;
                  let idle_day_TextCircle_dot_img_angle = 0;
                  idle_day_TextCircle_img_angle = toDegree(Math.atan2(idle_day_TextCircle_img_width/2, 178));
                  // alignment = CENTER_H
                  let idle_day_TextCircle_angleOffset = idle_day_TextCircle_img_angle * (idle_day_circle_string.length - 1);
                  idle_day_TextCircle_angleOffset = idle_day_TextCircle_angleOffset + 1 * (idle_day_circle_string.length - 1) / 2;
                  char_Angle -= idle_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_day_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 172 - idle_day_TextCircle_img_width / 2);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.SRC, idle_day_TextCircle_ASCIIARRAY[charCode]);
                      idle_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_day_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle year_TIME');
              let idle_year_circle_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -57;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_circle_string.length > 0 && idle_year_circle_string.length <= 4) {  // display data if it was possible to get it
                  let idle_year_TextCircle_img_angle = 0;
                  let idle_year_TextCircle_dot_img_angle = 0;
                  idle_year_TextCircle_img_angle = toDegree(Math.atan2(idle_year_TextCircle_img_width/2, 177));
                  // alignment = CENTER_H
                  let idle_year_TextCircle_angleOffset = idle_year_TextCircle_img_angle * (idle_year_circle_string.length - 1);
                  idle_year_TextCircle_angleOffset = idle_year_TextCircle_angleOffset + 1 * (idle_year_circle_string.length - 1) / 2;
                  char_Angle -= idle_year_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += idle_year_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 281 - idle_year_TextCircle_img_width / 2);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.SRC, idle_year_TextCircle_ASCIIARRAY[charCode]);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += idle_year_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let idle_step_circle_string = parseInt(valueStep).toString();
              idle_step_circle_string = idle_step_circle_string.padStart(5, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 362;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_circle_string.length > 0 && idle_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let idle_step_TextCircle_img_angle = 0;
                  let idle_step_TextCircle_dot_img_angle = 0;
                  idle_step_TextCircle_img_angle = toDegree(Math.atan2(idle_step_TextCircle_img_width/2, 175));
                  // alignment = CENTER_H
                  let idle_step_TextCircle_angleOffset = idle_step_TextCircle_img_angle * (idle_step_circle_string.length - 1);
                  idle_step_TextCircle_angleOffset = idle_step_TextCircle_angleOffset + 1 * (idle_step_circle_string.length - 1) / 2;
                  idle_step_TextCircle_angleOffset = -idle_step_TextCircle_angleOffset;
                  char_Angle -= idle_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_step_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 227 - idle_step_TextCircle_img_width / 2);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.SRC, idle_step_TextCircle_ASCIIARRAY[charCode]);
                      idle_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_step_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();
              idle_heart_rate_circle_string = idle_heart_rate_circle_string.padStart(3, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 359;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 177));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_angleOffset + 1 * (idle_heart_rate_circle_string.length - 1) / 2;
                  idle_heart_rate_TextCircle_angleOffset = -idle_heart_rate_TextCircle_angleOffset;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 220 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle + 1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}