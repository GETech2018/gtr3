﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        // start user_functions.js
const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();
      let groupVremya = ''
      let groupPogoda = ''
      // Создаем группу для Tap интерфейса
      let groupTap; // Объявляем глобально, чтобы управлять видимостью

      let groupActiv = ''
      let canvas0 = ''
      let canvas = ''

      let groupSleep = ''

      let i_tap_bg_img = ''
      let bg_edit_img = ''


      // const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

      let normal_background_bg = ''


      function loadSettings() {
       color_ic = hmFS.SysProGetInt('MD241_25_color_ic') === undefined ? (hmFS.SysProSetInt('MD241_25_color_ic', 0), 0) : hmFS.SysProGetInt('MD241_25_color_ic');
       Activ_color = hmFS.SysProGetInt('MD241_25_Activ_color') === undefined ? (hmFS.SysProSetInt('MD241_25_Activ_color', 0), 0) : hmFS.SysProGetInt('MD241_25_Activ_color');
       tip_grafik = hmFS.SysProGetInt('MD241_25_tip_grafik') === undefined ? (hmFS.SysProSetInt('MD241_25_tip_grafik', 0), 0) : hmFS.SysProGetInt('MD241_25_tip_grafik');
       crown = hmFS.SysProGetInt('MD241_25_crown') === undefined ? (hmFS.SysProSetInt('MD241_25_crown', 0), 0) : hmFS.SysProGetInt('MD241_25_crown');
       fix_gsm = hmFS.SysProGetInt('MD241_25_fix_gsm') === undefined ? (hmFS.SysProSetInt('MD241_25_fix_gsm', 0), 0) : hmFS.SysProGetInt('MD241_25_fix_gsm');
       for (let i = 0; i < Ar_Set.length - 1; i++) {
        Ar_Set[i][1] = hmFS.SysProGetInt('MD241_25_color_' + i) === undefined
         ? (hmFS.SysProSetInt('MD241_25_color_' + crown, Ar_Set[crown][1]), 0)
         : hmFS.SysProGetInt('MD241_25_color_' + i);
       }
      }


      let sleep_time_txt = ''
      let sleep_start_time_txt = ''
      let sleep_end_time_txt = ''
      let sleep_score_txt = ''
      let wake_time_txt

      const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
      let sleepInfo = sleep.getBasicInfo();

      let sleepTotalTime = sleep.getTotalTime();
      let sleepStartTime = sleepInfo.startTime;
      let sleepEndTime = sleepInfo.endTime + 1;
      let sleepScore = sleepInfo.score;

      //-----------  время пробуждений ------------------		
      let sleepStageArray = sleep.getSleepStageData();
      const modelData = sleep.getSleepStageModel();
      //-------------------------------------------------		

      //sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


      function click_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupSleep.setProperty(hmUI.prop.VISIBLE, true);
      }


      function click_exit_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupSleep.setProperty(hmUI.prop.VISIBLE, false);
      }


      function read_pressure() {
       const file_name_alt = "../../../baro_altim/pressure.dat";
       const [fs_stat, err] = hmFS.stat(file_name_alt);
       if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        return array_buffer;
       } else {
       }
       return null;
      }

      function getPressureValue(pressure_array) {
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
       }
       return 0;
      }

      function changesPressure(pressure_array) {
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       let value = pressure_array[start_index];
       let result = 0;
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        let element = pressure_array[index];
        if (element != 0) {
         if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          return value;
         }
        }
       }
       return result;
      }

      function hPa_To_mmHg(hPa_value = 0) {
       let mmHg = Math.round(hPa_value * 0.750064);
       return mmHg;
      }
      //#endregion

      let text_pressere; // отображаем давление
      let text_pressere_changes; // отображаем изменение давления 


      function makeAOD() {
       // color = hmFS.SysProGetInt('NUMNUM_color');
       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });


      }


      let Activ_color_alpha = ''
      let color_bg_Activ = [0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a];

      let menu = 0
      let color_ic = 0
      let Activ_color = 0

      function click_Activ_color() {
       Activ_color = (Activ_color + 1) % 2
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       hmFS.SysProSetInt('MD241_25_Activ_color', Activ_color);
      }


      let Btn_set_ = []
      let Shag_Y = 66


      let Ar_Set = [
       ['ЦВЕТ LED 1', 16, `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['ЦВЕТ ЦИФР', 24, `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['ЯРКОСТЬ LED', 0, `tap/i_tap_pusto.png`, 1, 'page/index'],
       ['APP', 2, `tap/i_tap_pusto.png`, 1, 'page/index'],
       ['ЦВЕТ LED 2', 17, `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['КОРОНКА ОТКЛЮЧЕНА', 0, `tap/i_tap_pusto.png`, 0, 'page/index'],


      ];

      let color_bg = [
       [0xFF0000, 0xFF2400, 0xDC143C, 0x8B0000, 0x800020, 0xFFC0CB, 0xFFA500, 0xFFDB58, 0xFFD700, 0xFFFF00, 0xFFF700, 0x98FF98, 0x50C878, 0x228B22, 0x808000, 0x00FF00, 0x30D5C8, 0x00FFFF, 0x007FFF, 0x0000FF, 0x00008B, 0x4B0082, 0x800080, 0xFF00FF, 0xFFFFFF, 0xF0FFF0, 0xF5F5DC, 0xD3D3D3, 0x808080, 0x505050, 0xA52A2A, 0x000000],
       [0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad],
       [0xff0000, 0xff6600, 0xff6600, 0xff6600],
       [0xb5e1d0, 0xc5e09d, 0xb5e7f6, 0xacfad9, 0xff1a4e, 0xff501e, 0xf6d945, 0xffb100, 0xa5ff1f, 0x00c37a, 0x00d3f0, 0x3f7af2, 0xffffff, 0xadadad, 0xadadad, 0xadadad, 0xadadad],
       [0xFF0000, 0xFF2400, 0xDC143C, 0x8B0000, 0x800020, 0xFFC0CB, 0xFFA500, 0xFFDB58, 0xFFD700, 0xFFFF00, 0xFFF700, 0x98FF98, 0x50C878, 0x228B22, 0x808000, 0x00FF00, 0x30D5C8, 0x00FFFF, 0x007FFF, 0x0000FF, 0x00008B, 0x4B0082, 0x800080, 0xFF00FF, 0xFFFFFF, 0xF0FFF0, 0xF5F5DC, 0xD3D3D3, 0x808080, 0x505050, 0xA52A2A, 0x000000],
       [0xff0000],

      ];

      let colorNames = ["Красный", "Алый", "Малиновый", "Тёмно-красный", "Бордовый", "Розовый", "Оранжевый", "Горчичный", "Золотой", "Жёлтый", "Лимонный", "Мятный", "Изумрудный", "Лесной зелёный", "Оливковый", "Зелёный", "Бирюзовый", "Голубой", "Лазурный", "Синий", "Тёмно-синий", "Индиго", "Пурпурный", "Пурпурный (маджента)", "Белый", "Медовый", "Бежевый", "Светло-серый", "Серый", "Тёмно-серый", "Коричневый", "Чёрный"];

      let menu_ARC_color = Array(Ar_Set.length).fill().map(() => []);


      // ===== КОНФИГУРАЦИЯ ГРАДИЕНТОВ (единая структура для всех типов) =====
      const GRADIENT_CONFIGS = [{ // 1. Вертикальный градиент (3 цвета)
line_thickness: 10, // Добавьте эту строку
		  x: 50,
       y: 50,
       w: 150,
       h: 150,
       color_start: 0xFF0000,
       color_middle: 0x00FF00,
       color_end: 0x0000FF,
       use_three_colors: true,
       alpha: 255,
       direction: 'vertical',
       reverse: false,
       is_single_color: false,
       enabled: false
      }, { // 2. Горизонтальный градиент (2 цвета)
line_thickness: 10, // Добавьте эту строку		  
       x: 0,
       y: 191,
       w: 418,
       h: 208,
       color_start: 0xFFFF00,
       color_middle: 0x000000, // Не используется
       color_end: 0x00FFFF,
       use_three_colors: false,
       alpha: 255,
       direction: 'horizontal',
       reverse: false,
       is_single_color: false,
       enabled: true
      }, { // 3. Одноцветный прямоугольник
line_thickness: 10, // Добавьте эту строку		  
       x: 50,
       y: 400,
       w: 350,
       h: 50,
       color_start: 0xFFFFFF,
       color_middle: 0x000000, // Не используется
       color_end: 0x000000, // Не используется
       use_three_colors: false,
       alpha: 255,
       direction: 'vertical', // Не важно
       reverse: false, // Не важно
       is_single_color: true,
       enabled: false
      }].filter(config => config.enabled);

      // ===== ПЕРЕМЕННЫЕ =====
      // let normal_background_bg = null;
      let line_gradient = Array(GRADIENT_CONFIGS.length).fill().map(() => []);

      // ===== ФУНКЦИИ (адаптированные под единую конфигурацию) =====
      function calculateGradientColor(config, t) {
       if (config.is_single_color) {
        return config.color_start;
       }

       const r1 = (config.color_start >> 16) & 0xFF;
       const g1 = (config.color_start >> 8) & 0xFF;
       const b1 = config.color_start & 0xFF;
       const r2 = (config.color_end >> 16) & 0xFF;
       const g2 = (config.color_end >> 8) & 0xFF;
       const b2 = config.color_end & 0xFF;

       if (config.use_three_colors) {
        const rm = (config.color_middle >> 16) & 0xFF;
        const gm = (config.color_middle >> 8) & 0xFF;
        const bm = config.color_middle & 0xFF;

        if (t < 0.5) {
         const t2 = t * 2;
         const r = Math.round(r1 + (rm - r1) * t2);
         const g = Math.round(g1 + (gm - g1) * t2);
         const b = Math.round(b1 + (bm - b1) * t2);
         return (r << 16) | (g << 8) | b;
        } else {
         const t2 = (t - 0.5) * 2;
         const r = Math.round(rm + (r2 - rm) * t2);
         const g = Math.round(gm + (g2 - gm) * t2);
         const b = Math.round(bm + (b2 - bm) * t2);
         return (r << 16) | (g << 8) | b;
        }
       } else {
        const r = Math.round(r1 + (r2 - r1) * t);
        const g = Math.round(g1 + (g2 - g1) * t);
        const b = Math.round(b1 + (b2 - b1) * t);
        return (r << 16) | (g << 8) | b;
       }
      }


function safeUpdateGradient(gradientIndex, newConfig) {
  const config = {
    ...GRADIENT_CONFIGS[gradientIndex],
    ...newConfig
  };

  // Для градиентов (не одноцветных)
  if (!config.is_single_color) {
    const isVertical = config.direction === 'vertical';
    const size = isVertical ? config.h : config.w;
    
    for (let i = 0; i < size; i += config.line_thickness) {
      const t = config.reverse ? 1 - (i / (size - 1)) : (i / (size - 1));
      const color = calculateGradientColor(config, t);
      
      // Обновляем блок градиента с учетом толщины
      line_gradient[gradientIndex][i].setProperty(hmUI.prop.MORE, {
        x: isVertical ? config.x : config.x + i,
        y: isVertical ? config.y + i : config.y,
        w: isVertical ? config.w : config.line_thickness,
        h: isVertical ? config.line_thickness : config.h,
        color: color,
        alpha: config.alpha
      });
    }
  }
  
  // Сохраняем обновленную конфигурацию
  GRADIENT_CONFIGS[gradientIndex] = config;
}		 
		 
      // ПРИМЕРЫ ФУНКЦИЙ ОБНОВЛЕНИЯ (адаптированные)
      function updateFirstGradient() {
       safeUpdateGradient(0, {
        color_start: color_bg[0][Ar_Set[0][1]],
        color_middle: 0xFFFFFF,
        color_end: color_bg[4][Ar_Set[4][1]],
		line_thickness: GRADIENT_CONFIGS[0].line_thickness, // Добавьте это   
        //reverse: true
       });
      }


      let bridg_bg = [
       ['100%', 0],
       ['80%', 51],
       ['70%', 77],
       ['60%', 102],
      ];


      //let app_text_num = 0;
      let app_TF = []
      let app_ic = []
      let app_ACR_text = []

      let app_text_arr = [
       ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 'ic_app_0.png'],
       ['КМ', hmUI.data_type.DISTANCE, false, 0, 'ic_app_1.png'],
       ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 'ic_app_2.png'],
       ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 'ic_app_3.png'],
       ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 'ic_app_4.png'],
       ['НОЧЬ/ДЕНЬ', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 'ic_app_5.png'],
       ['ВОСХОД', hmUI.data_type.SUN_RISE, false, 0, 'ic_app_7.png'],
       ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 'ic_app_8.png'],
       ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 'ic_app_9.png'],
       ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 'ic_app_10.png'],
       ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 'ic_app_11.png'],
       ['УФ', hmUI.data_type.UVI, false, 0, 'ic_app_12.png'],
       ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 'ic_app_13.png'],
       ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 'ic_app_14.png'],
       ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 'ic_app_15.png'],
       ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 'ic_app_16.png'],
       ['ВЕТЕР', hmUI.data_type.WIND, false, 0, 'ic_app_17.png'],
      ];


      let crownSensitivity = 70; // уровень чувствительности колесика
      let color = 0;
      let color_str = 0;
      let bridg = 127;
      let crown = 0


// Функция для обновления свойств кнопок
function updateButtons() {
  Ar_Set.forEach((_, i) => {
    Btn_set_[i].setProperty(hmUI.prop.MORE, {
      x: Ar_Set.length <= 5 ? 153 : i < Math.ceil(Ar_Set.length / 2) ? 70 : 233,
      y: Ar_Set.length <= 5 ? 70 + i * Shag_Y : i < Math.ceil(Ar_Set.length / 2) ? 70 + i * Shag_Y : 70 + i * Shag_Y - Shag_Y * Math.ceil(Ar_Set.length / 2),
      w: 160,
      h: 60,
      text: Ar_Set[i][0],
      char_space: 0,
      line_space: -35,
      color: 0xFFFFFFFF,
      text_size: 24,
      radius: 12,
      press_color: 0xFFFF0000,
      normal_color: i !== crown ? 0x000000 : 0x800000,
      text_style: hmUI.text_style.WRAP,
      show_level: hmUI.show_level.ONLY_NORMAL
    });
  });
}

// Функция для скрытия всех цветовых элементов меню
function hideAllColorElements() {
  Ar_Set.forEach((_, j) => {
    color_bg[j].forEach((_, i) => {
      menu_ARC_color[j][i].setProperty(hmUI.prop.VISIBLE, false);
    });
  });
}


         
function updateProgressArc() {
  menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
    center_x: D_W/2,
    center_y: D_W/2,
    start_angle: Ar_Set[crown][3] == 1 ?  45 + 90 / color_bg[crown].length * Ar_Set[crown][1] : 45 + 90 / 11 * 5,
    end_angle: Ar_Set[crown][3] == 1 ?  135 + 90 / color_bg[crown].length * Ar_Set[crown][1] : 135 + 90 / 11 * 5,
    radius: 219,
    line_width: 16,
    corner_flag: 0,
    color: 0xFF0000,
    level: Ar_Set[crown][3] == 1 ? 100 / color_bg[crown].length : 10,
    show_level: hmUI.show_level.ONLY_NORMAL
  });
  menu_ARC_PROGRES.setProperty(hmUI.prop.VISIBLE, true);
}
         

function updateColorElements() {
        for (let j = 0; j < Ar_Set.length; j++) {
         for (let i = 0; i < color_bg[j].length; i++) {
    let start_angle_crown = 45+40 +  10 * (i-Ar_Set[crown][1]);
    let end_angle_crown = 135+40 +  10 * (i-Ar_Set[crown][1]);
          menu_ARC_color[j][i].setProperty(hmUI.prop.MORE, {
           center_x: D_W/2,
           center_y: D_W/2,
           start_angle: start_angle_crown,
           end_angle: end_angle_crown,
           radius: 219 - 16,
           line_width: 16,
           corner_flag: 0,
           color: color_bg[j][i],
          // level: 100 / color_bg[j].length,
           level: 10,
           //alpha: start_angle_crown < 45 ? 0:255,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
            menu_ARC_color[j][i].setAlpha(start_angle_crown < 45 ? 0:start_angle_crown >= 135 ? 0:255);
         };
        };  
}

         

// Основная функция для обработки клика по короне
function click_crown(index) {
  crown = index;

  // Обновление кнопок
  updateButtons();

  // Скрытие всех элементов меню
  hideAllColorElements();

  // Показать элементы текущей короны
  color_bg[crown].forEach((_, i) => {
    menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, Ar_Set[crown][3] === 0);
  });

  // Обновление дуги прогресса
  updateProgressArc();

  // Обновление цветовых элементов
  updateColorElements();
}

// Функция для обработки включения настроек
function click_Set_on() {
  set = 1;
  groupVremya.setProperty(hmUI.prop.VISIBLE, true);
  g_Set.setProperty(hmUI.prop.VISIBLE, true);
  g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);

  // Скрыть все цветовые элементы
  hideAllColorElements();

  // Показать элементы текущей короны
  color_bg[crown].forEach(i => {
    menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, Ar_Set[crown][3] === 0);
  });
}

// Функция для обработки выключения настроек
function click_Set_off() {
  set = 0;
  g_Set.setProperty(hmUI.prop.VISIBLE, false);
  groupVremya.setProperty(hmUI.prop.VISIBLE, true);
  g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);

  // Скрыть все цветовые элементы
  hideAllColorElements();

  // Сохранить текущую корону
  hmFS.SysProSetInt('MD241_25_crown', crown);
}

// Функция для обработки текста приложения
function click_app_text_on_off() {
  bg_app_text.setProperty(hmUI.prop.VISIBLE, true);
  app_text_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true));
  
  // Скрыть все цветовые элементы
  hideAllColorElements();
  
  g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
  
  // Установить таймер для автоматического скрытия
  if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
  MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
    timer.stopTimer(MenuCirkl_Timer);
    bg_app_text.setProperty(hmUI.prop.VISIBLE, false);
    app_text_arr.forEach((_, i) => app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false));
    g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
  });
  
  // Установить цвета текста
  app_text_arr.forEach((_, i) => {
    app_ACR_text[i].setProperty(hmUI.prop.COLOR, Ar_Set[crown][1] == i ? 0xff0000 : 0xffffff);
  });
}

// Функция для изменения цвета короны
function crown_color(crown, step = 0, isCrownEvent = false) {
    
  if (isCrownEvent) step = degreeSum < 0 ? -1 : 1;
    
Ar_Set[crown][1] = Ar_Set[crown][1] + step < 0 ? 0 : (Ar_Set[crown][1] + step > color_bg[crown].length-1 ? color_bg[crown].length-1 : Ar_Set[crown][1] + step);
degreeSum = 0;
	
  hmFS.SysProSetInt('MD241_25_color_' + crown, Ar_Set[crown][1]);

  if (set == 0) {
    g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
    if (Ar_Set[crown][3] == 0) {
      for (let i = 0; i < color_bg[crown].length; i++)
        menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, true);
    }
    
    // Установить таймер для автоматического скрытия
    if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
    MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
      if (Ar_Set[crown][3] == 0) {
        for (let i = 0; i < color_bg[crown].length; i++)
          menu_ARC_color[crown][i].setProperty(hmUI.prop.VISIBLE, false);
      }
      g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
      timer.stopTimer(MenuCirkl_Timer);
    });
  } else {
    g_Set.setProperty(hmUI.prop.VISIBLE, false);
    
    // Установить таймер для автоматического показа
    if (MenuCirkl_Timer) timer.stopTimer(MenuCirkl_Timer);
    MenuCirkl_Timer = timer.createTimer(1000, 1, () => {
      g_Set.setProperty(hmUI.prop.VISIBLE, true);
      timer.stopTimer(MenuCirkl_Timer);
    });
  }

  // Обновить дугу прогресса
  updateProgressArc();
    
  // Обновление цветовых элементов
  updateColorElements();
    
}	  
         
	  
      let set = 0;
      let degreeSum = 0;
      let MenuCirkl_Timer = null;
         
         
function switch_crown(crown) {
    switch (crown) {
        case 0:
            switch_crown_0()
            break;
        case 1:
            switch_crown_1()
            break;
        case 2:
            switch_crown_2()
            break;
        case 3:
            switch_crown_3()
            break;
        case 4:
            switch_crown_4()
            break;
    }
}             
         
 function switch_crown_0() {
           hmUI.showToast({
            text: colorNames[Ar_Set[0][1]],
           });
           updateFirstGradient();
     }  
 
 function switch_crown_1(){ 
           normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
            x: 196,
            y: 100,
            w: 150,
            h: 40,
            text_size: 28,
            char_space: 0,
            line_space: 0,
            font: 'fonts/nasalization_rg.ttf',
            color: color_bg[1][Ar_Set[1][1]],
            align_h: hmUI.align.RIGHT,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.ELLIPSIS,
            type: hmUI.data_type.STEP,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

           normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
            x: 132,
            y: 55,
            w: 150,
            h: 40,
            text_size: 28,
            char_space: 0,
            line_space: 0,
            font: 'fonts/nasalization_rg.ttf',
            color: color_bg[1][Ar_Set[1][1]],
            align_h: hmUI.align.RIGHT,
            align_v: hmUI.align.CENTER_V,
            unit_type: 1,
            text_style: hmUI.text_style.ELLIPSIS,
            type: hmUI.data_type.WEATHER_CURRENT,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

           normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
            x: 217,
            y: 145,
            w: 150,
            h: 40,
            text_size: 28,
            char_space: 0,
            line_space: 0,
            font: 'fonts/nasalization_rg.ttf',
            color: color_bg[1][Ar_Set[1][1]],
            align_h: hmUI.align.RIGHT,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.ELLIPSIS,
            type: hmUI.data_type.HEART,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });

           for (var i = 0; i < app_text_arr.length; i++) {
            if (i != 2) {
             app_TF[i].setProperty(hmUI.prop.MORE, {
              x: 229 - 2,
              y: 192 - 2,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/nasalization_rg.ttf',
              color: color_bg[1][Ar_Set[1][1]],
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              padding: app_text_arr[i][2],
              type: app_text_arr[i][1],
              unit_type: app_text_arr[i][3],
              show_level: hmUI.show_level.ONLY_NORMAL,
             });
             app_TF[i].setProperty(hmUI.prop.VISIBLE, i == Ar_Set[3][1]);
            }
           }

           normal_text_pressure.setProperty(hmUI.prop.COLOR, color_bg[1][Ar_Set[1][1]]);

        
 }  
 
 function switch_crown_2() {
           hmUI.showToast({
            text: bridg_bg[Ar_Set[2][1]][0]
           });

           bridg_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: 0x000000,
            alpha: bridg_bg[Ar_Set[2][1]][1],
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
         
 }  
 
 function switch_crown_3() {
           click_app_text_on_off()
           for (var i = 0; i < app_text_arr.length; i++) {
            app_ic[i].setProperty(hmUI.prop.SRC, app_text_arr[i][4]);
            app_ic[i].setProperty(hmUI.prop.VISIBLE, i == Ar_Set[3][1]);

            if (i != 2) {
             app_TF[i].setProperty(hmUI.prop.VISIBLE, i == Ar_Set[3][1]);
            }
           }
           normal_text_pressure.setProperty(hmUI.prop.VISIBLE, 2 == Ar_Set[3][1]);
           normal_uvi_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 11 == Ar_Set[3][1]);
           normal_humidity_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 4 == Ar_Set[3][1]);
           normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, 16 == Ar_Set[3][1]);
         
 }  
 
 function switch_crown_4() {
           hmUI.showToast({
            text: colorNames[Ar_Set[4][1]],
           });
           updateFirstGradient();
 }  
 
         
      function onKeyEvent() {
       try {
        hmApp.registerKeyEvent(function (key, action) {
         if (action != hmApp.action.CLICK) return
         let step = 0;
         switch (key) {
          case hmApp.key.UP:
           step = 1;
           break
          case hmApp.key.DOWN:
           step = -1;
           break
          default:
           break
         }


          if (Activ_color == 1 && menu == 1) {
           //let step = degreeSum < 0 ? -1 : 1;
           color_ic += step;
           color_ic = color_ic < 0 ? color_bg_Activ.length + color_ic : color_ic % color_bg_Activ.length;
           degreeSum = 0;
           hmFS.SysProSetInt('MD241_25_color_ic', color_ic);


           Activ_color_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: color_bg_Activ[color_ic],
            alpha: color_ic == 0 ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           })
          }
            
          for (let i = 0; i < color_bg.length-1; i++) {
          if (Activ_color == 0 && menu == 0 && crown == i) {
           crown_color(crown, 0, true)
              switch_crown(crown)              
          }
          }
             
           if (color_bg.length-crown!=1) vibro();
			

        })
       } catch (e) {
       }
      }
         
         
      function offKeyEvent() {
       try {
        hmApp.unregisterKeyEvent();
       } catch (e) {
       }
      }



      function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


          if (Activ_color == 1 && menu == 1) {
           let step = degreeSum < 0 ? -1 : 1;
           color_ic += step;
           color_ic = color_ic < 0 ? color_bg_Activ.length + color_ic : color_ic % color_bg_Activ.length;
           degreeSum = 0;
           hmFS.SysProSetInt('MD241_25_color_ic', color_ic);


           Activ_color_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 233,
            center_y: 233,
            radius: 233,
            color: color_bg_Activ[color_ic],
            alpha: color_ic == 0 ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           })
          }
             
          for (let i = 0; i < color_bg.length-1; i++) {
          if (Activ_color == 0 && menu == 0 && crown == i) {
           crown_color(crown, 0, true)
              switch_crown(crown)              
          }
          }
             
             
           if (color_bg.length-crown!=1) vibro();
             
         }
        }
       }) // crown
      }


      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      function click_Pogoda_on() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       menu = 2
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Pogoda_off() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       menu = 0
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
      }

      function click_Activ_on() {
       menu = 1
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupActiv.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Activ_off() {
       menu = 0
       Activ_color = 0
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupActiv.setProperty(hmUI.prop.VISIBLE, false);
      }


      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
       ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
       ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
       ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
       ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
       ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
       ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
       ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
      ];


      // Параметры системы
      const SQUARE_SIZE = 112;
      const INNER_DIAMETER = 302; // Диаметр для центров квадратов
      const OUTER_DIAMETER = D_W; // Диаметр главной окружности
      const OFFSET = -6; // Намеренный сдвиг 

      // Генерация 5 конфигураций (без последнего элемента)
      const tapConfigs = Array.from({
       length: 5
      }, (_, i) => {
       // Угол: -90° + шаг 60° (первый квадрат сверху)
       const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

       // Центр квадрата (на окружности INNER_DIAMETER)
       const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
       const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

       // Левый верхний угол квадрата с поправкой (-6, -6)
       const x = Math.round(centerX - SQUARE_SIZE / 2) + OFFSET;
       const y = Math.round(centerY - SQUARE_SIZE / 2) + OFFSET;

       // Определение defaultType и смещения подсказок
       let defaultType, tipsY;
       switch (i) {
        case 0:
         defaultType = 19;
         tipsY = 130;
         break; // Верхний
        case 1:
         defaultType = 20;
         tipsY = 130;
         break; // Верхний правый
        case 2:
         defaultType = 24;
         tipsY = -62;
         break; // Нижний правый
        case 3:
         defaultType = 11;
         tipsY = -64;
         break; // Нижний (особый сдвиг -64)
        case 4:
         defaultType = 35;
         tipsY = -62;
         break; // Нижний левый
       }

       return {
        id: 101 + i,
        x: x,
        y: y,
        defaultType: defaultType,
        tipsX: -35, // Общее смещение по X для всех
        tipsY: tipsY // Индивидуальное по Y
       };
      });
      // Результат (можно раскомментировать последний элемент, если нужно все 6)


      // Генерация 6 квадратов
      const tapPositions = Array.from({
       length: 5
      }, (_, i) => {
       // Угол: -90° + шаг 60° (первый квадрат сверху)
       const angle = -Math.PI / 2 + i * (2 * Math.PI / 6);

       // Центр квадрата (на окружности INNER_DIAMETER)
       const centerX = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.cos(angle);
       const centerY = (OUTER_DIAMETER / 2) + (INNER_DIAMETER / 2) * Math.sin(angle);

       // Левый верхний угол квадрата
       return {
        x: Math.round(centerX - SQUARE_SIZE / 2),
        y: Math.round(centerY - SQUARE_SIZE / 2),
        index: i
       };
      });


      // 1. Создаём массив для хранения результатов
      const tapSelections = [];

      // 2. Проходим по всем конфигам последовательно
      for (let i = 0; i < tapConfigs.length; i++) {
       const config = tapConfigs[i];

       // 3. Создаём виджет
       const edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
        edit_id: config.id,
        x: config.x,
        y: config.y,
        w: 124,
        h: 124,
        select_image: 'tap/edit_red_1.png',
        un_select_image: 'tap/edit_griin_1.png',
        default_type: config.defaultType,
        optional_types: apps.map((app, index) => ({
         type: index,
         preview: app[2],
         title_en: app[0]
        })),
        count: apps.length,
        tips_x: config.tipsX,
        tips_y: config.tipsY,
        tips_width: 195,
        tips_margin: 10,
        tips_BG: 'tap/tips_bg.png'
       });

       // 4. Даём время на инициализацию (если нужно)
       let counter = 0;
       while (counter < 1000) counter++; // Микро-задержка

       // 5. Получаем текущий тип и сохраняем
       tapSelections[i] = edit.getProperty(hmUI.prop.CURRENT_TYPE);

      }

      // Создаем группу для Tap интерфейса (только 5 элементов: 0,1,2,3,5)


      function createTapInterface() {
       groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
        x: 0,
        y: 0,
        w: D_W,
        h: D_H,
        show_level: hmUI.show_level.ONLY_NORMAL
       });


       for (let i = 0; i < 5; i++) {
        // if (i === 4) continue; // Пропускаем 5-й элемент

        const pos = tapPositions[i];
        const appIndex = tapSelections[i];

        // Иконка приложения
        groupTap.createWidget(hmUI.widget.IMG, {
         x: pos.x,
         y: pos.y,
         src: apps[appIndex][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // Кнопка (невидимая, но кликабельная)
        groupTap.createWidget(hmUI.widget.BUTTON, {
         x: pos.x,
         y: pos.y,
         w: 113,
         h: 113,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          const app = apps[appIndex];
          hmApp.startApp({
           appid: app[3] === 0 ? '' : app[1],
           url: app[3] === 0 ? app[1] : app[4],
           native: app[3] === 0,
           params: app[3] === 0 ? null : {
            from_wf: true
           },
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
       }

       return groupTap;
      }


      let btn_tap = ''
      let btn_click_tap_exit = ''


      function tap_zona_exit() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);
      }


      function tap_run() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);
      }


      //-------------------------------- 
      //переменные для ргафика
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 119 - 23 - 23;
      let dney = 8;
      let isDayIcons = false

      let shotWeaterhNames = ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


      let tip_grafik = 0

      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       hmFS.SysProSetInt('MD241_25_tip_grafik', tip_grafik);
       ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        tip()
       }, 150);
      }

      let fix_gsm = 0;

      function click_fix_gms() {
       fix_gsm = (fix_gsm + 1) % 2
       hmFS.SysProSetInt('MD241_25_fix_gsm', fix_gsm);
       fix_gsm_text_font.setProperty(hmUI.prop.TEXT, fix_gsm == 0 ? '+0' : '+1');
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        updateGrafik()
        app_update();
       }, 150);
      }


      // let timeSensor = ''

      let normal_city_name_text_0 = ''


      //-------------------------------- 

      //массив иконок для графика       
      for (var i = 0; i <= 28; i++) {
       weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
      }


      //обновление для   графика           
      function updateGrafik() {
       if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
       let year = timeSensor.year;
       if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
        day_num[2] = 29
       } else {
        day_num[2] = 28
       }

       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       }; // end currentWeather; 

       let weatherData = weatherSensor.getForecastWeather();
       let forecastData = weatherData.forecastData;


       let tideData = weatherData.tideData;
       let sunset_hour = -1;
       let sunset_minute = -1;
       if (tideData.count > 0) {
        sunset_hour = tideData.data[0].sunset.hour + fix_gsm;;
        sunset_minute = tideData.data[0].sunset.minute;
       }; // end tideData;

       let sunsetTime = undefined;
       let normal_sunset_circle_string = undefined;
       if (sunset_hour >= 0 && sunset_minute >= 0) {
        sunsetTime = 0;
        normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
       };

       let sunrise_hour = -1;
       let sunrise_minute = -1;
       if (tideData.count > 0) {
        sunrise_hour = tideData.data[0].sunrise.hour + fix_gsm;;
        sunrise_minute = tideData.data[0].sunrise.minute;
       }; // end tideData;

       let sunriseTime = undefined;
       let normal_sunrise_circle_string = undefined;
       if (sunrise_hour >= 0 && sunrise_minute >= 0) {
        sunriseTime = 0;
        normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
       };


       normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");

       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);

       normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName + "   " + normal_sunset_circle_string);


       if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
         var invalidPath = "--";
         weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
       } else {
        let weekDay = timeSensor.week - 1;
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;

        for (let i = 0; i < dney; i++) {

         // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

         yArrH[i] = forecastData.data[i].high;

         let element = forecastData.data[i];
         let iconIndex = element.index;
         weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
         let week2 = week_array[weekDay];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
         if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

        }
       }

       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = (today.sunrise.hour + fix_gsm) * 60 + today.sunrise.minute;
        sunsetMins = (today.sunset.hour + fix_gsm) * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }


       normal_vos_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_zak_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
       normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);

       app_ic[6].setProperty(hmUI.prop.SRC, isDayIcons == false ? app_text_arr[6][4] : "ic_app_6.png");


       app_TF[6].setProperty(hmUI.prop.more, {
        x: 229 - 2,
        y: 192 - 2,
        w: 150,
        h: 40,
        text_size: 28,
        char_space: 0,
        line_space: 0,
        font: 'fonts/nasalization_rg.ttf',
        color: color_bg[1][Ar_Set[1][1]],
        align_h: hmUI.align.RIGHT,
        align_v: hmUI.align.CENTER_V,
        text_style: hmUI.text_style.ELLIPSIS,
        padding: app_text_arr[6][2],
        type: isDayIcons == false ? app_text_arr[6][1] : hmUI.data_type.SUN_SET,
        unit_type: app_text_arr[6][3],
        show_level: hmUI.show_level.ONLY_NORMAL,
       });


       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря ", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"];


       tip()

      }

      function tip() {

       canvas.clear({
        x: 0,
        y: 0,
        w: D_W,
        h: D_W
       })


       for (let i = 0; i < dney - 1; i++) {
        canvas.drawRect({
         x1: 94 + shag * [i],
         y1: 93,
         x2: 94 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }


       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)

       let RedArray = [];
       let BlueArray = [];

       if (tip_grafik == 0) {
        for (let i = 0; i < dney; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        // let n = arr_x.length;
        splain(dney)

        for (let i = 0; i < dney - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        // n = dney - 1;
        splain(dney - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < dney; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1
        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        //n = yArrAll.length - 1;
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < dney; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 50,
         h: 40,
         color: "0xFFffffff",
         text_size: 27,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < dney - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 50,
          h: 40,
          color: "0xFFffffff",
          text_size: 27,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //dney - 1
       }; //dney   
      }


      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

         if (tip_grafik == 0) {
          canvas.drawImage({
           x: xi,
           y: yi,
           w: 5,
           h: 310 - yi,
           alpha: 127,
           image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
          })
         }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
          // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
         })


        }
       }

      }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_stress_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_stress_icon_img = ''
        let idle_wind_direction_image_progress_img_level = ''
        let idle_wind_text_text_img = ''
        let idle_wind_text_separator_img = ''
        let idle_distance_icon_img = ''
        let idle_distance_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_fat_burning_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_humidity_image_progress_img_level = ''
        let idle_humidity_text_text_img = ''
        let idle_date_img_date_week_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 28,
              month_startY: 199,
              month_sc_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_tc_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_en_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 28,
              day_startY: 244,
              day_sc_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_tc_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_en_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 233,
              hour_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: '0092.png',
              hour_unit_tc: '0092.png',
              hour_unit_en: '0092.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 232,
              minute_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 303,
              second_startY: 244,
              second_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 54,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 62,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0150.png',
              unit_tc: '0150.png',
              unit_en: '0150.png',
              negative_image: '0149.png',
              invalid_image: '0149.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 131,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 180,
              // center_y: 113,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 25,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFF5151,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 180,
              center_y: 113,
              start_angle: 0,
              end_angle: 360,
              radius: 24,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFF5151,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 107,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 96,
              src: 'ic_app_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 139,
              image_array: ["puls_0.png","puls_1.png","puls_2.png","puls_3.png","puls_4.png","puls_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 151,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 85,
              // end_angle: 165,
              // radius: 172,
              // line_width: 23,
              // line_cap: Rounded,
              // color: 0xFF00FF40,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 85,
              end_angle: 165,
              radius: 161,
              line_width: 23,
              corner_flag: 0,
              color: 0xFF00FF40,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 107,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 180,
              src: 'fon2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 188,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 195,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 189,
              src: 'ic_app_17.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 374,
              y: 186,
              src: 'ic_app_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 195,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0611.png',
              unit_tc: '0611.png',
              unit_en: '0611.png',
              dot_image: '0917.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 362,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 344,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bpointer.png',
              center_x: 226,
              center_y: 372,
              x: 47,
              y: 26,
              start_angle: -5,
              end_angle: 295,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 362,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0610.png',
              unit_tc: '0610.png',
              unit_en: '0610.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 316,
              image_array: ["VL_0.png","VL_1.png","VL_2.png","VL_3.png","VL_4.png","VL_5.png","VL_6.png","VL_7.png","VL_8.png","VL_9.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 320,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0610.png',
              unit_tc: '0610.png',
              unit_en: '0610.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 28,
              month_startY: 199,
              month_sc_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_tc_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_en_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png","0408.png","0409.png","0410.png","0411.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 28,
              day_startY: 244,
              day_sc_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_tc_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_en_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 233,
              hour_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_unit_sc: '0092.png',
              hour_unit_tc: '0092.png',
              hour_unit_en: '0092.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 232,
              minute_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 303,
              second_startY: 244,
              second_array: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 54,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 62,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0150.png',
              unit_tc: '0150.png',
              unit_en: '0150.png',
              negative_image: '0149.png',
              invalid_image: '0149.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 102,
              y: 131,
              image_array: ["moon_0.png","moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 180,
              // center_y: 113,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 25,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFFFF5151,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 180,
              center_y: 113,
              start_angle: 0,
              end_angle: 360,
              radius: 24,
              line_width: 3,
              corner_flag: 0,
              color: 0xFFFF5151,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 107,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 160,
              y: 96,
              src: 'ic_app_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 139,
              image_array: ["puls_0.png","puls_1.png","puls_2.png","puls_3.png","puls_4.png","puls_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 151,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 85,
              // end_angle: 165,
              // radius: 172,
              // line_width: 23,
              // line_cap: Rounded,
              // color: 0xFF00FF40,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 227,
              center_y: 227,
              start_angle: 85,
              end_angle: 165,
              radius: 161,
              line_width: 23,
              corner_flag: 0,
              color: 0xFF00FF40,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 279,
              y: 107,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 180,
              src: 'fon2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 238,
              y: 188,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 195,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 189,
              src: 'ic_app_17.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 374,
              y: 186,
              src: 'ic_app_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 259,
              y: 195,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0611.png',
              unit_tc: '0611.png',
              unit_en: '0611.png',
              dot_image: '0917.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 362,
              src: 'stat_B_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 43,
              y: 344,
              src: 'stat_H_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_fill_20.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bpointer.png',
              center_x: 226,
              center_y: 372,
              x: 47,
              y: 26,
              start_angle: -5,
              end_angle: 295,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 362,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0610.png',
              unit_tc: '0610.png',
              unit_en: '0610.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 316,
              image_array: ["VL_0.png","VL_1.png","VL_2.png","VL_3.png","VL_4.png","VL_5.png","VL_6.png","VL_7.png","VL_8.png","VL_9.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 320,
              font_array: ["0907.png","0908.png","0909.png","0910.png","0911.png","0912.png","0913.png","0914.png","0915.png","0916.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0610.png',
              unit_tc: '0610.png',
              unit_en: '0610.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_tc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              week_sc: ["week_0.png","week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 180,
                      center_y: 113,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 24,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFF5151,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 85,
                      end_angle: 165,
                      radius: 161,
                      line_width: 23,
                      corner_flag: 0,
                      color: 0xFF00FF40,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_calorie * 100);
                  if (idle_calorie_circle_scale) {
                    idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 180,
                      center_y: 113,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 24,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFFFF5151,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 227,
                      center_y: 227,
                      start_angle: 85,
                      end_angle: 165,
                      radius: 161,
                      line_width: 23,
                      corner_flag: 0,
                      color: 0xFF00FF40,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();

                // start resume_call.js
//-----------  сон------------------
          sleepTotalTime = sleep.getTotalTime();
          sleepInfo = sleep.getBasicInfo();
          sleepStartTime = sleepInfo.startTime;
          if (sleepStartTime >= 24 * 60) {
           sleepStartTime -= 24 * 60
          }

          sleepEndTime = sleepInfo.endTime + 1;
          if (sleepEndTime >= 24 * 60) {
           sleepEndTime -= 24 * 60
          }

          //-----------  время пробуждений ------------------
          let wakeTime = 0;
          sleepStageArray = sleep.getSleepStageData();

          for (let i = 0; i < sleepStageArray.length; i++) {
           let data = sleepStageArray[i];
           if (data.model == modelData.WAKE_STAGE) {
            wakeTime += data.stop + 1 - data.start;
           }

          }

          sleepTotalTime -= wakeTime;
          //-------------------------------------------------

          sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
          sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
          sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
          wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
          sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
          //-------------------------------------------------


          let pressure_array = read_pressure();
          let value = getPressureValue(pressure_array);
          value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.

          let pressere_changes_str = "=";
          //let color_pressere = 0x00ff00;
          let color_pressere_0 = value < 760 ? 0xffff00 : value > 760 ? 0xff0000 : 0x00ff00;

          let pressere_changes = changesPressure(pressure_array);
          if (pressere_changes < 0) {
           pressere_changes_str = "↓"; /*color_pressere = 0xffff00;*/
          }
          if (pressere_changes > 0) {
           pressere_changes_str = "↑"; /*color_pressere = 0xff0000;*/
          }
          //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

          let value_str = value == 0 ? "--" : value + pressere_changes_str;
          text_pressere.setProperty(hmUI.prop.TEXT, value_str);
          text_pressere.setProperty(hmUI.prop.COLOR, color_pressere_0);


          normal_text_pressure.setProperty(hmUI.prop.TEXT, String(value));


          stopVibro();
          updateGrafik();
          click_Pogoda_off();
          setTimeout(() => {
           onDigitalCrown();
          }, 350);
          setTimeout(() => {
           onKeyEvent();
          }, 350);
                // end resume_call.js

              }),
              pause_call: (function () {

                // start pause_call.js
stopVibro();
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          hmApp.unregisterSpinEvent();
          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupActiv.setProperty(hmUI.prop.VISIBLE, false);
          groupSleep.setProperty(hmUI.prop.VISIBLE, false);
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}