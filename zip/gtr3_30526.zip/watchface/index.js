﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_day_pointer_progress_date_pointer = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_day_pointer_progress_date_pointer = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_month_pointer_progress_date_pointer = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0008.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0007.png',
              center_x: 231,
              center_y: 232,
              posX: 233,
              posY: 233,
              start_angle: 326,
              end_angle: -36,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0006.png',
              center_x: 140,
              center_y: 231,
              posX: 16,
              posY: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 355,
              posX: 16,
              posY: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 109,
              x: 16,
              y: 53,
              start_angle: -150,
              end_angle: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 42,
              hour_posY: 173,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 45,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   second_path: '0005.png',
            //   second_centerX: 227,
            //   second_centerY: 227,
            //   second_posX: 24,
            //   second_posY: 222
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

	      let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 24;
            let second_posY = 222;
            let second_path = "0005.png";
            // ----------------------------
            let lastTime = 0;
            let animTimer;
            const animDuration = 5000;
            const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
            const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection
            
            // Smooth Seconds
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: second_centerX - second_posX,
              pos_y: second_centerY - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
              }
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
            }

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {  // when the screen turns on, create a timer to update the animation
                console.log('ui resume');
      
                const screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.WATCHFACE) return;  // if not the main screen of the dial, then do nothing
                if (animTimer) return;  // if the timer is already running, then do nothing
      
                let duration = 0;
                const diffTime = now.utc - lastTime;
                if (diffTime < animDuration) {
                  duration = animDuration - diffTime;  // we calculate the timer start delay, depending on the time of its last start (so that there is no overlap of two animations)
                }
      
                console.log('createTimer');
                animTimer = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = now.utc;
                  let sec = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);  // we calculate the angle of the second hand depending on the seconds and milliseconds.
                  startSecAnim(sec);
                }));
              }),
              pause_call: (function () {  // when the screen turns off, delete the timer
                console.log('ui pause');
                if (animTimer) {
                  timer.stopTimer(animTimer);
                  animTimer = undefined;
                }
              }),
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: '0008.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0007.png',
              center_x: 231,
              center_y: 232,
              posX: 233,
              posY: 233,
              start_angle: 326,
              end_angle: -36,
              cover_path: '0002.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.date.DAY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0006.png',
              center_x: 140,
              center_y: 231,
              posX: 16,
              posY: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 355,
              posX: 16,
              posY: 53,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0006.png',
              center_x: 233,
              center_y: 109,
              x: 16,
              y: 53,
              start_angle: -150,
              end_angle: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 42,
              hour_posY: 173,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 45,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 233,
              second_centerY: 233,
              second_posX: 24,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  