﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 312,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Act_font_13.png',
              unit_tc: 'Act_font_13.png',
              unit_en: 'Act_font_13.png',
              negative_image: 'Act_font_12.png',
              invalid_image: 'Act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 262,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 287,
              month_startY: 81,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 88,
              y: 81,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 18,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 12,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 265,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 288,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'ACT_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 408,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 133,
              y: 328,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 95,
              day_sc_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_tc_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_en_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 362,
              y: 350,
              src: 'System_Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 54,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 40,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 353,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 38,
              am_y: 178,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 38,
              pm_y: 178,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 147,
              hour_array: ["Font_time_01.png","Font_time_02.png","Font_time_03.png","Font_time_04.png","Font_time_05.png","Font_time_06.png","Font_time_07.png","Font_time_08.png","Font_time_09.png","Font_time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 147,
              minute_array: ["Font_time_01.png","Font_time_02.png","Font_time_03.png","Font_time_04.png","Font_time_05.png","Font_time_06.png","Font_time_07.png","Font_time_08.png","Font_time_09.png","Font_time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 173,
              second_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 312,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Act_font_13.png',
              unit_tc: 'Act_font_13.png',
              unit_en: 'Act_font_13.png',
              negative_image: 'Act_font_12.png',
              invalid_image: 'Act_font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 262,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 287,
              month_startY: 81,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 88,
              y: 81,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 288,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0_Empty.png',
              unit_tc: '0_Empty.png',
              unit_en: '0_Empty.png',
              imperial_unit_sc: '0_Empty.png',
              imperial_unit_tc: '0_Empty.png',
              imperial_unit_en: '0_Empty.png',
              dot_image: 'ACT_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 18,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 12,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 265,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: '0_Empty.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 408,
              font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 133,
              y: 328,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 203,
              day_startY: 95,
              day_sc_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_tc_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_en_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 362,
              y: 350,
              src: 'System_Lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 55,
              y: 54,
              src: 'System_DND.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 341,
              y: 40,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 353,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 38,
              am_y: 178,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 38,
              pm_y: 178,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 147,
              hour_array: ["Font_time_01.png","Font_time_02.png","Font_time_03.png","Font_time_04.png","Font_time_05.png","Font_time_06.png","Font_time_07.png","Font_time_08.png","Font_time_09.png","Font_time_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 147,
              minute_array: ["Font_time_01.png","Font_time_02.png","Font_time_03.png","Font_time_04.png","Font_time_05.png","Font_time_06.png","Font_time_07.png","Font_time_08.png","Font_time_09.png","Font_time_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 173,
              second_array: ["Font_time_S_01.png","Font_time_S_02.png","Font_time_S_03.png","Font_time_S_04.png","Font_time_S_05.png","Font_time_S_06.png","Font_time_S_07.png","Font_time_S_08.png","Font_time_S_09.png","Font_time_S_10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 152,
              y: 7,
              w: 222,
              h: 88,
              select_image: '0_Empty.png',
              un_select_image: '0_Empty.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY_preview.png' },
                { type: hmUI.edit_type.STEP, preview: 'boarder_Zone_Batt.png' },
              ],
              count: 2,
              tips_BG: 'Tooltip.png',
              tips_x: -12,
              tips_y: 118,
              tips_width: 262,
              tips_margin: 262,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 192,
                  y: 5,
                  src: 'Orange_Battery_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 211,
                  y: 18,
                  font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 162,
                  y: 12,
                  image_array: ["Batt_icon_orange_01.png","Batt_icon_orange_02.png","Batt_icon_orange_03.png","Batt_icon_orange_04.png","Batt_icon_orange_05.png","Batt_icon_orange_06.png","Batt_icon_orange_07.png","Batt_icon_orange_08.png","Batt_icon_orange_09.png","Batt_icon_orange_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            };

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 129,
              y: 324,
              w: 222,
              h: 123,
              select_image: '0_Empty.png',
              un_select_image: '0_Empty.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP_preview.png' },
	   { type: hmUI.edit_type.BATTERY, preview: 'boarder_Zone.png' },
              ],
              count: 2,
              tips_BG: 'Tooltip.png',
              tips_x: 11,
              tips_y: -199,
              tips_width: 262,
              tips_margin: 262,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 202,
                  y: 361,
                  src: 'Orange_step_icon.png',
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 182,
                  y: 408,
                  font_array: ["ACT_Font_01.png","ACT_Font_02.png","ACT_Font_03.png","ACT_Font_04.png","ACT_Font_05.png","ACT_Font_06.png","ACT_Font_07.png","ACT_Font_08.png","ACT_Font_09.png","ACT_Font_10.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 133,
                  y: 328,
                  image_array: ["Step_icon_orange_01.png","Step_icon_orange_02.png","Step_icon_orange_03.png","Step_icon_orange_04.png","Step_icon_orange_05.png","Step_icon_orange_06.png","Step_icon_orange_07.png","Step_icon_orange_08.png","Step_icon_orange_09.png","Step_icon_orange_10.png"],
                  image_length: 10,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
                });
                break;
            };

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask--.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask2.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 47,
                    posY: 227,
                    path: 'hand_Second.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 47,
                    posY: 227,
                    path: 'hand_Seco_orange_d.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: '.png',
              tips_x: 138,
              tips_y: 265,
              tips_bg: 'tiptool2.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  