﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Esfera.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 108,
              month_startY: 354,
              month_sc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              month_tc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              month_en_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 354,
              day_sc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_tc_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_en_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 166,
              y: 31,
              week_en: ["Dig0001_1.png","Dig0002_1.png","Dig0003_1.png","Dig0004_1.png","Dig0005_1.png","Dig0006_1.png","Dig0007_1.png"],
              week_tc: ["Dig0001_1.png","Dig0002_1.png","Dig0003_1.png","Dig0004_1.png","Dig0005_1.png","Dig0006_1.png","Dig0007_1.png"],
              week_sc: ["Dig0001_1.png","Dig0002_1.png","Dig0003_1.png","Dig0004_1.png","Dig0005_1.png","Dig0006_1.png","Dig0007_1.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 330,
              y: 283,
              src: '0256.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 248,
              y: 298,
              src: '0255.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'PMw000.png',
              am_en_path: 'PMw000.png',
              pm_x: 70,
              pm_y: 70,
              pm_sc_path: 'PMw000.png',
              pm_en_path: 'PMw000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 0,
              hour_startY: 151,
              hour_array: ["DigBig00.png","DigBig01.png","DigBig02.png","DigBig03.png","DigBig04.png","DigBig05.png","DigBig06.png","DigBig07.png","DigBig08.png","DigBig09.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 153,
              minute_startY: 151,
              minute_array: ["DigBig00.png","DigBig01.png","DigBig02.png","DigBig03.png","DigBig04.png","DigBig05.png","DigBig06.png","DigBig07.png","DigBig08.png","DigBig09.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 303,
              second_startY: 151,
              second_array: ["DigBig00.png","DigBig01.png","DigBig02.png","DigBig03.png","DigBig04.png","DigBig05.png","DigBig06.png","DigBig07.png","DigBig08.png","DigBig09.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 280,
              w: 75,
              h: 75,
              src: '0258.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  