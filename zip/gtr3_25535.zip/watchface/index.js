﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_back_ground_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_back_ground_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_back_ground_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 277,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Font_12.png',
              unit_tc: 'Weather_Font_12.png',
              unit_en: 'Weather_Font_12.png',
              negative_image: 'Weather_Font_11.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 156,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 32,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 231,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 372,
              y: 154,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 333,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 263,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 91,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 217,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Day_Font_12.png',
              unit_tc: 'Day_Font_12.png',
              unit_en: 'Day_Font_12.png',
              dot_image: 'Day_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 155,
              month_startY: 386,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 383,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 213,
              y: 390,
              week_en: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              week_tc: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              week_sc: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 306,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 260,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 138,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 91,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 44,
              am_y: 209,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 44,
              pm_y: 209,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 214,
              hour_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 117,
              minute_startY: 214,
              minute_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 156,
              second_startY: 214,
              second_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 214,
              src: 'Step_Font_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 214,
              src: 'Step_Font_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 19,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 204,
              w: 56,
              h: 51,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 210,
              w: 43,
              h: 37,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 39,
              y: 205,
              w: 37,
              h: 45,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 366,
              y: 149,
              w: 47,
              h: 47,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 36,
              y: 264,
              w: 52,
              h: 40,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 120,
              w: 49,
              h: 50,
              src: '0_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 264,
              w: 60,
              h: 39,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 309,
              w: 55,
              h: 34,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 261,
              w: 140,
              h: 40,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_back_ground_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 45,
              y: 277,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Weather_Font_12.png',
              unit_tc: 'Weather_Font_12.png',
              unit_en: 'Weather_Font_12.png',
              negative_image: 'Weather_Font_11.png',
              invalid_image: 'Weather_Font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 156,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 211,
              y: 32,
              src: 'System_BT_Disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 51,
              y: 231,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 372,
              y: 154,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 333,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 263,
              font_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 277,
              y: 91,
              image_array: ["Step_icon_01.png","Step_icon_02.png","Step_icon_03.png","Step_icon_04.png","Step_icon_05.png","Step_icon_06.png","Step_icon_07.png","Step_icon_08.png","Step_icon_09.png","Step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 217,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Day_Font_12.png',
              unit_tc: 'Day_Font_12.png',
              unit_en: 'Day_Font_12.png',
              dot_image: 'Day_font_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 155,
              month_startY: 386,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 120,
              day_startY: 383,
              day_sc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_tc_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_en_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 213,
              y: 390,
              week_en: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              week_tc: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              week_sc: ["WeekDay_icon_01.png","WeekDay_icon_02.png","WeekDay_icon_03.png","WeekDay_icon_04.png","WeekDay_icon_05.png","WeekDay_icon_06.png","WeekDay_icon_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 306,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 104,
              y: 260,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 138,
              font_array: ["Day_Font_01.png","Day_Font_02.png","Day_Font_03.png","Day_Font_04.png","Day_Font_05.png","Day_Font_06.png","Day_Font_07.png","Day_Font_08.png","Day_Font_09.png","Day_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 91,
              image_array: ["Battery_icon_01.png","Battery_icon_02.png","Battery_icon_03.png","Battery_icon_04.png","Battery_icon_05.png","Battery_icon_06.png","Battery_icon_07.png","Battery_icon_08.png","Battery_icon_09.png","Battery_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 44,
              am_y: 209,
              am_sc_path: 'Time_icon_AM.png',
              am_en_path: 'Time_icon_AM.png',
              pm_x: 44,
              pm_y: 209,
              pm_sc_path: 'Time_icon_PM.png',
              pm_en_path: 'Time_icon_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 77,
              hour_startY: 214,
              hour_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 117,
              minute_startY: 214,
              minute_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 156,
              second_startY: 214,
              second_array: ["Step_Font_01.png","Step_Font_02.png","Step_Font_03.png","Step_Font_04.png","Step_Font_05.png","Step_Font_06.png","Step_Font_07.png","Step_Font_08.png","Step_Font_09.png","Step_Font_10.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 108,
              y: 214,
              src: 'Step_Font_11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 147,
              y: 214,
              src: 'Step_Font_11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_hour.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 19,
              minute_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_second.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 208,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  