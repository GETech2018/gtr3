﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_second_big = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''

        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

        //chronograph
        let btnstart = ''
        let btnreset = ''
        let ChronoTimer=null;
        let nowsec = hmSensor.createSensor(hmSensor.id.TIME);
        let flag = true
        let lastTime = 0
        let lastMark = 0
        let tmpMark = 0
        let diffTime = 0
        let minutes = 0
        let milis = 0
        let seconds = 0
        let chronosec = ''
        let chronosec_small = ''
        let chronomin = ''
        let a = null;
        let b = 0;

        function MakeTimer() {
             ChronoTimer = timer.createTimer(10, 10, TimerTick, {})
        }

        function TimerTick() {
             CalcTime(nowsec.utc - lastTime)
             DisplayChronoSec();
             DisplayChronoMinute();
        }

        function CalcTime(mark) {
	         diffTime = (mark + lastMark) / 10;
       	     milis = (diffTime % 100);
             diffTime = (diffTime - milis ) / 100;
             seconds= diffTime % 60;
             minutes= ((diffTime - seconds) / 60) % 60;
        }

        function DisplayChronoSec(){
             a=seconds*6+6*(milis % 100) / 100;
             if (lswitch) {
                 chronosec_small.setProperty(hmUI.prop.MORE, {
                   x: 0,
                   y: 0,
                   w: 466,
                   h: 466,
                   pos_x: 234 - 11,
                   pos_y: 335 - 65,
                   center_x: 234,
                   center_y: 335,
                   src: 'pointer.png',
                   angle:a,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 });
             } else { //default
                 chronosec.setProperty(hmUI.prop.MORE, {
                   x: 0,
                   y: 0,
                   w: 466,
                   h: 466,
                   pos_x: 233 - 24,
                   pos_y: 233 - 220,
                   center_x: 233,
                   center_y: 233,
                   src: 'second0.png',
                   angle:a,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 });
             }
        }

        function DisplayChronoMinute(){
             b=minutes*12;
             if (b>360) {b = b - 360};
             chronomin.setProperty(hmUI.prop.MORE, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 336 - 11,
               pos_y: 232 - 65,
               center_x: 336,
               center_y: 232,
               src: 'pointer.png',
               angle: b,
               show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }

        //start - pause Chrono
        function click_StartChrono(){
             click_Vibrate();
             flag = !flag
             if (flag) {
               timer.stopTimer(ChronoTimer);
	           tmpMark = nowsec.utc - lastTime
	           CalcTime(tmpMark);
               DisplayChronoSec();
               DisplayChronoMinute();
	           lastMark = lastMark + tmpMark;
             } else {
	             lastTime=nowsec.utc;
                 MakeTimer();
             }
        }

        //reset Chrono
        function click_ResetChrono(){
             click_Vibrate();
             if (!flag) {
                 timer.stopTimer(ChronoTimer);
             }
             flag=true;
             lastMark=0;
             lastTime=0;
             lsplit=false;
             splitangle=0;
             splitsec_small.setProperty(hmUI.prop.VISIBLE, false);
             splitsec.setProperty(hmUI.prop.VISIBLE, false);
             CalcTime(lastTime);
             DisplayChronoSec();
             DisplayChronoMinute();
        }
        // end chronograph

        // sweep seconds
        let hsTimer=null;
		let now = hmSensor.createSensor(hmSensor.id.TIME);

        function DisplaySeconds(){
        	   let cs=now.second*6+6*(now.utc % 1000)/1000;
               if (lswitch) {
               	   normal_analog_clock_time_pointer_second_big.setProperty(hmUI.prop.MORE, {
                     x: 0,
                     y: 0,
                     w: 466,
                     h: 466,
                     pos_x: 233 - 24,
                     pos_y: 233 - 220,
                     center_x: 233,
                     center_y: 233,
                     src: 'second0.png',
                     angle: cs,
                     show_level: hmUI.show_level.ONLY_NORMAL,
                   });
              } else { //default
               	   normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                     x: 0,
                     y: 0,
                     w: 466,
                     h: 466,
                     pos_x: 234 - 11,
                     pos_y: 335 - 65,
                     center_x: 234,
                     center_y: 335,
                     src: 'pointer.png',
                     angle: cs,
                     show_level: hmUI.show_level.ONLY_NORMAL,
                   });
              }
        }
        // end sweep seconds

        // Switch chronohand and secondhand
        let btnswitch = ''
        let lswitch = false // default false

        function click_SwitchSeconds() {
               click_Vibrate();
               if (lswitch) {
                  hmUI.showToast({text: 'Chrono use big secondhand'});
                  lswitch=false; //activate big Chrono
                  normal_analog_clock_time_pointer_second_big.setProperty(hmUI.prop.VISIBLE, false);
                  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
                  chronosec_small.setProperty(hmUI.prop.VISIBLE, false);
                  chronosec.setProperty(hmUI.prop.VISIBLE, true);
                  DisplayChronoSec();
                  if (lsplit) {DisplaySplitSecond();};
               } else {
                  hmUI.showToast({text: 'Chrono use small secondhand'});
                  lswitch=true; //activate small Chrono
                  normal_analog_clock_time_pointer_second_big.setProperty(hmUI.prop.VISIBLE, true);
                  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
                  chronosec_small.setProperty(hmUI.prop.VISIBLE, true);
                  chronosec.setProperty(hmUI.prop.VISIBLE, false);
                  DisplayChronoSec();
                  if (lsplit) {DisplaySplitSecond();};
               }
        }
        // end Switch chronohand and secondhand

        // Enable SplitSecond chrono minute
        let btnsplit = ''
        let splitsec = ''
        let splitsec_small = ''
        let lsplit = false
        let splitangle = 0

        function click_SplitSecond() {
               click_Vibrate();
               if (flag) return; //only when chrono runs
               if (lsplit){
                 splitsec.setProperty(hmUI.prop.VISIBLE, false);
                 splitsec_small.setProperty(hmUI.prop.VISIBLE, false);
                 lsplit=false;
               } else {
                 splitangle=a;
                 DisplaySplitSecond();
                 lsplit=true;
               }
        }

        function DisplaySplitSecond(){
                if (lswitch) {
                 splitsec_small.setProperty(hmUI.prop.MORE, {
                   x: 0,
                   y: 0,
                   w: 466,
                   h: 466,
                   pos_x: 234 - 11,
                   pos_y: 335 - 65,
                   center_x: 234,
                   center_y: 335,
                   src: 'splitpointer0.png',
                   angle: splitangle,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 });
                 splitsec_small.setProperty(hmUI.prop.VISIBLE, true);
                 splitsec.setProperty(hmUI.prop.VISIBLE, false);
               } else { //default
                 splitsec.setProperty(hmUI.prop.MORE, {
                   x: 0,
                   y: 0,
                   w: 466,
                   h: 466,
                   pos_x: 233 - 24,
                   pos_y: 233 - 220,
                   center_x: 233,
                   center_y: 233,
                   src: 'split0.png',
                   angle: splitangle,
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 });
                 splitsec.setProperty(hmUI.prop.VISIBLE, true);
                 splitsec_small.setProperty(hmUI.prop.VISIBLE, false);
               }
        }

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'background2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 351,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 130,
              center_y: 232,
              x: 11,
              y: 65,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 331,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 0,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //chrono minute pointer
            chronomin = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 336 - 11,
               pos_y: 232 - 65,
               center_x: 336,
               center_y: 232,
               src: 'pointer.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //Split pointer (default)
            splitsec_small = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 234 - 11,
               pos_y: 335 - 65,
               center_x: 234,
               center_y: 335,
               src: 'splitpointer0.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            splitsec_small.setProperty(hmUI.prop.VISIBLE, false);

            //chrono pointer
            chronosec_small = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 234 - 11,
               pos_y: 335 - 65,
               center_x: 234,
               center_y: 335,
               src: 'pointer.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            chronosec_small.setProperty(hmUI.prop.VISIBLE, false);

            // secondhand sweep Pointer (default)
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 234 - 11,
               pos_y: 335 - 65,
               center_x: 234,
               center_y: 335,
               src: 'pointer.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 132,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //Split big secondhand (default)
            splitsec = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 233 - 24,
               pos_y: 233 - 220,
               center_x: 233,
               center_y: 233,
               src: 'split0.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            splitsec.setProperty(hmUI.prop.VISIBLE, false);

            //chrono big secondhand (default)
            chronosec = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 233 - 24,
               pos_y: 233 - 220,
               center_x: 233,
               center_y: 233,
               src: 'second0.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // secondhand sweep big secondhand
            normal_analog_clock_time_pointer_second_big = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 466,
               h: 466,
               pos_x: 233 - 24,
               pos_y: 233 - 220,
               center_x: 233,
               center_y: 233,
               src: 'second0.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_second_big.setProperty(hmUI.prop.VISIBLE, false);


            //AOD
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 351,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 233,
              hour_centerY: 233,
              hour_posX: 17,
              hour_posY: 132,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 233,
              minute_centerY: 233,
              minute_posX: 23,
              minute_posY: 180,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // Start Chrono shortcut start
            btnstart = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 32,
              text: '',
              w: 103,
              h: 93,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_StartChrono();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnstart.setProperty(hmUI.prop.VISIBLE, true);
            // Start Chrono shortcut end

            // Reset Chono shortcut start
            btnreset = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 335,
              y: 336,
              text: '',
              w: 103,
              h: 93,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_ResetChrono();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnreset.setProperty(hmUI.prop.VISIBLE, true);
            // Reset Chono  shortcut end

            // Switch shortcut start
            btnswitch = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 336,
              text: '',
              w: 103,
              h: 93,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_SwitchSeconds();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnswitch.setProperty(hmUI.prop.VISIBLE, true);
            // Switch shortcut end

            // Split shortcut start
            btnsplit = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 32,
              text: '',
              w: 103,
              h: 93,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_SplitSecond();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnsplit.setProperty(hmUI.prop.VISIBLE, true);
            // Split shortcut end

			DisplaySeconds();
            hsTimer = timer.createTimer(50, 50, DisplaySeconds, {})

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				DisplaySeconds();
				if(hsTimer==null) hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
              }),
			  pause_call: (function () {
				timer.stopTimer(hsTimer);
				hsTimer=null;
             }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestroy() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
			timer.stopTimer(ChronoTimer);
            ChronoTimer=null;
            if (hsTimer) timer.stopTimer(hsTimer);
          },
          onDestory() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
			timer.stopTimer(ChronoTimer);
            ChronoTimer=null;
            if (hsTimer) timer.stopTimer(hsTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  