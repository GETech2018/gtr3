﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let editBg = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_circle_scale_mirror = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let fg_mask = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'tlo_0.png', path: 'tar_0.png' },
                { id: 2, preview: 'tlo_1.png', path: 'tar_1.png' },
              ],
              count: 2,
              default_id: 1,
              fg: 'fg.png',
              tips_bg: 'rolka_0.png',
              tips_x: 153,
              tips_y: 144,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 144,
              y: 253,
              src: 'aku_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 189,
              // start_y: 272,
              // color: 0xFF00FF00,
              // pointer: 'aku_wsk0.png',
              // lenght: 122,
              // line_width: 11,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 100,
              src: 'bt_0.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 111,
              src: 'al_0.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 288,
              w: 158,
              h: 30,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              color: 0xFFF1F807,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 242,
              font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'zn_st_C.png',
              unit_tc: 'zn_st_C.png',
              unit_en: 'zn_st_C.png',
              negative_image: 'zn_minus.png',
              invalid_image: 'zn_x0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 72,
              y: 179,
              image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 332,
              y: 226,
              week_en: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_tc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_sc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 327,
              day_startY: 185,
              day_sc_array: ["cd_00.png","cd_01.png","cd_02.png","cd_03.png","cd_04.png","cd_05.png","cd_06.png","cd_07.png","cd_08.png","cd_09.png"],
              day_tc_array: ["cd_00.png","cd_01.png","cd_02.png","cd_03.png","cd_04.png","cd_05.png","cd_06.png","cd_07.png","cd_08.png","cd_09.png"],
              day_en_array: ["cd_00.png","cd_01.png","cd_02.png","cd_03.png","cd_04.png","cd_05.png","cd_06.png","cd_07.png","cd_08.png","cd_09.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wskaz_h0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 40,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wskaz_m0.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 37,
              minute_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wskaz_s0.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 32,
              second_posY: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 231,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 337,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 314,
              y: 115,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 231,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 31,
              y: 115,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 9,
              w: 110,
              h: 110,
              src: 'zn_x0.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'tar_aod_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 180,
              // end_angle: 360,
              // radius: 100,
              // line_width: 7,
              // color: 0xFF666666,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
              idle_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wskaz_aod_0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 47,
              hour_posY: 167,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wskaz_aod_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 32,
              minute_posY: 222,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 172,
              y: 60,
              w: 114,
              h: 43,
              select_image: 'ram_wyb_0.png',
              un_select_image: 'ram_wyb_1.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
              ],
              count: 4,
              tips_BG: 'rolka_0.png',
              tips_x: -18,
              tips_y: 60,
              tips_width: 155,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 204,
                  y: 70,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 3,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 181,
                  y: 65,
                  src: 'zn_ludz.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 197,
                  y: 70,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'zn_kcal.png',
                  unit_tc: 'zn_kcal.png',
                  unit_en: 'zn_kcal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 175,
                  y: 66,
                  src: 'zn_kalorii.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 235,
                  y: 69,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 4,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 175,
                  y: 69,
                  src: 'zn_puls.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 174,
                  y: 71,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'zn_km.png',
                  unit_tc: 'zn_km.png',
                  unit_en: 'zn_km.png',
                  dot_image: 'zn_przecinek.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 172,
              y: 351,
              w: 114,
              h: 43,
              select_image: 'ram_wyb_0.png',
              un_select_image: 'ram_wyb_1.png',
              default_type: hmUI.edit_type.STEP,
              optional_types: [
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
              ],
              count: 8,
              tips_BG: 'rolka_0.png',
              tips_x: -18,
              tips_y: -54,
              tips_width: 155,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 205,
                  y: 362,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 179,
                  y: 352,
                  src: 'zn_ludz.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 202,
                  y: 363,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'zn_kcal.png',
                  unit_tc: 'zn_kcal.png',
                  unit_en: 'zn_kcal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 177,
                  y: 353,
                  src: 'zn_kalorii.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 242,
                  y: 362,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 177,
                  y: 360,
                  src: 'zn_puls.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 174,
                  y: 362,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'zn_km.png',
                  unit_tc: 'zn_km.png',
                  unit_en: 'zn_km.png',
                  dot_image: 'zn_przecinek.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 230,
                  y: 364,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                 hmUI.createWidget(hmUI.widget.IMG, {
                  x: 199,
                  y: 358,
                  src: 'zn_uv.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 212,
                  y: 362,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'zn_procent_%.png',
                  unit_tc: 'zn_procent_%.png',
                  unit_en: 'zn_procent_%.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 180,
                  y: 357,
                  src: 'zn_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 211,
                  y: 361,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'zn_hPa.png',
                  unit_tc: 'zn_hPa.png',
                  unit_en: 'zn_hPa.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 176,
                  y: 353,
                  src: 'zn_cisn.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 230,
                  y: 364,
                  font_array: ["cm_00.png","cm_01.png","cm_02.png","cm_03.png","cm_04.png","cm_05.png","cm_06.png","cm_07.png","cm_08.png","cm_09.png"],
                  padding: false,
                  h_space: 2,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 356,
              src: 'zn_wiat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'maska_1.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 189;
                  let start_y_normal_battery = 272;
                  let lenght_ls_normal_battery = 122;
                  let line_width_ls_normal_battery = 11;
                  let color_ls_normal_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 3;
                  let pointer_offset_y_ls_normal_battery = 10;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery + lenght_ls_normal_battery - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_y_ls_normal_battery,
                    src: 'aku_wsk0.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = 90;
                  let end_angle_idle_battery = 270;
                  let center_x_idle_battery = 227;
                  let center_y_idle_battery = 227;
                  let radius_idle_battery = 100;
                  let line_width_cs_idle_battery = 7;
                  let color_cs_idle_battery = 0xFF666666;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                  
                  // idle_battery_circle_scale_mirror
                  // initial parameters mirror
                  let start_angle_idle_battery_mirror = 90;
                  let end_angle_idle_battery_mirror = -90;
                  
                  // calculated parameters mirror
                  let angle_offset_idle_battery_mirror = end_angle_idle_battery_mirror - start_angle_idle_battery_mirror;
                  angle_offset_idle_battery_mirror = angle_offset_idle_battery_mirror * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw_mirror = start_angle_idle_battery_mirror + angle_offset_idle_battery_mirror;
                  
                  idle_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery_mirror,
                    end_angle: end_angle_idle_battery_draw_mirror,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  