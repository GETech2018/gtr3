﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 317,
              day_startY: 288,
              day_sc_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              day_tc_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              day_en_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 258,
              month_startY: 286,
              month_sc_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_tc_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_en_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png","0176.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 47,
              image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 273,
              hour_startY: 214,
              hour_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_angle: 0,
              hour_unit_sc: '43.png',
              hour_unit_tc: '43.png',
              hour_unit_en: '43.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 334,
              minute_startY: 214,
              minute_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 314,
              y: 143,
              image_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 160,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              unit_sc: '85.png',
              unit_tc: '85.png',
              unit_en: '85.png',
              negative_image: '84.png',
              invalid_image: '83.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 267,
              y: 160,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              unit_sc: '88.png',
              unit_tc: '88.png',
              unit_en: '88.png',
              negative_image: '87.png',
              invalid_image: '86.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 160,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              unit_sc: '91.png',
              unit_tc: '91.png',
              unit_en: '91.png',
              negative_image: '90.png',
              invalid_image: '89.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 172,
              y: 308,
              image_array: ["92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 288,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              unit_sc: '100.png',
              unit_tc: '100.png',
              unit_en: '100.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 327,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              unit_sc: '102.png',
              unit_tc: '102.png',
              unit_en: '102.png',
              imperial_unit_sc: '103.png',
              imperial_unit_tc: '103.png',
              imperial_unit_en: '103.png',
              dot_image: '101.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 327,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 178,
              image_array: ["0400.png","0401.png","0402.png","0403.png","0404.png","0405.png","0406.png","0407.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 288,
              y: 363,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 363,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 367,
              font_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              padding: false,
              h_space: 0,
              invalid_image: '104.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 352,
              y: 286,
              week_en: ["0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
              week_tc: ["0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
              week_sc: ["0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 173,
              y: 391,
              src: '0303.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 41,
              src: '0350.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '124.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 24,
              hour_posY: 153,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '125.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '126.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 222,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aodbg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '124.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 24,
              hour_posY: 153,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '125.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 24,
              minute_posY: 216,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aodblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}