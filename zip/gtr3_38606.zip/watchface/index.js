/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v1.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_animation0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_hour_rotary4 = '';
		let normal_minute_rotary5 = '';
		let normal_second_rotary6 = '';
		let idle_img10 = '';
		let idle_hour_imagecombo11 = '';
		let idle_minute_imagecombo12 = '';
		let idle_img14 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				if (screenType != hmSetting.screen_type.AOD) {
					normal_animation0 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
						x: 0,
						y: 1,
						anim_path: '',
						anim_prefix: '1711650607243',
						anim_ext: 'png',
						anim_fps: 20,
						anim_size: 65,
						anim_repeat: false,
						repeat_count: 1,
						anim_status: hmUI.anim_status.START,
						display_on_restart: true,
						enable: false,
					});
				};

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0067.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0068.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary4 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					hour_path: '0069.png',
					hour_centerX: 227,
					hour_centerY: 227,
					hour_posX: 16,
					hour_posY: 150,
					hour_start_angle: 0,
					hour_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary5 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					minute_path: '0070.png',
					minute_centerX: 227,
					minute_centerY: 227,
					minute_posX: 12,
					minute_posY: 204,
					minute_start_angle: 0,
					minute_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary6 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
					second_path: '0071.png',
					second_centerX: 227,
					second_centerY: 226,
					second_posX: 9,
					second_posY: 206,
					second_start_angle: 0,
					second_end_angle: 360,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 454,
					h: 454,
					src: '0072.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 80,
					hour_startY: 60,
					hour_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 100,
					minute_startY: 216,
					minute_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.CENTER_H,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -1,
					y: 1,
					w: 454,
					h: 454,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}