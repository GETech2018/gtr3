﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''

        //vibrate (add destroy at end)
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
        function click_Vibrate() {
           vibrate.stop()
           vibrate.scene = 25
           vibrate.start()
        }

        //chronograph
        let ChronoTimer=null;
        let nowsec = hmSensor.createSensor(hmSensor.id.TIME);
        let flag = true
        let lastTime = 0
        let lastMark = 0
        let tmpMark = 0
        let diffTime = 0
        let minutes = 0
        let milis = 0
        let seconds = 0
        let chronosec = ''
        let chronomin = ''
        let a = null;
        let b = 0;

        function MakeTimer() {
             ChronoTimer = timer.createTimer(10, 10, TimerTick, {})
        }

        function TimerTick() {
             CalcTime(nowsec.utc - lastTime)
             DisplayChronoSec();
             DisplayChronoMinute();
        }

        function CalcTime(mark) {
	         diffTime = (mark + lastMark) / 10;
       	     milis = (diffTime % 100);
             diffTime = (diffTime - milis ) / 100;
             seconds= diffTime % 60;
             minutes= ((diffTime - seconds) / 60) % 60;
        }

        function DisplayChronoSec(){
             a=seconds*6+6*(milis % 100) / 100;
             chronosec.setProperty(hmUI.prop.MORE, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 227 - 24,
               pos_y: 227 - 215,
               center_x: 227,
               center_y: 227,
               src: 'second0.png',
               angle:a,
               show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }

        function DisplayChronoMinute(){
             b=minutes*12;
             if (b>360) {b = b - 360};
             chronomin.setProperty(hmUI.prop.MORE, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 327 - 10,
               pos_y: 226 - 63,
               center_x: 327,
               center_y: 226,
               src: 'pointer.png',
               angle: b,
               show_level: hmUI.show_level.ONLY_NORMAL,
             });
        }

        //start - pause Chrono
        function click_StartChrono(){
             click_Vibrate();
             flag = !flag
             if (flag) {
               timer.stopTimer(ChronoTimer)
	           tmpMark = nowsec.utc - lastTime
	           CalcTime(tmpMark)
               DisplayChronoSec();
               DisplayChronoMinute();
	           lastMark = lastMark + tmpMark;
             } else {
	             lastTime=nowsec.utc;
                 MakeTimer();
             }
        }

        //reset Chrono
        function click_ResetChrono(){
             click_Vibrate();
             if (!flag) {
                 timer.stopTimer(ChronoTimer)
             }
             flag=true
             lastMark=0
             lastTime=0
             CalcTime(lastTime)
             DisplayChronoSec();
             DisplayChronoMinute();
        }
        // end chronograph

        // sweep seconds
        let hsTimer=null;
		let now = hmSensor.createSensor(hmSensor.id.TIME);

        function DisplaySeconds(){
        	   let cs=now.second*6+6*(now.utc % 1000)/1000;
		       normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 228 - 10,
               pos_y: 326 - 63,
               center_x: 228,
               center_y: 326,
               src: 'pointer.png',
               angle: cs,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });
        }
        // end sweep seconds

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'background1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 213,
              y: 342,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 127,
              center_y: 226,
              x: 10,
              y: 63,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 320,
              day_startY: 323,
              day_sc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_tc_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_en_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              day_zero: 0,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //chrono minute pointer
            chronomin = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 327 - 10,
               pos_y: 226 - 63,
               center_x: 327,
               center_y: 226,
               src: 'pointer.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });

//             normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
//               second_path: 'pointer.png',
//               second_centerX: 241,
//               second_centerY: 345,
//               second_posX: 11,
//               second_posY: 67,
//               show_level: hmUI.show_level.ONLY_NORMAL,
//             });

            // secondhand sweep
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 228 - 10,
               pos_y: 326 - 63,
               center_x: 228,
               center_y: 326,
               src: 'pointer.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 17,
              hour_posY: 129,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 23,
              minute_posY: 175,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //chrono second pointer
            chronosec = hmUI.createWidget(hmUI.widget.IMG, {
               x: 0,
               y: 0,
               w: 454,
               h: 454,
               pos_x: 227 - 24,
               pos_y: 227 - 215,
               center_x: 227,
               center_y: 227,
               src: 'second0.png',
               angle: 0,
               show_level: hmUI.show_level.ONLY_NORMAL,
            });


            //AOD
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 213,
              y: 342,
              src: 'bluetoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 17,
              hour_posY: 129,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minute0.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 23,
              minute_posY: 175,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // Start Chrono shortcut start
            btnstart = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 31,
              text: '',
              w: 100,
              h: 91,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_StartChrono();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnstart.setProperty(hmUI.prop.VISIBLE, true);
            // Start Chrono shortcut end

            // Reset Chono shortcut start
            btnreset = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 326,
              y: 327,
              text: '',
              w: 100,
              h: 91,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_ResetChrono();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnreset.setProperty(hmUI.prop.VISIBLE, true);
            // Reset Chono  shortcut end

			DisplaySeconds();
            hsTimer = timer.createTimer(50, 50, DisplaySeconds, {})

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
				DisplaySeconds();
				if(hsTimer==null) hsTimer = timer.createTimer(50, 50, DisplaySeconds, {});
              }),
			  pause_call: (function () {
				timer.stopTimer(hsTimer);
				hsTimer=null;
             }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestroy() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
			timer.stopTimer(ChronoTimer);
            ChronoTimer=null;
            if (hsTimer) timer.stopTimer(hsTimer);
          },
          onDestory() {
            console.log('index page.js on destory invoke')
            vibrate && vibrate.stop();
			timer.stopTimer(ChronoTimer);
            ChronoTimer=null;
            if (hsTimer) timer.stopTimer(hsTimer);
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  