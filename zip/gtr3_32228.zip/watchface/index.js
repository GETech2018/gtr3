﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_circle_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_pai_circle_scale = ''
        let idle_pai_weekly_text_img = ''
        let idle_pai_weekly_separator_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

       // Start on off element
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 6
        let cc = 0
        let circle_color = '' 


        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
                if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
                if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
                if(backgroundnumber==6) {
                  UpdateBackgroundSix();
                }
            }
            if(backgroundnumber==1) hmUI.showToast({text: 'Color Green'});
            if(backgroundnumber==2) hmUI.showToast({text: 'Color Orange'});
            if(backgroundnumber==3) hmUI.showToast({text: 'Color Red'});
            if(backgroundnumber==4) hmUI.showToast({text: 'Color Yellow'});
            if(backgroundnumber==5) hmUI.showToast({text: 'Color Blue'});
            if(backgroundnumber==6) hmUI.showToast({text: 'Color White'});
        }
//////////////////////////////////////////////////////////////////////////////////////////////////

        //color1
        function UpdateBackgroundOne(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main1.png");
              circle_color = '0xFF19F792' 
              const result = hmSetting.setScreenOff()

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

         //color2
        function UpdateBackgroundTwo(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main2.png");
              circle_color = '0xFFE9AD2E' 
const result = hmSetting.setScreenOff()
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

             //color3
        function UpdateBackgroundThree(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main3.png");
              circle_color = '0xFF2E3B' 
const result = hmSetting.setScreenOff()
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

             //color4
        function UpdateBackgroundFour(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main4.png");
              circle_color = '0xFFEAEA30' 
const result = hmSetting.setScreenOff()
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

             //color5
        function UpdateBackgroundFive(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main5.png");
              circle_color = '0xFF2EB4E7' 
const result = hmSetting.setScreenOff()
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

             //color6
        function UpdateBackgroundSix(){
              normal_background_bg_img.setProperty(hmUI.prop.SRC, "main6.png");
              circle_color = '0xFFE2E2E2' 
const result = hmSetting.setScreenOff()
        }


//////////////////////////////////////////////////////////////////////////////////////////////////

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 428,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 430,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 380,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 227,
              y: 382,
              w: 56,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 96,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_icons01.png',
              unit_tc: 'weather_icons01.png',
              unit_en: 'weather_icons01.png',
              negative_image: 'weather_icons02.png',
              invalid_image: 'weather_icons02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 52,
              image_array: ["Weather_ICONS_01.png","Weather_ICONS_02.png","Weather_ICONS_03.png","Weather_ICONS_04.png","Weather_ICONS_05.png","Weather_ICONS_06.png","Weather_ICONS_07.png","Weather_ICONS_08.png","Weather_ICONS_09.png","Weather_ICONS_10.png","Weather_ICONS_11.png","Weather_ICONS_12.png","Weather_ICONS_13.png","Weather_ICONS_14.png","Weather_ICONS_15.png","Weather_ICONS_16.png","Weather_ICONS_17.png","Weather_ICONS_18.png","Weather_ICONS_19.png","Weather_ICONS_20.png","Weather_ICONS_21.png","Weather_ICONS_22.png","Weather_ICONS_23.png","Weather_ICONS_24.png","Weather_ICONS_25.png","Weather_ICONS_26.png","Weather_ICONS_27.png","Weather_ICONS_28.png","Weather_ICONS_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 89,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 234,
              month_startY: 58,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 50,
              day_sc_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_tc_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_en_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 314,
              // start_angle: 94,
              // end_angle: 445,
              // radius: 63,
              // line_width: 13,
              // color: 0xFF0EF985,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 248,
              src: 'Top_heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 290,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 249,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 141,
              // center_y: 314,
              // start_angle: 94,
              // end_angle: 445,
              // radius: 63,
              // line_width: 13,
              // color: 0xFF0EF985,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 249,
              src: 'Top_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 249,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 301,
              font_array: ["Midium_Font_01.png","Midium_Font_02.png","Midium_Font_03.png","Midium_Font_04.png","Midium_Font_05.png","Midium_Font_06.png","Midium_Font_07.png","Midium_Font_08.png","Midium_Font_09.png","Midium_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_km.png',
              unit_tc: 'icon_km.png',
              unit_en: 'icon_km.png',
              imperial_unit_sc: 'icon_mi.png',
              imperial_unit_tc: 'icon_mi.png',
              imperial_unit_en: 'icon_mi.png',
              dot_image: 'icon_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 66,
              // center_y: 199,
              // start_angle: 114,
              // end_angle: 461,
              // radius: 34,
              // line_width: 7,
              // color: 0xFFE2E2E2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 197,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 165,
              src: 'top_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 391,
              // center_y: 199,
              // start_angle: 114,
              // end_angle: 461,
              // radius: 34,
              // line_width: 7,
              // color: 0xFFE2E2E2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 185,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 351,
              y: 165,
              src: 'top_Battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 218,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 215,
              pm_y: 218,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 124,
              hour_startY: 115,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 115,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 338,
              second_startY: 111,
              second_array: ["Time_second_01.png","Time_second_02.png","Time_second_03.png","Time_second_04.png","Time_second_05.png","Time_second_06.png","Time_second_07.png","Time_second_08.png","Time_second_09.png","Time_second_10.png"],
              second_zero: 1,
              second_space: 6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 112,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 428,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 203,
              y: 430,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 186,
              y: 380,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 227,
              y: 382,
              w: 56,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 96,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_icons01.png',
              unit_tc: 'weather_icons01.png',
              unit_en: 'weather_icons01.png',
              negative_image: 'weather_icons02.png',
              invalid_image: 'weather_icons02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 52,
              image_array: ["Weather_ICONS_01.png","Weather_ICONS_02.png","Weather_ICONS_03.png","Weather_ICONS_04.png","Weather_ICONS_05.png","Weather_ICONS_06.png","Weather_ICONS_07.png","Weather_ICONS_08.png","Weather_ICONS_09.png","Weather_ICONS_10.png","Weather_ICONS_11.png","Weather_ICONS_12.png","Weather_ICONS_13.png","Weather_ICONS_14.png","Weather_ICONS_15.png","Weather_ICONS_16.png","Weather_ICONS_17.png","Weather_ICONS_18.png","Weather_ICONS_19.png","Weather_ICONS_20.png","Weather_ICONS_21.png","Weather_ICONS_22.png","Weather_ICONS_23.png","Weather_ICONS_24.png","Weather_ICONS_25.png","Weather_ICONS_26.png","Weather_ICONS_27.png","Weather_ICONS_28.png","Weather_ICONS_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 180,
              y: 89,
              week_en: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_tc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              week_sc: ["Week_01.png","Week_02.png","Week_03.png","Week_04.png","Week_05.png","Week_06.png","Week_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 234,
              month_startY: 58,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 50,
              day_sc_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_tc_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_en_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 316,
              // center_y: 314,
              // start_angle: 94,
              // end_angle: 445,
              // radius: 63,
              // line_width: 13,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 251,
              y: 248,
              src: 'Top_heart.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 290,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 365,
              y: 249,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 141,
              // center_y: 314,
              // start_angle: 94,
              // end_angle: 445,
              // radius: 63,
              // line_width: 13,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 76,
              y: 249,
              src: 'Top_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 12,
              y: 249,
              font_array: ["Normal_Font_01.png","Normal_Font_02.png","Normal_Font_03.png","Normal_Font_04.png","Normal_Font_05.png","Normal_Font_06.png","Normal_Font_07.png","Normal_Font_08.png","Normal_Font_09.png","Normal_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 301,
              font_array: ["Midium_Font_01.png","Midium_Font_02.png","Midium_Font_03.png","Midium_Font_04.png","Midium_Font_05.png","Midium_Font_06.png","Midium_Font_07.png","Midium_Font_08.png","Midium_Font_09.png","Midium_Font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_km.png',
              unit_tc: 'icon_km.png',
              unit_en: 'icon_km.png',
              imperial_unit_sc: 'icon_mi.png',
              imperial_unit_tc: 'icon_mi.png',
              imperial_unit_en: 'icon_mi.png',
              dot_image: 'icon_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 66,
              // center_y: 199,
              // start_angle: 114,
              // end_angle: 461,
              // radius: 34,
              // line_width: 7,
              // color: 0xFFE2E2E2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 197,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 165,
              src: 'top_Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 391,
              // center_y: 199,
              // start_angle: 114,
              // end_angle: 461,
              // radius: 34,
              // line_width: 7,
              // color: 0xFFE2E2E2,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 185,
              font_array: ["Small_Font_01.png","Small_Font_02.png","Small_Font_03.png","Small_Font_04.png","Small_Font_05.png","Small_Font_06.png","Small_Font_07.png","Small_Font_08.png","Small_Font_09.png","Small_Font_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 351,
              y: 165,
              src: 'top_Battery.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 215,
              am_y: 218,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 215,
              pm_y: 218,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 124,
              hour_startY: 115,
              hour_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_align: hmUI.align.LEFT,

              minute_startX: 241,
              minute_startY: 115,
              minute_array: ["Time_Font_HM_01.png","Time_Font_HM_02.png","Time_Font_HM_03.png","Time_Font_HM_04.png","Time_Font_HM_05.png","Time_Font_HM_06.png","Time_Font_HM_07.png","Time_Font_HM_08.png","Time_Font_HM_09.png","Time_Font_HM_10.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 338,
              second_startY: 111,
              second_array: ["Time_second_01.png","Time_second_02.png","Time_second_03.png","Time_second_04.png","Time_second_05.png","Time_second_06.png","Time_second_07.png","Time_second_08.png","Time_second_09.png","Time_second_10.png"],
              second_zero: 1,
              second_space: 6,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 112,
              src: 'Time_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 119,
              w: 31,
              h: 72,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 117,
              w: 45,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 424,
              w: 76,
              h: 27,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 378,
              w: 40,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 39,
              w: 53,
              h: 52,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 173,
              w: 49,
              h: 51,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 331,
              w: 81,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 268,
              w: 86,
              h: 55,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
////////////////////////////////////////////////////////////////////////////////////////////////
		// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 108,
              w: 50,
              h: 50,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});
/////////////////////////////////////////////////////////////////////////////////


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 109,
              y: 213,
              w: 46,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 45)/(targetHeartRate - 45);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = 4;
                  let end_angle_normal_heart_rate = 355;
                  let center_x_normal_heart_rate = 316;
                  let center_y_normal_heart_rate = 314;
                  let radius_normal_heart_rate = 63;
                  let line_width_cs_normal_heart_rate = 13;
                  let color_cs_normal_heart_rate = circle_color;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = 4;
                  let end_angle_normal_step = 355;
                  let center_x_normal_step = 141;
                  let center_y_normal_step = 314;
                  let radius_normal_step = 63;
                  let line_width_cs_normal_step = 13;
                  let color_cs_normal_step = circle_color;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale
                  // initial parameters
                  let start_angle_normal_pai = 24;
                  let end_angle_normal_pai = 371;
                  let center_x_normal_pai = 66;
                  let center_y_normal_pai = 199;
                  let radius_normal_pai = 34;
                  let line_width_cs_normal_pai = 7;
                  let color_cs_normal_pai = 0xFFE2E2E2;
                  
                  // calculated parameters
                  let arcX_normal_pai = center_x_normal_pai - radius_normal_pai;
                  let arcY_normal_pai = center_y_normal_pai - radius_normal_pai;
                  let CircleWidth_normal_pai = 2 * radius_normal_pai;
                  let angle_offset_normal_pai = end_angle_normal_pai - start_angle_normal_pai;
                  angle_offset_normal_pai = angle_offset_normal_pai * progress_cs_normal_pai;
                  let end_angle_normal_pai_draw = start_angle_normal_pai + angle_offset_normal_pai;
                  
                  normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_pai,
                    y: arcY_normal_pai,
                    w: CircleWidth_normal_pai,
                    h: CircleWidth_normal_pai,
                    start_angle: start_angle_normal_pai,
                    end_angle: end_angle_normal_pai_draw,
                    color: color_cs_normal_pai,
                    line_width: line_width_cs_normal_pai,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 24;
                  let end_angle_normal_battery = 371;
                  let center_x_normal_battery = 391;
                  let center_y_normal_battery = 199;
                  let radius_normal_battery = 34;
                  let line_width_cs_normal_battery = 7;
                  let color_cs_normal_battery = 0xFFE2E2E2;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_idle_heart_rate = 4;
                  let end_angle_idle_heart_rate = 355;
                  let center_x_idle_heart_rate = 316;
                  let center_y_idle_heart_rate = 314;
                  let radius_idle_heart_rate = 63;
                  let line_width_cs_idle_heart_rate = 13;
                  let color_cs_idle_heart_rate = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_heart_rate = center_x_idle_heart_rate - radius_idle_heart_rate;
                  let arcY_idle_heart_rate = center_y_idle_heart_rate - radius_idle_heart_rate;
                  let CircleWidth_idle_heart_rate = 2 * radius_idle_heart_rate;
                  let angle_offset_idle_heart_rate = end_angle_idle_heart_rate - start_angle_idle_heart_rate;
                  angle_offset_idle_heart_rate = angle_offset_idle_heart_rate * progress_cs_idle_heart_rate;
                  let end_angle_idle_heart_rate_draw = start_angle_idle_heart_rate + angle_offset_idle_heart_rate;
                  
                  idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_heart_rate,
                    y: arcY_idle_heart_rate,
                    w: CircleWidth_idle_heart_rate,
                    h: CircleWidth_idle_heart_rate,
                    start_angle: start_angle_idle_heart_rate,
                    end_angle: end_angle_idle_heart_rate_draw,
                    color: color_cs_idle_heart_rate,
                    line_width: line_width_cs_idle_heart_rate,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = 4;
                  let end_angle_idle_step = 355;
                  let center_x_idle_step = 141;
                  let center_y_idle_step = 314;
                  let radius_idle_step = 63;
                  let line_width_cs_idle_step = 13;
                  let color_cs_idle_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales PAI');
                let progress_cs_idle_pai = progressPAI;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_pai_circle_scale
                  // initial parameters
                  let start_angle_idle_pai = 24;
                  let end_angle_idle_pai = 371;
                  let center_x_idle_pai = 66;
                  let center_y_idle_pai = 199;
                  let radius_idle_pai = 34;
                  let line_width_cs_idle_pai = 7;
                  let color_cs_idle_pai = 0xFFE2E2E2;
                  
                  // calculated parameters
                  let arcX_idle_pai = center_x_idle_pai - radius_idle_pai;
                  let arcY_idle_pai = center_y_idle_pai - radius_idle_pai;
                  let CircleWidth_idle_pai = 2 * radius_idle_pai;
                  let angle_offset_idle_pai = end_angle_idle_pai - start_angle_idle_pai;
                  angle_offset_idle_pai = angle_offset_idle_pai * progress_cs_idle_pai;
                  let end_angle_idle_pai_draw = start_angle_idle_pai + angle_offset_idle_pai;
                  
                  idle_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_pai,
                    y: arcY_idle_pai,
                    w: CircleWidth_idle_pai,
                    h: CircleWidth_idle_pai,
                    start_angle: start_angle_idle_pai,
                    end_angle: end_angle_idle_pai_draw,
                    color: color_cs_idle_pai,
                    line_width: line_width_cs_idle_pai,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = 24;
                  let end_angle_idle_battery = 371;
                  let center_x_idle_battery = 391;
                  let center_y_idle_battery = 199;
                  let radius_idle_battery = 34;
                  let line_width_cs_idle_battery = 7;
                  let color_cs_idle_battery = 0xFFE2E2E2;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

if (cc==0) {
  cc = 1
              circle_color = '0xFF19F792' 
}
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 323,
              y: 48,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}