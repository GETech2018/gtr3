﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_date_img_date_week_img = ''
        let normal_stress_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_pai_icon_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_stand_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_calorie_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 150,
              y: 402,
              week_en: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              week_tc: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              week_sc: ["day-funky_colors_0001.png","day-funky_colors_0002.png","day-funky_colors_0003.png","day-funky_colors_0004.png","day-funky_colors_0005.png","day-funky_colors_0006.png","day-funky_colors_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 55,
              y: 403,
              src: 'Picture64.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 48,
              y: 344,
              src: 'framePicture66.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 202,
              src: 'StPicture1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 364,
              y: 204,
              src: 'Picture64.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 379,
              y: 197,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -27,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 364,
              y: 203,
              src: 'steps comPicture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 60,
              y: -339,
              src: '12steps comPicture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -25,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 11,
              src: 'heartPicture125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 382,
              day_sc_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_tc_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_en_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              day_zero: 1,
              day_space: -36,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: -25,
              am_y: 229,
              am_sc_path: 'Picture40am.png',
              am_en_path: 'Picture40am.png',
              pm_x: -25,
              pm_y: 229,
              pm_sc_path: 'Picture41pm.png',
              pm_en_path: 'Picture41pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 65,
              hour_startY: 57,
              hour_array: ["funky_colors_0001.png","funky_colors_0002.png","funky_colors_0003.png","funky_colors_0004.png","funky_colors_0005.png","funky_colors_0006.png","funky_colors_0007.png","funky_colors_0008.png","funky_colors_0009.png","funky_colors_0010.png"],
              hour_zero: 1,
              hour_space: -37,
              hour_align: hmUI.align.LEFT,

              minute_startX: 65,
              minute_startY: 179,
              minute_array: ["funky_colors_0001.png","funky_colors_0002.png","funky_colors_0003.png","funky_colors_0004.png","funky_colors_0005.png","funky_colors_0006.png","funky_colors_0007.png","funky_colors_0008.png","funky_colors_0009.png","funky_colors_0010.png"],
              minute_zero: 1,
              minute_space: -37,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -13,
              second_startY: 198,
              second_array: ["small-funky_colors_0001.png","small-funky_colors_0002.png","small-funky_colors_0003.png","small-funky_colors_0004.png","small-funky_colors_0005.png","small-funky_colors_0006.png","small-funky_colors_0007.png","small-funky_colors_0008.png","small-funky_colors_0009.png","small-funky_colors_0010.png"],
              second_zero: 1,
              second_space: -34,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -128,
              y: 202,
              src: 'steps comPicture1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 160,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -23,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 214,
              y: 14,
              src: 'chargePicture113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 86,
              hour_startY: 54,
              hour_array: ["aob-funky_colors_0001.png","aob-funky_colors_0002.png","aob-funky_colors_0003.png","aob-funky_colors_0004.png","aob-funky_colors_0005.png","aob-funky_colors_0006.png","aob-funky_colors_0007.png","aob-funky_colors_0008.png","aob-funky_colors_0009.png","aob-funky_colors_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 86,
              minute_startY: 207,
              minute_array: ["aob-funky_colors_0001.png","aob-funky_colors_0002.png","aob-funky_colors_0003.png","aob-funky_colors_0004.png","aob-funky_colors_0005.png","aob-funky_colors_0006.png","aob-funky_colors_0007.png","aob-funky_colors_0008.png","aob-funky_colors_0009.png","aob-funky_colors_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 411,
              src: 'Logo_4.51z.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 0,
              font_array: ["batt-funky_colors_0001.png","batt-funky_colors_0002.png","batt-funky_colors_0003.png","batt-funky_colors_0004.png","batt-funky_colors_0005.png","batt-funky_colors_0006.png","batt-funky_colors_0007.png","batt-funky_colors_0008.png","batt-funky_colors_0009.png","batt-funky_colors_0010.png"],
              padding: false,
              h_space: -23,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 14,
              src: 'chargePicture113.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -40,
              y: -16,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  