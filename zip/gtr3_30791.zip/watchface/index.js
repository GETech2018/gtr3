﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_humidity_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'BACE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 224,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'kel.png',
              unit_tc: 'kel.png',
              unit_en: 'kel.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 209,
              y: 156,
              image_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 317,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294,
              y: 383,
              font_array: ["di001.png","di002.png","di003.png","di004.png","di005.png","di006.png","di007.png","di008.png","di009.png","di010.png"],
              padding: false,
              h_space: -8,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 383,
              font_array: ["di001.png","di002.png","di003.png","di004.png","di005.png","di006.png","di007.png","di008.png","di009.png","di010.png"],
              padding: false,
              h_space: -9,
              unit_sc: 'dikm.png',
              unit_tc: 'dikm.png',
              unit_en: 'dikm.png',
              dot_image: 'ditelia.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 36,
              y: 317,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 323,
              y: 279,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 77,
              y: 279,
              font_array: ["st001.png","st002.png","st003.png","st004.png","st005.png","st006.png","st007.png","st008.png","st009.png","st010.png"],
              padding: false,
              h_space: -9,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 113,
              y: 172,
              week_en: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_tc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_sc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 328,
              month_startY: 172,
              month_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 298,
              day_startY: 172,
              day_sc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_tc_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_en_array: ["DAY001.png","DAY002.png","DAY003.png","DAY004.png","DAY005.png","DAY006.png","DAY007.png","DAY008.png","DAY009.png","DAY010.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'dayspace.png',
              day_unit_tc: 'dayspace.png',
              day_unit_en: 'dayspace.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 57,
              font_array: ["BAT001.png","BAT002.png","BAT003.png","BAT004.png","BAT005.png","BAT006.png","BAT007.png","BAT008.png","BAT009.png","BAT010.png"],
              padding: false,
              h_space: -8,
              unit_sc: 'BATEKATO.png',
              unit_tc: 'BATEKATO.png',
              unit_en: 'BATEKATO.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 174,
              y: 9,
              image_array: ["B001.png","B002.png","B003.png","B004.png","B005.png","B006.png","B007.png","B008.png","B009.png","B010.png","B011.png","B012.png","B013.png","B014.png","B015.png","B016.png","B017.png","B018.png","B019.png","B020.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 123,
              hour_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 306,
              minute_startY: 123,
              minute_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 197,
              second_startY: 294,
              second_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 159,
              hour_startY: 199,
              hour_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'ANAMESA.png',
              hour_unit_tc: 'ANAMESA.png',
              hour_unit_en: 'ANAMESA.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 226,
              minute_startY: 199,
              minute_array: ["TIME001.png","TIME002.png","TIME003.png","TIME004.png","TIME005.png","TIME006.png","TIME007.png","TIME008.png","TIME009.png","TIME010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
