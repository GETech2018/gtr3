﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_calorie_icon_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_icon_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'black background with text overlay (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: -96,
              src: 'Picture192.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 227,
              src: 'Picture189.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 397,
              src: 'Picture172.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 376,
              font_array: ["2_thinsampawhite_0001.png","2_thinsampawhite_0002.png","2_thinsampawhite_0003.png","2_thinsampawhite_0004.png","2_thinsampawhite_0005.png","2_thinsampawhite_0006.png","2_thinsampawhite_0007.png","2_thinsampawhite_0008.png","2_thinsampawhite_0009.png","2_thinsampawhite_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 392,
              src: 'Picture171.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 13,
              day_sc_array: ["2_thinsampawhite_0001.png","2_thinsampawhite_0002.png","2_thinsampawhite_0003.png","2_thinsampawhite_0004.png","2_thinsampawhite_0005.png","2_thinsampawhite_0006.png","2_thinsampawhite_0007.png","2_thinsampawhite_0008.png","2_thinsampawhite_0009.png","2_thinsampawhite_0010.png"],
              day_tc_array: ["2_thinsampawhite_0001.png","2_thinsampawhite_0002.png","2_thinsampawhite_0003.png","2_thinsampawhite_0004.png","2_thinsampawhite_0005.png","2_thinsampawhite_0006.png","2_thinsampawhite_0007.png","2_thinsampawhite_0008.png","2_thinsampawhite_0009.png","2_thinsampawhite_0010.png"],
              day_en_array: ["2_thinsampawhite_0001.png","2_thinsampawhite_0002.png","2_thinsampawhite_0003.png","2_thinsampawhite_0004.png","2_thinsampawhite_0005.png","2_thinsampawhite_0006.png","2_thinsampawhite_0007.png","2_thinsampawhite_0008.png","2_thinsampawhite_0009.png","2_thinsampawhite_0010.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 13,
              week_en: ["2_daysampawhite_0001.png","2_daysampawhite_0002.png","2_daysampawhite_0003.png","2_daysampawhite_0004.png","2_daysampawhite_0005.png","2_daysampawhite_0006.png","2_daysampawhite_0007.png"],
              week_tc: ["2_daysampawhite_0001.png","2_daysampawhite_0002.png","2_daysampawhite_0003.png","2_daysampawhite_0004.png","2_daysampawhite_0005.png","2_daysampawhite_0006.png","2_daysampawhite_0007.png"],
              week_sc: ["2_daysampawhite_0001.png","2_daysampawhite_0002.png","2_daysampawhite_0003.png","2_daysampawhite_0004.png","2_daysampawhite_0005.png","2_daysampawhite_0006.png","2_daysampawhite_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: -28,
              hour_array: ["2_sampablue_0001.png","2_sampablue_0002.png","2_sampablue_0003.png","2_sampablue_0004.png","2_sampablue_0005.png","2_sampablue_0006.png","2_sampablue_0007.png","2_sampablue_0008.png","2_sampablue_0009.png","2_sampablue_0010.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 4,
              minute_startY: 132,
              minute_array: ["2_sampawhite_0001.png","2_sampawhite_0002.png","2_sampawhite_0003.png","2_sampawhite_0004.png","2_sampawhite_0005.png","2_sampawhite_0006.png","2_sampawhite_0007.png","2_sampawhite_0008.png","2_sampawhite_0009.png","2_sampawhite_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -46,
              y: -31,
              src: 'Picture239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 4,
              hour_startY: -26,
              hour_array: ["2_sampawhite_0001.png","2_sampawhite_0002.png","2_sampawhite_0003.png","2_sampawhite_0004.png","2_sampawhite_0005.png","2_sampawhite_0006.png","2_sampawhite_0007.png","2_sampawhite_0008.png","2_sampawhite_0009.png","2_sampawhite_0010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 4,
              minute_startY: 130,
              minute_array: ["2_sampawhite_0001.png","2_sampawhite_0002.png","2_sampawhite_0003.png","2_sampawhite_0004.png","2_sampawhite_0005.png","2_sampawhite_0006.png","2_sampawhite_0007.png","2_sampawhite_0008.png","2_sampawhite_0009.png","2_sampawhite_0010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 397,
              src: 'Picture172.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 376,
              font_array: ["2_thinsampawhite_0001.png","2_thinsampawhite_0002.png","2_thinsampawhite_0003.png","2_thinsampawhite_0004.png","2_thinsampawhite_0005.png","2_thinsampawhite_0006.png","2_thinsampawhite_0007.png","2_thinsampawhite_0008.png","2_thinsampawhite_0009.png","2_thinsampawhite_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -44,
              y: -96,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  