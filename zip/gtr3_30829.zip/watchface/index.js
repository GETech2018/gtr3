﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_circle_scale_mirror = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 't_1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 't_2.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 't_3.png' },
              ],
              count: 3,
              default_id: 1,
              fg: 'fg_i.png',
              tips_bg: 'tt.png',
              tips_x: 152,
              tips_y: 284,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'wskaz_dn_tyg.png',
              center_x: 227,
              center_y: 227,
              posX: 24,
              posY: 217,
              start_angle: 0,
              end_angle: 210,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 154,
              y: 367,
              src: 'brak_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 370,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 202,
              font_array: ["cdataku_00.png","cdataku_01.png","cdataku_02.png","cdataku_03.png","cdataku_04.png","cdataku_05.png","cdataku_06.png","cdataku_07.png","cdataku_08.png","cdataku_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 200,
              src: 'procent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 302,
              day_startY: 201,
              day_sc_array: ["cdataku_00.png","cdataku_01.png","cdataku_02.png","cdataku_03.png","cdataku_04.png","cdataku_05.png","cdataku_06.png","cdataku_07.png","cdataku_08.png","cdataku_09.png"],
              day_tc_array: ["cdataku_00.png","cdataku_01.png","cdataku_02.png","cdataku_03.png","cdataku_04.png","cdataku_05.png","cdataku_06.png","cdataku_07.png","cdataku_08.png","cdataku_09.png"],
              day_en_array: ["cdataku_00.png","cdataku_01.png","cdataku_02.png","cdataku_03.png","cdataku_04.png","cdataku_05.png","cdataku_06.png","cdataku_07.png","cdataku_08.png","cdataku_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 274,
              hour_array: ["cgn_01.png","cgn_02.png","cgn_03.png","cgn_04.png","cgn_05.png","cgn_06.png","cgn_07.png","cgn_08.png","cgn_09.png","cgn_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_unit_sc: 'dwukropek_nieb.png',
              hour_unit_tc: 'dwukropek_nieb.png',
              hour_unit_en: 'dwukropek_nieb.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 240,
              minute_startY: 274,
              minute_array: ["cgn_01.png","cgn_02.png","cgn_03.png","cgn_04.png","cgn_05.png","cgn_06.png","cgn_07.png","cgn_08.png","cgn_09.png","cgn_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD_ring.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 227,
              // center_y: 227,
              // start_angle: 180,
              // end_angle: 360,
              // radius: 80,
              // line_width: 14,
              // color: 0xFF9B9B9B,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
              idle_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wh_0.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 13,
              hour_posY: 131,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wm_0.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 9,
              minute_posY: 200,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 28,
              y: 146,
              w: 182,
              h: 60,
              select_image: 'ramka_wyb_akt.png',
              un_select_image: 'ramka wyb_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.STAND, preview: 'ez(1)_STAND.png' },
              ],
              count: 5,
              tips_BG: 'tt.png',
              tips_x: 13,
              tips_y: 64,
              tips_width: 150,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 41,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: true,
                  h_space: 0,
                  unit_sc: 'ico_buty.png',
                  unit_tc: 'ico_buty.png',
                  unit_en: 'ico_buty.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STEP_TARGET,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 60,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'param_kcal.png',
                  unit_tc: 'param_kcal.png',
                  unit_en: 'param_kcal.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 36,
                  y: 157,
                  src: 'ico_cal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 74,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'param_BPM.png',
                  unit_tc: 'param_BPM.png',
                  unit_en: 'param_BPM.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 36,
                  y: 160,
                  src: 'ico_serce.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 36,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'param_km.png',
                  unit_tc: 'param_km.png',
                  unit_en: 'param_km.png',
                  dot_image: 'cpz_przecin.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STAND:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 36,
                  y: 157,
                  src: 'znak_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 209,
              y: 82,
              w: 182,
              h: 60,
              select_image: 'ramka_wyb_akt.png',
              un_select_image: 'ramka wyb_pas.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(2)_SUN.png' },
              ],
              count: 2,
              tips_BG: 'tt.png',
              tips_x: -1,
              tips_y: -42,
              tips_width: 150,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 309,
                  y: 80,
                  image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 309,
                  y: 80,
                  src: 'znak_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 249,
              y: 146,
              w: 182,
              h: 60,
              select_image: 'ramka_wyb_akt.png',
              un_select_image: 'ramka wyb_pas.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(3)_WEATHER.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(3)_ALTIMETER.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(3)_WIND.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(3)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(3)_UVI.png' },
                { type: hmUI.edit_type.SUN, preview: 'ez(3)_SUN.png' },
              ],
              count: 6,
              tips_BG: 'tt.png',
              tips_x: 17,
              tips_y: 64,
              tips_width: 150,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 315,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'param_st_C.png',
                  unit_tc: 'param_st_C.png',
                  unit_en: 'param_st_C.png',
                  negative_image: 'cpz_minus.png',
                  invalid_image: 'znak_pusty.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 157,
              src: 'ico_term.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 314,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'param_uv.png',
                  unit_tc: 'param_uv.png',
                  unit_en: 'param_uv.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 280,
                  y: 157,
                  src: 'ico_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 316,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'param_proc.png',
                  unit_tc: 'param_proc.png',
                  unit_en: 'param_proc.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 277,
                  y: 157,
                  src: 'param_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 293,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'param_hPa.png',
                  unit_tc: 'param_hPa.png',
                  unit_en: 'param_hPa.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 257,
                  y: 157,
                  src: 'ico_cisn.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.SUN:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 293,
                  y: 157,
                  src: 'znak_pusty.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 340,
                  y: 157,
                  font_array: ["cpz_00.png","cpz_01.png","cpz_02.png","cpz_03.png","cpz_04.png","cpz_05.png","cpz_06.png","cpz_07.png","cpz_08.png","cpz_09.png"],
                  padding: false,
                  h_space: 2,
                  unit_sc: 'param_st.png',
                  unit_tc: 'param_st.png',
                  unit_en: 'param_st.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 298,
                  y: 157,
                  src: 'ico_wiatr.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask_bottom.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fg_i.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 6,
                    posY: 205,
                    path: 'ws_0.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 13,
                    posY: 131,
                    path: 'wh_0.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wm_0.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 6,
                    posY: 205,
                    path: 'ws_1.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 13,
                    posY: 131,
                    path: 'wh_1.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wm_1.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: 'fg_i.png',
              tips_x: 153,
              tips_y: 65,
              tips_bg: 'tt.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 215,
              y: 214,
              src: 'znak_pusty.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(0);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 226,
              y: 346,
              w: 172,
              h: 92,
              src: 'znak_pusty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 346,
              w: 174,
              h: 92,
              src: 'znak_pusty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 274,
              w: 220,
              h: 70,
              src: 'znak_pusty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 60,
              w: 146,
              h: 128,
              src: 'znak_pusty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 60,
              w: 146,
              h: 128,
              src: 'znak_pusty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = 90;
                  let end_angle_idle_battery = 270;
                  let center_x_idle_battery = 227;
                  let center_y_idle_battery = 227;
                  let radius_idle_battery = 80;
                  let line_width_cs_idle_battery = 14;
                  let color_cs_idle_battery = 0xFF9B9B9B;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                  
                  // idle_battery_circle_scale_mirror
                  // initial parameters mirror
                  let start_angle_idle_battery_mirror = 90;
                  let end_angle_idle_battery_mirror = -90;
                  
                  // calculated parameters mirror
                  let angle_offset_idle_battery_mirror = end_angle_idle_battery_mirror - start_angle_idle_battery_mirror;
                  angle_offset_idle_battery_mirror = angle_offset_idle_battery_mirror * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw_mirror = start_angle_idle_battery_mirror + angle_offset_idle_battery_mirror;
                  
                  idle_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery_mirror,
                    end_angle: end_angle_idle_battery_draw_mirror,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
