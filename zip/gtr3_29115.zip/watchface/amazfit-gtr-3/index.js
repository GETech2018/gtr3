try {
    (() => {
        const e = __$$hmAppManager$$__.currentApp;
//代码开始     
        let normal_analog_clock_time_pointer_second = ''
        let now;
        let lastTime = 0;
        let animTimer;
        let widgetDelegate;
        const animDuration = 5000;
        const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

        function setSec() {
            const screenType = hmSetting.getScreenType();
         //   if (screenType === hmSetting.screen_type.AOD) {
         //       return stopSecAnim();
         //   }
            if (!now) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            if (widgetDelegate) return;

            widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function() {
                    console.log('ui resume');

                    if (animTimer) return;

                    let duration = 0;
                    const diffTime = now.utc - lastTime;
                    if (diffTime < animDuration) {
                        duration = animDuration - diffTime;
                    }

                    animTimer = timer.createTimer(duration, animDuration, (function(option) {
                        lastTime = now.utc;
                        startSecAnim(now.second * 6);
                    }));
                }),
                pause_call: (function() {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim(sec) {
            const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
            }

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()
         */
        function stopSecAnim() {
            if (animTimer) {
                timer.stopTimer(animTimer);
                animTimer = undefined;
            }
        }
//代码结束 
 const t = e.current,
            {
                px: n
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, t)), e.__globals__);
        let r = "",
            _ = "",
            g = "",
            o = "",
            h = "",
            p = "",
            i = "",
            a = "",
            s = "";
        const m = Logger.getLogger("watchface6");
        t.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), r = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 197,
                    y: 121,
                    w: 60,
                    h: 40,
                    text: "[HR]",
                    color: "0xFFf5af83",
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), _ = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 187,
                    y: 306,
                    w: 80,
                    h: 30,
                    text: "[SC]",
                    color: "0xFFf5af83",
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), g = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 315,
                    y: 240,
                    w: 50,
                    h: 30,
                    text: "[DAY_Z]",
                    color: "0xFFf5af83",
                    text_size: 30,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 83,
                    y: 177,
                    image_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 80,
                    y: 231,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -4,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "44.png",
                    unit_tc: "44.png",
                    unit_en: "44.png",
                    negative_image: "43.png",
                    invalid_image: "42.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 311,
                    y: 201,
                    week_sc: ["45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 105,
                    y: 326,
                    src: "52.png",
                    type: hmUI.system_status.DISCONNECT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_STATUS, {
                    x: 321,
                    y: 323,
                    src: "53.png",
                    type: hmUI.system_status.DISTURB,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 183,
                    y: 333,
                    type: hmUI.data_type.DISTANCE,
                    font_array: ["54.png", "55.png", "56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png", "63.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "65.png",
                    unit_tc: "65.png",
                    unit_en: "65.png",
                    dot_image: "64.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 225,
                    hour_posX: 28,
                    hour_posY: 209,
                    hour_path: "66.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 29,
                    minute_posY: 226,
                    minute_path: "67.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 
				normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG,{
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    pos_x: 454/ 2 - 28,
                    pos_y: 454 / 2 - 227,
                    center_x: 227,
                    center_y: 227,
                    src: "68.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
            });
            setSec();
				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "69.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), p = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 187,
                    y: 306,
                    w: 80,
                    h: 40,
                    text: "[SC]",
                    color: "0xFFf5af83",
                    text_size: 28,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 225,
                    hour_posX: 28,
                    hour_posY: 209,
                    hour_path: "70.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 29,
                    minute_posY: 226,
                    minute_path: "67.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), i || (i = hmSensor.createSensor(hmSensor.id.HEART)), a || (a = hmSensor.createSensor(hmSensor.id.STEP)), s || (s = hmSensor.createSensor(hmSensor.id.TIME)), i.addEventListener(i.event.LAST, (function () {
                    r.setProperty(hmUI.prop.MORE, {
                        text: `${i.last}`
                    })
                })), a.addEventListener(hmSensor.event.CHANGE, (function () {
                    _.setProperty(hmUI.prop.MORE, {
                        text: `${a.current}`
                    }), p.setProperty(hmUI.prop.MORE, {
                        text: `${a.current}`
                    })
                })), s.addEventListener(s.event.DAYCHANGE, (function () {
                    o = hmSetting.getDateFormat(), h = [() => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(s.day).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(s.day).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(s.day).padStart(2,"0")}`
                        })
                    }], h[o]()
                })), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        r.setProperty(hmUI.prop.MORE, {
                            text: `${i.last}`
                        }), _.setProperty(hmUI.prop.MORE, {
                            text: `${a.current}`
                        }), o = hmSetting.getDateFormat(), h = [() => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(s.day).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(s.day).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(s.day).padStart(2,"0")}`
                            })
                        }], h[o](), p.setProperty(hmUI.prop.MORE, {
                            text: `${a.current}`
                        })
                    }
                })
            }, onInit() {
                m.log("index page.js on init invoke")
            }, build() {
                this.init_view(), m.log("index page.js on ready invoke")
            }, onDestroy() {
                m.log("index page.js on destroy invoke")
            }
        })
    })()
} catch (e) {
    console.log("Mini Program Error", e), e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}